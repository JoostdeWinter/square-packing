Exact feasible upper bound for 229 unit squares: 15.650174756949.
Run python3 verify_exact.py n229_exact.json
Run python3 verify_polygon_exact.py n229_exact.json
Run python3 verify_polygon_clipping.py --witness n229_exact.json --expected-n 229
These are upper bounds, not optimality claims. All three algorithms are same-campaign implementations sharing rational input.
