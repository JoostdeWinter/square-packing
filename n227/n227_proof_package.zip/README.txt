Exact feasible upper bound for 227 unit squares: 15.563796703670.
Run python3 verify_exact.py n227_exact.json
Run python3 verify_polygon_exact.py n227_exact.json
Run python3 verify_polygon_clipping.py --witness n227_exact.json --expected-n 227
These are upper bounds, not optimality claims. All three algorithms are same-campaign implementations sharing rational input.
