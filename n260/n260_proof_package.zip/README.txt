Exact feasible upper bound for 260 unit squares: 16.645778804182.
Run python3 verify_exact.py n260_exact.json
Run python3 verify_polygon_exact.py n260_exact.json
Run python3 verify_polygon_clipping.py --witness n260_exact.json --expected-n 260
These are upper bounds, not optimality claims. All three algorithms are same-campaign implementations sharing rational input.
