Each candidate is a feasible rational witness. Comparisons are signed as previous side minus new side.

Run python3 -B check_vertices.py 232/candidate.json.gz
