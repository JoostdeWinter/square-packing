# Starting layouts and software

Joost de Winter directed this search and certification with OpenAI Codex. The individual comparisons identify the source files and their hashes. Credit for the underlying geometry follows each published case.

| Squares | Starting layout |
|---:|---|
| 90 | Sargis Khachatryan and jazivxt, via Nevska’s explorer. Previous rational witness by Joost de Winter in issue 997 |
| 105 | Xu’s packing and Mykhailo Polkovskyi’s rational certificate, through the earlier search |
| 109 | Navneet Prabhat and Tomáš Kodaj, via Asterios Panoras’s compilation. The earlier exact witness is attached to issue 1012 |
| 129 | Mykhailo Polkovskyi’s published rational witness. The case note identifies related public algebraic packings |
| 130 | alex chilton’s starter kit and Polkovskyi’s earlier rational certificate |
| 156, 180 | The Özden–Polkovskyi packings, through the earlier search |
| 172, 175 | alex chilton’s starter kit. Previous records credited to Doğa Özden at 172 and Evan Daniel at 175 |
| 179 | Sergio Fernández Rubio’s public coordinates. Doğa Özden derived her earlier 179-square construction from Ryan Xu’s packing for 70, as refined by Evan Daniel |
| 182 | Evan Daniel’s cut from Couzo’s 211-square packing based on Ostashev’s design, through Sergio Fernández Rubio’s compilation |
| 199 | Sergio Fernández Rubio’s compilation. The earlier certified packing was registered by Özden and refined by de Winter |
| 228, 268 | Public compilations by alex chilton. The algebraic case notes give the known earlier constructions and submissions |
| 232 | Tomáš Kodaj’s construction, refined by JoeGun, distributed in alex chilton’s public starter kit |
| 237 | Doğa Özden’s packing, issue 960, through the earlier search |
| 259 | Sergio Fernández Rubio’s published 259-square packing. Nevska reached the same numerical side to the leaderboard’s 50 decimal places |
| 260, 272 | prvsiyan, *Squares Verified Best of 1105*, version 25. Polkovskyi provided public rational certificates in issue 1009 |
| 262 | Mykhailo Polkovskyi’s improvement to Joost de Winter’s band construction, registered through issue 1009 |
| 269 | alex chilton’s starter kit and Özden’s registered packing |
| 292 | alex chilton’s starter kit. Previous rational certificates by de Winter and Polkovskyi |
| 295 | Sergio Fernández Rubio’s published arrangement, via de Winter’s rational certificate attached to issue 1037 |
| 299 | Joost de Winter’s diagonal-slice packing from issue 1031, based on 372- and 335-square layouts in Asterios Panoras’s compilation |
| 304 | Evan Daniel after Chris Deotte’s fault-line method, via prvsiyan’s compilation |
| 305 | The Kodaj–JoeGun family as refined in the earlier search |
| 307 | Polkovskyi’s public rational witness |
| 308 | Evan Daniel’s registered packing, via alex chilton’s compilation, with Polkovskyi’s rational certificate as a comparison |

Sergio Fernández Rubio’s source coordinates use CC BY 4.0. His original license and notice accompany this file. The geometry files derived from prvsiyan’s dataset use its CC BY-SA 4.0 license. Özden’s 237-square witness and data carry CC BY 4.0. Evan Daniel developed the number-field reconstruction, contact solver and standard-library algebraic verifier under the included MIT license. The second independent field checker came from the attachment to issue 1037.

- https://www.kaggle.com/datasets/prvsiyan/squares-verified-best-of-1105/versions/25
- https://creativecommons.org/licenses/by-sa/4.0/
- https://creativecommons.org/licenses/by/4.0/
- https://github.com/jlevy/squares/issues/960
- https://github.com/jlevy/squares/issues/1009
- https://github.com/jlevy/squares/issues/1021
- https://github.com/jlevy/squares/issues/1031
- https://github.com/jlevy/squares/issues/1037
- https://github.com/jlevy/squares/issues/1038
