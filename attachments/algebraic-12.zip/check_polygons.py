"""Independent audit by exact polygon vertices and oriented edges over a real algebraic field."""
import argparse
import gzip
import json
from pathlib import Path
from functools import lru_cache
import flint

def inspect(path, bits):
    flint.ctx.prec = bits
    with (gzip.open(path, 'rt') if path.suffix == '.gz' else path.open()) as stream:
        data = json.load(stream)
    mod = flint.fmpq_poly(data['field']['f'])
    def isolated(poly, endpoints):
        a,b = map(lambda v: flint.arb(flint.fmpq(v)), endpoints)
        if a == b:
            if not poly(flint.fmpq(endpoints[0])).is_zero(): raise ValueError('Invalid rational generator')
            return a
        roots = [z.real for z,_ in flint.fmpz_poly(poly.numer()).complex_roots() if z.imag.is_zero() and a < z.real < b]
        if len(roots) != 1: raise ValueError('Root interval failed')
        return roots[0]
    root = isolated(mod, data['field']['t_interval'])
    @lru_cache(None)
    def read(raw):
        return flint.fmpq_poly([flint.fmpq(v) for v in raw]) % mod
    def ball(p):
        a = flint.arb(0)
        for v in reversed(p.coeffs()): a = a * root + v
        return a
    def certified(p,a):
        if a > 0: return 1
        if a < 0: return -1
        if p().is_zero(): return 0
        b=ball(p())
        if b>0:return 1
        if b<0:return -1
        raise ArithmeticError('Increase working precision')
    S=read(tuple(data['S']['in_K']));B=ball(S);poly=flint.fmpq_poly(data['S']['poly']);other=isolated(poly,data['S']['interval'])
    if not B.overlaps(other):raise ValueError('The side lies outside the given interval')
    residue=flint.fmpq_poly()
    for a in reversed(poly.coeffs()):residue=(residue*S+a)%mod
    if not residue.is_zero():raise ValueError('The side polynomial failed')
    corners=[];edges=[];boxes=[]
    for item in data['squares']:
        u=read(tuple(item['u']));x=read(tuple(item['x']));y=read(tuple(item['y']))
        den=1+u*u;g,inv,_=den.xgcd(mod)
        if g.degree()!=0:raise ValueError('Singular rotation')
        inv=inv/g[0];c=((1-u*u)*inv)%mod;s=(2*u*inv)%mod
        for _ in range(item['m']%4):c,s=-s,c
        pts=[((2*x+a*c-b*s)/2,(2*y+a*s+b*c)/2)for a,b in [(1,1),(-1,1),(-1,-1),(1,-1)]]
        pp=[(x,y,ball(x),ball(y))for x,y in pts];cc=[]
        for x,y,xx,yy in pp:
            if min(certified(lambda:x,xx),certified(lambda:y,yy),certified(lambda:S-x,B-xx),certified(lambda:S-y,B-yy))<0:raise ValueError('Board wall crossed')
        for i,(x,y) in enumerate(pts):
            x2,y2=pts[(i+1)%4];x3,y3=pts[(i+2)%4];dx,dy=x2-x,y2-y
            if not ((dx*dx+dy*dy-1)%mod).is_zero() or not ((dx*(x3-x2)+dy*(y3-y2))%mod).is_zero():raise ValueError('Square side or right angle failed')
            A,H=-dy,dx;V=-(A*x+H*y)%mod;cc.append((A,H,V,ball(A),ball(H),ball(V)))
        corners.append(pp);edges.append(cc)
        bx=[z[2]for z in pp];by=[z[3]for z in pp]
        boxes.append((min(z.lower()for z in bx),max(z.upper()for z in bx),min(z.lower()for z in by),max(z.upper()for z in by)))
    n=int(data['n'])
    if len(corners)!=n:raise ValueError('Wrong number of squares')
    def external(edge_set,vertices):
        for A,H,V,ab,hb,vb in edge_set:
            for x,y,xb,yb in vertices:
                b=ab*xb+hb*yb+vb
                if certified(lambda:(A*x+H*y+V)%mod,b)>0:break
            else:return True
        return False
    short=proper=0
    for j,(a,b,c,d) in enumerate(boxes):
        for i,(e,f,g,h) in enumerate(boxes[:j]):
            if b<e or f<a or d<g or h<c:
                short+=1;continue
            if not external(edges[j],corners[i]) and not external(edges[i],corners[j]):raise ValueError(f'Overlapping polygons {i} and {j}')
            proper+=1
    print(f'PASS n={n}, {n*4} sides and right angles, {n*4} vertices inside, {short} disjoint boxes and {proper} separating polygon lines, {short+proper} pairs.',flush=True)

if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__);cli.add_argument('files',nargs='+',type=Path);cli.add_argument('--bits',type=int,default=1400);args=cli.parse_args()
    for file in args.files:inspect(file,args.bits)
