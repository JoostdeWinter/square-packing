For the exact-side register in #811, I request review of 11 exact construction endpoints. The 12th row, n=259, was already attached to #1047 and is included only for replaying the identity at 292. No separate intake of 259 is requested. For each row, the attachment specifies the real root by its polynomial and an isolating interval, gives the center and rotation of every unit square, and verifies wall containment and pairwise separation at that root.

At 172 and 199 this supplies the evidence discussed in #946 and #939. The quintics were reported there with rational witnesses slightly above the roots. The attached witnesses attain the roots themselves. Writing $L_n$ for the side of the specific construction, the certificates give $L_{199}=L_{172}+1$, $L_{268}=L_{129}+5$, and $L_{292}=L_{259}+1$. These are equalities between construction sides. Global optimality remains open.

| $n$ | Feasible side, rounded up | Polynomial degree | Earlier packing or filing |
|---:|---:|---:|---|
| 109 | 10.949289580944 | 44 | #1012 |
| 129 | 11.870013850405 | 7 | [case 129](https://squaremath.org/cases/129.html) |
| 172 | 13.614689853284 | 5 | #946 |
| 175 | 13.764050051544 | 9 | #914 |
| 199 | 14.614689853284 | 5 | #939 |
| 237 | 15.893805580570 | 6 | #960 |
| 259 | 16.590016439230 | 5 | #1040 |
| 262 | 16.698115018700 | 7 | #1009 |
| 268 | 16.870013850405 | 7 | #1021 |
| 269 | 16.889730073593 | 7 | #967 |
| 292 | 17.590016439230 | 5 | #1009 |
| 295 | 17.698042929358 | 12 | #1037 |

**Replay.** Extract `algebraic-12.zip` and run `python3 -B verify_roots.py` from the extracted directory. Run `python3 -B verify_relations.py` to check the three identities directly against the paired polynomials and their isolating intervals. Each case has its own field coordinates, polynomial, rational isolating interval and comparisons. The archived Kaggle leaderboard comparison is dated by version (v38). It already lists smaller numerical sides at 199, 269, 292 and 295.

**Credit.** Please retain the existing layout credits, including the proposed attribution to Samanyu-dev in #1047 at 109, the Daniel–Özden construction at 172 and its extension at 199, and Sergio Fernández Rubio (GeiserX) at 259 and 295. The per-case attribution and software notices accompany the coordinates. I directed the algebraic reconstruction and certificate work using GPT6.2 Astra in OpenAI Codex. Evan Daniel developed the contact solver, number-field reconstruction and primary geometry verifier.

Joost de Winter, Delft University of Technology
