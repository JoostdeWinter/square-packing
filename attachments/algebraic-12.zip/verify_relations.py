"""Check three equalities between the isolated roots in the attached certificates."""
import gzip
import json
from fractions import Fraction
from math import comb
from pathlib import Path

base = Path(__file__).resolve().parent
def side(n):
    with gzip.open(base / f'n{n}' / f'n{n}.minpoly.json.gz', 'rt') as source:
        return json.load(source)['S']

def value(polynomial, x):
    total = Fraction(0)
    for coefficient in reversed(polynomial):
        total = total * x + coefficient
    return total

for smaller, larger, shift in [(172,199,1),(129,268,5),(259,292,1)]:
    p, q = side(smaller), side(larger)
    coefficients = p['poly']
    translated = [sum(coefficients[j] * comb(j,i) * (-shift)**(j-i)
                      for j in range(i,len(coefficients))) for i in range(len(coefficients))]
    if translated != q['poly']:
        raise ValueError(f'Polynomial mismatch for {smaller}, {larger}')
    a,b = map(Fraction,p['interval'])
    c,d = map(Fraction,q['interval'])
    left, right = max(a+shift,c), min(b+shift,d)
    if not (left<right and value(translated,left)*value(translated,right)<0):
        raise ValueError(f'The translated isolating intervals do not isolate a shared root at {larger}')
    print(f'PASS L_{larger} = L_{smaller} + {shift}')
