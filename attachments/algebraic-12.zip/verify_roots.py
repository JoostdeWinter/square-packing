"""Replay the published exact-proof checker and the narrower intervals used for the comparisons."""
from pathlib import Path
from fractions import Fraction as Q
from math import comb
import gzip,json,sys
import verify_algebraic
base=Path(__file__).resolve().parent

def value(poly,x):
 y=Q(0)
 for c in reversed(poly):y=y*x+Q(c)
 return y

def verify(folder):
 c=json.loads((folder/'comparison.json').read_text());n=c['n'];cert=folder/f'n{n}.minpoly.json.gz';d=json.load(gzip.open(cert));s=d['S'];a,b=map(Q,c['isolating_interval']);left,right=map(Q,s['interval']);p=c['modern_polynomial_ascending'];assert p==s['poly'] and left<=a<b<=right and value(p,a)*value(p,b)<0 and b-a<Q(1,10**100)
 for row in c['prior_bounds']:
  q=Q(row['value']);assert q-b==Q(row['minimum_improvement'])>0 and q-a==Q(row['maximum_improvement'])
 k=Q(c['kaggle_row']['L_full']);assert list(map(Q,c['kaggle_gain_interval']))==[k-b,k-a];ulp=Q(1,2*10**50);assert c['kaggle_case']==('strictly smaller' if b<k-ulp else 'same to 50 decimal places' if max(abs(a-k),abs(b-k))<ulp else 'larger than leaderboard')
 for r in c.get('prior_algebraic',[]):
  u,v=map(Q,r['interval']);pp=r['poly'];assert a<b<u<v and value(pp,u)*value(pp,v)<0 and u-b==Q(r['minimum_improvement']) and v-a==Q(r['maximum_improvement'])
  low=high=Q(0)
  for j in range(len(pp)-1,0,-1):
   q=[low*u,low*v,high*u,high*v];low=min(q)+j*pp[j];high=max(q)+j*pp[j]
  assert low>0 or high<0
 for old in c.get('other_fields',[]):
  u=old['poly'];h=old['shift'];co=[sum(q*comb(j,i)*(-h)**(j-i)for j,q in enumerate(u)if j>=i)for i in range(len(u))];assert co==p;lo,hi=map(Q,old['isolation']);assert lo<a-h<b-h<hi
 if len(p)>25:
  import polynomial_arithmetic
  mul,mod=verify_algebraic.pmul,verify_algebraic.pmod
  try:
   verify_algebraic.pmul=polynomial_arithmetic.convolution;verify_algebraic.pmod=polynomial_arithmetic.remainder;verify_algebraic.check(str(cert))
  finally:verify_algebraic.pmul,verify_algebraic.pmod=mul,mod
 else:verify_algebraic.check(str(cert))
 print(f'PASS n={n}, previous exact bounds and leaderboard comparison.');return n
if __name__=='__main__':
 if not __debug__:raise SystemExit('Run with Python assertions enabled.')
 for f in sorted(base.glob('n*/comparison.json')):verify(f.parent)
