"""Validate an algebraic packing with FLINT, using an isolated real root and exact separating axes.
Install python-flint 0.9.0, then run this file on any supplied .minpoly.json or .json.gz certificate.
"""
import argparse
import gzip
import json
from pathlib import Path
import flint

Q = flint.fmpq
Poly = flint.fmpq_poly
ZPoly = flint.fmpz_poly
Ball = flint.arb

def at_root(poly, root):
    result = Ball(0)
    for coefficient in reversed(poly.coeffs()):
        result = result * root + Ball(coefficient)
    return result

class Field:
    def __init__(self, integers, interval):
        self.mod = Poly(integers)
        p = ZPoly(integers)
        factors = p.factor()[1]
        if len(factors) != 1 or factors[0][1] != 1:
            raise ValueError('Field polynomial must be irreducible')
        lo, hi = [Ball(Q(v)) for v in interval]
        roots = [z.real for z, _ in p.complex_roots() if z.imag.is_zero() and z.real > lo and z.real < hi]
        if len(roots) != 1:
            raise ValueError('The given interval must isolate a real root')
        self.root = roots[0]

    def number(self, coefficients):
        p = Poly([Q(c) for c in coefficients]) % self.mod
        return Value(self, at_root(p, self.root), p)

class Value:
    def __init__(self, field, enclosure, polynomial):
        self.field = field
        self.ball = enclosure
        self._poly = polynomial

    @property
    def poly(self):
        if not isinstance(self._poly, Poly):
            self._poly = self._poly() % self.field.mod
        return self._poly

    def __add__(self, other):
        return Value(self.field, self.ball + other.ball, lambda: self.poly + other.poly)

    def __neg__(self):
        return Value(self.field, -self.ball, lambda: -self.poly)

    def __sub__(self, other):
        return Value(self.field, self.ball - other.ball, lambda: self.poly - other.poly)

    def __mul__(self, other):
        return Value(self.field, self.ball * other.ball, lambda: self.poly * other.poly)

    def sign(self):
        if self.ball > 0:
            return 1
        if self.ball < 0:
            return -1
        exact = self.poly
        if exact.is_zero():
            return 0
        sign = at_root(exact, self.field.root)
        if sign > 0:
            return 1
        if sign < 0:
            return -1
        raise ArithmeticError('Increase --bits to decide a nonzero field element')

    def __abs__(self):
        return self if self.sign() >= 0 else -self

def check(path, bits):
    flint.ctx.prec = bits
    with (gzip.open(path, 'rt') if path.suffix == '.gz' else path.open()) as stream:
        data = json.load(stream)
    n = data['n']
    field = Field(data['field']['f'], data['field']['t_interval'])
    one, half = field.number(['1']), field.number(['1/2'])
    S = field.number(data['S']['in_K'])
    coeffs = data['S']['poly']
    residual = Poly()
    for c in reversed(coeffs):
        residual = (residual*S.poly + c) % field.mod
    factors = ZPoly(coeffs).factor()[1]
    if not residual.is_zero() or len(factors) != 1 or factors[0][1] != 1:
        raise ValueError('Side polynomial identity or irreducibility failed')
    lo, hi = [Ball(Q(x)) for x in data['S']['interval']]
    if not (lo < S.ball and S.ball < hi):
        raise ValueError('Side outside the stated interval, or insufficient precision')
    isol = [r for r, _ in ZPoly(coeffs).complex_roots() if r.imag.is_zero() and lo < r.real and r.real < hi]
    if len(isol) != 1:
        raise ValueError('Side interval does not isolate one real root')
    rotations, cells = {}, []
    for sq in data['squares']:
        key = tuple(sq['u']), int(sq['m']) % 4
        if key not in rotations:
            u = field.number(sq['u']).poly
            u2 = (u*u) % field.mod
            g, inv, _ = (1+u2).xgcd(field.mod)
            if g.degree() != 0:
                raise ValueError('Singular rotation')
            inv /= g[0]
            cp, sp = ((1-u2)*inv) % field.mod, (2*u*inv) % field.mod
            for _ in range(key[1]):
                cp, sp = -sp, cp
            if not ((cp*cp+sp*sp-1) % field.mod).is_zero():
                raise ValueError('Rotation has non-unit norm')
            c = Value(field, at_root(cp, field.root), cp)
            s = Value(field, at_root(sp, field.root), sp)
            rotations[key] = c, s, (abs(c)+abs(s))*half
        c, s, h = rotations[key]
        x, y = field.number(sq['x']), field.number(sq['y'])
        if min((x-h).sign(), (S-x-h).sign(), (y-h).sign(), (S-y-h).sign()) < 0:
            raise ValueError(f'Wall violation at square {len(cells)}')
        cells.append((x, y, key))
    if len(cells) != n:
        raise ValueError('Square count mismatch')
    radii, broad, near = {}, 0, 0
    for j, (x, y, angle) in enumerate(cells):
        c, s, h = rotations[angle]
        for i, (xx, yy, other) in enumerate(cells[:j]):
            cc, ss, hh = rotations[other]
            dx, dy = xx-x, yy-y
            halfwidth = h.ball+hh.ball
            if abs(dx.ball) > halfwidth or abs(dy.ball) > halfwidth:
                broad += 1
                continue
            near += 1
            key = angle, other
            if key not in radii:
                radii[key] = (one+abs(c*cc+s*ss)+abs(c*ss-s*cc))*half
            r = radii[key]
            projections = [dx*c+dy*s, dy*c-dx*s, dx*cc+dy*ss, dy*cc-dx*ss]
            projections.sort(key=lambda v: -abs(float(v.ball)))
            if not any((abs(v)-r).sign() >= 0 for v in projections):
                raise ValueError(f'Squares {i} and {j} overlap')
    print(f'PASS n={n}, side degree {len(coeffs)-1}, field degree {field.mod.degree()}, '
          f'{broad} pairs separated by coordinate intervals, {near} pairs checked on square axes, '
          f'{n*(n-1)//2} pairs in total.', flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('certificates', type=Path, nargs='+')
    parser.add_argument('--bits', type=int, default=1800)
    args = parser.parse_args()
    for cert in args.certificates:
        check(cert, args.bits)
