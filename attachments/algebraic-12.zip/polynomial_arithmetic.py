"""Integer convolution for the standard-library checker's rational polynomials."""
from fractions import Fraction
from math import gcd, lcm

def integer_coefficients(poly):
    common = lcm(*(int(x.denominator) for x in poly))
    return [int(x.numerator) * (common // int(x.denominator)) for x in poly], common

def strip(p):
    while p and p[-1] == 0:
        p.pop()
    return p

def convolution(a, b):
    if not a or not b:
        return []
    x, u = integer_coefficients(a)
    y, v = integer_coefficients(b)
    if len(x) == 1:
        out = [x[0] * t for t in y]
    elif len(y) == 1:
        out = [y[0] * t for t in x]
    else:
        # Evaluate both signed polynomials at 2^w. Its balanced digits recover each
        # convolution coefficient because every coefficient has magnitude below 2^(w-1).
        w = max(map(abs, x)).bit_length() + max(map(abs, y)).bit_length() + min(len(x),len(y)).bit_length() + 2
        xx = yy = 0
        for t in reversed(x):
            xx = (xx << w) + t
        for t in reversed(y):
            yy = (yy << w) + t
        value = xx * yy
        mask = (1 << w) - 1
        half = 1 << (w - 1)
        out = []
        for _ in range(len(x) + len(y) - 1):
            t = value & mask
            if t >= half:
                t -= mask + 1
            out.append(t)
            value = (value - t) >> w
        assert value == 0
    return [Fraction(t, u*v) for t in strip(out)]

def remainder(a, f):
    if len(a) < len(f):
        return strip(list(a))
    a, den = integer_coefficients(a)
    f, _ = integer_coefficients(f)
    lead = f[-1]
    while len(a) >= len(f):
        top = a[-1]
        if top:
            mult = abs(lead) // gcd(lead, top)
            if mult != 1:
                a = [v*mult for v in a]
                den *= mult
            fac = a[-1] // lead
            off = len(a)-len(f)
            for j, c in enumerate(f):
                a[off+j] -= fac*c
        strip(a)
    return [Fraction(t,den) for t in a]
