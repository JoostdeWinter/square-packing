"""Replay the supporting-line checker with the FLINT rational-polynomial backend."""
from fractions import Fraction
from pathlib import Path
import sys
import flint
import verify_algebraic as checker

def fp(poly):
    return flint.fmpq_poly([flint.fmpq(int(x.numerator), int(x.denominator)) for x in poly])

def coefficients(poly):
    return [Fraction(int(c.p), int(c.q)) for c in poly.coeffs()]

def multiply(a, b):
    return coefficients(fp(a) * fp(b))

def remainder(a, f):
    if len(a) < len(f):
        return checker.trim(a)
    return coefficients(fp(a) % fp(f))

if __name__ == '__main__':
    if not __debug__:
        raise SystemExit('Run with assertions enabled.')
    checker.pmul = multiply
    checker.pmod = remainder
    for path in sys.argv[1:]:
        checker.check(str(Path(path)))
