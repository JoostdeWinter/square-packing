"""Validate inputs and archived receipts; recompute all transfer bounds using exact arithmetic."""
import gzip
import hashlib
import json
import math
import sys
from pathlib import Path
from fractions import Fraction as Q
from functools import lru_cache

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "code"))
from bm import rows as integer_rectangles
from angular_assignment import assess, assess_domains
from transfer import bound, display_floor, half_width, hybrid109, regular_cells

EVIDENCE = HERE / "evidence"
PREVIOUS = {r["n"]: r for r in json.loads((HERE/"previous_transfers.json").read_text())}


def json_gz(p):
    return json.loads(gzip.decompress(p.read_bytes()))


@lru_cache(None)
def measure(part):
    z = json_gz(EVIDENCE / part / "measure.json.gz")
    L, B = Q(z["L"]), Q(z["B"])
    assert not z["points"] and 0 < B < 1 < L
    total = Q(0)
    for row in z["rectangles"]:
        x, y, X, Y = map(Q,row["rectangle"])
        mass = Q(row["mass"])
        assert 0 <= x < X <= L and 0 <= y < Y <= L and mass >= 0
        total += mass
    assert total == Q(z["total_mass"]) < z["n"]
    return z


def source_row(r):
    assert r["verdict"] == "verified" and Q(r["threshold"]) == 1
    assert Q(str(r["min_certified_lower_bound"])) >= 1


def lines(p):
    return [json.loads(line) for line in gzip.decompress(p.read_bytes()).splitlines()]


def matching_rectangles(a,b):
    if a["rectangles"] == b["rectangles"]: return True
    return len(a["rectangles"]) == len(b["rectangles"]) and all(
        tuple(map(Q,x["rectangle"])) == tuple(map(Q,y["rectangle"])) and Q(x["mass"]) == Q(y["mass"])
        for x,y in zip(a["rectangles"],b["rectangles"]))


def published_binding(part,z):
    n=z["n"]; p=EVIDENCE/part; f=p/"original_coverage.jsonl.gz"
    ref=PREVIOUS[n]; raw=(p/"measure.json.gz").read_bytes()
    assert ref["input_sha256"] in {hashlib.sha256(b).hexdigest() for b in (raw,gzip.decompress(raw))}
    assert ref["receipt_sha256"] == hashlib.sha256(f.read_bytes()).hexdigest()
    original=lines(f); meta=original.pop()["premises"]
    assert meta["format"]=="M" and meta["centre_domain"]=="per-bin" and meta["input_sha256"]==ref["input_sha256"]
    assert Q(meta["mass_exact"])==Q(z["total_mass"]) and Q(meta["L"])==Q(z["L"]) and Q(meta["B"])==Q(z["B"])
    return {r["r"]:r for r in original}


_input_digests = {}


def verify_integer_input(z, meta):
    assert (meta["G"], meta["DS"], meta["M"]) == (2**30, 2**32, 2**48)
    key=hashlib.sha256(json.dumps([z["L"],z["total_mass"],z["rectangles"]],sort_keys=True,separators=(",",":")).encode()).digest()
    if key in _input_digests:
        assert _input_digests[key]==(meta["rectangles"],meta["rects_sha256"])
        return
    digest = hashlib.sha256()
    digest.update((str(meta["rectangles"]) + "\n").encode())
    count = 0
    for row in integer_rectangles(z):
        digest.update((" ".join(map(str, row)) + "\n").encode())
        count += 1
    assert count == meta["rectangles"] and digest.hexdigest() == meta["rects_sha256"]
    _input_digests[key]=(count,digest.hexdigest())


@lru_cache(None)
def coverage(part):
    z=measure(part); p=EVIDENCE/part; step=Q(z["proof_net"]["step"]); records=lines(p/"coverage.jsonl.gz"); seen=set()
    prior=None;binding=None
    if part.startswith("published_"):binding=published_binding(part,z)
    if any(x["method"]=="inherited_even" for x in records):
        n=z["n"];och="original108" if n==108 else f"published_n{n}"
        dz=measure(och); assert z["n"]==dz["n"] and Q(z["B"])==Q(dz["B"]) and Q(z["L"])==Q(dz["L"])
        assert Q(z["total_mass"])==Q(dz["total_mass"]) and matching_rectangles(z,dz)
        assert 2*step==Q(dz["proof_net"]["step"]) and z["proof_net"]["last"]==2*dz["proof_net"]["last"]
        if n==108:
            old=[r for f in sorted((EVIDENCE/och).glob("directions*.gz")) for r in lines(f) if "r" in r]
            prior={x["r"]:x for x in old}
        else:prior=published_binding(och,dz)
    if any(x["method"]=="integer" for x in records):
        meta=json.loads((p/"integer_run.json").read_text())
        assert meta["measure_sha256"]==hashlib.sha256((p/"measure.json.gz").read_bytes()).hexdigest()
        assert meta["source_sha256"]==hashlib.sha256((HERE/"code/bmcheck.cpp").read_bytes()).hexdigest()
        assert meta.get("center_domain","parent_bin")==z.get("proof_center_domain","parent_bin")
        verify_integer_input(z, meta)
    for row in records:
        kind=row["method"];r=row["evidence"];i=r["r"]
        assert i not in seen and isinstance(i,int) and 0<=i<=z["proof_net"]["last"];seen.add(i)
        if kind=="integer":
            assert r["verdict"]=="PASS" and r["lower_units"]>=2**48 and r["leaves"]>0 and r["nodes"]>=r["leaves"]
            if "header" in r:
                t=i*step;P,W=t.numerator,t.denominator;C,H,E=W*W-P*P,2*P*W,P*P+W*W
                G=2**30;B=Q(z["B"]);L=Q(z["L"]);v=half_width(max(Q(0),t-step/2))
                if z.get("proof_center_domain")=="contained_core":v=B*Q(C+H,2*E)
                lo=math.floor(G*L/2);hi=math.ceil(G*(L-v));cut=math.floor(E*G*B/2)
                assert r["header"]==[C,H,E,cut//E,cut%E,lo,lo,hi,hi]
        elif kind=="interval":
            assert r["verdict"]=="PASS" and r["engine_verdict"]=="DECIDED" and r["min_bound"]>=1 and r["unresolved"]==0
            t=i*step;assert Q(r["tangent"])==t and Q(r["cos"])==(1-t*t)/(1+t*t) and Q(r["sin"])==2*t/(1+t*t)
            assert Q(r["domain_upper"])==Q(z["L"])-half_width(max(Q(0),t-step/2))
        elif kind=="source":
            source_row(r);assert binding[i]==r
        elif kind=="inherited_even":
            assert i==2*r["original_index"] and r["source_direction"]==prior[i//2];source_row(r["source_direction"])
        else:raise ValueError(kind)
    return seen


def results(only=None):
    result={}
    for spec in json.loads((HERE/"sources.json").read_text()):
        if only is not None and spec["id"] not in only: continue
        ids=spec["parts"];z=measure(ids[0]);n=z["n"];L=Q(z["L"]);B=Q(z["B"]);D=Q(z["proof_net"]["step"]);K=z["proof_net"]["last"]
        assert n==spec["n"] and L==Q(spec["board"])
        assignment="regular"
        if spec["mode"]=="regular":
            assert coverage(ids[0]) == set(range(K+1));cells=regular_cells(D,K,B)
        elif spec["mode"]=="standalone_subnet":
            indices=coverage(ids[0]);grid=[(i*D,max(Q(0),i*D-D/2)) for i in sorted(indices)]
            S,u,m=assess(L,grid,B);assignment="adaptive on a verified subset"
        elif spec["mode"]=="wider_domain":
            assert coverage(ids[0])==set(range(K+1))
            domains=[];fully=set()
            for part in ids:
                q=measure(part);step=Q(q["proof_net"]["step"])
                assert q["n"]==n and Q(q["L"])==L and Q(q["B"])==B and matching_rectangles(z,q)
                for i in coverage(part):
                    t=i*step
                    if q.get("proof_center_domain")=="contained_core":
                        domains.append((t,B*half_width(t)));fully.add(t)
                    else:
                        domains.append((t,half_width(max(Q(0),t-step/2))))
            S,u,m=assess_domains(L,domains,B);assignment="broader independently verified center boxes"
            tt=sorted(fully)
            if len(tt)>=2 and tt[0]==0 and tt[-1]*tt[-1]+2*tt[-1]>=1 and max(b-a for a,b in zip(tt,tt[1:]))<Q(1,50):
                _,uc,_=assess_domains(L,[(t,B*half_width(t))for t in tt],B)
                if L/uc>S:S,u,m=L/uc,uc,Q(0);assignment="every contained core at the chosen directions"
        elif spec["mode"]=="combined_core":
            q=measure(ids[1])
            assert z["n"]==q["n"] and Q(q["L"])==L and Q(q["total_mass"])==Q(z["total_mass"])
            assert z["proof_net"]==q["proof_net"] and matching_rectangles(z,q)
            core=max(B,Q(q["B"]))
            indices=sorted(coverage(ids[0]) | coverage(ids[1]))
            grid=[(i*D,max(Q(0),i*D-D/2)) for i in indices]
            S,u,m=assess(L,grid,core);assignment="larger common core across certified subsets"
        elif spec["mode"]=="irregular":
            q=measure(ids[1]);newstep=Q(q["proof_net"]["step"])
            assert Q(q["L"])==L and Q(q["B"])==B and q["n"]==n and Q(q["total_mass"])==Q(z["total_mass"])
            assert matching_rectangles(z,q) and coverage(ids[0])==set(range(K+1))
            extra=coverage(ids[1]);assert extra and 2*newstep==D and q["proof_net"]["last"]==2*K
            grid=[(i*D,max(Q(0),i*D-D/2)) for i in range(K+1)]
            grid.extend((i*newstep,max(Q(0),i*newstep-newstep/2)) for i in extra)
            S,u,m=assess(L,grid,B);assignment="adaptive with extra directions"
        else:
            zz=measure(ids[1])
            assert spec["mode"]=="hybrid109" and coverage(ids[0])==set(range(1,K+1)) and coverage(ids[1])=={0,1}
            assert matching_rectangles(z,zz) and Q(z["L"])==Q(zz["L"]) and Q(z["total_mass"])==Q(zz["total_mass"])
            assert Q(zz["proof_net"]["step"])==D/2;cells=hybrid109(D,K,B,Q(zz["B"]))
        if spec["mode"] not in ("irregular","standalone_subnet","combined_core","wider_domain"):S,u,m=bound(L,cells)
        if spec["mode"]=="regular":
            grid=[(i*D,max(Q(0),i*D-D/2)) for i in range(K+1)]
            alt=assess(L,grid,B)
            if alt[0]>S:S,u,m=alt;assignment="adaptive"
        result[spec["id"]]=dict(n=n,board=str(L),lower=str(S),lower_floor_12=display_floor(S),scale=str(u),margin=str(m),assignment=assignment)
    return result


if __name__=="__main__":
    for key,row in results().items():
        print(f"{key:28} {row['lower_floor_12']}")
