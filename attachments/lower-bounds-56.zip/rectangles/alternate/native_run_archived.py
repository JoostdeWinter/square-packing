from pathlib import Path
from fractions import Fraction as F
import argparse,gzip,json,sys,concurrent.futures,time,os,hashlib
root=Path(__file__).resolve().parent;base=root.parent;sys.path.insert(0,str(root));import rv1018_common as cm,rv1018_decide as rv
def run_task(r):
 h,meta=rv.direction_header(r,step,B,L,F(1),9e6,8)
 fn=scratch/f'in{os.getpid()}.bin';rv.write_input(fn,h,recs)
 import subprocess
 p=subprocess.run([str(exe),str(fn)],capture_output=True,text=True,check=True);out=rv.parse_output(p.stdout);out.update(meta);out['verdict']='PASS' if out['engine_verdict']=='DECIDED' and out['min_bound']>=1. else 'INCOMPLETE';return out
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('source');p.add_argument('n',type=int);p.add_argument('L');p.add_argument('B');p.add_argument('last',type=int);p.add_argument('workers',type=int);p.add_argument('mode');p.add_argument('--tag',default='');a=p.parse_args()
 srcpath=Path(a.source);orig=json.load(gzip.open(srcpath));L=F(a.L);B=F(a.B);step=F(83,200*a.last);q=L/F(orig['L']);mass=F(a.n)-F(1,100000);weight=mass/F(orig['total_mass'])
 for row in orig['rectangles']:
  row['rectangle']=[str(F(v)*q) for v in row['rectangle']]
  row['mass']=str(F(row['mass'])*weight)
 orig.update(n=a.n,L=str(L),B=str(B),proof_net={'step':str(step),'last':a.last},total_mass=str(mass))
 label=f'n{a.n}_L{a.L}_B{a.B}_r{a.last}'+a.tag;scratch=root/'runs'/label;scratch.mkdir(parents=True,exist_ok=True)
 raw=(json.dumps(orig,separators=(',',':'))+'\n').encode();mpath=scratch/'measure.json.gz';mpath.write_bytes(gzip.compress(raw,mtime=0));meas=cm.read_measure(mpath)
 rects=cm.expand(meas['rows'],L);recs=rv.rect_records(rects,F(1));exe,build=rv.build(scratch)
 if a.mode=='odd':dirs=list(range(1,a.last+1,2))
 elif a.mode=='all':dirs=list(range(1,a.last+1))
 elif a.mode=='pilot':dirs=list(dict.fromkeys([1,3,5,9,15,25,41,65,101]+[int(x*a.last//15)|1 for x in range(2,15)]));dirs=[r for r in dirs if r<=a.last]
 else:dirs=[int(i) for i in a.mode.split(',')]
 log=scratch/'directions.jsonl';done={j['r'] for line in log.read_text().splitlines() for j in [json.loads(line)] if j['verdict']=='PASS'} if log.exists() else set()
 dirs=[r for r in dirs if r not in done];(scratch/'meta.json').write_text(json.dumps(dict(build=build,source=str(srcpath),side=str(L),B=str(B),last=a.last,measure_sha256=hashlib.sha256(raw).hexdigest()),indent=1))
 with concurrent.futures.ProcessPoolExecutor(a.workers) as ex,open(log,'a',buffering=1) as f:
  fut={ex.submit(run_task,r):r for r in dirs}
  for result in concurrent.futures.as_completed(fut):
   row=result.result();f.write(json.dumps(row)+'\n')
