"""Compute an exact lower bound from an arbitrary list of certified directions."""
from fractions import Fraction as Q
from functools import lru_cache
from math import isqrt
from transfer import half_width, above_diagonal, H


def _separator(c, d, a, b, core, rho):
    left = max(c, (d-rho)/(1+d*rho))
    right = min(d, (c+rho)/(1-c*rho))
    assert left <= right
    dc, dd, side = float(c), float(d), float(core)
    domain_difference = float(a-b)

    def cost(t):
        def v(z):
            return (1+2*z-z*z)/(2*(1+z*z))
        p = 2*side*v((t-dc)/(1+t*dc))
        q = 2*side*v((dd-t)/(1+t*dd))
        return domain_difference + (p-q)/(4*v(t))

    # This proposes a rational separator. The verification below uses only exact endpoints.
    x, y = float(left), float(right)
    if cost(x) >= 0:
        return left
    if cost(y) <= 0:
        return right
    i, j = 0, 1024
    while j-i > 1:
        k = (i+j)//2
        if cost(x+(y-x)*k/1024) <= 0:
            i = k
        else:
            j = k
    return left+(right-left)*j/1024


@lru_cache(maxsize=110)
def domain_constants(records, core):
    """Each record gives a direction tangent and the start of its certified center domain."""
    cutoff = next(i for i,row in enumerate(records) if above_diagonal(row[0]))
    records = records[:cutoff+1]
    assert 0<=records[0][0]<Q(1,50) and all(records[j][0]<records[j+1][0] for j in range(cutoff))
    gap = max((d-c)/(1+c*d) for (c,a),(d,b) in zip(records,records[1:]))
    precision=10**22
    rad=1+gap*gap
    sqrt_lower=Q(isqrt(rad.numerator*precision**2//rad.denominator),precision)
    rho=max(records[0][0],gap/(1+sqrt_lower))
    assert 0<rho<Q(1,50)
    bounds=[Q(0)]
    for (c,a),(d,b) in zip(records,records[1:]):
        bounds.append(_separator(c,d,a,b,core,rho))
    bounds.append(records[-1][0])
    assert above_diagonal(bounds[-1])
    states=[]
    end=Q(0)
    for (c,a),l,h in zip(records,bounds,bounds[1:]):
        assert 0<a<Q(1) and l==end and l<=c<=h
        for u,v in [(l,c),(c,h)]:
            if u==v:continue
            for x,y in [(u,(u+v)/2),((u+v)/2,v)]:
                assert end==x and x<y
                end=y
                if above_diagonal(x):continue
                z=max(abs(c-x)/(1+c*x),abs(c-y)/(1+c*y))
                assert z<=rho
                width=2*core*half_width(z)
                max_half=H if above_diagonal(y) else half_width(y)
                states.append((width,a,half_width(x),max_half))
    assert end==bounds[-1]
    U=max(p for p,a,l,V in states)
    margin=max(Q(0),max(a-U*l-(U-p)/(4*V) for p,a,l,V in states))
    return U,margin


def assess_domains(board, records, core):
    by_t={}
    for t,width in records:
        by_t[t]=min(by_t.get(t,width),width)
    U,m=domain_constants(tuple(sorted(by_t.items())),core)
    return (board-2*m)/U,U,m


def assess(board, records, core):
    return assess_domains(board, [(t,half_width(a)) for t,a in records], core)
