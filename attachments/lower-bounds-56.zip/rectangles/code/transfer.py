"""Exact contraction for non-uniform direction cells of rectangle measures."""
from fractions import Fraction as Q

H = Q(707106781186548, 10**15)
assert H**2 > Q(1, 2)


def half_width(t):
    return (1 + 2*t - t*t) / (2*(1+t*t))


def above_diagonal(t):
    return t*t + 2*t > 1


def regular_cells(step, last, core, start_index=0):
    for r in range(start_index, last+1):
        center = r*step
        left = max(Q(0), center-step/2)
        yield (left, center+step/2, center, left, core)


def bound(board, cells):
    """A row is (assigned left, assigned right, core tangent, certified domain left, core side)."""
    cover = Q(0)
    usable = []
    for low, high, center, domain_start, core in sorted(cells):
        if above_diagonal(low):
            continue
        assert 0 <= domain_start <= low <= cover and low < high and core > 0
        assert 0 <= center < Q(1,2) and not above_diagonal(domain_start)
        cover = max(cover, high)
        z = max(abs(center-low)/(1+center*low), abs(center-high)/(1+center*high))
        assert z < Q(1,100)
        projected = 2*core*half_width(z)
        parent_max = H if above_diagonal(high) else half_width(high)
        usable.append((projected, parent_max, half_width(low), half_width(domain_start)))
    assert usable and above_diagonal(cover)
    scale = max(row[0] for row in usable)
    assert scale > 0
    margins = [domain_min-scale*parent_min-(scale-p)/(4*parent_max)
               for p,parent_max,parent_min,domain_min in usable]
    margin = max(Q(0), max(margins))
    return (board-2*margin)/scale, scale, margin


def hybrid109(step, last, coarse_core, bridge_core):
    q = step/2
    cells = list(regular_cells(step,last,coarse_core,1))
    lo,hi,t,ar,b = cells[0]
    cells[0] = (3*q/2,hi,t,ar,b)
    return [(Q(0),q/2,Q(0),Q(0),bridge_core),
            (q/2,3*q/2,q,q/2,bridge_core)]+cells


def display_floor(x,places=12):
    k=x.numerator*10**places//x.denominator
    return f"{k//10**places}.{k%10**places:0{places}d}"
