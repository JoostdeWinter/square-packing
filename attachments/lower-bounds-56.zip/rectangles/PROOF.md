# A lower bound from certified square cores

Let L be a board side. A nonnegative, square-symmetric, absolutely continuous rectangle measure on [0,L]² has total mass strictly less than n. A direction record has half-angle tangent c, a core side B and a lower endpoint a for the allowed parent tangents. The computational premise is that the core has measure at least one at every center whose two coordinates are in [v(a),L−v(a)], where

    v(t) = (1 + 2t − t²) / [2(1+t²)].

A turned unit square at angle 2 atan(t) has half-width v(t) in each board direction for 0 ≤ t ≤ √2−1. A quarter turn preserves the orientation of a square modulo π/2 and sends each center quadrant to the top-right quadrant in turn. Reflection reduces parent orientation to [0,π/4]. These symmetries explain the center quadrant used in the computation.

## Assigning directions and moving the core

Assign each possible tangent t to a closed interval [l,h] and a certified record (c,a,B), with its recorded center-domain endpoint a. Only t ≤ √2−1 is needed. The tangent of half the difference of the two orientations is |t−c|/(1+tc). Its largest value on [l,h] occurs at an endpoint. Write z for that maximum. In the records used here z < 1/100. An inscribed core therefore has total width at most p = 2Bv(z) in either parent direction.

Let u be the largest p of all the assigned intervals. The argument applies to every positive u. On an interval write V = v(h) if h ≤ √2−1 and V = 707106781186548/10¹⁵ otherwise. The latter is a rational upper bound for 1/√2. Thus v(l) ≤ v(t) ≤ V. Define d = (u−p)/(4V). The core can move by at most d in each board coordinate while remaining in a concentric parent of side u. Indeed, its center displacement on either parent axis is at most (cos θ + sin θ)d = 2v(t)d, which is at most half the unused width.

Choose

    m = max over the intervals of max(0, v(a) − u v(l) − d),
    S = (L − 2m) / u.

If n unit squares fit in side S, dilate the configuration by u and translate it by (m,m) into the L-board. A parent center is at least m+u v(t) from every board edge. Clamp its two coordinates to [v(a),L−v(a)]. Each moves by at most d. The chosen core fits in its parent and its center is covered by the certified record. Different parent interiors are disjoint. Boundaries of the cores have zero measure, so the n cores capture at least n in total, contradicting the mass budget. Consequently s(n) ≥ S. A result for n also applies to every larger count by removing squares.

The arithmetic program evaluates these expressions over exact rationals. All reported lower decimals are rounded down. Using v(a) directly in the margin exploits the center domain the checker actually certified. The earlier transfer used v(t) to bound that requirement.

## Direction records and sources

A regular grid has c = rD and certified domain lower endpoint a = max(0,c−D/2). An even index in a grid with half the step of the original has the same c. Its old a is smaller, so its original coverage includes the newly required center domain. This reuse requires the same measure, total mass, core side and board side.

For the 10.64-board experiment at n = 109, D = 83/160000. The main grid uses B = 0.99948 and indices 1 through 800. A second grid with step q = D/2 uses B = 0.9997 at indices 0 and 1. Both measures have exactly the same rectangles and weights. Assign [0,q/2] to the fine index 0, [q/2,3q/2] to the fine index 1, and [3q/2,3D/2] to the main index 1. The remaining regular intervals begin at 3D/2. The main index 1 was checked down to D/2 and therefore covers its assigned centers.

## Adapting the switch between neighboring directions

The certified start of the center domain, a, may exceed the left end of the assigned angle cell. The same margin proof applies. The expression v(a) − u v(l) explicitly pays for this difference. This freedom lets the assignment favor the direction with the wider verified center domain near the boundary. Each pair of consecutive tangents c and d has angular half-gap tangent (d−c)/(1+cd). A rational upper bound on the half-angle tangent of half that gap defines overlapping permissible intervals for the two directions. The program chooses a rational separator in their intersection and partitions each resulting cell at its own direction and at the two half-interval midpoints. It then checks coverage of the whole angle range, the projection extents and the center margins in exact rational arithmetic. Floating-point comparisons only select a proposed separator.

Some results use extra directions on a subset of the original angle gaps. Each original direction keeps the broader center domain certified by the published verifier. The additional directions use the smaller angular cell used in their independent integer check. The same calculation checks both types together. The exact transfer file identifies the winning assignment.

Some directions can be certified with a larger core on the identical measure. For a fixed center and orientation the larger core contains the smaller one. The smaller-core coverage therefore remains valid at the larger core size. The verifier checks the equality of geometry, weights, center domains and mesh, joins the two sets of successful directions, and uses the larger core side throughout the angle transfer.

A direction marked contained_core uses the entire center box of a contained B-core. Its clearance is B v(c). The wrapper rounds that box outward exactly. The variable-angle proof accepts this clearance directly in place of v(a). When a set of such directions independently covers the full angle interval, each centered core fits within its parent and hence within the board. In that case the board margin can be zero and L/u is also valid.
