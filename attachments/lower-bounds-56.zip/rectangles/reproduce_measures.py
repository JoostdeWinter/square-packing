"""Recreate the 82- and 112-square measures from archived exact source data."""
from fractions import Fraction as Q
from pathlib import Path
import gzip,json
R=Path(__file__).resolve().parent
def load(path):return json.loads(gzip.decompress(path.read_bytes()))
def rectangle_measure_82():
    z=load(R.parent/'linear/evidence/n82/candidate.json.gz');L=Q(z['L']);width=Q(1,20000);rectangles=[]
    def add(x,y,X,Y,mass):
        x,X=sorted((x,X));y,Y=sorted((y,Y))
        if x==X:x,X=max(Q(0),x-width),min(L,X+width)
        if y==Y:y,Y=max(Q(0),y-width),min(L,Y+width)
        rectangles.append(dict(rectangle=list(map(str,(x,y,X,Y))),mass=str(mass)))
    for row in z['primitives']:
        g=list(map(Q,row['geometry']));mass=Q(row['mass'])
        if row['kind']=='point':add(*g,*g,mass)
        elif row['kind']=='rectangle':add(*g,mass)
        else:
            x,y,X,Y=g;length=max(abs(X-x),abs(Y-y))
            count=max(2,min(96,1+int(length*96))) if x!=X and y!=Y else 1
            dx,dy=(X-x)/count,(Y-y)/count
            for i in range(count):add(x+i*dx,y+i*dy,x+(i+1)*dx,y+(i+1)*dy,mass/count)
    result=dict(n=82,L=str(L),B=z['B'],total_mass=z['total_mass'],points=[],rectangles=rectangles,proof_net={'step':'83/160000','last':800})
    assert result==load(R/'evidence/smoothed_n82/measure.json.gz')
    return len(rectangles)
def reweighted_112():
    z=load(R/'evidence/learned_n113/measure.json.gz');want=load(R/'evidence/tuned_n112_from113/measure.json.gz')
    mass=Q(112)-Q(1,100000);factor=mass/Q(z['total_mass'])
    for row in z['rectangles']:row['mass']=str(factor*Q(row['mass']))
    z.update(n=112,total_mass=str(mass),B=str(Q('0.99948125')),proof_net={'last':800,'step':'83/160000'})
    assert z==want
    return len(z['rectangles'])
if __name__=='__main__':
    print(f'82 squares: reproduced all {rectangle_measure_82()} rectangle-orbit weights and positions.')
    print(f'112 squares: reproduced all {reweighted_112()} rectangle-orbit weights and positions.')
