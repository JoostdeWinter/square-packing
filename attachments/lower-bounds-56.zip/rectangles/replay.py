"""Recompute coverage with the bundled integer checker, optionally for a comma-separated index list."""
import argparse
import gzip
import json
import shutil
import subprocess
import sys
from pathlib import Path

root=Path(__file__).resolve().parent
ap=argparse.ArgumentParser()
ap.add_argument("part",help="directory name under evidence, for example hybrid_n109_main")
ap.add_argument("indices",nargs="?",help="all, or comma-separated indices; default is the recorded set")
ap.add_argument("--workers",type=int,default=1)
ap.add_argument("--output",type=Path,default=Path("replay-output"))
ap.add_argument("--cap",type=int,default=3000000)
a=ap.parse_args()
src=root/"evidence"/a.part
if not src.is_dir() or src.parent.resolve()!=(root/"evidence").resolve():ap.error("unknown part")
dest=a.output.resolve()/a.part;dest.mkdir(exist_ok=True,parents=True)
shutil.copyfile(src/"measure.json.gz",dest/"measure.json.gz")
code=a.output.resolve()/"checker";code.mkdir(exist_ok=True)
for name in ["bm.py","bmcheck.cpp"]:shutil.copyfile(root/"code"/name,code/name)
subprocess.run(["c++","-O3","-std=c++17",str(code/"bmcheck.cpp"),"-o",str(code/"bmcheck")],check=True)
idx=a.indices
if idx is None:
    with gzip.open(src/"coverage.jsonl.gz","rt") as f:ids=sorted({json.loads(s)["evidence"]["r"] for s in f})
    idx=",".join(map(str,ids))
subprocess.run([sys.executable,str(code/"bm.py"),str(dest/"measure.json.gz"),idx,str(a.workers),"--cap",str(a.cap)],check=True)
with open(dest/"independent/directions.jsonl") as f:row=[json.loads(s)for s in f]
target=set(range(json.load(gzip.open(dest/"measure.json.gz"))["proof_net"]["last"]+1)) if idx=="all" else set(map(int,idx.split(",")))
passed={r["r"] for r in row if r["verdict"]=="PASS" and r["lower_units"]>=2**48}
if not target<=passed:raise SystemExit(f"Unresolved directions: {sorted(target-passed)}")
print(f"PASS for {len(target)} requested direction(s)")
