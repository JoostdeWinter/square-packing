"""Derive every submitted value from its named proof and check the exact claims table."""
import argparse
import csv
import gzip
import importlib.util
import json
import math
from fractions import Fraction as Q
from pathlib import Path
from io import StringIO
from bound_table import lower

ROOT = Path(__file__).resolve().parent

def load_module(name, relpath):
    spec = importlib.util.spec_from_file_location(name, ROOT / relpath)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def claims_table():
    rect = load_module('submission_rectangles', 'rectangles/verify.py')
    mixed = load_module('submission_mixed', 'mixed/verify.py')
    levels = load_module('submission_levels', 'heterogeneous/verify.py')
    cores = load_module('submission_cores', 'adaptive_cores/verify.py')
    extensions = load_module('submission_extensions', 'extensions/verify.py')
    exact = {}
    rectangles = rect.results()
    stored = json.loads((ROOT / 'rectangles/exact_transfers.json').read_text())
    assert set(rectangles) == set(stored)
    for key, r in rectangles.items():
        assert Q(r['lower']) == Q(stored[key]['lower'])
        exact[key] = (r['n'], 'rational', Q(r['lower']), 'rectangles/PROOF.md')
    for n, reference in json.loads((ROOT / 'mixed/exact_transfers.json').read_text()).items():
        r = mixed.result(int(n))
        assert r == reference
        exact['mixed_n' + n] = (int(n), 'sqrt', Q(r['lower_squared']), 'mixed/PROOF.md')
    for p in (ROOT / 'heterogeneous').glob('n*/transfer.json'):
        manifest = json.loads((p.parent / 'manifest.json').read_text())
        for level in manifest['levels']:
            z = json.loads(gzip.decompress((p.parent / level['measure']).read_bytes()))
            board = Q(z['L'])
            assert z['points'] == [] and int(z['n']) == int(manifest['n'])
            total = Q(0)
            for item in z['rectangles']:
                x, y, right, top = map(Q, item['rectangle'])
                mass = Q(item['mass'])
                assert 0 <= x < right <= board and 0 <= y < top <= board and mass >= 0
                total += mass
            assert total == Q(z['total_mass']) < int(z['n'])
        r = levels.run(p.parent)
        exact['levels_' + r['source_folder']] = (r['n'], 'rational', Q(r['side']), 'heterogeneous/PROOF.md')
    for r in cores.results():
        exact['adaptive_cores_n' + str(r['n'])] = (r['n'], 'rational', Q(r['side']), 'adaptive_cores/PROOF.md')
    for r in extensions.results():
        key = 'extension_' + r['source_id'] + '_to' + str(r['target'])
        if key not in exact or Q(r['side']) > exact[key][2]:
            exact[key] = (r['target'], 'rational', Q(r['side']), 'extensions/PROOF.md')
    prior = json.loads((ROOT / 'attribution/strongest_prior_lower.json').read_text())
    rows = list(csv.DictReader((ROOT / 'lower_bounds.csv').open()))
    buf = StringIO(newline='')
    writer = csv.writer(buf, lineterminator='\n')
    writer.writerow(['n','source_n','derivation','lower_floor_12','exact_kind','rational_value_or_radicand','best_registry_listed_floor_12','previous_comparison_floor_12','certificate_id','proof','coverage'])
    for row in rows:
        n = int(row['n'])
        source, kind, q, proof = exact[row['certificate']]
        assert source == int(row['source_n']) <= n
        b = Q(row['new_lower_floor_12'])
        hi = b + Q(1, 10**12)
        if kind == 'sqrt':
            assert b*b <= q < hi*hi
        else:
            assert b <= q < hi
        assert b > Q(prior[str(n)])
        writer.writerow([n,source,'direct' if n==source else 'monotonicity',row['new_lower_floor_12'],kind,str(q),row['squaremath_best_listed_lower'],row['previous_comparison_floor_12'],row['certificate'],proof,row['coverage']])
    assert lower() == (56,7,27)
    return buf.getvalue()

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--write', action='store_true')
    args = ap.parse_args()
    text = claims_table()
    path = ROOT / 'exact_claims.csv'
    if args.write:
        path.write_text(text)
    else:
        assert text == path.read_text()
    print('PASS. All 56 bounds recomputed, including 49 direct bounds and 7 consequences of monotonicity.')
