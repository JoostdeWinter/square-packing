# Transferring Hosono’s linear certificates to a larger board

Write s(n) for the smallest side of a square containing n unit squares with disjoint interiors. Hiroaki Hosono’s four linear certificates give nonnegative measures on boards of sides L = 9.32, 10.28, 11.26 and 12.24. Their total masses are respectively 82, 101, 122 and 145 minus 0.00001. Each uses closed square cores of side B = 9977/10000. At each listed orientation every such core contained in the board has measure at least one. The original exporter covers a centered box of half-width (L − B(cos θ + sin θ))/2, which is precisely the domain of all centers of contained cores. Square symmetry accounts for the reflected center domains. This last fact matters when reusing the computation. Certificates that verify a more restricted center domain need a separate argument.

## Angle selection

Use θᵣ = 2 atan(rD) for r = 0,…,200, where D = 83/40000. The last angle exceeds π/4 because (1+200D)² > 2. Quarter turns and reflection reduce a parent square’s direction to [0,π/4]. As atan is concave on [0,∞), successive gaps are at most 2 atan D. Pick the nearest angle in angular distance. The error δ is at most atan D. The two axis projections of a centered B-square onto the parent’s axes each have full length B(cos δ + sin δ). Hence a parent of side strictly greater than

    u = B (1 + D) / sqrt(1 + D²)

contains its chosen closed core strictly in its interior.

## Packing contradiction

Suppose n unit squares fit in a board of side S < L/u. Dilate the entire packing to the L-board. The parent squares now have side L/S > u. Their closed cores are disjoint, even if two parents share a boundary. Each core is contained in the board and has mass at least one. The resulting total of at least n contradicts the exact measure budget. Thus

    s(n) ≥ L sqrt(1 + D²) / [B(1 + D)].

Removing squares proves s(m) ≥ s(n) for m ≥ n. The included Python checker uses integer square roots to round each decimal down and verify the next decimal is too large.

## Premises and credit

Hosono constructed all four measures and the original angle certificates. For n = 82, 101 and 145, SquareMath records complete coverage replays. The packet checks the 201 stored source records, their index coverage, candidate bindings and exact mass totals. For n = 122 the first SquareMath audit reran two directions. The later stage-four review in project pull request 1034 decided all 201 independently. This packet includes both original release files matched by SHA-256. The mixed directory also includes this search’s independent integer decisions.

The cases, source history, verifier details and record status are available at the following addresses.

- https://squaremath.org/cases/82.html
- https://squaremath.org/cases/101.html
- https://squaremath.org/cases/122.html
- https://squaremath.org/cases/145.html
- https://github.com/jlevy/squares/tree/1015fc175fa4e2c01f912d915d784100e36d3bab/packing/resources/web
- https://github.com/wand125/square-packing/tree/a9f76c382d023b4095899c4eb7ea7483b8b87ecf/problems/square-lower-bounds

- https://github.com/jlevy/squares/pull/1034
