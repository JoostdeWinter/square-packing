"""Check the exact transfer and its source receipts with the Python standard library."""
import gzip
import hashlib
import json
from fractions import Fraction as Q
from math import isqrt
from pathlib import Path

HERE = Path(__file__).resolve().parent
EV = HERE / "evidence"
TARGETS = {82: [82], 101: [101, 102, 103], 122: list(range(122, 126)), 145: list(range(145, 149))}


def load_gzip(path):
    with gzip.open(path, "rt", encoding="utf-8") as inp:
        return json.load(inp)


def source_parameters(n):
    folder = EV / f"n{n}"
    if n == 122:
        audit = json.loads((folder / "linear-premises.json").read_text())
        c = audit["linear_certificate"]
        report = json.loads((folder / "reported-n122.json").read_text())
        assert audit["status"] == "EXACT_PREMISES_HOLD" and c["d4_invariant"]
        assert report["maintained_replay_sample"]["angles"] == [37, 108]
        assert Q(c["total_mass"]) < n and c["certificate_status"] == "ALL_LINEAR_ANGLES_VERIFIED_AND_REPLAYED"
        if not (folder / "candidate.json.gz").exists():
            return Q(c["side"]), Q(c["core"]), Q(c["net"]["step"]), int(c["net"]["count"]) - 1
        for item in audit["asset"]["files"]:
            if item["path"] in ("candidate.json", "certificate.json"):
                raw = gzip.decompress((folder / (item["path"] + ".gz")).read_bytes())
                assert hashlib.sha256(raw).hexdigest() == item["sha256"]
    data = load_gzip(folder / "candidate.json.gz")
    cert = load_gzip(folder / "certificate.json.gz")
    assert data["n"] == cert["n"] == n and data["schema"] == "point_line_rectangle_v1"
    values = {k: data[k] for k in ("schema", "n", "L", "B", "primitives", "total_mass", "net")}
    digest = hashlib.sha256(json.dumps(values, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    weights = [Q(p["mass"]) for p in data["primitives"]]
    assert cert["candidate_digest"] == digest and all(w >= 0 for w in weights)
    assert sum(weights) == Q(cert["total_mass"]) == Q(data["total_mass"]) < n
    assert cert["status"] == "ALL_LINEAR_ANGLES_VERIFIED_AND_REPLAYED"
    count = data["net"]["last"] + 1
    assert count == cert["angle_count"] and set(map(int, cert["results"])) == set(range(count))
    for i in range(count):
        r = cert["results"][str(i)]
        assert r["index"] == i and r["status"] == "LINEAR_ANGLE_REPLAYED" and r["nodes"] > 0
    assert Q(data["L"]) == Q(cert["L"]) and Q(data["B"]) == Q(cert["B"])
    assert Q(data["net"]["step"]) == Q(cert["net"]["step"])
    return Q(data["L"]), Q(data["B"]), Q(data["net"]["step"]), count - 1


def result(n):
    length, core, step, last = source_parameters(n)
    assert 0 < step < 1 and (1 + last * step) ** 2 >= 2 and last * step < Q(1, 2)
    square = (length / (core * (1 + step))) ** 2 * (1 + step**2)
    scale = 10**12
    k = isqrt(square.numerator * scale**2 // square.denominator)
    assert (Q(k, scale)) ** 2 <= square < (Q(k + 1, scale)) ** 2 and Q(k, scale) > length
    return f"{k // scale}.{k % scale:012}", str(square)


if __name__ == "__main__":
    for source, cases in TARGETS.items():
        lower, squared = result(source)
        status = "source-reported coverage" if source == 122 else "project-replayed coverage"
        print(f"n={','.join(map(str,cases))}  lower={lower}  exact squared side={squared}  {status}")
