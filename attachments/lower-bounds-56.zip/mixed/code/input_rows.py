from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
import math
root=Path(__file__).resolve().parent;G=2**30;M=2**48
def source_rows(z,strips):
 L=F(z['L']);tot=F(0);acc=defaultdict(F)
 for it in z['primitives']:
    k=it['kind'];geo=tuple(map(F,it['geometry']));m=F(it['mass']);assert m>=0;tot+=m
    x,y=geo[:2];X,Y=geo[2:] if k!='point' else geo[:2]
    for flip in (0,1):
     a,b,c,d=(y,x,Y,X) if flip else (x,y,X,Y)
     for l,h in ((a,c),(L-a,L-c)):
      for j,v in ((b,d),(L-b,L-d)):
       if k=='rectangle':
        l0,l1=sorted((l,h));j0,j1=sorted((j,v));lo=j0
        for s in range(1,strips+1):
         hi=j0+(j1-j0)*s/strips;acc[(l0,l0,lo,hi,l1,l1,lo,hi)]+=m/(8*strips);lo=hi
       else:
        A,B=sorted(((l,l,j,j),(h,h,v,v)));acc[A+B]+=m/8
 assert tot==F(z['total_mass'])<z['n'] and sum(acc.values())==tot
 for a,wt in acc.items():
    row=tuple((math.floor if j%2==0 else math.ceil)(v*G)for j,v in enumerate(a));yield (*row,math.floor(wt*M))
