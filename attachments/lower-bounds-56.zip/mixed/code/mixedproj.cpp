// Integer coverage of points, segments and thin horizontal area strips.
#include <cstdint>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <numeric>
#include <vector>
#include <array>
#include <limits>
using I=std::int64_t;using W=__int128_t;
constexpr I G=I(1)<<30,M=I(1)<<48,P=I(1)<<30;
struct Ends{I x,X,y,Y;};struct Interval{I u,U,v,V;};struct Row{Interval a,b,all;I m;};struct Box{I x,X,y,Y;};
I C,H,E,hw;Box orig_domain;std::vector<Row>rows;long long nodes,leaves,terms,cap,least=std::numeric_limits<I>::max();int depthmax=0;
I down(W n){return n>=0?I(n/E):-I((-n+E-1)/E);}
I up(W n){return -down(-n);}
Interval project(Ends a){return {down(W(C)*a.x+W(H)*a.y),up(W(C)*a.X+W(H)*a.Y),down(-W(H)*a.X+W(C)*a.y),up(-W(H)*a.x+W(C)*a.Y)};}
bool full(const Interval&r,const Interval&q){return r.u>=q.U-hw&&r.U<=q.u+hw&&r.v>=q.V-hw&&r.V<=q.v+hw;}
bool outside(const Interval&r,const Interval&q){return r.u>q.U+hw||r.U<q.u-hw||r.v>q.V+hw||r.V<q.v-hw;}
bool restrict_interval(I left,I right,I bound,I&lo,I&hi){
 if(left<=bound&&right<=bound)return true;
 if(left>bound&&right>bound)return false;
 if(left<=bound){I delta=right-left;hi=std::min(hi,I(W(P)*(bound-left)/delta));}
 else{I delta=left-right;lo=std::max(lo,I((W(P)*(left-bound)+delta-1)/delta));}
 return lo<hi;
}
struct Entry{I x=0,y=0,w=0;int key=-1;};constexpr int count=1<<18;std::vector<Entry>cache(count);
I mass(int i,I x,I y,const Interval&q){
 auto key=std::uint64_t(x)*11354029ULL ^std::uint64_t(y)*91942311ULL ^std::uint64_t(i)*764120787ULL;key^=key>>30;key*=0xbf58476d1ce4e5b9ULL;key^=key>>27;key*=0x94d049bb133111ebULL;key^=key>>31; auto&entry=cache[key&(count-1)];
 if(entry.key==i&&entry.x==x&&entry.y==y)return entry.w;
 auto &r=rows[i];I val=0,lo=0,hi=P;
 if(full(r.all,q))val=r.m;
 else if(!outside(r.all,q)&&restrict_interval(r.a.U,r.b.U,q.u+hw,lo,hi)&&restrict_interval(-r.a.u,-r.b.u,hw-q.U,lo,hi)&&restrict_interval(r.a.V,r.b.V,q.v+hw,lo,hi)&&restrict_interval(-r.a.v,-r.b.v,hw-q.V,lo,hi))
  val=I(W(r.m)*(hi-lo)/P);
 entry={x,y,val,i};return val;
}
bool decide(Box b,const std::vector<int>&xs,I inherited,int depth){
 if(++nodes>cap||depth>69)return false;depthmax=std::max(depth,depthmax);
 // This box is in the two axes of the core. Integer inverse interval bounds
 // allow exclusion only outside the original center-domain square.
 if(W(C)*b.X-W(H)*b.y<W(E)*orig_domain.x || W(C)*b.x-W(H)*b.Y>W(E)*orig_domain.X ||
    W(H)*b.X+W(C)*b.Y<W(E)*orig_domain.y || W(H)*b.x+W(C)*b.y>W(E)*orig_domain.Y){return true;}
 Interval qb={b.x,b.X,b.y,b.Y};I px[4]={b.x,b.X,b.x,b.X},py[4]={b.y,b.y,b.Y,b.Y};Interval qs[4];
 for(int k=0;k<4;k++)qs[k]={px[k],px[k],py[k],py[k]};
 I all=inherited,v[4]={};std::vector<int>sub;sub.reserve(xs.size());
 for(int i:xs){auto&r=rows[i];if(outside(r.all,qb))continue;if(full(r.all,qb)){all+=r.m;continue;}sub.push_back(i);
  if(b.X-b.x>G/3||b.Y-b.y>G/3)continue;
  I t[4];int j=0;for(;j<4;j++){terms++;t[j]=mass(i,px[j],py[j],qs[j]);if(!t[j])break;}
  if(j==4)for(int a=0;a<4;a++)v[a]+=t[a];
 }
 I lower=all+*std::min_element(v,v+4);
 if(lower>=M){leaves++;least=std::min(least,(long long)lower);return true;}
 if(std::max(b.X-b.x,b.Y-b.y)<=1){std::cerr<<"unresolved "<<b.x<<" "<<b.y<<" "<<lower<<"\n";return false;}
 Box a=b,c=b;bool hor=b.X-b.x>=b.Y-b.y;I low=hor?b.x:b.y,high=hor?b.X:b.Y,mid=low+(high-low)/2,m=mid,best=(high-low)/6;
 if(high-low>80)for(int rid:sub){auto &r=rows[rid];for(auto ep:{r.a,r.b})for(I e:{(hor?ep.u:ep.v)+hw,(hor?ep.U:ep.V)-hw}){
    I d=std::abs(e-mid);if(d<best&&e>low&&e<high){best=d;m=e;}
 }}
 if(hor){a.X=m;c.x=m;}else{a.Y=m;c.y=m;}

 return decide(a,sub,all,depth+1)&&decide(c,sub,all,depth+1);
}
int main(int argc,char**argv){
 if(argc!=4)return 2;std::ifstream data(argv[1]),hdr(argv[2]);Box box;hdr>>C>>H>>E>>hw>>box.x>>box.X>>box.y>>box.Y;cap=std::atoll(argv[3]);
 if(!hdr||C<0||H<0||C>E||H>E||E<=0||E>20000000000000LL||hw<=0||hw>G||box.x<0||box.X>22*G||box.x>box.X||box.y<0||box.Y>22*G||box.y>box.Y)return 2;
 int n;data>>n;if(!data||n<=0||n>90000)return 2;I tot=0;
 for(int i=0;i<n;i++){Ends a,b;I m;data>>a.x>>a.X>>a.y>>a.Y>>b.x>>b.X>>b.y>>b.Y>>m;
  if(!data||m<0||m>4*M)return 2;
  for(auto e:{a,b})if(e.x<0||e.X>22*G||e.x>e.X||e.y<0||e.Y>22*G||e.y>e.Y)return 2;
  auto A=project(a),B=project(b);Interval T={std::min(A.u,B.u),std::max(A.U,B.U),std::min(A.v,B.v),std::max(A.V,B.V)};
  rows.push_back({A,B,T,m});tot+=m;if(tot>400*M)return 2;
 }
 std::vector<int>xs(n);std::iota(xs.begin(),xs.end(),0);orig_domain=box;auto q=project({box.x,box.X,box.y,box.Y});bool ok=decide({q.u,q.U,q.v,q.V},xs,0,0);
 std::cout<<(ok?"PASS":"UNDECIDED")<<" "<<nodes<<" "<<leaves<<" "<<terms<<" "<<depthmax<<" "<<(ok?least:0)<<"\n";return ok?0:1;
}
