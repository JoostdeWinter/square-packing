"""Rebuild integer checker inputs and recompute the worst angular gap exactly."""
import gzip,hashlib,importlib.util,json,math,sys
from fractions import Fraction as Q
from pathlib import Path
from functools import lru_cache
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'code'))
from input_rows import source_rows
spec=importlib.util.spec_from_file_location('original_linear',root.parent/'linear/verify.py')
linear=importlib.util.module_from_spec(spec);spec.loader.exec_module(linear)
def loadzip(p):return json.loads(gzip.decompress(p.read_bytes()))
@lru_cache(None)
def data(n):
    return loadzip(root.parent/'linear/evidence'/f'n{n}'/'candidate.json.gz')
def integer_rows(n,strips,factor):
    rr=list(source_rows(data(n),strips))
    return str(len(rr))+'\n'+''.join(' '.join(map(str,(*r[:-1],math.floor(r[-1]*factor))))+'\n' for r in rr)
@lru_cache(None)
def digest(n,strips,factor):
    return hashlib.sha256(integer_rows(n,strips,factor).encode()).hexdigest()
def result(n):
    L,B,D,k=linear.source_parameters(n);dirs={D*i for i in range(k+1)}
    count=0;info=[];fresh=set()
    for p in sorted((root/'evidence').glob(f'n{n}_r*')):
        meta=json.loads((p/'meta.json').read_text());z=data(n);step=Q(meta['step'])
        assert n==meta['source_n']==meta['n'] and Q(meta['mass_factor'])==1 and Q(meta['L'])==L and Q(meta['B'])==B
        assert meta['source_sha256']==hashlib.sha256((root.parent/'linear/evidence'/f'n{n}'/'candidate.json.gz').read_bytes()).hexdigest()
        assert meta['cpp_sha256']==hashlib.sha256((root/'code/mixedproj.cpp').read_bytes()).hexdigest()
        assert meta['input_sha256']==digest(n,meta['strips'],Q(1)) and meta['M']==2**48 and meta['G']==2**30
        assert Q(z['total_mass'])<n and Q(z['B'])==B and Q(z['L'])==L
        seen=set()
        with gzip.open(p/'directions.jsonl.gz','rt')as f:
            for line in f:
                q=json.loads(line);i=q['r'];assert isinstance(i,int) and 0<=i<=meta['last'] and i not in seen
                assert q['verdict']=='PASS' and q['nodes']>0 and q['leaves']>0 and q['lower_units']>=2**48
                seen.add(i);dirs.add(step*i);fresh.add(step*i)
        info.append([p.name,len(seen)]);count+=len(seen)
    ts=sorted(dirs);assert ts[0]==0 and ts[-1]**2+2*ts[-1]>1
    # No coverage past the first orientation at or above the physical diagonal is needed.
    ts=ts[:next(j for j,t in enumerate(ts) if t*t+2*t>=1)+1]
    gaps=[(v-u)/(1+u*v)for u,v in zip(ts,ts[1:])]
    g=max(gaps);ss=(L/(B*(1+g)))**2*(1+g*g);dd=10**12;m=math.isqrt(ss.numerator*dd**2//ss.denominator)
    assert Q(m,dd)**2<=ss<Q(m+1,dd)**2
    return dict(id=f'mixed_n{n}',n=n,lower=f'{m//dd}.{m%dd:012}',lower_squared=str(ss),largest_gap_half_tangent=str(g),checked_direction_records=count,all_angles_fresh=all(t in fresh for t in ts),distinct_angles_through_diagonal=len(ts),runs=info)
if __name__=='__main__':
    for n in sorted({int(p.name.split('_')[0][1:])for p in (root/'evidence').glob('n*_r*')}):
        print(json.dumps(result(n)))
