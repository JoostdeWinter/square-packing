"""Recompute archived integer-direction checks, writing work files to a chosen directory."""
import argparse,concurrent.futures,gzip,hashlib,json,math,os,subprocess,sys,time
from pathlib import Path
from fractions import Fraction as Q
from verify import root,integer_rows
def run(i):
    t=i*step;a,b=t.numerator,t.denominator;C=b*b-a*a;H=2*a*b;E=a*a+b*b
    low=math.floor(L*G/2);high=math.ceil((L-B*Q(C+H,2*E))*G);size=math.floor(G*B/2)
    header=dest/f'header-{os.getpid()}.txt';header.write_text(' '.join(map(str,[C,H,E,size,low,high,low,high]))+'\n')
    p=subprocess.run([str(binary),str(datafile),str(header),str(cap)],capture_output=True,text=True)
    vals=p.stdout.split();return dict(r=i,verdict=vals[0]if vals else 'ERROR',nodes=int(vals[1])if vals else 0,lower_units=int(vals[5])if vals else 0)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('run',help='name of a folder under evidence')
    ap.add_argument('indices',nargs='?',help='comma-separated integers, all, or omit to replay the archived set')
    ap.add_argument('--workers',type=int,default=1);ap.add_argument('--cap',type=int,default=9000000);ap.add_argument('--output',type=Path,default=Path('mixed-replay'))
    a=ap.parse_args();rp=root/'evidence'/a.run
    if not rp.is_dir()or rp.parent.resolve()!=(root/'evidence').resolve():ap.error('unknown run')
    z=json.loads((rp/'meta.json').read_text());dest=a.output.resolve()/a.run;dest.mkdir(parents=True,exist_ok=True)
    L=Q(z['L']);B=Q(z['B']);step=Q(z['step']);G=z['G'];cap=a.cap;datafile=dest/'data.txt';binary=dest/'mixedproj'
    datafile.write_text(integer_rows(z['source_n'],z['strips'],Q(z['mass_factor'])));assert hashlib.sha256(datafile.read_bytes()).hexdigest()==z['input_sha256']
    subprocess.run(['c++','-std=c++17','-O3',str(root/'code/mixedproj.cpp'),'-o',str(binary)],check=True)
    if a.indices is None:
        with gzip.open(rp/'directions.jsonl.gz','rt')as f:ids=[json.loads(row)['r']for row in f]
    else:ids=list(range(z['last']+1))if a.indices=='all'else list(map(int,a.indices.split(',')))
    assert all(0<=i<=z['last']for i in ids)
    with concurrent.futures.ProcessPoolExecutor(a.workers)as ex:
        output=list(ex.map(run,ids))
    (dest/'replay.json').write_text(json.dumps(output,indent=2)+'\n')
    if not all(r['verdict']=='PASS'and r['lower_units']>=2**48 for r in output):raise SystemExit('Unresolved directions')
    print('PASS',len(output),'directions')
