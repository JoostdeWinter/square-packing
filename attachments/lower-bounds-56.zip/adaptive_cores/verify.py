"""Check a continuous angle cover using a common scale and each recorded center domain."""
from fractions import Fraction as Q
from pathlib import Path
from functools import lru_cache
import importlib.util,json,math
R=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('rect_level_inputs',R.parent/'rectangles/verify.py')
rect=importlib.util.module_from_spec(spec);spec.loader.exec_module(rect)
base_measure=rect.measure
@lru_cache(None)
def extended_measure(part):
    z=rect.json_gz(rect.EVIDENCE/part/'measure.json.gz')
    if Q(z['B'])<1:return base_measure(part)
    L=Q(z['L']);assert 0<Q(z['B'])<L and not z['points']
    total=Q(0)
    for r in z['rectangles']:
        x,y,X,Y=map(Q,r['rectangle']);w=Q(r['mass'])
        assert 0<=x<X<=L and 0<=y<Y<=L and w>=0
        total+=w
    assert total==Q(z['total_mass'])<z['n']
    return z
rect.measure=extended_measure

def radius(t):return (1+2*t-t*t)/(2*(1+t*t))
def root_bound(x,up):
    prec=10**24;k=math.isqrt(x.numerator*prec**2//x.denominator)
    return Q(k+int(up),prec)
def reaches_diagonal(x):return x*x+2*x>=1
def covers(rows,u,m):
    scales={};thresholds={};intervals=[]
    for t,a,B in rows:
        if B>u:continue
        if B not in scales:
            r=2*B*B-u*u
            assert r>0
            z=(u-B)/(B+root_bound(r,True));assert 0<=z<Q(1,20) and 2*B*radius(z)<=u
            scales[B]=z
        z=scales[B];lo=max(Q(0),(t-z)/(1+t*z));hi=(t+z)/(1-t*z)
        if a is not None:
            if a not in thresholds:
                c=(a-m)/u
                if c<=Q(1,2):safe=Q(0)
                elif 2*c*c>=1:safe=Q(1)
                else:
                    safe=(2*c-1)/(1+root_bound(2-4*c*c,False))
                    if reaches_diagonal(safe):safe=Q(1)
                    else:assert radius(safe)>=c
                thresholds[a]=safe
            lo=max(lo,thresholds[a])
        if lo<=hi:intervals.append((lo,hi))
    end=Q(0)
    for lo,hi in sorted(intervals):
        if lo>end:break
        end=max(end,hi)
        if reaches_diagonal(end):return True
    return False
def check(r):
    parts=r['parts'];z=rect.measure(parts[0]);L=Q(z['L']);n=z['n'];dirs=[]
    for part in parts:
        q=rect.measure(part);assert q['n']==n and Q(q['L'])==L and Q(q['total_mass'])==Q(z['total_mass']) and rect.matching_rectangles(z,q)
        b=Q(q['B']);d=Q(q['proof_net']['step']);dom=q.get('proof_center_domain','parent_bin');assert dom in ('contained_core','parent_bin')
        for i in rect.coverage(part):
            t=i*d;dirs.append((t,None if dom=='contained_core' else radius(max(Q(0),t-d/2)),b))
    m,u,S=map(Q,[r['margin'],r['scale'],r['side']])
    assert m>=0 and 0<u and S==(L-2*m)/u and r['n']==n and covers(dirs,u,m)
    return r
def results():
    return [check(json.load(open(f))) for f in sorted(R.glob('n*.json'))]
if __name__=='__main__':
    for r in results():print(r['n'],rect.display_floor(Q(r['side'])),flush=True)
