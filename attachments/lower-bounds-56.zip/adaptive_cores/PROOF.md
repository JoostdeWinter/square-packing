# Angle coverage with several core sizes and center domains

Use one common scaling factor u and a border of width m. A unit square in a physical board of side (L − 2m)/u becomes a square of side u inside the L-board after scaling and translation. A rectangle measure on the L-board has total mass less than the target integer n. The included direction receipts establish unit capture at every center in their specified domain.

For half-angle tangent t, let v(t) = (1 + 2t − t²)/(2 + 2t²). A core of side B and direction c fits at the center of this parent whenever 2Bv(|t−c|/(1+tc)) ≤ u. For a record whose checker covered all contained cores, this condition suffices. For a record that covered centers of clearance at least a, also require m + u v(t) ≥ a in both board axes. Each parent has at least this clearance at orientation t.

The verifier derives conservative rational endpoints for both conditions. It joins the resulting closed intervals and checks that they cover every orientation up to 45 degrees. Square symmetry gives the remaining directions. Every parent contains a core that captures unit mass. The interiors of n disjoint squares would then require total mass at least n. Rectangle densities give boundaries zero mass.

Run `python3 adaptive_cores/verify.py`. The associated exact measures and center-coverage receipts are in `rectangles/evidence`. Each case file identifies its evidence and the exact rational scale, margin and resulting side.
