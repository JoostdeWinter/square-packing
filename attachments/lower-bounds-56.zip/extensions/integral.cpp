#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <map>
#include <string>
#include <vector>
using I = std::int64_t;
using Wide = __int128_t;
using Densities = std::array<I,4>;
struct Event { I x, y, top, weight; int source; };

std::string decimal(Wide value) {
    if (!value) return "0";
    std::string s;
    while (value) { s.push_back(char('0' + value % 10)); value /= 10; }
    std::reverse(s.begin(),s.end());
    return s;
}
int main() {
    I L,h,sx,syl,syr,R;
    int count;
    if (!(std::cin >> L >> h >> sx >> syl >> syr >> R >> count)) return 2;
    if (L<=0 || L>22000000000LL || h<=0 || h>2000000000LL || count<1 || count>120000) return 3;
    for (auto seam : {sx,syl,syr}) if (seam<h+R || seam>L-R) return 3;
    std::vector<Event> events;
    I total_density=0;
    for (int i=0;i<count;i++) {
        I x,y,X,Y,r;
        if (!(std::cin >> x >> y >> X >> Y >> r) || x<0 || y<0 || x>=X || y>=Y || X>L || Y>L || r<=0 || r>1000000000000000000LL-total_density) return 4;
        total_density+=r;
        for(int a=0;a<2;a++) for(int b=0;b<2;b++) {
            I sy=a?syr:syl;
            I x0=a?std::max(x+h,sx-R):x;
            I x1=a?X+h:std::min(X,sx+R);
            I y0=b?std::max(y+h,sy-R):y;
            I y1=b?Y+h:std::min(Y,sy+R);
            if(x0<x1 && y0<y1) {
                events.push_back({x0,y0,y1,r,2*a+b});
                events.push_back({x1,y0,y1,-r,2*a+b});
            }
        }
    }
    if(Wide(L+h)*(L+h)*total_density >= (Wide(1)<<120)) return 5;
    std::sort(events.begin(),events.end(),[](const Event& a,const Event& b){return a.x<b.x;});
    std::map<I,Densities> jumps;
    Wide integral=0;
    std::size_t i=0;
    while(i<events.size()) {
        auto x=events[i].x;
        while(i<events.size() && events[i].x==x) {
            auto e=events[i++];
            for(auto q : {std::make_pair(e.y,e.weight),std::make_pair(e.top,-e.weight)}) {
                auto& v=jumps[q.first];v[e.source]+=q.second;
                if(v==Densities{}) jumps.erase(q.first);
            }
        }
        if(i==events.size()) break;
        I dx=events[i].x-x, previous=0;
        Densities running{};
        for(auto& [y,delta] : jumps) {
            auto peak=*std::max_element(running.begin(),running.end());
            integral+=Wide(dx)*(y-previous)*peak;
            for(int k=0;k<4;k++){running[k]+=delta[k];if(running[k]<0)return 6;}
            previous=y;
        }
        if(running!=Densities{})return 6;
    }
    std::cout<<decimal(integral)<<"\n";
}
