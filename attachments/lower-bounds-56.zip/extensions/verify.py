"""Verify board extensions using exact rational source data and an independent integer sweep."""
from pathlib import Path
from fractions import Fraction as Q
from functools import lru_cache
import argparse,gzip,hashlib,importlib.util,json,math,subprocess,sys,tempfile
root=Path(__file__).resolve().parent;packet=root.parent
spec=importlib.util.spec_from_file_location('source_rectangles',packet/'rectangles/verify.py');rect=importlib.util.module_from_spec(spec);spec.loader.exec_module(rect)
from angular_assignment import assess
G=10**9;DS=10**7;R=707106782

def rectangles(z,S,u,m):
    L=Q(z['L']);lf=math.floor(S*G);field={}
    assert S*u==L-2*m
    for row in z['rectangles']:
        x,y,X,Y=map(Q,row['rectangle']);w=Q(row['mass'])
        density=math.ceil(w*u*u*DS/(8*(X-x)*(Y-y)))
        if density==0:continue
        for x0,y0,x1,y1 in ((x,y,X,Y),(y,x,Y,X)):
            for a,b in ((x0,x1),(L-x1,L-x0)):
                for c,d in ((y0,y1),(L-y1,L-y0)):
                    q=(max(0,math.floor((a-m)*G/u)),max(0,math.floor((c-m)*G/u)),min(lf,math.ceil((b-m)*G/u)),min(lf,math.ceil((d-m)*G/u)))
                    if q[0]<q[2] and q[1]<q[3]:field[q]=field.get(q,0)+density
    return lf,field

@lru_cache(None)
def source(case):
    s=json.load(open(root/case/'source.json'))
    if 'adaptive_proof' in s:
        sp=importlib.util.spec_from_file_location('extension_levels',packet/'adaptive_cores/verify.py')
        levels=importlib.util.module_from_spec(sp);sp.loader.exec_module(levels);r=levels.check(s['adaptive_proof'])
        z=levels.rect.measure(r['parts'][0]);S,u,m=map(Q,[r['side'],r['scale'],r['margin']])
        assert s['n']==r['n'] and s['source_id']=='adaptive_cores_n'+str(r['n']) and Q(s['L'])==Q(z['L'])
        assert [S,u,m]==list(map(Q,[s['physical_side'],s['scale'],s['margin']]))
        return s,*rectangles(z,S,u,m)
    specs=json.load(open(packet/'rectangles/sources.json'));v=next(q for q in specs if q['id']==s['source_id'])
    parts=v['parts'];z=rect.measure(parts[0]);available={}
    for part in parts:
        zz=rect.measure(part);assert Q(zz['L'])==Q(z['L']) and Q(zz['B'])==Q(z['B']) and rect.matching_rectangles(z,zz)
        assert zz.get('proof_center_domain','parent_bin')=='parent_bin'
        D=Q(zz['proof_net']['step'])
        for i in rect.coverage(part):
            t=i*D;a=max(Q(0),t-D/2);available[t]=min(available.get(t,a),a)
    grid=[(Q(t),Q(a))for t,a in s['tangents']]
    assert all(t in available and available[t]<=a for t,a in grid)
    S,u,m=assess(Q(z['L']),grid,Q(z['B']))
    assert [S,u,m]==list(map(Q,[s['physical_side'],s['scale'],s['margin']]))
    return s,*rectangles(z,S,u,m)

def verify(case,f,exe):
    s,L,field=source(case);r=json.load(open(f));h=r['h'];n=r['target']
    assert s['n']==r['source_n']<n and s['source_id']==r['source_id'] and L==r['base_units']
    assert 2*R**2>G**2 and all(h+R<=x<=L-R for x in (r['x'],r['y_left'],r['y_right']))
    head=[L,h,r['x'],r['y_left'],r['y_right'],R,len(field)]
    data=' '.join(map(str,head))+'\n'+''.join(' '.join(map(str,(*g,rho)))+'\n'for g,rho in field.items())
    val=int(subprocess.run([exe],input=data,text=True,capture_output=True,check=True).stdout)
    assert val==int(r['mass_numerator']) and int(r['mass_denominator'])==DS*G**2
    assert val<n*DS*G**2 and Q(L+h,G)==Q(r['side']);return r

def results():
    result=[]
    with tempfile.TemporaryDirectory()as d:
        exe=Path(d)/'integral';subprocess.run(['c++','-O3','-std=c++17',root/'integral.cpp','-o',exe],check=True)
        for f in sorted(root.glob('*/n*.json')):result.append(verify(f.parent.name,f,exe))
    return result
if __name__=='__main__':
    for r in results():print(r['target'],r['side'],flush=True)
