# Extending a certified board

Start with an area measure on a physical board of side S. Every unit square in that board captures at least one unit of its mass. The rectangle transfer certificate identifies the scale and translation that give this physical measure. A smaller board of side L, obtained by rounding S down on a 10⁻⁹ grid, has the same coverage property after restriction.

Place four translated copies of the measure on a board of side L+h, using translations (0,0), (0,h), (h,0) and (h,h). Fix a vertical seam x. The left and right groups may have **different horizontal seams**. Choose R = 0.707106782, greater than the maximum axial half-width of a unit square. All seams lie between h+R and L−R.

For a unit square choose its column by its center relative to x. The chosen original board fits that square along the horizontal axis. For instance, a square centered left of x has right edge at most x+R ≤ L. In its column choose the lower or upper copy using the corresponding horizontal seam. The square also lies within that translated board in the vertical direction. Each copy may be truncated beyond its seam by R. The chosen square stays on the retained side, since its half-width never exceeds R.

At each point take the maximum of the four retained densities. This measure dominates the chosen translated density at every point of each square. Each unit square captures at least one. If the integrated upper bound on total mass is less than the target square count, packing that many squares is impossible.

The checker reconstructs the physical source measure from exact inputs. Each rectangle rounds outward on the coordinate grid and each density rounds upward to a multiple of 10⁻⁷. Coincident contributions within a copy add. The independent C++ sweep clips every translated rectangle, tracks four accumulated densities, and integrates the maximum using signed 128-bit integers. Exact range checks precede integration. Parameter search uses a separate program that partitions the board at all candidate seams before evaluating the mass.

Run `python3 extensions/verify.py` from the extracted packet. The companion November 18 search also used rectangular board extensions and maxima of translated densities. Its 111- and 112-square certificates are among the previous comparisons in this packet.
