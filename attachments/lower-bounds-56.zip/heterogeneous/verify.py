"""Fit cores of several sizes into one common parent square and verify the entire angular cover."""
from pathlib import Path
from fractions import Fraction as Q
from functools import lru_cache
import gzip,json,hashlib,math,sys
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root.parent/'rectangles/code'));from bm import rows,G,M
H=Q(707106781186548,10**15)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def data(folder,check=True):
    m=json.load(open(folder/'manifest.json'));assert m.get('kernel','square')=='square' and m['native_sha256']==sha(root.parent/'rectangles/code/bmcheck.cpp')
    n=m['n'];L=Q(m['side']);geom=None;digest=None;nr=0;nodes=0;directions=[]
    for level in m['levels']:
        f=folder/level['measure'];r=folder/level['receipts'];assert sha(f)==level['measure_sha256']and sha(r)==level['receipts_sha256']
        z=json.load(gzip.open(f));B=Q(z['B']);D=Q(z['proof_net']['step']);K=level['K']
        assert int(z['n'])==n and Q(z['L'])==L and D==Q(83,200*K)and z['proof_net']['last']==K and 0<B<1
        fields=[z['n'],z['L'],z['total_mass'],z['points'],z['rectangles']];ident=hashlib.sha256(json.dumps(fields,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        if geom is None:
            geom=ident
            if check:
                rs=list(rows(z));nr=len(rs);digest=hashlib.sha256((str(nr)+'\n'+''.join(' '.join(map(str,row))+'\n'for row in rs)).encode()).hexdigest()
        assert geom==ident
        if check:assert nr==level['rectangles'] and digest==level['rects_sha256']
        seen=set()
        for v in map(json.loads,gzip.open(r,'rt')):
            i=v['r'];assert 0<=i<=K and i not in seen and v['verdict']=='PASS'and v['lower_units']>=M
            seen.add(i);t=i*D;a=max(Q(0),t-D/2)
            if check:
                p,q=t.numerator,t.denominator;c,s,e=q*q-p*p,2*p*q,q*q+p*p;cut=math.floor(e*G*B/2);lo=math.floor(L*G/2);hi=math.ceil(G*(L-(1+2*a-a*a)/(2*(1+a*a))))
                assert v['header']==[c,s,e,cut//e,cut%e,lo,lo,hi,hi] and v['nodes']==2*v['leaves']-1 and v['leaves']>0 and 0<=v['depth']<=65
            directions.append((t,a,B));nodes+=v['nodes']
    assert len(directions)==m['directions'] and nodes==m['nodes'];return n,L,directions
def cover(directions,u):
    bounds={};intervals=[];prec=10**22
    for t,a,B in directions:
        if a*a+2*a>1 or B>u:continue
        if B not in bounds:
            rad=2*B*B-u*u
            assert rad>0
            top=Q(math.isqrt(rad.numerator*prec**2//rad.denominator)+1,prec)
            z=(u-B)/(B+top);assert 0<=z<Q(1,50)
            assert B*(1+2*z-z*z)<=u*(1+z*z)
            bounds[B]=z
        z=bounds[B];left=max(a,(t-z)/(1+t*z));right=(t+z)/(1-t*z)
        if left<=right:intervals.append((left,right))
    end=Q(0)
    for lo,hi in sorted(intervals):
        if lo>end:break
        end=max(end,hi)
        if end*end+2*end>=1:return True
    return False
def run(folder):
    n,L,dirs=data(folder);r=json.load(open(folder/'transfer.json'));u=Q(r['scale']);S=Q(r['side'])
    assert 0<u<=1 and 2*H*H>1 and S==(L-2*(1-u)*H)/u and cover(dirs,u);return r
if __name__=='__main__':
    for d in sorted(root.glob('n*/transfer.json')):print(run(d.parent)['side'],flush=True)
