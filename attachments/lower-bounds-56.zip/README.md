# Lower bounds for 56 square counts

`exact_claims.csv` is the submission table. For each count it gives a guaranteed decimal rounded downward, the exact value, its proof identifier, the source count, and two comparison columns. An exact kind of `sqrt` means the positive square root of the displayed rational. All other exact values are the displayed rationals themselves.

The 49 direct bounds use nonnegative measures. For a given count n, the constructed measure has total mass less than n and gives every admissible unit square mass at least one after the stated transfer. The contradiction excludes a packing below the claimed side. Seven further rows use monotonicity. The proofs at 101, 122 and 145 also apply at 102, 123–125 and 146–148, respectively.

The registry comparison is the stronger of the reported and verified bounds at Squares Project commit `1015fc175fa4e2c01f912d915d784100e36d3bab`. The other comparison also includes stronger author and companion calculations located before this handoff. Both displayed comparison columns are rounded down. The exact reference intervals and comparator floors are in `attribution/`.

## Verify the submission

On Linux, use Python 3.10 or later and a C++17 compiler with 128-bit integer support on the command path as `c++`. From this directory run

```sh
python3 verify.py
```

This command checks file hashes, recomputes each exact claim and its outward rounding, checks direction receipts and mass budgets, reproduces the 82- and 112-square measures, compiles the area integration checker, and verifies the seven monotonic consequences. The calculation uses Python's standard library. Selected raw direction replays are in `receipts/`.

The proof field of each CSV row points to the argument specific to that row. The rectangle and mixed-measure proofs describe the subdivision over possible centers and the analytic coverage between tested angles. `adaptive_cores/PROOF.md` and `heterogeneous/PROOF.md` explain how the covered centers and permissible angle errors change with the size of the core. The file `rectangles/INTEGER_CHECKER.md` describes the integer geometry and rounding rules.

## Rerun the center subdivisions

The fast verification uses archived outputs of the center subdivisions. Two example commands regenerate individual directions directly from their measures and checker source.

```sh
python3 rectangles/replay.py hybrid_n109_main 570 --output replay-rectangle
python3 mixed/replay.py n101_r400_s12_proj 200 --output replay-mixed
```

Omit the direction argument to rerun the full set of indices archived for that input. Choose the input directory under `rectangles/evidence/` or `mixed/evidence/`. The replay drivers accept `--workers` and a subdivision cap. Some receipt sets combine original source directions with additional integer-checked directions. Each row of `lower_bounds.csv` identifies its coverage history. The supplement in `rectangles/alternate/` records selected checks with a second implementation.

The independent steps in this handoff include complete arithmetic recomputation on the retained receipts and sample native replays. A new run of every underlying historical center search and a formal proof-assistant verification remain available for further review.

## Credit

Submitted by Joost de Winter after Hiroaki Hosono. Hosono developed the original point, segment and rectangle measures. The 108-square source used on the way to 109 was rescaled by de Winter and registered as T-327. The changes in this submission include modifications to the measures, new checks over centers and orientations, and sharper analytic transfers of existing checks. The row-specific files identify reused evidence. OpenAI's Codex assisted de Winter with search, implementation, checking and preparation of this packet. Upstream notices and licenses are included.

Project and source links

- https://squaremath.org/frontier.html
- https://squaremath.org/result/t-327.html
- https://github.com/jlevy/squares/tree/1015fc175fa4e2c01f912d915d784100e36d3bab
- https://github.com/wand125/square-packing
