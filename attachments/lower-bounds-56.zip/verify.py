"""Verify the pinned source tree, then run this submission's mathematical checks."""
import hashlib
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SCRIPTS = ['check_claims.py', 'rectangles/reproduce_measures.py']

def git_object(kind, contents):
    header = kind + b' ' + str(len(contents)).encode() + b'\0'
    return hashlib.sha1(header + contents).digest()

def tree_digest(entries):
    packed = bytearray()
    for name, item in sorted(entries.items(), key=lambda pair: pair[0].encode() + (b'/' if isinstance(pair[1], dict) else b'')):
        if isinstance(item, dict):
            mode, value = b'40000', tree_digest(item)
        else:
            mode, value = b'100644', item
        packed += mode + b' ' + name.encode() + b'\0' + value
    return git_object(b'tree', packed)

def verify_revision():
    manifest = ROOT / 'SHA256SUMS'
    entries = {}
    files = ['SHA256SUMS']
    for line in manifest.read_text().splitlines():
        expected, name = line.split('  ', 1)
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == expected, name
        files.append(name)
    for name in files:
        target = entries
        parts = Path(name).parts
        for part in parts[:-1]:
            target = target.setdefault(part, {})
        assert parts[-1] not in target
        target[parts[-1]] = git_object(b'blob', (ROOT/name).read_bytes())
    raw = (ROOT/'.source'/'git-commit.txt').read_bytes()
    revision = (ROOT/'.source'/'revision.txt').read_text().strip()
    assert git_object(b'commit', raw).hex() == revision
    assert raw.splitlines()[0].decode() == 'tree ' + tree_digest(entries).hex()
    print(f'PASS. {len(files)} source files match Git commit {revision}.', flush=True)

if __name__ == '__main__':
    if not __debug__:
        raise SystemExit('Run Python with assertions enabled.')
    verify_revision()
    for script in SCRIPTS:
        subprocess.run([sys.executable, '-B', str(ROOT/script)], cwd=ROOT, check=True)
    print('PASS. All submission checks completed.')
