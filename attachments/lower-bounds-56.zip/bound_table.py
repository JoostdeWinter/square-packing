"""Bind both summary tables to the archived bounds, coordinates and prior comparisons."""
from fractions import Fraction as Q
from pathlib import Path
import csv,gzip,hashlib,importlib.util,json
R=Path(__file__).resolve().parent
def mod(file,name):
    spec=importlib.util.spec_from_file_location(name,file);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def read(p):return json.loads(p.read_text())
def lower():
    baseline={int(n):Q(s) for n,s in read(R/'attribution/strongest_prior_lower.json').items()}
    official=read(R/'attribution/registry_lower_intervals.json')
    previous=list(csv.DictReader((R/'attribution/prior_lower_comparisons.csv').open()));p={}
    for row in previous:
        n=int(row['n']);p[n]=max(p.get(n,Q(0)),Q(row['exact']))
    for n in sorted(baseline):
        assert baseline[n]>=max([baseline.get(n-1,0),p.get(n,0),*[Q(r['upper']) for r in official[str(n)].values()]])
    choices={k:(r['n'],Q(r['lower']))for k,r in read(R/'rectangles/exact_transfers.json').items()}
    for n,r in read(R/'mixed/exact_transfers.json').items():choices['mixed_n'+n]=int(n),Q(r['lower'])
    lin=mod(R/'linear/verify.py','table_linear')
    for n in lin.TARGETS:choices['linear_n'+str(n)]=n,Q(lin.result(n)[0])
    for f in (R/'heterogeneous').glob('n*/transfer.json'):
        r=read(f);choices['levels_'+r['source_folder']]=r['n'],Q(r['side'])
    for f in (R/'adaptive_cores').glob('n*.json'):
        r=read(f);choices['adaptive_cores_n'+str(r['n'])]=r['n'],Q(r['side'])
    for f in (R/'extensions').glob('*/n*.json'):
        r=read(f);n=r['target'];k='extension_'+r['source_id']+'_to'+str(n)
        choices[k]=n,max(Q(r['side']),choices.get(k,(0,Q(0)))[1])
    seen=set();inherited=0;substantial=0
    for row in csv.DictReader((R/'lower_bounds.csv').open()):
        n=int(row['n']);k=row['certificate'];source,exact=choices[k];s=Q(row['new_lower_floor_12'])
        assert n not in seen and source==int(row['source_n']) and source<=n and s<=exact<s+Q(1,10**12)
        assert s>baseline[n] and Q(row['previous_comparison_floor_12'])<=baseline[n]<Q(row['previous_comparison_floor_12'])+Q(1,10**12)
        assert abs(Q(row['increase_using_display'])-(s-baseline[n]))<=Q(1,10**13)
        if k.startswith('linear_'):assert n in lin.TARGETS[source]
        inherited+=int(source<n);substantial+=int(s-baseline[n]>=Q(1,1000));seen.add(n)
    return len(seen),inherited,substantial

if __name__=='__main__':
    rows, inherited, substantial = lower()
    print(f'{rows} verified claim rows, {inherited} monotonic corollaries, {substantial} gains of at least 0.001.')
