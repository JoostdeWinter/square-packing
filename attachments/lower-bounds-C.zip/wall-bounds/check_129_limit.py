"""Compute the exact mass of a single upright wall tile under the 129-square measure."""
from fractions import Fraction
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'checker'))
import boundary


def wall_mass(measure, target, center_y=None):
    side = Fraction(measure['L'])
    right = (side + target) / 2
    top = right if center_y is None else center_y + Fraction(1,2)
    assert (side-target)/2 <= top-1 and top<=right

    def overlap(a, b, hi):
        return max(0, min(hi, b) - max(hi-1, a))

    total = Fraction()
    for row in measure['rectangles']:
        x, y, X, Y = map(Fraction, row['rectangle'])
        density = Fraction(row['mass']) / (8 * (X-x) * (Y-y))
        for a, b, A, B in ((x,y,X,Y), (y,x,Y,X)):
            for low_x, high_x in ((a,A), (side-A,side-a)):
                for low_y, high_y in ((b,B), (side-B,side-b)):
                    total += density * overlap(low_x,high_x,right) * overlap(low_y,high_y,top)
    return total


if __name__ == '__main__':
    case = ROOT / 'cases/129'
    prior = json.loads((case/'prior.json').read_text())
    manifest = json.loads((case/'core/manifest.json').read_text())
    source = json.loads(gzip.decompress((case/'core'/manifest['levels'][0]['measure']).read_bytes()))
    measure = boundary.weighted_measure(source, 129, prior['mass'], prior.get('band'))
    examples = [('11.496851', Fraction('9.993935')), ('11.4969', None), ('11.5', None)]
    for side_text, center_y in examples:
        target = Fraction(side_text)
        captured = wall_mass(measure, target, center_y)
        assert 0 < captured < 1
        print(f'Side {target}, captured mass {float(captured):.12f}\nExact mass {captured}')
