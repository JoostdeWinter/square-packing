"""Verify a wall extension, with the original integer C++ geometry kernel."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction
import gzip
import json
from math import floor
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'checker'))
import boundary
import check

def check_case(case, executable, workers, full_core=False):
    source = case / 'core'
    manifest = check.verify(source)
    old = json.loads((case / 'prior.json').read_bytes())
    extension = json.loads((case / 'extension.json').read_bytes())
    n = int(case.name)
    assert old['n'] == old['base_n'] == extension['n'] == n
    assert manifest['levels'][0]['measure_sha256'].startswith(old['source'])
    assert old['source'] == extension['source'] and old['method'] in ('boundary','derived_boundary')
    m, _ = check.read_level(source, manifest['levels'][0])
    assert manifest['n'] == m['n']
    if old['method'] == 'derived_boundary':
        import derived_boundary
        import extend_measure
        import local_corner
        repair = case / 'repair'
        params = json.loads((repair/'parameters.json').read_bytes())
        assert params['source'] == old['source']
        assert params['extension'] == old['extension_before_repair']
        extended = extend_measure.extend_measure(m, **params['extension'])
        repaired = local_corner.verify_local(repair, extended, replay=full_core, workers=workers)
        m = derived_boundary.measure(m, repaired, params, old['foundation'])
    assert m['n'] == n
    old_side, end, mass = map(Fraction, (old['side'], extension['side'], old['mass']))
    assert old_side == Fraction(extension['base']) and Fraction(m['L']) < old_side < end
    assert not m['points'] and Fraction(m['total_mass']) <= mass < n
    if full_core:
        subprocess.run([sys.executable, '-B', ROOT/'checker/replay.py', source,
                        '--workers', str(workers), '--controls'], check=True)
    boundary.verify_saved(case/'old-wall', m, old, check, replay=False)
    old_entries = json.loads(gzip.decompress((case/'old-wall/receipts.gz').read_bytes()))
    angles = extension['angles']
    assert all(axis in (0, 1) for axis, k, j in angles)
    for face in (0, 1):
        boundary.check_cover([(k, j) for axis, k, j in angles if axis == face])
    jobs = [(a['axis'], a['header'], a['nodes']) for a in old_entries]
    for axis, k, j in angles:
        h = boundary.header(m, end, k, j, axis, check)
        t = Fraction(83*(2*j+1), 400*k)
        half_width = Fraction(707107, 1_000_000) if t*t+2*t >= 1 else (1+2*t-t*t)/(2*(1+t*t))
        cutoff = floor(check.bm.G*((Fraction(m['L'])+old_side)/2-half_width))
        h[5+axis] = max(h[5+axis],cutoff)
        jobs.append((axis,h,None))
    with TemporaryDirectory() as tmp:
        directory=Path(tmp)
        for axis,raw in enumerate(boundary.fields(m,n,old['mass'],check,old.get('band'))):
            (directory/f'grid{axis}').write_bytes(raw)
        def test(item):
            idx,(axis,header,old_nodes)=item
            path=directory/f'h{idx}'
            path.write_text(' '.join(map(str,header))+'\n')
            run=subprocess.run([executable,directory/f'grid{axis}',path,'2200000'],
                               text=True,capture_output=True,check=True)
            verdict,nodes,leaves,clips,depth,lower=run.stdout.split()
            assert verdict=='PASS' and int(lower)>=check.bm.M and int(nodes)==2*int(leaves)-1
            if old_nodes is not None:
                assert int(nodes)==old_nodes
            return int(nodes)
        with ThreadPoolExecutor(workers) as pool:
            node_count=sum(pool.map(test,enumerate(jobs)))
    return dict(n=n,side=str(end),relation='>',old_side=str(old_side),total_mass=str(mass),
                inherited_core_orientation_intervals=manifest['directions'],native_core_replayed=full_core,
                old_wall_intervals=len(old_entries),new_wall_intervals=len(angles),wall_nodes=node_count)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--only',nargs='+',type=int)
    parser.add_argument('--workers',type=int,default=4)
    parser.add_argument('--full-core',action='store_true',help='Also rerun every inherited core interval and negative controls.')
    parser.add_argument('--receipt',type=Path)
    args=parser.parse_args()
    if not __debug__ or args.workers<1:raise ValueError('Use enabled assertions and a positive worker count.')
    counts=sorted(args.only or [int(p.name) for p in (ROOT/'cases').iterdir()])
    receipt=[]
    with TemporaryDirectory() as tmp:
        executable=Path(tmp)/'geometry'
        subprocess.run(['c++','-std=c++17','-O3',ROOT/'checker/gram.cpp','-o',executable],check=True)
        for n in counts:
            row=check_case(ROOT/'cases'/str(n),executable,args.workers,args.full_core)
            receipt.append(row)
            print(f"PASS n={n}, s(n) > {row['side']}, {row['new_wall_intervals']} new wall intervals",flush=True)
    if args.receipt:args.receipt.write_text(json.dumps(receipt,indent=2)+'\n')

if __name__=='__main__':main()
