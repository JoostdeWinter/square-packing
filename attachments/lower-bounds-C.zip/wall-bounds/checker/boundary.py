"""Verify unit squares that meet the extra border of a concentrically enlarged board."""

from fractions import Fraction as F
from hashlib import sha256
from math import ceil, floor


def identity(row):
    data = f"{row['source']}/{row['n']}/{F(row['side'])}/{F(row['mass'])}"
    if 'foundation' in row:
        import json
        data += '/foundation/'+json.dumps(row['foundation'],sort_keys=True,separators=(',',':'))+'/'+str(row.get('repair',''))
    if 'case' in row:data += '/case/'+row['case']
    if 'band' in row:
        data += '/band/' + '/'.join(str(F(v)) for v in row['band'])
    return sha256(data.encode()).hexdigest()[:18]


def original_claim(row):
    if row['method'] in ('boundary','archived_boundary','derived_boundary'):return row
    assert row['method']=='periodic_boundary'
    return dict(source=row['source'],base_n=row['base_n'],n=row['boundary_n'],side=row['boundary_side'],mass=row['boundary_mass'],boundary=row['boundary'],method='boundary',**({'band':row['boundary_band']} if 'boundary_band' in row else {}))


def weighted_measure(source, n, mass, band=None):
    initial = F(source['total_mass'])
    total = F(mass)
    side = F(source['L'])
    assert initial <= total < n and not source['points']
    if band is None and total == initial:
        return source
    edge_mass = F(0)
    additions = []
    if band is not None:
        inner, outer, share = map(F, band)
        assert 0 <= inner < outer < side/2 and 0 < share <= 1
        # The source format averages each rectangle over all eight square symmetries.
        edge_mass = (total-initial)*share
        assert edge_mass > 0
        additions.append(dict(rectangle=[str(side-outer),'0',str(side-inner),str(side)],mass=str(edge_mass)))
    scale = (total-edge_mass)/initial
    assert scale >= 1
    rects = [dict(row,mass=str(F(row['mass'])*scale)) for row in source['rectangles']]
    return dict(source,n=n,total_mass=str(total),rectangles=rects+additions)


def padded_measure(source, row):
    shift = (F(row['side'])-F(source['L']))/2
    assert shift>0
    augmented = weighted_measure(source,row['n'],row['mass'],row.get('band'))
    from functools import lru_cache
    @lru_cache(None)
    def moved(v):return str(F(v)+shift)
    rects=[dict(r,rectangle=[moved(v) for v in r['rectangle']]) for r in augmented['rectangles']]
    return dict(n=row['n'],L=row['side'],total_mass=row['mass'],points=[],rectangles=rects)


def digest_headers(jobs):
    raw = ''.join(' '.join(map(str,h))+'\n' for k,j,h in sorted(jobs))
    return sha256(raw.encode()).hexdigest()


def fields(source, n, total, check, band=None):
    size = F(source['L'])
    measure = weighted_measure(source,n,total,band)
    threshold = floor((size-2)*check.bm.G)
    rows = list(check.bm.rows(measure))
    # Dropping any nonnegative rectangle preserves the direction of the local lower bound.
    return [check.input_bytes([r for r in rows if r[6+axis]>=threshold]) for axis in range(2)]


def angle_supported(k,j):
    lo = F(83*(2*j-1),400*k)
    return 0 <= j <= k and (lo<0 or lo*lo+2*lo<1)


def header(source, target, k, j, axis, check):
    S, T = F(source['L']), F(target)
    assert T>S and axis in (0,1) and angle_supported(k,j)
    half_pad = (T-S)/2
    step = F(83,200*k)
    level = dict(source,B=str(1/(1+step/(1-step*step/4))-F(1,10**12)),proof_net=dict(last=k,step=str(step)))
    h = check.header(level,j,'octagon-gram')
    def half(t):return (1+2*t-t*t)/(2*(1+t*t))
    lo = max(F(0),(j-F(1,2))*step); hi = (j+F(1,2))*step
    max_half = F(707107,10**6) if hi*hi+2*hi>=1 else half(hi)
    # In source coordinates, a tile outside the old board has its center above
    # S-h(theta) on at least one axis. Newly legal centers end at S+pad-h(theta).
    h[5+axis] = max(h[5+axis],floor(check.bm.G*(S-max_half)))
    h[7] = h[8] = ceil(check.bm.G*(S+half_pad-half(lo)))
    return h


def check_cover(pairs):
    assert pairs and len(pairs)==len(set(pairs))
    spans=[]
    for k,j in pairs:
        assert isinstance(k,int) and k>0 and isinstance(j,int) and angle_supported(k,j)
        spans.append((F(83*(2*j-1),400*k),F(83*(2*j+1),400*k)))
    right=F(0)
    for a,b in sorted(spans):
        assert a<=right,'boundary certificate has an angular gap'
        right=max(right,b)
    assert right*right+2*right>=1,'boundary certificate misses the last orientation'


def verify_compact(extra,source,row,check,replay,angle_jobs):
    assert identity(row)==row['boundary'] and row['base_n']==source['n']
    digests=[];queued=[]
    for axis,raw in enumerate(fields(source,row['n'],row['mass'],check,row.get('band'))):
        grid_hash=sha256(raw).hexdigest()
        jobs=angle_jobs(source,extra['angles'][axis],lambda k,r:header(source,row['side'],k,r,axis,check))
        check_cover([(k,r)for k,r,h in jobs])
        header_hash=digest_headers(jobs)
        if 'binding' in extra:digests.extend(bytes.fromhex(x)for x in (grid_hash,header_hash))
        else:assert grid_hash==extra['grids'][axis] and header_hash==extra['header_sha256'][axis]
        queued.append((raw,jobs))
    if digests:assert sha256(b''.join(digests)).hexdigest()==extra['binding']
    for raw,jobs in queued:replay(raw,jobs)


def verify_saved(folder, source, row, check, replay=False, workers=1):
    from concurrent.futures import ThreadPoolExecutor
    from pathlib import Path
    from tempfile import TemporaryDirectory
    import gzip, json, subprocess
    assert identity(row)==row['boundary'] and row['base_n']==source['n']
    proof=json.loads((folder/'proof.json').read_text())
    data=(folder/'receipts.gz').read_bytes();assert sha256(data).hexdigest()==proof['receipts_sha256']
    receipts=json.loads(gzip.decompress(data));groups=[[],[]]
    for q in receipts:
        axis=q['axis'];assert axis in (0,1);groups[axis].append(q)
        assert q['header']==header(source,row['side'],q['K'],q['r'],axis,check)
        assert q['verdict']=='PASS' and q['nodes']==2*q['leaves']-1 and q['leaves']>0 and 0<=q['depth']<=65 and q['lower_units']>=check.bm.M
    assert [len(g)for g in groups]==proof['angles'] and sum(q['nodes']for q in receipts)==proof['nodes']
    grids=fields(source,row['n'],row['mass'],check,row.get('band'))
    for axis in range(2):
        assert sha256(grids[axis]).hexdigest()==proof['grids'][axis]
        check_cover([(q['K'],q['r'])for q in groups[axis]])
    if replay:
        with TemporaryDirectory()as td:
            tmp=Path(td);binary=tmp/'gram'
            subprocess.run(['c++','-O3','-std=c++17',check.here/'gram.cpp','-o',binary],check=True)
            for axis,raw in enumerate(grids):(tmp/f'grid{axis}').write_bytes(raw)
            def test(q):
                path=tmp/f"{q['axis']}_{q['K']}_{q['r']}";path.write_text(' '.join(map(str,q['header'])))
                words=subprocess.run([binary,tmp/f"grid{q['axis']}",path,'2200000'],check=True,text=True,capture_output=True).stdout.split()
                assert words==[str(q[k])for k in ('verdict','nodes','leaves','clips','depth','lower_units')]
            with ThreadPoolExecutor(workers)as ex:list(ex.map(test,receipts))
