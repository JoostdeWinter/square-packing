"""Split corner rectangles without changing the source density, then group by position and shape."""
from fractions import Fraction as F
from itertools import product


def split_field(measure, corner, width):
    side = F(measure['L'])
    corner, width = F(corner), F(width)
    assert 0 < width < corner < side / 2
    marks = {F(0), corner, side-corner, side}
    for i in range(1, int(corner/width)+1):
        marks.update([i*width, side-i*width])
    marks = sorted(marks)
    def cuts(a, b):
        tx = [a, *(v for v in marks if a < v < b), b]
        return list(zip(tx, tx[1:]))
    for row in measure['rectangles']:
        x,y,X,Y = map(F, row['rectangle'])
        mass = F(row['mass'])
        if min(x,side-X)>=corner or min(y,side-Y)>=corner:
            yield (x,y,X,Y),mass,None
            continue
        for (a,A),(b,B) in product(cuts(x,X),cuts(y,Y)):
            dx,dy=A-a,B-b
            nearx,neary=min(a,side-A),min(b,side-B)
            label=None
            if nearx+dx<=corner and neary+dy<=corner:
                d1,d2=sorted(((nearx+dx/2,dx),(neary+dy/2,dy)))
                geom=1 if d1[1]>3*d2[1] else 2 if d2[1]>3*d1[1] else 0
                label=(int(d1[0]//width),int(d2[0]//width),geom)
            yield (a,b,A,B), mass*dx*dy/((X-x)*(Y-y)), label


def orbit(x,y,X,Y,side):
    for a,b,c,d in ((x,y,X,Y),(y,x,Y,X)):
        for lo,hi in ((a,c),(side-c,side-a)):
            for left,right in ((b,d),(side-d,side-b)):
                yield lo,left,hi,right
