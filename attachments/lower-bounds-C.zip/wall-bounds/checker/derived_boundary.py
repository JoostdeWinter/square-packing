"""Reconstruct a previously covered board before certifying an enlarged outer edge."""
from fractions import Fraction as F


def measure(source, use, parameters, foundation):
    from extend_measure import extend_measure, copied_measure
    method=foundation['method']
    if method=='direct':field=use
    elif method=='periodic':
        assert F(foundation.get('period','1'))==1 and 'board_scale' not in (parameters or {})
        field=extend_measure(use,foundation['periods'],foundation['offset'])
    elif method=='corner_copy':
        assert parameters and 'board_scale' not in parameters
        field=copied_measure(source,parameters,use,foundation['target_offset'],foundation['periods'])
    else:raise ValueError('Unknown source-board construction.')
    assert F(field['L'])==F(foundation['side']) and F(field['total_mass'])==F(foundation['mass'])<foundation['n']
    return dict(field,n=foundation['n'])
