"""Construct the exact density after repeating a certified central strip."""
from collections import defaultdict
from fractions import Fraction as F
from transfer import coordinate, strip_map, G
from scaled_period import inspect_period


def extend_measure(source, periods, offset):
    assert isinstance(offset,int) and isinstance(periods,int) and periods>=3 and periods+offset>=2
    if offset==0:return source
    side=F(source['L'])
    mass,strip,cell=inspect_period(source,periods,F(1))
    segments=[tuple(F(x,G) for x in entry) for entry in strip_map(coordinate(side),periods,offset)]
    def slices(lo,hi):
        for a,b,shift in segments:
            x,X=max(lo,a),min(hi,b)
            if x<X:yield x+shift,X+shift,X-x
    pieces=defaultdict(F)
    for row in source['rectangles']:
        x,y,X,Y=map(F,row['rectangle'])
        density=F(row['mass'])/((X-x)*(Y-y))
        for a,A,dx in slices(x,X):
            for b,B,dy in slices(y,Y):
                pieces[a,b,A,B]+=density*dx*dy
    total=sum(pieces.values(),F(0))
    assert total==mass+2*offset*strip+offset**2*cell
    rows=[dict(rectangle=list(map(str,box)),mass=str(weight)) for box,weight in pieces.items()]
    return dict(n=int(total)+1,L=str(side+offset),total_mass=str(total),points=[],rectangles=rows)


def corner_density(measure, width):
    """Signed rectangular events specify exactly the symmetrized density on a corner."""
    from corner_field import orbit
    events=defaultdict(F);side=F(measure['L'])
    for row in measure['rectangles']:
        x,y,X,Y=map(F,row['rectangle'])
        density=F(row['mass'])/(8*(X-x)*(Y-y))
        for a,b,A,B in orbit(x,y,X,Y,side):
            A=min(A,width);B=min(B,width)
            if a>=A or b>=B:continue
            events[a,b]+=density;events[a,B]-=density
            events[A,b]-=density;events[A,B]+=density
    return {key:value for key,value in events.items() if value}


def copied_corner_mass(source, parameters, target_offset, periods=None):
    """Transfer four separated corner changes between boards with identical corner densities."""
    cfg=parameters.get('extension', {})
    period_count=cfg.get('periods',periods)
    reference_offset=cfg.get('offset',0)
    assert isinstance(period_count,int) and period_count>=3
    assert isinstance(target_offset,int) and target_offset!=reference_offset
    assert period_count+min(reference_offset,target_offset)>=2
    ref=extend_measure(source,period_count,reference_offset)
    target=extend_measure(source,period_count,target_offset)
    corner=F(parameters['corner']);scale=F(parameters.get('board_scale','1'));assert 0<scale<=1
    diameter=F(1414214,10**6)/scale
    assert (diameter*scale)**2>=2 and 2*corner+diameter<=min(F(ref['L']),F(target['L']))
    # Any tile that intersects a change fits in the corresponding corner window.
    # All four windows have the stated density by dihedral symmetry.
    assert corner_density(ref,corner+diameter)==corner_density(target,corner+diameter)
    return F(target['total_mass'])-F(parameters['removed_mass'])


def copied_measure(source, parameters, reference_repaired, target_offset, periods=None):
    """Preserve the target background and install the certified reference density inside its four corners."""
    cfg=parameters.get('extension',{})
    p=cfg.get('periods',periods);ref_offset=cfg.get('offset',0)
    assert target_offset!=ref_offset
    expected=copied_corner_mass(source,parameters,target_offset,p)
    target=extend_measure(source,p,target_offset)
    ref_side=F(reference_repaired['L']);side=F(target['L']);corner=F(parameters['corner'])
    assert ref_side==F(source['L'])+ref_offset
    boxes=defaultdict(F)

    def add_parts(field,keep_corner):
        length=F(field['L'])
        for row in field['rectangles']:
            a,b,A,B=map(F,row['rectangle'])
            density=F(row['mass'])/((A-a)*(B-b))
            xs=[a,*(u for u in (corner,length-corner) if a<u<A),A]
            ys=[b,*(u for u in (corner,length-corner) if b<u<B),B]
            for x,X in zip(xs,xs[1:]):
                for y,Y in zip(ys,ys[1:]):
                    cx=(X<=corner or x>=length-corner);cy=(Y<=corner or y>=length-corner)
                    if (cx and cy)!=keep_corner:continue
                    dx=side-length if keep_corner and x>=length-corner else F(0)
                    dy=side-length if keep_corner and y>=length-corner else F(0)
                    box=(x+dx,y+dy,X+dx,Y+dy)
                    assert 0<=box[0]<box[2]<=side and 0<=box[1]<box[3]<=side
                    boxes[box]+=density*(X-x)*(Y-y)

    # Symmetrization commutes with both cropping out all four corners and
    # transferring their contents to the corresponding target corners.
    add_parts(target,False);add_parts(reference_repaired,True)
    total=sum(boxes.values(),F(0));assert total==expected
    rows=[dict(rectangle=list(map(str,box)),mass=str(weight)) for box,weight in sorted(boxes.items()) if weight]
    return dict(n=int(total)+1,L=str(side),total_mass=str(total),points=[],rectangles=rows)
