"""Exact periodic-strip test for a general rational period length."""
from collections import defaultdict
from fractions import Fraction


def inspect_period(measure, periods, step):
    length, side = Fraction(step), Fraction(measure['L'])
    assert periods >= 3 and length > 0 and ((periods - 1) * length)**2 >= 2
    start = (side - periods * length) / 2
    unit = (side - length) / 2
    assert start >= 0 and not measure['points']
    maps = [[defaultdict(Fraction) for _ in range(periods)] for _ in range(2)]
    mass = Fraction(0)
    strip = Fraction(0)
    cell = Fraction(0)

    def central_fraction(left, right):
        return max(Fraction(0), min(right, unit + length) - max(left, unit)) / (right - left)

    for row in measure['rectangles']:
        x, y, X, Y = map(Fraction, row['rectangle'])
        weight = Fraction(row['mass'])
        assert 0 <= x < X <= side and 0 <= y < Y <= side and weight >= 0
        density = weight / ((X - x) * (Y - y))
        fx, fy = central_fraction(x, X), central_fraction(y, Y)
        mass += weight
        strip += weight * (fx + fy) / 2
        cell += weight * fx * fy
        for axis, (lo, hi, across_lo, across_hi) in enumerate(((x, X, y, Y), (y, Y, x, X))):
            for i in range(periods):
                left = start + i * length
                a, b = max(left, lo) - left, min(left + length, hi) - left
                if a >= b:
                    continue
                events = maps[axis][i]
                events[a, across_lo] += density
                events[a, across_hi] -= density
                events[b, across_lo] -= density
                events[b, across_hi] += density
    for axis in maps:
        first = {key: value for key, value in axis[0].items() if value}
        assert all({key: value for key, value in part.items() if value} == first for part in axis[1:])
    assert mass == Fraction(measure['total_mass'])
    return mass, strip, cell


def verify_periodic(measure, claim, cache):
    length = Fraction(claim.get('period', '1'))
    periods, offset = claim['periods'], claim['offset']
    assert isinstance(periods, int) and isinstance(offset, int) and periods + offset > 0
    assert ((periods + offset) * length)**2 >= 2
    key = periods, length
    if key not in cache:
        cache[key] = inspect_period(measure, periods, length)
    initial, strip, cell = cache[key]
    value = initial + 2 * offset * strip + offset**2 * cell
    assert Fraction(claim['side']) == Fraction(measure['L']) + offset * length
    assert value == Fraction(claim['mass']) < claim['n']
    return value
