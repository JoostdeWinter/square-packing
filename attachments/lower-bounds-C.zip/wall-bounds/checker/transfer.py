"""Exact integrals for boards obtained by restricting or joining parts of a covered board."""
from collections import defaultdict
from fractions import Fraction
from hashlib import sha256

from envelope_grid import D, G, grid
from envelope_exact import piece
from period_verify import inspect

RADIUS = 7071070

def coordinate(value):
    scaled = Fraction(value) * G
    if scaled.denominator != 1:
        raise ValueError('The coordinate is outside the integration grid.')
    return int(scaled)

def strip_map(side, periods, offset):
    """List source intervals and their translations into the extended board."""
    if offset == 0:
        return [(0, side, 0)]
    assert periods >= 3 and periods + offset >= 2 and (side - periods * G) % 2 == 0
    cut = (side - periods * G) // 2
    assert 0 <= cut and cut + periods * G <= side
    if offset < 0:
        return [(0, cut, 0), (cut - offset * G, side, offset * G)]
    return [(0, cut, 0)] + [(cut, cut + G, i * G) for i in range(offset)] + [(cut, side, offset * G)]

def source_grid(measure):
    raw = grid(measure)
    lines = raw.splitlines()
    size, count = map(int, lines[0].split())
    rows = [tuple(map(int, line.split())) for line in lines[1:]]
    assert len(rows) == count and all(weight >= 0 for *_, weight in rows)
    return size, rows, sha256(raw).hexdigest()

def clipped(low, high, window):
    for start, stop, shift in window:
        left, right = max(low, start), min(high, stop)
        if left < right:
            yield left + shift, right + shift

def expanded_grid(rows, mapping):
    if len(mapping) == 1:
        return rows
    pieces = defaultdict(int)
    for x, y, X, Y, weight in rows:
        xs, ys = list(clipped(x, X, mapping)), list(clipped(y, Y, mapping))
        for left, right in xs:
            for bottom, top in ys:
                pieces[left, bottom, right, top] += weight
    return [(*box, weight) for box, weight in sorted(pieces.items())]

def cut_length(a, b, origin, side, mapping):
    return sum(max(0, min(hi, origin + side) - max(lo, origin)) for lo, hi in clipped(a, b, mapping))

def cropped_integral(rows, side, x, y, mapping):
    return sum(weight * cut_length(a, A, x, side, mapping) * cut_length(b, B, y, side, mapping)
               for a, b, A, B, weight in rows)

def axis_zones(size, seam, origin, source_size):
    assert origin >= 0
    if seam is None:
        assert origin + size <= source_size
        return [(0, size, False)]
    q = coordinate(seam)
    assert min(q, size - q) > RADIUS and origin + max(q, size - q) + RADIUS <= source_size
    return [(0, q - RADIUS, False), (q - RADIUS, q + RADIUS, True), (0, size - q - RADIUS, False)]

def patch_integral(rows, side, cfg, source_size, mapping):
    assert 2 * RADIUS**2 >= G**2
    x, y = coordinate(cfg['origin_x']), coordinate(cfg['origin_y'])
    xs = axis_zones(side, cfg['seam_x'], x, source_size)
    ys = axis_zones(side, cfg['seam_y'], y, source_size)
    field = [(a - x, b - y, A - x, B - y, weight) for a, b, A, B, weight in expanded_grid(rows, mapping)]
    return sum(piece(field, side, (lo, bot, hi, top), fx, fy)
               for lo, hi, fx in xs for bot, top, fy in ys)

def verify_geometry(measure, claim, prepared=None, period_laws=None):
    side = coordinate(claim['side'])
    size, rows, digest = prepared or source_grid(measure)
    assert digest == claim['source_grid_sha256'] and not measure['points']
    offset = claim.get('offset', 0)
    periods = claim.get('periods', 0)
    assert isinstance(offset, int) and isinstance(periods, int)
    if offset:
        if period_laws is not None and periods in period_laws:
            law = period_laws[periods]
        else:
            law = inspect(measure, periods)
            if period_laws is not None:
                period_laws[periods] = law
    source_size = size + offset * G
    mapping = strip_map(size, periods, offset)
    if claim['method'] == 'periodic':
        assert offset and side == source_size
        mass, strip_mass, cell_mass = law
        value = mass + 2 * offset * strip_mass + offset**2 * cell_mass
    elif claim['method'] == 'crop':
        x, y = coordinate(claim['x']), coordinate(claim['y'])
        assert min(x, y, side) >= 0 and max(x, y) + side <= source_size
        value = Fraction(cropped_integral(rows, side, x, y, mapping), D * G**2)
    elif claim['method'] == 'patch':
        value = Fraction(patch_integral(rows, side, claim, source_size, mapping), D * G**2)
    else:
        raise ValueError(f"Unknown transfer {claim['method']}")
    assert value == Fraction(claim['mass']) and value < claim['n']
    return value
