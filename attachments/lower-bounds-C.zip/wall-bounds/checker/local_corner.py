"""Construct a locally reweighted measure and check/replay only the affected centers."""
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction as F
from hashlib import sha256
from math import ceil, floor
from pathlib import Path
import gzip, json, subprocess, tempfile
import check
from corner_field import split_field


def rounded_blend(value):
    scale = 10**8
    return min(F(1), F(ceil(value * scale) + 1000, scale))


def prepare(measure, parameters):
    side, corner = F(measure['L']), F(parameters['corner'])
    width = F(parameters['width'])
    board_scale=F(parameters.get('board_scale','1'))
    assert 0 < board_scale <= 1
    if 'raw_groups' in parameters:
        raw = {tuple(record[:3]): F(record[3], parameters['weight_denominator']) for record in parameters['raw_groups']}
        assert len(raw) == len(parameters['raw_groups']) and all(v >= 0 for v in raw.values())
        weights = defaultdict(F)
        for _, mass, label in split_field(measure, corner, width):
            if label is not None:
                weights[label] += mass
        assert set(raw) == set(weights)
        savings = sum((1-raw[k])*weights[k] for k in raw)
        blend = F(parameters['removed_mass'])/savings
        if 'quantized_change' in parameters:
            blend = rounded_blend(blend)
        assert 0 < blend <= 1
        factors = {k: 1+(v-1)*blend for k,v in raw.items()}
    else:
        factors = {tuple(record[:3]): F(record[3]) for record in parameters['groups']}
        assert len(factors) == len(parameters['groups'])
    assert all(v >= 0 for v in factors.values())
    full, local = [], []
    original = F(0)
    captured = F(0)
    included = F(0)
    used = set()
    pieces = list(split_field(measure, corner, width))
    scale = parameters.get('quantized_change')
    if scale is not None:
        assert isinstance(scale, int) and scale > 0
        # Each rounded change leaves at least as much mass as the proposed factor.
        changes = [F(floor(weight * (1-factors[label]) * scale), scale) if label is not None else F(0)
                   for _, weight, label in pieces]
        extra = sum(changes) - F(parameters['removed_mass'])
        assert extra >= 0
        keeper = max(range(len(changes)), key=changes.__getitem__)
        assert changes[keeper] >= extra
        changes[keeper] -= extra
    for i, (box, weight, label) in enumerate(pieces):
        original += weight
        adjusted = (weight - changes[i] if scale is not None else
                    weight if label is None else weight * factors[label])
        assert adjusted >= 0
        if label is not None:
            used.add(label)
        captured += adjusted
        record = dict(rectangle=[str(v*board_scale) for v in box], mass=str(adjusted))
        full.append(record)
        x, y, X, Y = box
        if min(x, side-X) <= corner + F(142,100)/board_scale and min(y, side-Y) <= corner + F(142,100)/board_scale:
            local.append(record)
            included += adjusted
    assert used == set(factors) and original == F(measure['total_mass']) and captured < original
    assert original - captured == F(parameters['removed_mass'])
    side*=board_scale;corner*=board_scale
    modified = dict(measure, L=str(side),rectangles=full, total_mass=str(captured))
    kept = dict(measure, L=str(side),rectangles=local, total_mass=str(included))
    radius = F(707107,10**6)
    assert 2*radius**2 >= 1
    lower = floor(check.bm.G * (side - corner - radius))
    near = lower - ceil(check.bm.G * radius)
    rows = [row for row in check.bm.rows(kept) if row[6] >= near and row[7] >= near]
    return modified, check.input_bytes(rows), lower


def header(measure, lower, k, i):
    h = check.header(dict(measure,B='1',proof_net=dict(step=str(F(83,200*k)),last=k)),i,'octagon-gram')
    h[5], h[6] = max(lower, h[5]), max(lower, h[6])
    assert h[5] <= h[7] and h[6] <= h[8]
    return h


def check_angular_union(pairs):
    seen=set();intervals=[]
    for k,i in pairs:
        assert type(k) is int and type(i) is int and k>0 and 0<=i<=k and (k,i) not in seen
        seen.add((k,i));step=F(83,200*k)
        intervals.append((max(F(0),(i-F(1,2))*step),(i+F(1,2))*step))
    end=F(0)
    for left,right in sorted(intervals):
        assert left<=end
        end=max(end,right)
    assert end*end+2*end>=1


def inherited_grid(source, parameters, scale):
    shrink=F(parameters.get('board_scale','1'))
    assert shrink<F(scale)<=1
    measured,raw,low=prepare(source,dict(parameters,board_scale=str(F(scale))))
    assert sha256(raw).hexdigest()==parameters['inherited_grids'][scale]
    return measured,raw,low


def verify_local(folder, source, replay=False, workers=1):
    p=json.loads((folder/'parameters.json').read_text())
    modified,raw,low=prepare(source,p)
    assert sha256(raw).hexdigest()==p['integer_grid_sha256']
    evidence={'target':(modified,raw,low)}
    for scale in p.get('inherited_grids',{}):
        evidence[scale]=inherited_grid(source,p,scale)
    receipts=json.loads(gzip.decompress((folder/'receipts.json.gz').read_bytes()))
    check_angular_union([(r['K'],r['r']) for r in receipts])
    for r in receipts:
        geom,_,bound=evidence[r.get('inherited_scale','target')]
        assert header(geom,bound,r['K'],r['r'])==r['header']
        assert r['verdict']=='PASS' and r['nodes']==2*r['leaves']-1 and r['leaves']>0 and 0<=r['depth']<=65 and r['lower_units']>=check.bm.M
    assert len(receipts)==p['directions'] and sum(r['nodes']for r in receipts)==p['nodes']
    if replay:
        with tempfile.TemporaryDirectory()as td:
            temp=Path(td);binary=temp/'gram';grids={}
            for index,(scale,(_,data,_)) in enumerate(evidence.items()):
                grids[scale]=temp/f'grid-{index}';grids[scale].write_bytes(data)
            subprocess.run(['c++','-O3','-std=c++17',check.here/'gram.cpp','-o',binary],check=True)
            def test(r):
                q=temp/f"{r['K']}_{r['r']}.txt";q.write_text(' '.join(map(str,r['header'])))
                v=subprocess.run([binary,grids[r.get('inherited_scale','target')],q,'1200000'],text=True,capture_output=True,check=True).stdout.split()
                assert v==[str(r[k]) for k in ['verdict','nodes','leaves','clips','depth','lower_units']]
            with ThreadPoolExecutor(workers)as ex:list(ex.map(test,receipts))
    return modified
