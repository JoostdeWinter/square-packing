"""Replay an enlarged wall strip against the original unmodified geometric verifier."""
import argparse
import hashlib
import json
from fractions import Fraction
from pathlib import Path
import subprocess
import sys
import tempfile
from zipfile import ZipFile

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("case",type=Path)
    parser.add_argument("--source",type=Path,default=Path(__file__).resolve().parent.parent/"parallel-chords/tilt-input.zip")
    parser.add_argument("--workers",type=int,default=3)
    parser.add_argument("--pinned-floors",action="store_true")
    parser.add_argument("--receipt",type=Path)
    a=parser.parse_args()
    assert __debug__
    assert hashlib.sha256(a.source.read_bytes()).hexdigest()=="81deab2f7a88bd337f3aa5fa745212dbf9d116dcfd7d9784c059b4ad0c71a1dd"
    result=json.loads((a.case/"result.json").read_text())
    with tempfile.TemporaryDirectory() as temporary:
        root=Path(temporary)
        with ZipFile(a.source) as z:z.extractall(root)
        claims=json.loads((root/"claims.json").read_text())
        row=next(r for r in claims if r["n"]==result["n"])
        assert result["prior"]==row["side"] and Fraction(result["gain"])==Fraction(result["side"])-Fraction(row["side"])>0
        assert result["relation"] in (">=",">")
        (root/row["shells"][-1]).write_bytes((a.case/"wall.json").read_bytes())
        if row.get("extra_split"):
            (root/row["extra_split"]).write_bytes((a.case/"extra.json").read_bytes())
        if "terms" in result:row["terms"]=result["terms"]
        for k in ("side","E","margin","capture","intercept","relation","surplus"):
            row[k]=result[k]
        (root/"claims.json").write_text(json.dumps(claims))
        cmd=[sys.executable,"-B",str(root/"replay.py"),"--only",str(row["n"]),"--workers",str(a.workers)]
        if a.pinned_floors:cmd.append("--use-pinned-floors")
        if a.receipt:cmd.extend(["--receipt",str(a.receipt.resolve())])
        subprocess.run(cmd,check=True)

if __name__=="__main__":main()
