"""Restore the exact original input ZIP using the shared prior certificate."""
from hashlib import sha256
from pathlib import Path

here = Path(__file__).resolve().parent
reference = here.parents[2] / 'wall' / 'prior_certificates.zip'
data = (here/'input-prefix.bin').read_bytes() + reference.read_bytes() + (here/'input-suffix.bin').read_bytes()
if sha256(data).hexdigest() != '7488b81cc5f8624a4b9c32bdc2b5e9a3b31e7a10b2e3b53a7cba0d74a87a576b':
    raise ValueError('The reconstructed ZIP has an unexpected checksum.')
(here/'four-input.zip').write_bytes(data)
