"""Stronger parallel-chord bounds using four earlier clipped-board certificates."""
from fractions import Fraction as F
from pathlib import Path
from math import isqrt
from zipfile import ZipFile
from tempfile import TemporaryDirectory
from hashlib import sha256
import argparse,json,sys,subprocess
here=Path(__file__).resolve().parent
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--source',type=Path,default=here/'four-input.zip')
 ap.add_argument('--lemma',type=Path,default=here.parent/'parallel-chords')
 ap.add_argument('--probe',type=F);ap.add_argument('--search',action='store_true');ap.add_argument('--full',action='store_true')
 ap.add_argument('--only',nargs='+',type=int,default=[190,247,249,280])
 a=ap.parse_args()
 assert __debug__ and sha256(a.source.read_bytes()).hexdigest()=='7488b81cc5f8624a4b9c32bdc2b5e9a3b31e7a10b2e3b53a7cba0d74a87a576b'
 sys.path.insert(0,str(a.lemma.resolve()))
 from chords import missing_area,check_constants
 assert check_constants()
 with TemporaryDirectory() as td:
    tmp=Path(td);wall=tmp/'wall'
    with ZipFile(a.source) as z:z.extractall(wall)
    if a.full:subprocess.run([sys.executable,'-B',str(wall/'verify.py'),'--workers','2','--only',*map(str,a.only)],check=True)
    outer=tmp/'outer';base=tmp/'base'
    with ZipFile(wall/'prior_certificates.zip') as z:z.extractall(outer)
    with ZipFile(outer/'baseline.zip') as z:z.extractall(base)
    sys.path[:0]=[str(wall),str(base)]
    from mass import certificate,capture_surplus,public_weights,compile_checker,read
    from context_v8 import coverage,previous
    from independent import audited_line
    from line_gaps import missing_line,profiles
    oldrows={r['n']:r for r in read(wall/'claims.json')}
    checkout=public_weights(base,tmp)
    bin=tmp/'intervals';compile_checker(previous.WEIGHTED/'asymmetric/intervals.cpp',bin)
    for n in a.only:
        d=tmp/f'{n}';d.mkdir()
        r=oldrows[n];orig=F(r['side']);q=isqrt(n)+1;c=q-F(38,5)
        cl,f,m,E=certificate(base,outer,n);B=m['b_micro'];b=F(B,10**6);e=F(E,10**6);peak=(q+2*e)/b
        table=coverage.get_table(f,checkout);pr=profiles(table,q,coverage)
        def margin(S,cross=False):
            ar=missing_area(c,b,((q+2*e)/S-b)/2)
            if r['family']=='clipped_disk':
                ln=missing_line(q,B,E,S,pr)
                if cross:assert ln==audited_line(table,q,b,e,S)
            else:
                mesh=(cl['mesh'],cl['length_classes'],cl['angle_classes']) if n==280 else cl['dp']
                ln=previous.surplus(f,q,n,S,*mesh,executable=bin,work=d,checkout=checkout)[4]
            sur=capture_surplus(n,S,cl,m);return sur+ar+ln
        path=here/f'n{n}.json'
        if a.probe:
            S=orig+a.probe
            if S>=peak or margin(S)<=0:
                print('unresolved probe',n,str(S),flush=True);continue
        elif a.search:
            lo=int(orig*10**9);hi=int(peak*10**9)+1
            if r['family']=='clipped_disk_dp':
                mesh=cl['mesh'] if n==280 else cl['dp'][0]
                hi=min(hi,int((q/(b+F(2,mesh)))*10**9)+1)
            while hi-lo>1:
                mid=(lo+hi)//2
                if margin(F(mid,10**9))>0:lo=mid
                else:hi=mid
            S=F(lo,10**9)
        else:S=F(read(path)['side'])
        mrg=margin(S,True);assert orig<S<peak and mrg>0
        result=dict(n=n,relation='>',side=str(S),prior=str(orig),gain=str(S-orig),margin=str(mrg))
        if a.search or a.probe:
            if not path.exists() or F(read(path)['side'])<S:path.write_text(json.dumps(result,indent=2)+'\n')
        else:assert result==read(path)
        print('PASS',n,float(S),float(S-orig),flush=True)
if __name__=='__main__':main()
