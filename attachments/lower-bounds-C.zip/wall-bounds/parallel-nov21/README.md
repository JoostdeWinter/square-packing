# Ten lower-bound updates

The 00:05 UTC checkpoint on 21 November 2026 certifies ten improvements over the initial 166-count draft. Eight of them strengthen the 23:12 checkpoint handoff. The table in `results.csv` compares both drafts. Five inequalities use the parallel-chord estimate in `parallel-chords/PROOF.md`. The 190-square case uses the same idea with a different certificate. The 162- and 318-square proofs extend periodic wall regions. The 28- and 37-square cases extend rectangle densities at the walls. The separate proof folders supply the original work, attributions and replay receipts.

Extract A, B and C together and run `python3 prepare.py` at the top level to rebuild the pinned input for 28, 37 and 190. From this directory run the following commands for a complete replay:

    python3 -B parallel-chords/verify.py --full --workers 4
    python3 -B wall-extension/replay.py wall-extension/n162 --workers 4
    python3 -B wall-extension/replay.py wall-extension/n318 --workers 4
    python3 -B additional-counts/small_search.py --only 28 37 --full
    python3 -B additional-counts/verify.py --only 190 --full

The earlier native run in `additional-counts/earlier-190-replay.log` was for the preceding 190-square endpoint. The current check uses the same native foundation and updated rational area bound. The receipt for each periodic-wall case states whether its original base enumeration was regenerated during that particular run.
