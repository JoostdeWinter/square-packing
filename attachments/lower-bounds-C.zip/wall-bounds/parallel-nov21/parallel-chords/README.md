# Stronger lower bounds for freely rotated unit squares

The exact rational endpoints and strict inequalities are in records.csv, together with the private predecessor and the exact improvement. PROOF.md proves the new geometric estimate. Run `python3 -B verify.py` to check the rational inequality on its full domain, reconstruct the weights, independently cross-check the line mass and reproduce every positive surplus, using the archived capture receipts. Run `python3 -B verify.py --full --workers 4` to regenerate the underlying native geometry and the capture receipts as well. The full replay needs a C++17 compiler. Both run offline using Python 3.10+.

For example, `python3 -B verify.py --only 163 --full --workers 4` checks a single count. The complete previous geometry, kernel, proofs and provenance accompany the new result. The excluded board and all comparisons use the rational numbers, including where a decimal is displayed in a log.
