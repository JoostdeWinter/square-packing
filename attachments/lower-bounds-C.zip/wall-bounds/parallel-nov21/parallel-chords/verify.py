"""Check or search the endpoints using the enclosed tilt certificate."""
import argparse,csv,hashlib,io,json,subprocess,sys,tempfile
from fractions import Fraction as Q
from math import isqrt
from pathlib import Path
from zipfile import ZipFile
from chords import check_constants,missing_area

ROOT=Path(__file__).resolve().parent
def main():
    p=argparse.ArgumentParser()
    p.add_argument('--search',action='store_true')
    p.add_argument('--only',type=int,nargs='+')
    p.add_argument('--full',action='store_true',help='Regenerate native geometry and capture for selected rows before the new arithmetic.')
    p.add_argument('--workers',type=int,default=4)
    a=p.parse_args()
    if not __debug__:raise RuntimeError('Enable assertions.')
    assert check_constants()
    source=ROOT/'tilt-input.zip'
    assert hashlib.sha256(source.read_bytes()).hexdigest()==(ROOT/'source-sha256.txt').read_text().strip()
    answers=[]
    with tempfile.TemporaryDirectory() as td:
        work=Path(td);tilt=work/'tilt';foundation=work/'foundation'
        with ZipFile(source) as z:z.extractall(tilt)
        with ZipFile(tilt/'foundations.zip') as z:z.extractall(foundation)
        base=foundation/'baseline';ref=foundation/'reference'
        sys.path[:0]=[str(tilt),str(ref),str(base)]
        from mass import public_weights
        from context_v8 import coverage
        from line_gaps import profiles,missing_line
        from independent import audited_line
        specs=json.loads((tilt/'claims.json').read_text())
        rows=[r for r in specs if r['relation']=='>' and (not a.only or r['n'] in a.only)]
        if a.only:assert {r['n'] for r in rows}==set(a.only)
        receipt=json.loads((tilt/'verification.json').read_text())['claims']
        if a.full:
            dest=work/'replay.json'
            subprocess.run([sys.executable,'-B',str(tilt/'replay.py'),'--only',*[str(r['n']) for r in rows],'--workers',str(a.workers),'--receipt',str(dest)],check=True)
            receipt=json.loads(dest.read_text())['claims']
        caps={r['n']:r for r in receipt}
        weights=public_weights(base,work/'sourcefiles')
        targets={} if a.search else {int(r['n']):Q(r['side']) for r in csv.DictReader((ROOT/'records.csv').open())}
        for r in rows:
            n,B,E=r['n'],r['B'],r['E'];b,e=Q(B,10**6),Q(E,10**6);q=isqrt(n)+1;c=q-Q(38,5)
            field=base/r['field']; meta=json.loads((field/'geometry.json').read_text())
            cap=caps[n];assert cap['capture']==r['capture']
            surplus=Q(cap['capture']-meta['total_masses'][str(q)],2*10**12)
            table=coverage.get_table(field,weights);parts=profiles(table,q,coverage)
            def values(S):
                d=((q+2*e)/S-b)/2
                return missing_area(c,b,d),missing_line(q,B,E,S,parts)
            prev=Q(r['side'])
            if a.search:
                lo,hi=int(prev*10**12),int((q+2*e)/b*10**12)+1
                while hi-lo>1:
                    mid=(lo+hi)//2;ar,ln=values(Q(mid,10**12))
                    if surplus+ar+ln>0:lo=mid
                    else:hi=mid
                S=Q(lo,10**12)
            else:S=targets[n]
            ar,ln=values(S)
            assert prev<S<(q+2*e)/b and ln==audited_line(table,q,b,e,S) and surplus+ln+ar>0
            answers.append(dict(n=n,relation='>',side=str(S),prior=str(prev),gain=str(S-prev),margin=str(surplus+ln+ar)))
            if not a.search:
                recorded=next(row for row in csv.DictReader((ROOT/'records.csv').open()) if int(row['n'])==n)
                assert all(str(answers[-1][k])==v for k,v in recorded.items())
            print(f'PASS {n} > {float(S):.12f}  gain {float(S-prev):.5g}',flush=True)
    if a.search:
        with (ROOT/'records.csv').open('w',newline='') as f:
            wr=csv.DictWriter(f,fieldnames=list(answers[0]));wr.writeheader();wr.writerows(answers)
if __name__=='__main__':main()
