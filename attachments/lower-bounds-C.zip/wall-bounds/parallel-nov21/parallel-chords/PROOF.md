# A parallel slice bounds the perimeter lost at a window edge

Let disjoint-interior, freely rotated squares of side a each contain a parallel concentric test square of side b<a. Write d=(a-b)/2. In an axis-aligned square C of side c, the test squares cover area A. We prove a lower bound on c²−A. The argument only uses the fact that the a-squares have disjoint interiors.

For each positive-area intersection K of a test square with C, the divergence formula about the test square's center gives twice the area of K as the sum of the signed normal distance h times the length of each edge. Edges on the test square have h=b/2. Thus the sum P of the perimeters satisfies

    4A/b − P = sum over edges on C of (2h/b−1) times edge length.

Only h>b/2 can contribute positively. Normalize lengths by b. Fold the orientation so that u=cos θ ≥ v=sin θ ≥0, and put H=(u+v)/2. For v=0 there is no positive charge. Otherwise a line at signed distance h in [1/2,H] cuts a tip of the unit square in a chord of length (H−h)/(uv). This chord formula follows by projecting the two edges issuing from the extreme vertex onto the cutting line. The full chord at distance x from the center has length min(1/u,(H−|x|)/(uv)).

For every contributing chord on a fixed side of C, look at the chord of the same tile on the parallel line 3b/5 inward from that side. In normalized coordinates its length is the chord length at x=h−3/5. The original positive charge is at most 0.034 times this second length. Here is the finite rational check of the constant. With t=tan(θ/2), w=u+v, h=(1+(w−1)z)/2 and 0≤z≤1, the ratio is the larger of

    t(1−t)² z(1−z)/(1+t²)
    (w−1)² z(1−z) / (2(w/2−|h−3/5|)).

The first expression follows by division by the central-chord branch 1/u, the second by division by the triangular branch. The routine check_constants subdivides 0≤t≤sqrt(2)−1 in steps of 1/1000 and z in steps of 1/40. On the last t interval it uses the rational upper bound 1.41422 for w. It verifies both bounds by outward rational inequalities on every closed rectangle, including the endpoint limits. Truncating the original tip chord to the side segment can only reduce the positive charge.

The inward chords have disjoint interiors. The tilts giving positive charge have v>0, so these are transverse slices through tile interiors. Pick a point of the original chord on the side segment. Its tangential distance to the tile center is at most b/2 since its normal distance is at least b/2 and the circumradius is b/sqrt(2). Every point of the inward chord is within tangential distance b/sqrt(2) of that center. A sharper enclosure uses the two lines in the same tile. In coordinates with x normal to the boundary and y tangent, each point satisfies |ux+vy|≤1/2 and |−vx+uy|≤1/2. The function cut encloses the admissible y-interval on each slice, first at x=h and then at x=h−3/5, using the rational orientation and depth boxes above. Subtracting the intervals bounds every tangential displacement by 1.01b. Thus all inward chords fit in a line interval of length c+2(1.01)b. Summing over the four sides gives P ≥ 4A/b−D with D=4(0.034)(c+2(1.01)b).

For m positive-area pieces, expand each K by a Euclidean disk of radius d. The expansion lies in its own a-square and in C expanded by d. The expansions have disjoint interiors. Adding their areas by the polygon parallel-area formula gives

    A + dP + πd²(m−1) ≤ c²+4cd.

Let p=3.14159<π, verified using Machin’s identity and the alternating arctangent series in the checker. As m is an integer and A≤mb², we obtain the upper bound

    max over integers 1≤m≤ceil(c²/b²) of
      min(c², mb², [c²+4cd+dD−p d²(m−1)]/[1+4d/b]).

Larger values of m only decrease the third argument after the mb² constraint ceases to bind. If there are no pieces, A=0. The checker also includes zero among the candidate upper bounds.

For each row, use the stated earlier certificate's measure and orientation-dependent capture bounds. In its scaled coordinates q is the next integer above sqrt(n), the board side is q+2e, c=q−38/5, and a=(q+2e)/S. Captured mass plus compulsory missed line mass plus the stronger missed area exceeds the total available mass by the exact rational margin in records.csv. The inner squares lie strictly inside the corresponding a-squares, which prevents double counting even if outer boundaries touch. This excludes the closed board at S. Compactness of the translation and rotation parameters gives s(n)>S.

The previous capture and line lemmas, source weights and credits are in tilt-input.zip. This argument adds the charge on a parallel chord and keeps the integer count in the parallel-area estimate. Research directed by Joost de Winter with GPT-6.2 Astra. Underlying periodic measures by Mohsen Khalili and Sara Gharabaghi, with additional provenance in the included certificate.

### Counting the interior squares

Inset C on each of its four sides by √2(b+d), or by the slightly larger rational amount chosen by the checker. Call the remaining square H and denote its side by h, taking h=0 when it is empty. Every test square that meets H lies wholly in C, since its diameter is √2 b. Its full concentric outer square also lies in C because any added point is within √2 d of the test square. Use the entire outer square in the area sum for each such tile. It occupies (4−π)d² more area than the rounded expansion. This replacement preserves containment and disjoint interiors.

If R tiles meet H, the area covered inside H is at most R b². Outside H the covered area is at most c²−h², giving R ≥ (A−c²+h²)/b². Since 4−π>6/7, the earlier area inequality gains a nonnegative term that is at least (6/7)d²(A−c²+h²)/b². Retain both the original inequality and this strengthened one; solving each for A gives the two rational upper bounds in upper(m). The checker verifies both π bounds using 16 atan(1/5)−4 atan(1/239).
