# Sixteen stronger lower bounds for squares in a square

The largest improvement over the preceding private draft is at 129. A square of side 229937/20000 = 11.49685 cannot contain 129 freely rotating closed unit squares with pairwise disjoint interiors. The earlier 166-count draft gave 11.492. The 155-count filing in issue 1042 gave 11.4915.

`bounds.csv` lists the 16 strict inequalities, including the exact gain over each comparison. `claims-166-updated.csv` is the revised master table. The same 166 counts appear in the earlier draft. Ten further rows incorporate the parallel study’s stronger certificates at 28, 37, 162, 163, 190, 248, 250, 283, 314 and 318. Their proof and replay instructions are in `parallel-nov21/README.md`. The other 140 rows retain their earlier proofs. Their inputs are available in the original two attachments. This ZIP is self-contained for the sixteen wall extensions and seven of the ten parallel-study updates. The 28-, 37- and 190-square proofs reuse the exact input from A and B.

## Reproduce

Unzip the archive, open the `wall-bounds` directory and run the following with Python 3.10+ and a C++17 compiler supporting signed 128-bit integers. All measures, inputs and verifier sources for these 16 cases are included. Python uses the standard library.

    python3 -B replay.py --only 129 --workers 4 --full-core
    python3 -B replay.py --workers 4 --full-core --receipt reproduced.json

Omitting `--full-core` validates the archived interior checks and reruns the old and new wall geometry. Adding it also recompiles and reruns the inherited interior geometry, its negative controls and the inherited corner repair for 187. The checker raises an error at the first failed certificate. `verification.json` records the checks performed in preparing this archive.

## Why the wall check suffices

For each count, the certificate gives a nonnegative measure made of rectangles of uniform density. Its total mass is strictly less than the number of squares. Every unit square on the enlarged board must capture mass at least one. Tile boundaries have measure zero, so a feasible packing would capture at least as much mass as there are squares. This contradicts the total mass. Feasible packings attain their minimum enclosing side by compactness of the center and orientation parameters and closedness of containment and interior-disjointness. Exclusion at the tested side therefore gives a strict lower bound.

The construction holds the measure fixed while expanding the board concentrically. Let the source board be [0,L]² and let T₀ be the previously certified side. The proof for T₀ covers all placements inside that board with the same weighted measure. After a rotation through a multiple of 90 degrees we may put the tile center in the upper right quadrant. A diagonal reflection lets us take its angle θ between 0 and π/4. These operations preserve the measure and both boards. A placement on a larger board of side T that escapes the old board must cross its right or top wall. On the corresponding axis the center coordinate u must satisfy

    (L + T₀)/2 − h(θ) < u ≤ (L + T)/2 − h(θ),
    h(θ) = (cos θ + sin θ)/2.

The verifier writes h = (1 + 2t − t²)/(2(1 + t²)), with t = tan(θ/2). This function is increasing on the angular range of interest. For each rational interval in t, it uses both endpoints to enclose the possible center coordinates and rounds outward on the fixed-point lattice. At π/4 it bounds h from above by 707107/1000000. It checks the union of intervals on each of the two walls reaches tan(π/8) without gaps.

The original compiled geometry program proves the mass bound throughout each resulting center box. It uses an inscribed polygon valid for the entire angular interval, exact integer lower estimates of overlap, and subdivision of the center domain. Floating point may propose intersection vertices. The decisive containment and area bounds use integer arithmetic. See `checker/INTEGER_CHECKER.md` for the interpolation argument and integer units.

For 187 the interior starts with the included 161-square source measure, repeats a unit-period strip and applies the archived corner repair. The verifier reconstructs and checks these stages before testing the enlarged wall. The other 15 cases use the included interior measure directly.

## What limits the 129-square proof

At side 11.496851, an upright unit square touching the right wall, with center height 9.993935 in source-board coordinates, captures only 0.999994193302 units of the chosen measure. At side 11.4969, an upright unit square touching the top and right walls captures only 0.998109591397 units of the chosen measure. At side 11.5 it captures only 0.522941895495. The first example lies exactly 0.000001 above the certified lower endpoint. Because the board of side 11.496851 embeds concentrically into every larger one, the first placement also obstructs the same fixed-measure proof on every larger board. A different weighting or additional packing constraints would be needed to reach 11.5. The construction and exact fractions can be reproduced with `python3 -B check_129_limit.py`.

## Credits and earlier filing

Joost de Winter directed this continuation with GPT-6.2 Astra in OpenAI Codex. The work extends earlier certificates based on Hiroaki Hosono’s measures. The prior certificate inputs and verifier sources are included with their hashes. The present contribution is the tighter wall restriction and its sixteen verified extensions.

[155-count filing and prior attachment](https://github.com/jlevy/squares/issues/1042#issuecomment-7022143149)
