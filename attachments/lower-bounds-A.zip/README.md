# Lower bounds for 166 square counts

Extract all three ZIPs into the same directory and run `python3 prepare.py`. The registration request is the 166 distinct rows in `claims-166.csv`. The copy at `wall-bounds/claims-166-updated.csv` is identical. Each row gives its comparison sign and exact rational endpoint.

## Replay

Use Python 3.10+ with assertions enabled and a C++17 compiler. The proof_directory column selects the verifier. For the sixteen wall extensions run `python3 -B wall-bounds/replay.py --workers 4 --full-core`. For the ten other updated rows follow `wall-bounds/parallel-nov21/README.md`. For the remaining 140 rows use the replay commands in `earlier-proof-guide.md`. Its historical counts and examples describe the previous draft.

Sixty explicitly flagged rows use Hiroaki Hosono’s T-180 for coverage away from the modified corners. The other entries have their individual proof sources and credit in the respective proof folders.
