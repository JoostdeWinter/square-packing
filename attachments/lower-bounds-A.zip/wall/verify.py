"""Replay strictly improved square-packing lower bounds, including geometry by default."""
import argparse
import csv
import hashlib
import json
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

from clipped_area import clipped_disk_bound
from independent import area_from_upper, audited_line
from mass import (capture_surplus, certificate, compile_checker, public_weights,
                  read, verify_extra_capture)

HERE = Path(__file__).resolve().parent
PRIOR_HASH = "5bb8b275c3f1cf67349875918d126ef8359044b727bc6696ed1bb76ff061d72a"
EXTRA = {247, 249, 280}


def unpack(work):
    packed = HERE / "prior_certificates.zip"
    assert hashlib.sha256(packed.read_bytes()).hexdigest() == PRIOR_HASH
    outer = work / "reference"
    base = work / "baseline"
    with ZipFile(packed) as z:
        z.extractall(outer)
    with ZipFile(outer / "baseline.zip") as z:
        z.extractall(base)
    return outer, base


def replay(rows, outer, base, work, workers, stored, foundations, public_kernel, public_family):
    from context_v8 import coverage, previous
    from line_gaps import missing_line, profiles

    counts = sorted({r["n"] for r in rows if r["n"] not in EXTRA and r["family"] != "boundary"})
    old_receipts = {}
    if counts and not stored:
        receipt = work / "captures.json"
        subprocess.run([sys.executable, "-Bu", outer/"verify.py", "--workers", str(workers),
                        "--only", *map(str, counts), "--receipt", receipt], check=True)
        raw = read(receipt)
        assert not raw["reused_pinned_baseline"]
        old_receipts = {r["n"]: r for r in raw["claims"]}
        assert set(old_receipts) == set(counts)
    checkout = public_weights(base, work)
    if public_family:
        source_info=read(base/"prior/replays/source_inputs.json")["public_family"]
        for filename, digest in source_info["verified_inputs"].items():
            assert hashlib.sha256((public_family/filename).read_bytes()).hexdigest()==digest
            assert (public_family/filename).read_bytes()==(checkout/filename).read_bytes()
        checkout=public_family
    with (outer / "all_167.csv").open() as f:
        previous_rows = {int(r["n"]): r for r in csv.DictReader(f)}
    public={r["n"]: r for r in read(HERE/"comparison.json")["case_records"]}
    outcomes = []
    for row in rows:
        n = row["n"]
        side = F(row["side"])
        old = F(row["previous"])
        comparator = previous_rows[n]
        assert 1 < n < 325 and n != 19
        assert old == F(comparator["lower_bound_exact"]) < side
        if n >= 20:
            assert side > F(99,20)  # The monotone consequence of the newer filing at 20.
        assert side > F(public[n]["reported_lower"][1])
        assert side > F(public[n]["verified_lower"][0])
        assert side > max(F(r["lower_bound_exact"]) for k, r in previous_rows.items() if k <= n)
        for name in ("public_reported_lower_reference", "issue_1042_later_155_count_filing_at_n",
                     "earlier_public_or_pending_comparison_ceiling"):
            if comparator[name]:
                assert side > F(comparator[name])
        if row["family"] == "boundary":
            from small import verify_boundary
            result = verify_boundary(n, row, base, work, workers, stored, foundations, public_kernel)
            outcomes.append(result)
            print(f"PASS n={n}  s(n) > {side}  added angle intervals={result['angle_intervals']}", flush=True)
            continue
        q = isqrt(n)+1
        claim, field, meta, E = certificate(base, outer, n)
        local = work / f"n{n}"
        local.mkdir()
        if n in EXTRA:
            if not stored:
                verify_extra_capture(n, local, base, checkout, claim, field, meta, workers)
        elif not stored:
            assert old_receipts[n]["status"] == "PASS"
            assert old_receipts[n]["verified_capture"] >= claim["capture"]
            assert F(old_receipts[n]["exact_side"]) == old
        B = meta["b_micro"]
        b, e = F(B, 10**6), F(E, 10**6)
        c = q - F(38, 5)
        d = ((q+2*e)/side-b)/2
        assert d > 0 and row["relation"] == ">"
        missed = clipped_disk_bound(c, b, d)
        assert missed == area_from_upper(c,b,d) == F(row["root_area"])
        raw_table = coverage.get_table(field, checkout)
        if row["family"] == "clipped_disk":
            line = missing_line(q,B,E,side,profiles(raw_table,q,coverage))
            assert line == audited_line(raw_table,q,b,e,side)
        else:
            assert row["family"] == "clipped_disk_dp" and E == 0
            binary = local / "intervals"
            compile_checker(previous.WEIGHTED/"asymmetric/intervals.cpp", binary)
            mesh = (claim["mesh"],claim["length_classes"],claim["angle_classes"]) if n==280 else claim["dp"]
            line = previous.surplus(field,q,n,side,*mesh,executable=binary,work=local,checkout=checkout)[4]
            assert line == F(row["line_loss"])
        capture = capture_surplus(n, side, claim, meta)
        margin = capture + missed + line
        assert margin == F(row["margin"]) > 0
        outcomes.append(dict(n=n, side=str(side), relation=">", previous=str(old), capture_minus_total=str(capture),
                             clipped_area=str(missed), missed_line_mass=str(line), margin=str(margin)))
        print(f"PASS n={n}  s(n) > {side}  gain={side-old}", flush=True)
    return outcomes


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workers",type=int,default=4)
    parser.add_argument("--only",type=int,nargs="+")
    parser.add_argument("--arithmetic-only",action="store_true",help="Read the pinned geometry data and recheck the final inequalities.")
    parser.add_argument("--receipt",type=Path)
    parser.add_argument("--replay-foundations",action="store_true",help="Additionally regenerate archived native foundation checks for small counts where the archive supplies that checker.")
    parser.add_argument("--public-kernel",type=Path,help="Rebuild the pinned public gram.cpp separately and compare every new boundary verdict and work count.")
    parser.add_argument("--public-family",type=Path,help="Use a checkout of the pinned public family measure.")
    args=parser.parse_args()
    if not __debug__ or args.workers < 1:
        parser.error("Enable assertions and use at least one worker.")
    rows=read(HERE/"claims.json")
    assert len(rows)==len({r["n"] for r in rows})
    if args.only:
        rows=[r for r in rows if r["n"] in args.only]
        assert set(args.only)=={r["n"] for r in rows}
    with TemporaryDirectory() as td:
        work=Path(td)
        outer,base=unpack(work)
        sys.path.insert(0,str(base))
        result=replay(rows,outer,base,work,args.workers,args.arithmetic_only,
                      args.replay_foundations,args.public_kernel,args.public_family)
    assert len(result)==len(rows)
    if args.receipt:
        args.receipt.write_text(json.dumps(dict(new_geometry_replayed=not args.arithmetic_only, historical_native_replay_requested=args.replay_foundations, public_kernel_compared=bool(args.public_kernel), public_family_compared=bool(args.public_family),claims=result),indent=2)+"\n")
    print(f"Verified {len(rows)} strictly improved endpoints.",flush=True)


if __name__=="__main__":
    main()
