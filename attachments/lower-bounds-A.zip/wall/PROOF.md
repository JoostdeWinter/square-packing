# Excluding a closed square at an exact rational side

Research direction and credit go to Joost de Winter. GPT6.2 Astra is the AI author. Every unit square may rotate and translate independently. The claims in this package are lower bounds for the side of the containing square.

## Extending a rectangle-density certificate at small counts

Use a nonnegative measure made of finitely many uniformly weighted rectangles and their eight symmetry images. The reference certificate gives a rectangle measure on a centered board of side L such that every contained closed unit square captures mass at least one. The prior certificate scales up the weights, and in some cases assigns part of the available weight to a strip. Its total mass remains less than n. It proves coverage on a larger centered board of side T₀ using a wall check. The archive binds each source measure to its reference certificate. All comparisons of lengths, angular interval endpoints and masses in the replay are exact.

Keep that same weighted measure, in the same coordinates, while enlarging the board to side T. Any newly admitted unit square crosses a wall of the T₀ board. The old and new boards have a common center at (L/2,L/2). By reflections and transposition, the center of the tile can be put in the upper-right quadrant and its angle represented in [0,π/4]. The nearest crossing wall in that quadrant is then the right or the top wall. In the case of multiple crossings it suffices that one check applies.

Let h(θ)=(cos θ+sin θ)/2 be a tile's half-width in either board direction. In the case of the right wall its center coordinate x satisfies

    (L+T₀)/2 − h(θ) < x ≤ (L+T)/2 − h(θ).

For the top wall use the same inequality for y. On each angle interval use the interval maximum of h in the lower cutoff, and the interval minimum in the upper cutoff. The checker rounds the resulting center region outwards. For angles up to 45 degrees h is increasing. The formula evaluated at t=tan(θ/2) is (1+2t−t²)/(2(1+t²)). At the 45-degree end, 0.707107 is an upper enclosure for h. Centers inside the T₀ board retain the original coverage. This narrower additional center region and adaptive angular subdivision make a further extension possible.

The saved intervals cover the full closed range from 0 to tan(π/8) on each of the two walls. The geometric kernel uses a common inner octagon on each interval and verifies a mass of at least one everywhere in its center region. It subdivides the center region until every leaf passes. Integer lower bounds handle polytope areas and comparisons. The inherited checker documentation explains its support-function bounds and fixed-point rounding. The separate one-interval public executable and the local batch implementation can be run on the same headers. The batch implementation clears the orientation-dependent cache and every geometric counter after each interval.

Thus n such squares would capture a total of at least n. Their interiors are disjoint, and rectangle area measures give zero mass to their boundaries, so the available total is strictly less than n. This excludes the *closed* board of side T. Since the feasible centers and angles form a compact closed set when the side is bounded above, the minimum packing side is strictly larger than T.

## A bound on area left between smaller concentric squares

Let the outer squares have side a, disjoint interiors, and arbitrary orientations. In each put a parallel, concentric square of side b<a. Fix an axis-aligned square C of side c>b, and write d=(a−b)/2. Let A be the area of C covered by the smaller squares. The following argument bounds c²−A using c, b and d only.

Write Kᵢ for each positive-area intersection of an inner square and C. Write m for their number and P for the sum of their perimeters. The centers are mᵢ. The closed Euclidean d-neighborhood of each Kᵢ fits in the corresponding outer square and in the d-neighborhood of C. The neighborhoods therefore have disjoint interiors. The area of the d-neighborhood of a convex polygon is its area plus d times its perimeter plus πd². This follows by adding the exterior rectangles on the edges and the circular sectors at its vertices, whose angles sum to 2π. Adding the areas gives

    A + dP + πd²(m−1) ≤ c² + 4cd.                              (1)

For a polygon with edges of length ℓ and signed distances h from a fixed point to each supporting line, measured towards the outward normal, its area is one half the sum of hℓ. This follows by summing signed triangle areas. Apply this identity to Kᵢ with fixed point mᵢ. Every surviving edge of the tile has h=b/2. Consequently

    4 area(Kᵢ)/b − perimeter(Kᵢ) = Σ (2h/b−1)ℓ,              (2)

where the sum is over its edges on the boundary of C. If a tile edge lies on that boundary its contribution is zero. Only h>b/2 can make a positive contribution.

Choose the tile's axes so their nonnegative projections on the corresponding side normal are u≥v≥0 with u²+v²=1. Its largest projected distance from the center is H=b(u+v)/2. If v=0 there is no positive contribution. Otherwise h>b/2≥b(u−v)/2, so the slice of the tile is in its triangular tip. Its complete chord there has length (H−h)/(uv). Restricting the chord to a side segment of C can only shorten it. Write w=u+v. The positive contribution to (2) is therefore bounded by

    max over b/2≤h≤H of (2h/b−1)(H−h)/(uv)
        = b(w−1)/(4(w+1)) ≤ b(3−2√2)/4.                        (3)

For a given side of C all contributing tile centers have distances in (b/2,√2 b/2] from its supporting line. Their projections onto that line lie in an interval of length at most c+√2 b, because their tiles meet the segment. The centers of different tiles are at least b apart, by the inscribed disks. Take U=14142135623730951/10¹⁶ and r=9783/10000. Since U>√2 and r²+((U−1)/2)²<1, the tangential projections of any two contributing centers differ by at least rb. At most

    J = 1 + floor((c+Ub)/(rb))

can contribute on that side. Taking all four sides, (2) and (3) yield P≥4A/b−D, with D=Jb(3−2u₀) and u₀=14142135623730950/10¹⁶<√2. Counting a tile on more than one side is permitted.

When A>0, m≥1 and m≥A/b². An inscribed regular twelve-gon in the unit disk has area 3, so π>3. It follows that π(m−1)≥3(A/b²−1). Substitution into (1) yields the certified deficit

    c²−A ≥ max(0, [d(4c²/b−4c−D)+3d²(c²/b²−1)]
                        / [1+4d/b+3d²/b²]).                   (4)

If A=0, (4) follows at once since the same untruncated expression is at most c². The verifier evaluates (4) using exact rational arithmetic. A separate implementation bounds A from above directly in (1) and subtracts that upper bound from c².

## Using the deficit in a packing obstruction

Let q be the next integer above √n. Dilate a hypothetical side-S packing to the carrier [−e,q+e]². The outer tile side becomes a=(q+2e)/S. The inherited measure places unit area density in the centered square of side c=q−38/5 and nonnegative weights on line segments. For the nine larger counts the old certificate bounds the mass captured by the concentric b-squares using lower bounds for all center cells and angle ranges. Some rows refine that estimate by counting centers in low-mass regions. For 247 the verifier replays the regional occupancy bound. At 249 and 280 it recomputes the number of inner squares that must lie entirely inside the central region.

At the displayed side, add the captured lower bound, the missing area from (4) and the guaranteed missing line mass. The sum exceeds the total mass by the exact positive margin in the receipt. The area and line integrals are different components of the same measure. In the line calculation the verifier either reconstructs weighted intervals twice using different algorithms or checks an interval dynamic program together with every Bellman upper-bound inequality. The selected line calculation is recorded per count.

Every endpoint has a>b, so the smaller squares lie strictly inside their outer tiles. Even a shared boundary segment of two outer tiles cannot double-count charged line mass. The contradiction therefore applies at S itself. Monotonicity of feasibility in the side and compactness give s(n)>S.

The inherited measures and coverage arguments are attributed in the reference archive. The public family measure is due to Mohsen Khalili and Sara Gharabaghi. The small-count extension and inequality (4) are the proof contributions of this follow-up.
