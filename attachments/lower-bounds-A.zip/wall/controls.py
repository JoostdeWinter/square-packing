"""Exact polygon controls for the new central-area inequality, using rational rotations."""
from fractions import Fraction as F
from itertools import product

from clipped_area import clipped_disk_bound
from independent import area_from_upper


def clip(polygon, axis, bound, sign):
    result=[]
    for p,q in zip(polygon, polygon[1:]+polygon[:1]):
        dp, dq = sign*(p[axis]-bound), sign*(q[axis]-bound)
        if dp>=0:
            result.append(p)
        if dp*dq<0:
            t=dp/(dp-dq)
            result.append(tuple(a+t*(b-a) for a,b in zip(p,q)))
    return result


def clipped_tile_area(center, basis, b, c):
    u,v=basis
    polygon=[(center[0]+b*(u*i-v*j)/2,center[1]+b*(v*i+u*j)/2)
             for i,j in ((-1,-1),(1,-1),(1,1),(-1,1))]
    for a in (0,1):
        for bound,sign in ((0,1),(c,-1)):
            polygon=clip(polygon,a,bound,sign)
    double_area=sum((x*Y-y*X for (x,y),(X,Y) in zip(polygon,polygon[1:]+polygon[:1])), F(0))
    assert double_area>=0
    return double_area/2


def main():
    if not __debug__:
        raise RuntimeError("Enable assertions.")
    examples=0
    for t, c, d, offset in product((F(0),F(1,8),F(1,3),F(2,5)),
                                   (F(3,2),F(4),F(33,5)),(F(0),F(1,1000),F(1,8)),
                                   ((F(0),F(0)),(F(1,3),F(2,5)))):
        b=F(1)
        a=b+2*d
        u,v=(1-t*t)/(1+t*t),2*t/(1+t*t)
        assert u*u+v*v==1
        covered=F(0)
        # A finite patch of a rotated grid of touching outer squares is itself a valid packing.
        for i,j in product(range(-8,9),repeat=2):
            x,y=offset[0]+a*(u*i-v*j),offset[1]+a*(v*i+u*j)
            if x < -b or x > c+b or y < -b or y > c+b:
                continue
            covered+=clipped_tile_area((x,y),(u,v),b,c)
        required=clipped_disk_bound(c,b,d)
        assert 0 <= required == area_from_upper(c,b,d) <= c*c-covered
        examples+=1
    print(f"PASS {examples} rational clipped-tiling controls.")
if __name__=="__main__":
    main()
