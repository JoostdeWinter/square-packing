# Twenty-two strict lower bounds for packing unit squares

Joost de Winter directed this search. GPT6.2 Astra is the AI author. The certificates exclude a closed square of the specified side for each of 22 square counts. All tiles may move and rotate independently.

The thirteen smaller counts are 26–31 and 37–43. Their proofs extend earlier rectangle-density measures. They cover every newly admitted location and angle along the walls, using 42,138 angular intervals in total. For example, 43 squares require a side strictly larger than 6.942900. The earlier private lower endpoint was 6.942815.

The other nine counts are 163, 190, 247, 248, 249, 250, 280, 314 and 318. Their proofs give a lower bound for uncovered area in a square intersected by separated, freely rotated tiles. At 280 squares this raises the previous private endpoint from 16.830678 to 16.831120. All 22 exact endpoints, changes and comparison values are in results.csv. The optimal container sides remain open in this work.

## Files

- **PROOF.md** derives the wall argument, the central area bound and the strict endpoint conclusion.
- **results.csv** and **claims.json** contain the new results. Fractions specify every certificate endpoint exactly.
- **angles/** holds each complete angular cover for the added wall regions.
- **comparison.json** identifies the public case records and their Git blob hashes. The previous private table also records the November 20 registration update on issue 1042 and earlier public or pending comparison ceilings.
- **prior_certificates.zip** supplies the earlier measures, integer verifiers, reference angle covers, prior occupancy certificates and comparison table as an unmodified offline dependency. Its SHA-256 is 5bb8b275c3f1cf67349875918d126ef8359044b727bc6696ed1bb76ff061d72a.
- **verification.json** records the replay outcomes. **provenance.json** identifies public input versions. **SHA256SUMS** covers the proof, tables, software, angular inputs and reference archive.

## Replay

Use Python 3.10 or later with assertions enabled and a C++17 compiler available as c++. After extracting the archive, change to the directory containing verify.py and run

```sh
python -B verify.py --workers 4 --receipt my-replay.json
python -B controls.py
```

The default run uses the included files offline. It validates the existing small-count foundation certificates and their coverage receipts, then reruns the previous wall regions and every new interval. It reconstructs and reruns the regional or uniform geometry for the nine area claims. The final accounting uses exact fractions. The 72 controls clip explicitly rotated rational squares against test windows and check the new geometric inequality against their exact areas.

To replay selected counts, pass their numbers after `--only`. The option `--arithmetic-only` omits the native regional and wall replays while checking the archived inputs, angular covers and final arithmetic. The option `--replay-foundations` additionally regenerates historical native checks where the earlier archive supplies that program. The registered premises for 28 and 42 use the pinned public input and verification receipts of wand125, including their full angular coverage. Their provenance files are included in the reference archive.

A reviewer with the separately downloaded public sources can cross-check every added interval and the line-weight inputs by running

```sh
python -B verify.py --workers 4 --public-kernel /path/to/lower_bounds_2026_11_19/proof/gram.cpp --public-family /path/to/k2m5-family
```

This builds the original public, single-interval executable separately. For each new angular interval it compares the verdict, subdivision nodes, leaves, clipping count, depth and certified mass with the batched replay. The program also checks the public family's two exact input files against the saved data. Simple line-mass claims use a second integration procedure. Dynamic line claims check all Bellman upper-bound inequalities inside the native verifier.

The case n=31 is 6²−5. The new bound and the known grid packing leave 5.977880 < s(31) ≤ 6. Khalili and Gharabaghi’s reported family starts at k=7. The case n=43 is 7²−6 and its grid side is 7. [31-square public case](https://squaremath.org/cases/31.html) · [43-square public case](https://squaremath.org/cases/43.html)

The earlier marked-point proof at 20 has its own filing. [Issue 1055](https://github.com/jlevy/squares/issues/1055)

The historical registration and family sources are linked here. [Issue 1042](https://github.com/jlevy/squares/issues/1042#issuecomment-7022143149) · [Joost de Winter’s pinned source](https://github.com/JoostdeWinter/square-packing/tree/21d944c43098e2261ab7d713cd10f02a5eb13f3d/lower_bounds_2026_11_19) · [Mohsen Khalili and Sara Gharabaghi’s pinned family measure](https://github.com/moh63-dev/k2m5-family/tree/355f83e9147b310b581b72cf91baf56d7ad36625)
