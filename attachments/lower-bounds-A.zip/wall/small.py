"""Replay a rectangle-density obstruction on the old board and its added wall strips."""
from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction as F
from hashlib import sha256
from math import floor
from pathlib import Path
import gzip
import json
import subprocess
import sys


def compile_batch(checker, target):
    source = (checker/"gram.cpp").read_text()
    original = 'if(argc!=4)return 2;std::ifstream in(argv[1]),dir(argv[2]);cap=std::atoll(argv[3]);'
    assert source.count(original) == 1
    source = source.replace(original, 'if(argc!=2)return 2;std::ifstream in(argv[1]);auto& dir=std::cin;cap=2200000;')
    marker = ' I Twhole,Trem;Box b;dir>>C'
    assert source.count(marker) == 1
    source = source.replace(marker, '''
 while(dir>>std::ws && dir.peek()!=EOF){
     nodes=clips=leaves=maxdepth=0;
     least=std::numeric_limits<I>::max();
     std::fill(cache.begin(),cache.end(),CacheEntry{});
     I Twhole,Trem;Box b;dir>>C''')
    assert source.count(' return ok?0:1;')==1
    source=source.replace(' return ok?0:1;', ' } return 0;')
    path=target.with_suffix(".cpp")
    path.write_text(source)
    subprocess.run(["c++","-O3","-std=c++17",path,"-o",target],check=True)


def verify_boundary(n, row, base, work, workers, stored, foundations=False, public_kernel=None):
    foundation=base/"prior/previous_168/previous_164"
    checker=foundation/"previous_142/previous_75/first_66/checker"
    sys.path.insert(0,str(checker))
    import boundary, check, edge_reserve
    from zipfile import ZipFile
    if n in (27,28,37,39,40,42):
        foundation=foundation/"previous_142"
    paths=foundation/"edges"
    old=next(v for v in json.loads((paths/"claims.json").read_text()) if v["n"]==n)
    assert F(old["side"])==F(row["previous"]) and row["relation"]==">"
    source=foundation/json.loads((paths/"source_paths.json").read_text())["proofs"][old["source"]]
    angles=json.loads(gzip.decompress((Path(__file__).parent/row["angles"]).read_bytes()))
    assert len(angles)==row["angle_intervals"]
    for axis in range(2):
        boundary.check_cover([(k,j) for a,k,j in angles if a==axis])
    assert all(a in (0,1) for a,k,j in angles)
    dest=work/f"boundary-{n}"
    dest.mkdir()
    binary=dest/"batch"
    if not stored:
        compile_batch(checker,binary)
    if public_kernel:
        assert not stored
        assert sha256(public_kernel.read_bytes()).hexdigest()==sha256((checker/"gram.cpp").read_bytes()).hexdigest()
        plain=dest/"public-single-angle"
        subprocess.run(["c++","-O3","-std=c++17",public_kernel,"-o",plain],check=True)
    old_side, end=F(old["side"]),F(row["side"])
    assert old_side<end and F(old["mass"])<n

    def wall_check(measure, oldrow):
        assert oldrow==old and not measure["points"]
        L=F(measure["L"])
        assert L<old_side
        evidence=paths/"boundaries"/old["boundary"]
        boundary.verify_saved(evidence,measure,old,check,False)
        old_angles=json.loads(gzip.decompress((evidence/"receipts.gz").read_bytes()))
        grids=boundary.fields(measure,n,old["mass"],check,old.get("band"))
        for axis,raw in enumerate(grids):
            (dest/f"grid{axis}").write_bytes(raw)
        headers=[[],[]]
        # Previous wall region. Rebuild its signed verdict and all recorded work counts.
        for entry in old_angles:
            axis=entry["axis"]
            expected=[str(entry[k]) for k in ("verdict","nodes","leaves","clips","depth","lower_units")]
            headers[axis].append((entry["header"],expected))
        # Added poses must cross the old centered board on at least one wall.
        for axis,k,j in angles:
            h=boundary.header(measure,end,k,j,axis,check)
            t=F(83*(2*j+1),400*k)
            upper_half=F(707107,10**6) if t*t+2*t>=1 else (1+2*t-t*t)/(2*(1+t*t))
            h[5+axis]=max(h[5+axis],floor(check.bm.G*((L+old_side)/2-upper_half)))
            headers[axis].append((h,None))
        if stored:
            return
        def batch(item):
            axis, jobs=item
            raw="".join(" ".join(map(str,h))+"\n" for h,expect in jobs)
            result=subprocess.run([binary,dest/f"grid{axis}"],input=raw,text=True,capture_output=True,check=True)
            lines=result.stdout.splitlines()
            assert len(lines)==len(jobs)
            for line,(header,expected) in zip(lines,jobs):
                words=line.split()
                assert len(words)==6 and words[0]=="PASS" and int(words[5])>=check.bm.M
                if expected is not None:
                    assert words==expected
                elif public_kernel:
                    # Original single-angle executable, including a fresh cache and grid reader.
                    from tempfile import NamedTemporaryFile
                    with NamedTemporaryFile(mode="w",dir=dest) as single:
                        single.write(" ".join(map(str,header))+"\n")
                        single.flush()
                        actual=subprocess.run([plain,dest/f"grid{axis}",single.name,"2200000"],
                                              text=True,capture_output=True,check=True).stdout.split()
                        assert actual==words
        batches=[(a,group[i:i+36]) for a,group in enumerate(headers) for i in range(0,len(group),36)]
        with ThreadPoolExecutor(workers) as pool:
            list(pool.map(batch,batches))

    if old["method"]=="archived_boundary":
        # Full mode also recomputes the initial angular source certificate and exact transfer.
        edge_reserve.check_rows(source/"lower-bounds-56.zip",[old],
                                replay_existing=foundations,workers=workers,boundary_checker=wall_check)
    elif old["method"]=="registered_boundary":
        import registered_transfer
        origin=json.loads((source/"origin.json").read_text())
        assert origin["input_sha256"].startswith(old["source"])
        inputs=registered_transfer.load(origin,source)
        registered_transfer.prove(*inputs,old,wall_check)
    else:
        assert old["method"]=="boundary"
        manifest=check.verify(source)
        measure,_=check.read_level(source,manifest["levels"][0])
        if foundations:
            subprocess.run([sys.executable,"-B",checker/"replay.py",source,"--workers",str(workers)],check=True)
        wall_check(measure,old)
    return dict(n=n,side=str(end),relation=">",previous=str(old_side),
                angle_intervals=len(angles),exact_available_mass=old["mass"])
