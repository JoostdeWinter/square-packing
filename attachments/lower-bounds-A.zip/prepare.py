"""Place the two lower-bound ZIP attachments together, extract part A, then run this file."""
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile

root = Path(__file__).resolve().parent
part_b = root / 'inputs-B.bin'
if not part_b.is_file():
    archive = next((p / 'lower-bounds-B.zip' for p in (root, root.parent) if (p / 'lower-bounds-B.zip').is_file()), None)
    if archive is None:
        raise SystemExit('Extract lower-bounds-B.zip into the same directory as prepare.py, then run again.')
    with ZipFile(archive) as z:
        data_b = z.read('inputs-B.bin')
else:
    data_b = part_b.read_bytes()
reference = (root / 'inputs-A.bin').read_bytes() + data_b
expected = '5bb8b275c3f1cf67349875918d126ef8359044b727bc6696ed1bb76ff061d72a'
if sha256(reference).hexdigest() != expected:
    raise SystemExit('The two parts do not match the reference archive SHA-256.')
prior = root / 'wall' / 'prior_certificates.zip'
prior.write_bytes(reference)
with ZipFile(prior) as z:
    z.extractall(root / 'thirteen')
with ZipFile(root / 'thirteen' / 'baseline.zip') as z:
    z.extractall(root / 'baseline')
print('Prepared baseline/, thirteen/, wall/ and seven/. See README.md for replay commands.')

import subprocess,sys
subprocess.run([sys.executable,"-B",root/"wall-bounds/parallel-nov21/additional-counts/prepare_shared_input.py"],check=True)
