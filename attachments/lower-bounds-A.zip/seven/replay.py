"""Verify new packing lower bounds offline. Geometry is replayed by default."""
import argparse
import csv
import gzip
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile

ROOT=Path(__file__).resolve().parent
def read(p):
    return json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())

def load_reference(root):
    spec=importlib.util.spec_from_file_location('old_reference',root/'verify.py')
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--only',nargs='+',type=int)
    p.add_argument('--workers',type=int,default=4)
    p.add_argument('--use-pinned-floors',action='store_true',help='Skip the archived base angle enumeration. All new inequalities, wall strips and endpoints are still checked.')
    p.add_argument('--receipt',type=Path)
    a=p.parse_args()
    if not __debug__ or a.workers<1:raise ValueError('Run with assertions enabled and a positive worker count.')
    bundle=ROOT/'foundations.zip'
    assert hashlib.sha256(bundle.read_bytes()).hexdigest()=='5560d905831c9bf847e1e1756f3bc0eb6aaf3d64a95b306d9458b64a1c65583c'
    comparisons=ROOT/'previous-bounds.csv'
    assert hashlib.sha256(comparisons.read_bytes()).hexdigest()=='f9ca1eb21144127e06f05ad849a8c512651957518c27f207cb000dfd96f58eb5'
    with comparisons.open() as f:prior={int(r['n']):F(r['new_exact'] if 'new_exact' in r else r['new_lower_exact']) for r in csv.DictReader(f)}
    rows=read(ROOT/'claims.json')
    assert len(rows)==len({r['n'] for r in rows}) and all(F(r['previous'])==prior[r['n']] for r in rows)
    if a.only:
        rows=[r for r in rows if r['n'] in a.only]
        assert set(a.only)=={r['n'] for r in rows}
    receipt=[]
    with TemporaryDirectory() as td:
        work=Path(td);ref=work/'reference';base=work/'baseline'
        with ZipFile(bundle) as z:
            provenance=read(ROOT/'foundation-provenance.json')['included_unmodified_files']
            assert set(z.namelist())==set(provenance)
            for name,digest in provenance.items():
                assert hashlib.sha256(z.read(name)).hexdigest()==digest
            z.extractall(work)
        sys.path[:0]=[str(ref),str(base)]
        from context_v8 import coverage,region_verify
        from line_gaps import missing_line,profiles,WD
        from clipped_area import clipped_disk_bound
        from independent import area_from_upper,audited_line
        from mass import public_weights,compile_checker
        from pose_capture import verify_capture
        from replay_angles import verify_records
        from subcell_kernel import restricted_source
        old=load_reference(ref)
        checkout=public_weights(base,work)
        for fn,h in read(base/'prior/replays/source_inputs.json')['public_family']['verified_inputs'].items():
            assert hashlib.sha256((checkout/fn).read_bytes()).hexdigest()==h
        exe=work/'regional'
        compile_checker(base/'prior/regional.cpp',exe)
        area_exe=work/'oriented_area';compile_checker(ROOT/'oriented_area.cpp',area_exe)
        split_cpp=work/'subcell.cpp';split_cpp.write_text(restricted_source((base/'prior/regional.cpp').read_text()))
        split_exe=work/'subcell';compile_checker(split_cpp,split_exe)
        cached={}
        for claim in rows:
            n=claim['n'];q=isqrt(n)+1;S=F(claim['side']);f=base/claim['field'];meta=read(f/'geometry.json')
            w=work/f.name
            if f not in cached:
                w.mkdir()
                if a.use_pinned_floors:coverage.once(f,checkout,w,exe,1,False)
                else:region_verify.replay(f,checkout,w,exe,a.workers)
                cached[f]=True
            floors=read(f/'floors.json.gz')
            E=meta.get('extra_micro',0);B=meta['b_micro']
            for path in claim['shells']:
                if path.startswith('shells/'):sh=read(ref/path)
                else:sh=read(ROOT/path)
                check_exe=exe
                if 'from_extra' in sh:
                    assert sh['from_extra']==E
                    native=(base/'prior/regional.cpp').read_text()
                    for letter in ('X','Y'):
                        src=f'std::min(b.{letter},upper_reach(b.T1))'
                        assert native.count(src)==1
                        native=native.replace(src,f'std::min(b.{letter},upper_reach(b.T1)-{E})')
                    cpp=work/f'shell{n}.cpp';check_exe=work/f'shell{n}'
                    cpp.write_text(native);compile_checker(cpp,check_exe)
                assert sh['extra_micro']>E
                E,stats=old.verify_walls(sh,claim['field'],meta,floors,w,check_exe,a.workers)
            assert (B,E)==(claim['B'],claim['E'])
            counts={};arows=[];srows=[]
            for name,mode,checker in [('lift',True,exe),('angle_file',False,exe),('split_file','split',split_exe),('extra_split','split',split_exe)]:
                if claim.get(name):
                    info=read(ROOT/claim[name])
                    counts[name]=verify_records(info,mode,claim['field'],B,E,checker,w/'measure11.txt',a.workers)
                    if mode is True:
                        for i,j,t,iv in info['records']:floors[i][j]=max(floors[i][j],t)
                    elif mode=='split':srows.extend(info['records'])
                    else:arows=info['records']
            captured,poses=verify_capture(claim,q,B,E,floors,arows,srows,coverage,w,area_exe)
            assert captured==claim['capture']
            surplus=F(captured-meta['total_masses'][str(q)],WD)
            b,e=F(B,10**6),F(E,10**6);max_side=(q+2*e)/b
            relation=claim['relation'];assert S>F(claim['previous'])
            area=line=F(0)
            if S==max_side:
                assert relation=='>='
            else:
                assert S<max_side and relation=='>'
                d=((q+2*e)/S-b)/2;c=q-F(38,5)
                area=clipped_disk_bound(c,b,d)
                assert area==area_from_upper(c,b,d)
                table=coverage.get_table(f,checkout)
                line=missing_line(q,B,E,S,profiles(table,q,coverage))
                assert line==audited_line(table,q,b,e,S)
            margin=surplus+area+line
            assert margin==F(claim['margin'])>0
            receipt.append(dict(n=n,relation=relation,side=str(S),capture=captured,checked_poses=poses,additional_geometry=counts,capture_surplus=str(surplus),missed_area=str(area),missed_lines=str(line),margin=str(margin)))
            print(f'PASS n={n}   s(n) {relation} {S}',flush=True)
    if a.receipt:a.receipt.write_text(json.dumps(dict(base_geometry_replayed=not a.use_pinned_floors,claims=receipt),indent=2)+'\n')
if __name__=='__main__':main()
