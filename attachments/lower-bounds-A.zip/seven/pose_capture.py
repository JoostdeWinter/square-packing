"""Independent integer verification of dual prices for each center cell and angle sector."""
from collections import Counter,defaultdict
from fractions import Fraction
from constraints import key,orbit,box,strip_data,independent_bound
from occupancy import center_floors
from pose_mass import pose_masses

def direction(t):
    return 1000000-t*t,2000*t,1000000+t*t

def inside(dx,dy,dirs,B):
    if dx*dx+dy*dy<B*B:return True
    for A,C in ((dx,dy),(dy,-dx)):
        derivatives=[]
        for u,v,h in dirs:
            if abs(A*u+C*v)>=B*h:return False
            derivatives.append(C*u-A*v)
        if derivatives[0]*derivatives[1]<=0:return False
    return True

def verify_capture(cl,q,B,E,floors,records,split,coverage,work,area_exe):
    from capacity_audit import admits
    from context_v8 import previous_packing
    from footprint import Footprints,overlap_rows,weighted_bound
    bins,step=cl['bins'],cl['step'];N=q*10
    assert 2<=bins<=40 and bins%2==0 and step>=10000 and 2*q*10**6%step==0
    Q=2*q*10**6//step
    cells=center_floors(q,B,E,floors,coverage)
    reps=sorted({key(*p,N-1) for p in cells});boxes={p:box(*p,q,B,E) for p in cells}
    score=pose_masses(q,reps,bins,floors,records,coverage)
    from refine_centers import subboxes
    from pose_mass import refined_masses
    parts=cl.get('parts',1);assert 1<=parts<=8
    if split:scores=refined_masses(q,B,E,reps,bins,parts,score,split,coverage)
    else:scores=[vv for vv in score for _ in range(parts*parts)]
    angular=[[0]*bins for p in reps]
    child_credits=[[0]*bins for _ in scores]
    from pixels import area_columns
    vgroups=defaultdict(list)
    for kind,*a,price in cl['terms']:
        if kind in ('V','W'):vgroups[(kind,*a[:5])].append((a[5],price))
    vbudget=0
    for (kind,pitch,sub,asub,slabs,factor),group in vgroups.items():
        masks=[m for m,pr in group]
        data,caps=area_columns(area_exe,work,q,B,E,reps,bins,pitch,sub,asub,slabs,factor,masks,parts if kind=='W' else 1)
        for col,(mask,pr) in enumerate(group):
            assert isinstance(pr,int) and pr>0
            vbudget+=caps[col]*pr
            for z,vec in enumerate(child_credits if kind=='W' else angular):
                for k in range(bins):vec[k]+=data[(z*bins+k)*len(group)+col]*pr
    static=dict.fromkeys(reps,0); budget=vbudget; marks={};pools={};overlaps={}
    for kind,*a,price in cl['terms']:
        assert isinstance(price,int) and price>0
        if kind in ('V','W'):continue
        if kind=='C':
            from separation import conflict
            ids=a[0];assert len(ids)==len(set(ids))
            for at,z in enumerate(ids):
                i,k=divmod(z,bins);assert 0<=i<len(reps)
                for prev in ids[:at]:
                    j,l=divmod(prev,bins)
                    assert conflict(boxes[reps[i]],k,boxes[reps[j]],l,B,bins)
                angular[i][k]+=price
            cap=8
        elif kind=='L':
            from continuous_band import continuous_capacity
            credit,cap=continuous_capacity(q,B,E,reps,score,a)
            for (i,k),v in credit.items():angular[i][k]+=v*price
        elif kind=='D':
            from band_budget import band_capacity
            credit,cap=band_capacity(q,B,bins,a,reps,score)
            for (i,k),v in credit.items():angular[i][k]+=v*price
        elif kind=='G':
            i,j=a;assert 0<=i<=j<=Q//2
            cap=len(orbit(i,j,Q))
            for u,v in orbit(i,j,Q):marks[u,v]=marks.get((u,v),0)+price
        elif kind in ('S','R'):
            if kind=='S':sel,limit=strip_data(q,B,E,cells,a,boxes)
            else:
                x,X,y,Y,wedge,level=a
                assert 0<=x<X<=N and 0<=y<Y<=N and wedge in (0,1)
                sel=[(i,j) for i in range(x,X) for j in range(y,Y) if (not wedge or i<=j) and (i,j) in cells and cells[i,j]<level]
                limit=independent_bound(sel,boxes,B,55)
            assert not admits(sel,boxes,B,limit+1)
            cap=8*limit
            for p,count in Counter(key(*h,N-1) for h in sel).items():static[p]+=price*count*(8//len(orbit(*p,N-1)))
        elif kind=='K':
            level,cap=a;weak={p for p in cells if cells[p]<level}
            assert previous_packing.max_occupancy(q,B,weak,E)==cap
            for p in reps:
                if p in weak:static[p]+=price
        elif kind in ('U','F'):
            pitch,trim,mask,*tail=a;shape=pitch,trim
            if shape not in pools:pools[shape]=Footprints(q,B,E,pitch,trim,reps)
            pool=pools[shape]
            if kind=='F':
                inds,cap=pool.bound(mask)
                for k in inds:static[reps[k]]+=price
            else:
                if shape not in overlaps:overlaps[shape]=overlap_rows(q,B,E,pitch,trim,reps)
                coeff,cap=weighted_bound(pool.area,pool.denominator,overlaps[shape],mask,tail[0])
                for p,v in zip(reps,coeff):static[p]+=price*v
        else:raise ValueError(kind)
        budget+=cap*price
    edges=[-415+830*j//bins for j in range(bins+1)]
    pools=[(direction(a),direction(b)) for a,b in zip(edges,edges[1:])]
    totalposes=0;t=cl['intercept'];true_min=None
    for idx,p in enumerate(reps):
        for bidx,(x,X,y,Y,D) in enumerate(subboxes(boxes[p],q,E,parts)):
            basepaid=static[p]
            near=[];span=(B*1414214+999999)//1000000
            for u in range(max(0,(X-span)//step),min(Q,(x+span)//step)+1):
                for v in range(max(0,(Y-span)//step),min(Q,(y+span)//step)+1):
                    price=marks.get((u,v))
                    if price:
                        px,py=u*step,v*step
                        dx=max(abs(px-x),abs(px-X));dy=max(abs(py-y),abs(py-Y))
                        if dx*dx+dy*dy<B*B or max(dx,dy)*D<B*B:
                            basepaid+=price
                        else:near.append((px,py,price))
            for k,dirs in enumerate(pools):
                if not edges[k]<=0<=edges[k+1] and all(B*(u+abs(v))>D*h for u,v,h in dirs):continue
                totalposes+=1;val=scores[idx*parts*parts+bidx][k]+basepaid+angular[idx][k]+child_credits[idx*parts*parts+bidx][k]
                # When the target is met, an additional nonnegative credit can only raise the score.
                if val<t:
                    for px,py,price in near:
                        if all(inside(px-cx,py-cy,dirs,B) for cx in (x,X) for cy in (y,Y)):val+=price
                assert val>=t,(p,k,val,t)
    captured=cl['n']*t-budget
    assert captured==cl['capture']
    return captured,totalposes
