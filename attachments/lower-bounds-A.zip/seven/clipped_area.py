"""Compulsory missed area in a square clipped by separated, freely rotated tiles."""
from fractions import Fraction as F


def clipped_disk_bound(core, tile, clearance):
    c, b, d = map(F, (core, tile, clearance))
    assert c > b > 0 and d >= 0
    root_lower, root_upper = F(14142135623730950, 10**16), F(14142135623730951, 10**16)
    assert root_lower**2 < 2 < root_upper**2
    separation = F(9783, 10000)
    depth_spread = (root_upper - 1) / 2
    assert separation**2 + depth_spread**2 < 1
    count = 1 + (c + root_upper*b) // (separation*b)
    boundary_loss = count * b * (3 - 2*root_lower)
    circle_lower = F(3)
    linear = d*(4*c**2/b - 4*c - boundary_loss)
    quadratic = circle_lower*d**2*((c/b)**2 - 1)
    return max(F(0), (linear+quadratic) / (1 + 4*d/b + circle_lower*(d/b)**2))
