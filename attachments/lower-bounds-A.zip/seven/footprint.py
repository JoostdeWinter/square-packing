"""Pixel orbits which can meet a tile or a clipped, concentric portion."""
from bisect import bisect_left, bisect_right
from math import isqrt
from constraints import box, key, orbit
from check_geometry import independent_polygon_area

class Footprints:
    def __init__(self,q,B,E,pitch,trim,reps):
        board=2*q*10**6
        assert board%pitch==0 and 0<=trim<=500
        N=board//pitch
        edges=[-2*E]+[i*pitch for i in range(1,N)]+[board+2*E]
        keys=sorted({key(i,j,N-1) for i in range(N) for j in range(N)})
        ids={s:k for k,s in enumerate(keys)}
        self.keys=keys
        self.area=[len(orbit(i,j,N-1))*(edges[i+1]-edges[i])*(edges[j+1]-edges[j]) for i,j in keys]
        self.denominator=independent_polygon_area(B,trim,8)
        self.neighbors=[]
        radius=B*B+(B-2*B*trim//1000)**2
        for i,j in reps:
            x,X,y,Y,D=box(i,j,q,B,E)
            reach=min(D,isqrt(radius))
            # Integer differences of cell and pixel endpoints can be compared to floor(sqrt(radius)).
            left=max(0,bisect_left(edges,x-reach)-1)
            right=min(N,bisect_right(edges,X+reach))
            bottom=max(0,bisect_left(edges,y-reach)-1)
            top=min(N,bisect_right(edges,Y+reach))
            possible=set()
            for ix in range(left,right):
                dx=max(0,x-edges[ix+1],edges[ix]-X)
                for iy in range(bottom,top):
                    dy=max(0,y-edges[iy+1],edges[iy]-Y)
                    if max(dx,dy)<=reach and dx*dx+dy*dy<=radius:
                        possible.add(ids[key(ix,iy,N-1)])
            assert possible
            self.neighbors.append(tuple(sorted(possible)))

    def bound(self,pixels):
        allowed=set(pixels)
        assert len(allowed)==len(pixels) and all(0<=p<len(self.area) for p in allowed)
        selected=[i for i,neighbors in enumerate(self.neighbors) if all(p in allowed for p in neighbors)]
        maximum=sum(self.area[p] for p in allowed)//self.denominator
        return selected, maximum

def overlap_rows(q,B,E,pitch,trim,reps):
    """Upper areas for individual intersections in twice-micro coordinates."""
    board=2*q*10**6
    N=board//pitch
    edges=[-2*E]+[i*pitch for i in range(1,N)]+[board+2*E]
    keys=sorted({key(i,j,N-1) for i in range(N) for j in range(N)})
    ids={s:k for k,s in enumerate(keys)}
    radius=B*B+(B-2*B*trim//1000)**2
    rows=[]
    for i,j in reps:
        x,X,y,Y,D=box(i,j,q,B,E)
        reach=min(D,isqrt(radius))
        if reach**2<radius and reach<D:reach+=1
        left=max(0,bisect_left(edges,x-reach)-1)
        right=min(N,bisect_right(edges,X+reach))
        bottom=max(0,bisect_left(edges,y-reach)-1)
        top=min(N,bisect_right(edges,Y+reach))
        areas={}
        for iy in range(bottom,top):
            low=max(edges[iy],y-reach); high=min(edges[iy+1],Y+reach)
            if low>=high:continue
            cuts=[low+(high-low)*k//4 for k in range(5)]
            for y1,y2 in zip(cuts,cuts[1:]):
                dy=max(0,y-y2,y1-Y)
                rad=radius-dy*dy
                if rad<0:continue
                v=isqrt(rad);v=min(D,v+int(v*v<rad))
                for ix in range(left,right):
                    w=min(edges[ix+1],X+v)-max(edges[ix],x-v)
                    if w>0:
                        p=ids[key(ix,iy,N-1)]
                        areas[p]=areas.get(p,0)+w*(y2-y1)
        rows.append(areas)
    return rows

def weighted_bound(areas,denominator,overlaps,pixels,factor):
    allowed=set(pixels)
    assert factor>0 and len(allowed)==len(pixels) and all(0<=p<len(areas) for p in allowed)
    coefficients=[]
    for row in overlaps:
        outside=sum(v for p,v in row.items() if p not in allowed)
        coefficients.append(max(0,(denominator-outside)*factor//denominator))
    cap=sum(areas[p] for p in allowed)*factor//denominator
    return coefficients,cap
