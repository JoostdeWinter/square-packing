"""Serialize symmetric pixel unions and read their area certificates."""
from pathlib import Path
from array import array
from constraints import orbit,key,box
import subprocess

def area_columns(exe,local,q,B,E,reps,bins,pitch,sub,asub,slabs,factor,masks,parts=1):
    board=2*q*10**6;N=board//pitch
    assert board%pitch==0
    keys=sorted({key(x,y,N-1) for x in range(N) for y in range(N)})
    lookup={p:i for i,p in enumerate(keys)}
    rows=[[lookup[key(x,y,N-1)] for x in range(N)] for y in range(N)]
    edges=[-2*E]+[i*pitch for i in range(1,N)]+[board+2*E]
    unit=[len(orbit(i,j,N-1))*(edges[i+1]-edges[i])*(edges[j+1]-edges[j]) for i,j in keys]
    capacities=[]
    from refine_centers import subboxes
    boxes=[b for p in reps for b in subboxes(box(*p,q,B,E),q,E,parts)]
    inp=local/'area-input.txt';out=local/'area-output.bin'
    with inp.open('w') as f:
        f.write(f'{q} {B} {E} {pitch} {bins} {sub} {asub} {slabs} {factor} {len(boxes)} {len(masks)}\n')
        for mask in masks:
            valid=set(mask)
            assert len(valid)==len(mask) and all(0<=z<len(keys) for z in valid)
            capacities.append(sum(unit[z] for z in valid)*factor//(4*B*B))
            chars=['1' if z in valid else '0' for z in range(len(keys))]
            for rr in rows:f.write(''.join(chars[z] for z in rr)+'\n')
        for b in boxes:f.write(' '.join(map(str,b))+'\n')
    subprocess.run([exe,inp,out],check=True)
    a=array('h')
    with out.open('rb') as f:a.fromfile(f,len(boxes)*bins*len(masks));assert f.read()==b''
    assert a.itemsize==2
    return a,capacities
