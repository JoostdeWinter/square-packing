"""Rebuild the archived weight field and its exact capture and line inequalities."""
import gzip
import json
import shutil
import subprocess
from fractions import Fraction as F
from math import isqrt


def read(path):
    raw = path.read_bytes()
    if path.suffix == ".gz":
        raw = gzip.decompress(raw)
    return json.loads(raw)


def public_weights(base, work):
    source = base / "prior/previous_168/previous_164/previous_142/previous_75/core_proof/source"
    checkout = work / "sources"
    files = (("gen_fam10_data.py", "lean/K2m5/scripts"), ("sol_exact_family.txt", "certificate"))
    for name, folder in files:
        target = checkout / folder / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source / name, target)
    return checkout


def certificate(base, outer, n):
    if n in (247, 249, 280):
        root = base / "prior" if n == 280 else base
    else:
        root = outer
    claim = next(v for v in read(root / "claims.json") if v["n"] == n)
    field = (root if n == 280 else base) / claim["field"]
    meta = read(field / "geometry.json")
    extra = meta.get("extra_micro", 0)
    if claim.get("shell"):
        extra = read(outer / claim["shell"])["extra_micro"]
    return claim, field, meta, extra


def compile_checker(source, target):
    subprocess.run(["c++", "-O3", "-std=c++17", source, "-o", target], check=True)


def verify_extra_capture(n, work, base, checkout, claim, field, meta, workers):
    from context_v8 import coverage, previous, previous_packing, region_verify
    from occupancy import combine, swept_counts

    assert n in (247, 249, 280) and meta.get("extra_micro", 0) == 0
    if n in (249, 280):
        binary = work / "weighted"
        compile_checker(previous.WEIGHTED / "weighted.cpp", binary)
        coverage.once(field, checkout, work, binary, workers)
        return
    q = isqrt(n) + 1
    binary = work / "regional"
    compile_checker(base / "prior/regional.cpp", binary)
    floors = region_verify.replay(field, checkout, work, binary, workers)
    binary = work / "footprints"
    compile_checker(base / "footprints.cpp", binary)
    counts = swept_counts(q, meta["b_micro"], 0, floors, coverage, previous_packing, binary,
                         claim["step"], claim["parameters"], claim.get("arc_pieces", 0))
    captured, population = combine(n, *counts)
    assert population == claim["population"]
    assert F(captured - meta["total_masses"][str(q)], coverage.WD) == F(claim["capture_minus_total"])


def capture_surplus(n, side, claim, meta):
    from context_v8 import coverage
    from interior import inside_count
    import wall_chords

    q = isqrt(n) + 1
    B = meta["b_micro"]
    total = meta["total_masses"][str(q)]
    if n == 247:
        return F(claim["capture_minus_total"])
    if n == 249:
        k = inside_count(q, n, F(B, 10**6), 0, side)
        g = meta["threshold_units"]
        return F(n*g + k*max(0, 2*B*B - g) - total, coverage.WD)
    if n == 280:
        g = F(meta["threshold_units"], coverage.WD)
        _, bonus = wall_chords.core.core_bonus(q, n, F(B, 10**6), g, side)
        return n*g + bonus - F(total, coverage.WD)
    return F(claim["capture"] - total, coverage.WD)
