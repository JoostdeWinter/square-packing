# A bound on area left between smaller concentric squares

Let the outer squares have side a, disjoint interiors, and arbitrary orientations. In each put a parallel, concentric square of side b<a. Fix an axis-aligned square C of side c>b, and write d=(a−b)/2. Let A be the area of C covered by the smaller squares. The following argument bounds c²−A using c, b and d only.

Write Kᵢ for each positive-area intersection of an inner square and C. Write m for their number and P for the sum of their perimeters. The centers are mᵢ. The closed Euclidean d-neighborhood of each Kᵢ fits in the corresponding outer square and in the d-neighborhood of C. The neighborhoods therefore have disjoint interiors. The area of the d-neighborhood of a convex polygon is its area plus d times its perimeter plus πd². This follows by adding the exterior rectangles on the edges and the circular sectors at its vertices, whose angles sum to 2π. Adding the areas gives

    A + dP + πd²(m−1) ≤ c² + 4cd.                              (1)

For a polygon with edges of length ℓ and signed distances h from a fixed point to each supporting line, measured towards the outward normal, its area is one half the sum of hℓ. This follows by summing signed triangle areas. Apply this identity to Kᵢ with fixed point mᵢ. Every surviving edge of the tile has h=b/2. Consequently

    4 area(Kᵢ)/b − perimeter(Kᵢ) = Σ (2h/b−1)ℓ,              (2)

where the sum is over its edges on the boundary of C. If a tile edge lies on that boundary its contribution is zero. Only h>b/2 can make a positive contribution.

Choose the tile's axes so their nonnegative projections on the corresponding side normal are u≥v≥0 with u²+v²=1. Its largest projected distance from the center is H=b(u+v)/2. If v=0 there is no positive contribution. Otherwise h>b/2≥b(u−v)/2, so the slice of the tile is in its triangular tip. Its complete chord there has length (H−h)/(uv). Restricting the chord to a side segment of C can only shorten it. Write w=u+v. The positive contribution to (2) is therefore bounded by

    max over b/2≤h≤H of (2h/b−1)(H−h)/(uv)
        = b(w−1)/(4(w+1)) ≤ b(3−2√2)/4.                        (3)

For a given side of C all contributing tile centers have distances in (b/2,√2 b/2] from its supporting line. Their projections onto that line lie in an interval of length at most c+√2 b, because their tiles meet the segment. The centers of different tiles are at least b apart, by the inscribed disks. Take U=14142135623730951/10¹⁶ and r=9783/10000. Since U>√2 and r²+((U−1)/2)²<1, the tangential projections of any two contributing centers differ by at least rb. At most

    J = 1 + floor((c+Ub)/(rb))

can contribute on that side. Taking all four sides, (2) and (3) yield P≥4A/b−D, with D=Jb(3−2u₀) and u₀=14142135623730950/10¹⁶<√2. Counting a tile on more than one side is permitted.

When A>0, m≥1 and m≥A/b². An inscribed regular twelve-gon in the unit disk has area 3, so π>3. It follows that π(m−1)≥3(A/b²−1). Substitution into (1) yields the certified deficit

    c²−A ≥ max(0, [d(4c²/b−4c−D)+3d²(c²/b²−1)]
                        / [1+4d/b+3d²/b²]).                   (4)

If A=0, (4) follows at once since the same untruncated expression is at most c². The verifier evaluates (4) using exact rational arithmetic. A separate implementation bounds A from above directly in (1) and subtracts that upper bound from c².
