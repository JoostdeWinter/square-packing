def subboxes(p,q,E,parts):
    x,X,y,Y,_=p;board=2*q*10**6
    for a in range(parts):
        l=x+(X-x)*a//parts;r=x+(X-x)*(a+1)//parts
        for b in range(parts):
            s=y+(Y-y)*b//parts;t=y+(Y-y)*(b+1)//parts
            yield l,r,s,t,min(r,t,board-l,board-s)+2*E
