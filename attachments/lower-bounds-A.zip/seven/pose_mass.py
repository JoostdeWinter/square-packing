"""Transport signed angle floors through reflections of locally identical portions of the measure."""
from functools import lru_cache
from occupancy import equivalent_centers

def angle_windows(sectors):
    edges=[-415+(830*k)//sectors for k in range(sectors+1)]
    windows=[]
    for a,b in zip(edges,edges[1:]):
        assert a*b>=0
        l,h=sorted((abs(a),abs(b)))
        windows.append((b>0,131072*l//1000,min(54292,(131072*h+999)//1000)))
    return windows

def pose_masses(q,reps,bins,floors,records,coverage):
    refs=equivalent_centers(q,coverage)
    windows=angle_windows(bins)
    values={}
    for i,j,l,h,t,_ in records:
        for k,(_,lo,hi) in enumerate(windows):
            if l<=lo and h>=hi:
                values[i,j,k]=max(t,values.get((i,j,k),0))
    @lru_cache(None)
    def at(xs,ys,k):
        positive=windows[k][0]
        lower=0
        for i,sx in xs:
            for j,sy in ys:
                a,b=(i,j) if positive==(sx==sy) else (j,i)
                lower=max(lower,floors[a][b],values.get((a,b,k),0))
        return lower
    return [[at(refs[i],refs[j],k) for k in range(bins)] for i,j in reps]

def refined_masses(q,B,E,reps,bins,parts,pre,records,coverage):
    """Use exact closed half-cell coverage after each local reflection and transposition."""
    from constraints import box
    from refine_centers import subboxes
    refs=equivalent_centers(q,coverage);wins=angle_windows(bins)
    val={}
    for i,j,a,b,l,h,t,_ in records:
        for k,(_,lo,hi) in enumerate(wins):
            if l<=lo and hi<=h:val[i,j,a,b,k]=max(t,val.get((i,j,a,b,k),0))
    U=200000
    def halves(l,r,sgn):
        if sgn<0:l,r=U-r,U-l
        if r<=U//2:return (0,)
        if l>=U//2:return (1,)
        return (0,1)
    @lru_cache(None)
    def hit(aa,bb,l,r,s,t,k):
        pos=wins[k][0];best=0
        for i,sx in aa:
            xx=halves(l,r,sx)
            for j,sy in bb:
                yy=halves(s,t,sy)
                if pos==(sx==sy):
                    z=min(val.get((i,j,h,v,k),0) for h in xx for v in yy)
                else:
                    z=min(val.get((j,i,v,h,k),0) for h in xx for v in yy)
                best=max(best,z)
        return best
    answer=[]
    for idx,(i,j) in enumerate(reps):
        for l,r,s,t,_ in subboxes(box(i,j,q,B,E),q,E,parts):
            answer.append([max(pre[idx][k],hit(refs[i],refs[j],l-U*i,r-U*i,s-U*j,t-U*j,k)) for k in range(bins)])
    return answer
