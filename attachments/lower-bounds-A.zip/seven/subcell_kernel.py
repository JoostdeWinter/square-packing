"""Derive a restricted-center version of the archived regional checker."""
def restricted_source(original):
    changes=[
       ('I axis_local(I A,int col,int row){','int sx_cell=0,sy_cell=0;\nI axis_local(I A,int col,int row){'),
       ('auto cuts_for = [&](int i) {','auto cuts_for = [&](int i,int sub) {'),
       ('i*P-A/2-2','i*P+sub*(P/2)-A/2-2'),
       ('(i+1)*P-A/2+2','i*P+(sub+1)*(P/2)-A/2+2'),
       ('auto xs=cuts_for(col),ys=cuts_for(row);','auto xs=cuts_for(col,sx_cell),ys=cuts_for(row,sy_cell);'),
       ('while(std::cin>>row>>lo>>hi){','while(std::cin>>row>>lo>>hi>>sx_cell>>sy_cell){if(sx_cell<0||sx_cell>1||sy_cell<0||sy_cell>1)return 2;'),
       ('if(cache[row]<0)cache[row]=local_side(col,row);axisB=cache[row];','axisB=local_side(col,row);'),
       ('{col*P,(col+1)*P,row*P,(row+1)*P,lo,hi}','{col*P+sx_cell*(P/2),col*P+(sx_cell+1)*(P/2),row*P+sy_cell*(P/2),row*P+(sy_cell+1)*(P/2),lo,hi}')]
    for a,b in changes:
        assert original.count(a)==1,a
        original=original.replace(a,b)
    return original
