# Seven stronger square-packing lower bounds

The comparison in bounds.csv is with the previous seven certificates for the same counts. The column new_exact gives the exact endpoint and relation gives its inequality sign. The decimal columns are rounded. geometry-check.md explains the new ideas. For the worked 318 case, the final certificate uses tilt-dependent marker coverage, pixel-region area constraints and pairwise geometric exclusions.

## Results

| Squares | New lower bound | Gain in side length |
|---:|---:|---:|
| 162 | ≥ 1300456/100839 | 0.000158669 |
| 163 | > 12.957941938 | 0.000242457 |
| 248 | > 15.872678734 | 0.000048049 |
| 250 | > 15.968489745 | 0.000149875 |
| 283 | > 16.972476396 | 0.000259997 |
| 314 | > 17.811338490 | 0.000103568 |
| 318 | ≥ 200003/11127 | 0.000086234 |

## Replaying a proof

Run from this directory with Python 3.10 or later and a C++17 compiler named c++:

    python3 replay.py --only 318 --workers 4

To replay all seven counts and write your own receipt:

    python3 replay.py --workers 4 --receipt my-replay.json

For a quicker run:

    python3 replay.py --use-pinned-floors --workers 4

The quick replay accepts the archived base angle floors and checks all new regional intervals, wall checks, occupancy constraints and endpoint arithmetic. The default also regenerates all the base floors. Both modes run offline using the Python standard library. No optimization software is needed.

The extensions directory contains the selected exact pose intervals. foundations.zip includes the original reference kernel, the necessary local mass fields, and their public measure sources. Its contents were extracted unchanged from the two archived certificates whose SHA-256 hashes are recorded in foundation-provenance.json. verification.json gives the positive rational margin, verification mode and pose counts for each final result. SHA256SUMS covers the replay and its inputs. Running python3 controls.py checks the area-enclosure kernel against an independent exact rational polygon calculation, including empty, full and partially covered regions.
