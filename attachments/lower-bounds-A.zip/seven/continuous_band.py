"""Exact interval scheduling for a weighted band of movable, separated tile centers."""
from bisect import bisect_right
from math import isqrt
from constraints import box

def schedule(intervals,gap):
    if not intervals:return 0
    # A left-shifted maximizing sequence starts a new run at a left endpoint.
    last=max(r for l,r,w in intervals)
    times=sorted({l+k*gap for l,r,w in intervals for k in range(1+(last-l)//gap)})
    vals=[];best=0
    for j,t in enumerate(times):
        weight=max((w for l,r,w in intervals if l<=t<=r),default=0)
        k=bisect_right(times,t-gap,0,j)-1
        best=max(best,weight+(vals[k] if k>=0 else 0));vals.append(best)
    return best

def band_parameters(q,B,E,x,width):
    U=200000;lo=max(B-2*E,x*U);hi=min(2*q*10**6-B+2*E,(x+width)*U)
    W=max(0,hi-lo);assert W<2*B
    gap=isqrt(4*B*B-W*W)
    D=hi+2*E
    if W*D<2*B*B:gap=max(gap,2*B*B//D)
    return gap

def continuous_capacity(q,B,E,reps,scores,spec):
    x,w,y,Y,whole,L,unit=spec;P=200000
    assert 0<=x<x+w<=10*q and 0<=y<Y<=5*q and whole in (0,1) and unit>=0
    gap=band_parameters(q,B,E,x,w)
    weights={};credits={}
    for z,(i,j) in enumerate(reps):
        if x<=i<x+w and y<=j<Y:
            for k,g in enumerate(scores[z]):
                value=max(0,(L-g+unit-1)//unit) if unit else int(g<L)
                if value:
                    credits[z,k]=value
                    weights[j]=max(value,weights.get(j,0))
    board=2*q*10**6
    intervals=[(max(B-2*E,j*P),min(board-B+2*E,(j+1)*P),v) for j,v in weights.items()]
    if whole:intervals+= [(board-r,board-l,v) for l,r,v in intervals]
    return credits,(4 if whole else 8)*schedule(intervals,gap)
