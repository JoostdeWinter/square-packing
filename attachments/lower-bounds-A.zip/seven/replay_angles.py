"""Certify selected higher floors for full turns or angle windows, using the pinned native kernel."""
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
import subprocess

def verify_records(data,full,field,B,E,binary,measure,workers):
    assert data['field']==field and data['B']==B and E<=data['E']<=100000
    batches=defaultdict(list);seen=set()
    for row in data['records']:
        if full=='split':
            i,j,sx,sy,l,h,t,iv=row
            assert sx in (0,1) and sy in (0,1)
        elif full is True:i,j,t,iv=row;l,h=0,54292;sx=sy=-1
        else:i,j,l,h,t,iv=row;sx=sy=-1
        assert 0<=i<55 and 0<=j<55 and 0<=l<h<=54292 and (i,j,sx,sy,l,h) not in seen
        seen.add((i,j,sx,sy,l,h))
        assert isinstance(t,int) and 0<t<=3*10**12
        low=l
        for high,nodes in iv:
            assert low<high<=h and isinstance(nodes,int) and 1<=nodes<=10**8
            batches[i,t,sx,sy].append((j,low,high,nodes));low=high
        assert low==h
    def run(batch):
        i,t,sx,sy,rows=batch
        cmd=[str(v) for v in [binary,measure,B,t,i,1+max(v[-1] for v in rows),-1,data['E'],2]]
        output=subprocess.check_output(cmd,input=''.join(f'{j} {l} {h}'+(f' {sx} {sy}' if full=='split' else '')+'\n' for j,l,h,k in rows),text=True)
        for (j,l,h,k),line in zip(rows,output.splitlines(),strict=True):
            a=line.split()
            assert a[4]=='PASS' and list(map(int,a[:4]))==[i,j,l,h] and int(a[5])==k
    tasks=[(i,t,sx,sy,rows[k:k+100]) for (i,t,sx,sy),rows in batches.items() for k in range(0,len(rows),100)]
    with ThreadPoolExecutor(workers) as pool:list(pool.map(run,tasks))
    return {'windows':len(seen),'angle_intervals':sum(len(z) for z in batches.values()),'interval_nodes':sum(row[-1] for z in batches.values() for row in z)}
