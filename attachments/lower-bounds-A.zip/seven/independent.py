"""Second area calculation via an upper bound on covered area; separate line integrations."""
from fractions import Fraction as F
from math import isqrt


def area_from_upper(c, b, d):
    # For a contributing centre, tangential distance from the segment is at most b/sqrt(2).
    scale = 10**16
    lower = isqrt(2 * scale**2)
    upper = F(lower + 1, scale)
    assert lower**2 < 2*scale**2 < (lower+1)**2
    projected_separation = F(9783, 10000)
    assert 4*(1-projected_separation**2) > (upper-1)**2
    # Count the maximum possible ordered centers by their minimum tangential spacing.
    interval = c/b + upper
    gaps = 0
    while (gaps+1)*projected_separation <= interval:
        gaps += 1
    tip_flux = b * (3-2*F(lower, scale)) / 4
    total_flux_error = 4*(1+gaps)*tip_flux
    # A + d(4A/b-D) + 3 d^2(A/b^2-1) <= c^2+4cd.
    max_covered = (c*c + d*(4*c + total_flux_error) + 3*d*d) / (1+4*d/b+3*(d/b)**2)
    assert max_covered >= 0
    return c*c - min(c*c, max_covered)


def audited_line(table, q, b, e, side):
    import audit
    return audit.line_audit(q, b, e, side, audit.alternate_runs(table, q))
