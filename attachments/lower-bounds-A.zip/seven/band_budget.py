"""A weighted longest-path bound for folded squares in a narrow band."""
from math import isqrt
from separation import pair_geometry

def band_capacity(q,B,bins,spec,reps,g):
    axis,x,w,y,Y,level,unit=spec
    P=200000
    assert axis in (0,1) and 0<=x<x+w<=10*q and 0<=y<Y<=10*q and unit>=0
    assert (w*P)**2+P**2<(2*B)**2
    cost=[[0]*bins for _ in range(Y-y)]
    credits={}
    for z,p in enumerate(reps):
        i,j=p if axis==0 else p[::-1]
        if x<=i<x+w and y<=j<Y:
            for k in range(bins):
                gap=level-g[z][k]
                value=(max(0,(gap+unit-1)//unit) if unit else int(gap>0))
                if value:
                    credits[z,k]=value
                    cost[j-y][k]=max(cost[j-y][k],value)
    steps=[]
    for k in range(bins):
        row=[]
        for l in range(bins):
            R=pair_geometry(B,bins,k,l)[0];sq=R*R-(w*P)**2
            r=isqrt(sq);r+=r*r<sq
            row.append(max(1,(r+P-1)//P-1))
        steps.append(row)
    pref=[]
    for j,row in enumerate(cost):
        last=pref[-1] if pref else [0]*bins
        current=last.copy()
        for k,val in enumerate(row):
            if val:
                tail=max((pref[j-d][l] for l,d in enumerate(steps[k]) if j>=d),default=0)
                current[k]=max(current[k],val+tail)
        pref.append(current)
    return credits,8*max(pref[-1])
