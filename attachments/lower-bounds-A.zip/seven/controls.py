"""Independent rational polygon checks for the area enclosure, including wall poses."""
from fractions import Fraction as F
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import subprocess,sys

def clip(poly,axis,z,sign):
    if not poly:return []
    ans=[];p=poly[-1]
    for s in poly:
        old=sign*(p[axis]-z);new=sign*(s[axis]-z)
        if (old<0)!=(new<0):
            t=old/(old-new)
            ans.append(tuple(p[j]+t*(s[j]-p[j]) for j in (0,1)))
        if new>=0:ans.append(s)
        p=s
    return ans

def polygon_area(p):
    return abs(sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(p,p[1:]+p[:1])))/2 if p else F(0)

def main():
    assert __debug__
    root=Path(__file__).resolve().parent
    with TemporaryDirectory() as temp:
        d=Path(temp)
        with ZipFile(root/'foundations.zip') as z:z.extractall(d)
        sys.path.insert(0,str(d/'reference'))
        from constraints import box,key
        from refine_centers import subboxes
        from pixels import area_columns
        exe=d/'area';subprocess.run(['c++','-O3','-std=c++17',root/'oriented_area.cpp','-o',exe],check=True)
        q,B,E,bins=18,1001430,135,8
        pitch=200000;N=180;board=N*pitch;factor=1024
        reps=[(5,19),(17,34),(37,39),(67,70)]
        coords=sorted({key(i,j,N-1) for i in range(N) for j in range(N)})
        lookup={c:i for i,c in enumerate(coords)}
        masks=[[],list(range(len(coords))),[z for z,(i,j) in enumerate(coords) if (i+2*j)%5<3],
               [z for z,(i,j) in enumerate(coords) if i<7 or 28<=j<39], [z for z,(i,j) in enumerate(coords) if i+j<106]]
        raw,_=area_columns(exe,d,q,B,E,reps,bins,pitch,2,3,4,factor,masks,2)
        edges=[-2*E]+[i*pitch for i in range(1,N)]+[board+2*E]
        masks=[set(m) for m in masks];checks=0;strict=0
        for j,p in enumerate(reps):
            for z,(x,X,y,Y,_) in enumerate(subboxes(box(*p,q,B,E),q,E,2)):
                cx,cy=F(x+X,2),F(y+Y,2)
                for k in range(bins):
                    a=-415+830*k//bins;b=-415+830*(k+1)//bins
                    t=F(a+b,2000)
                    co=(1-t*t)/(1+t*t);si=2*t/(1+t*t)
                    poly=[(cx+B*(i*co-h*si),cy+B*(i*si+h*co)) for i,h in ((-1,-1),(1,-1),(1,1),(-1,1))]
                    if not all(edges[0]<=u<=edges[-1] and edges[0]<=v<=edges[-1] for u,v in poly):continue
                    assert polygon_area(poly)==4*B*B
                    total=[F(0)]*len(masks)
                    for ix in range(max(0,int(min(u for u,v in poly)//pitch)),min(N-1,int(max(u for u,v in poly)//pitch))+1):
                        strip=clip(clip(poly,0,edges[ix],1),0,edges[ix+1],-1)
                        for iy in range(max(0,int(min(v for u,v in poly)//pitch)),min(N-1,int(max(v for u,v in poly)//pitch))+1):
                            area=polygon_area(clip(clip(strip,1,edges[iy],1),1,edges[iy+1],-1))
                            idx=lookup[key(ix,iy,N-1)]
                            for h,m in enumerate(masks):
                                if idx in m:total[h]+=area
                    for h,ar in enumerate(total):
                        val=raw[((j*4+z)*bins+k)*len(masks)+h]
                        assert val*4*B*B<=ar*factor
                        if h in (0,1):assert val==(factor if h else 0)
                        strict+=int(0<val<factor);checks+=1
        assert strict>0
        print(f'PASS {checks} exact polygon comparisons, including {strict} nontrivial lower bounds.')
if __name__=='__main__':main()
