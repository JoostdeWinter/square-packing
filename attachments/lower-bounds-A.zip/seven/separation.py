"""A certified pair of incompatible center-and-angle cells."""
from functools import lru_cache
from itertools import product
from pose_capture import direction,inside

@lru_cache(None)
def pair_geometry(B,bins,k,j):
    angles=[(-415+830*v//bins) for v in range(bins+1)]
    ka=tuple(direction(v) for v in angles[k:k+2])
    ja=tuple(direction(v) for v in angles[j:j+2])
    dots=[];cross=[];ratios=[]
    for (u,v,h),(w,z,H) in product(ka,ja):
        c=u*w+v*z;s=u*z-v*w
        dots.append(c);cross.append(s);ratios.append((abs(c)+abs(s))*1000000//(h*H))
    w=1000000 if min(dots)<=0<=max(dots) or min(cross)<=0<=max(cross) else min(ratios)
    return B+B*w//1000000,ka,ja

def conflict(box1,k,box2,j,B,bins):
    x,X,y,Y,_=box1;l,L,s,S,_=box2
    R,ka,ja=pair_geometry(B,bins,k,j)
    dx=max(abs(x-L),abs(X-l));dy=max(abs(y-S),abs(Y-s))
    if dx*dx+dy*dy<R*R:return True
    for u,v in product((x-L,X-l),(y-S,Y-s)):
        if not inside(u,v,ka,R) or not inside(u,v,ja,R):return False
    return True
