// Integer enclosures of the area that an arbitrarily placed, rotated square contributes to a pixel union.
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <vector>
using I=std::int64_t;
struct Wall { I x,y,l,h; };
using Strip=std::array<Wall,2>;
struct Mask { std::vector<unsigned char> pixels; std::vector<I> prefix; };
I down(I a,I b) {return a>=0?a/b:-((-a+b-1)/b);}
I up(I a,I b) {return -down(-a,b);}
Wall window(I u,I v,I h,I half,I x,I X,I y,I Y,bool inside){
    I lo=std::min(x*u,X*u)+std::min(y*v,Y*v),hi=std::max(x*u,X*u)+std::max(y*v,Y*v);
    return {u,v,(inside?hi:lo)-half*h,(inside?lo:hi)+half*h};
}
std::pair<I,I> extent(const Strip &s,I lo,I hi,bool inside,I board,I e){
    I left=-e,right=board+e;
    for(auto a:s){
        I ymin=std::min(a.y*lo,a.y*hi),ymax=std::max(a.y*lo,a.y*hi);
        I l=a.l-(inside?ymin:ymax),h=a.h-(inside?ymax:ymin);
        if(a.x<0){I tmp=-h;h=-l;l=tmp;a.x=-a.x;}
        if(!a.x){if(l>0||h<0)return {0,0};continue;}
        left=std::max(left,inside?up(l,a.x):down(l,a.x));
        right=std::min(right,inside?down(h,a.x):up(h,a.x));
    }
    return {left,std::max(left,right)};
}
int main(int argc,char **argv){
    if(argc!=3)return 1;
    std::ifstream in(argv[1]);std::ofstream out(argv[2],std::ios::binary);
    int q,B,E,pitch,bins,sub,asub,slabs,fac,nrep,nmask;
    if(!(in>>q>>B>>E>>pitch>>bins>>sub>>asub>>slabs>>fac>>nrep>>nmask))return 2;
    if(q<10||q>20||B<1000000||B>1100000||E<0||E>100000||pitch<100000||pitch>1000000||bins<2||bins>40||bins%2||sub<1||sub>8||asub<1||asub>8||slabs<1||slabs>16||fac<1||fac>4096||nrep<1||nmask<1)return 3;
    I board=I(2000000)*q,e=2*E,den=4*I(B)*B;
    if(board%pitch)return 4;
    int N=board/pitch;std::vector<I> edge(N+1);
    for(int i=0;i<=N;i++)edge[i]=i*pitch;edge[0]=-e;edge[N]=board+e;
    auto pixel=[&](I x){return int(std::clamp<I>(x/pitch,0,N-1));};
    std::vector<Mask> masks(nmask);
    for(auto &m:masks){
        m.pixels.resize(N*N);m.prefix.resize(N*(N+1));
        for(int y=0;y<N;y++){
            std::string row;in>>row;if(row.size()!=unsigned(N))return 5;
            for(int x=0;x<N;x++){
                if(row[x]!='0'&&row[x]!='1')return 6;
                m.pixels[y*N+x]=row[x]-'0';
                m.prefix[y*(N+1)+x+1]=m.prefix[y*(N+1)+x]+m.pixels[y*N+x]*(edge[x+1]-edge[x]);
            }
        }
    }
    auto length=[&](const Mask &m,int row,I l,I r,int i,int j){
        return m.prefix[row*(N+1)+j]-m.prefix[row*(N+1)+i]+
        m.pixels[row*N+j]*(r-edge[j])-m.pixels[row*N+i]*(l-edge[i]);};
    std::vector<I> lb(nmask),covered(nmask),outside(nmask);
    for(int id=0;id<nrep;id++){
        I x,X,y,Y,D;if(!(in>>x>>X>>y>>Y>>D)||x>X||y>Y||D<B)return 7;
        for(int k=0;k<bins;k++){
            std::fill(lb.begin(),lb.end(),den);
            int A=-415+830*k/bins,C=-415+830*(k+1)/bins;
            for(int a=0;a<asub;a++){
                int aa=A*asub+(C-A)*a,cc=aa+(C-A),H=2000*asub,t=aa+cc;
                I u=I(H)*H-I(t)*t,v=2*I(H)*t,h=I(H)*H+I(t)*t;
                // 2*|tangent difference| <= 2*(cc-aa)/H.
                I num=H+2*(cc-aa),outer=up(I(B)*num,H),inner=down(I(B)*H,num);
                for(int sx=0;sx<sub;sx++)for(int sy=0;sy<sub;sy++){
                    I xl=x+(X-x)*sx/sub,xr=x+(X-x)*(sx+1)/sub;
                    I yl=y+(Y-y)*sy/sub,yr=y+(Y-y)*(sy+1)/sub;
                    Strip innerShape={window(u,v,h,inner,xl,xr,yl,yr,true),window(-v,u,h,inner,xl,xr,yl,yr,true)};
                    Strip outerShape={window(u,v,h,outer,xl,xr,yl,yr,false),window(-v,u,h,outer,xl,xr,yl,yr,false)};
                    std::fill(covered.begin(),covered.end(),0);std::fill(outside.begin(),outside.end(),0);
                    I reach=std::min<I>(D,up(I(B)*1414214,1000000));
                    for(int row=pixel(yl-reach);row<=pixel(yr+reach);row++){
                        I low=std::max(edge[row],yl-reach),high=std::min(edge[row+1],yr+reach);
                        if(low>=high)continue;
                        for(int z=0;z<slabs;z++){
                            I bot=low+(high-low)*z/slabs,top=low+(high-low)*(z+1)/slabs,ht=top-bot;
                            auto [l,r]=extent(innerShape,bot,top,true,board,e);
                            auto [L,R]=extent(outerShape,bot,top,false,board,e);
                            // A pose in this cell also obeys the wall half-width limit.
                            L=std::max(L,xl-reach);R=std::max(L,std::min(R,xr+reach));
                            if(l>r||L>R)return 8;
                            int i=pixel(l),j=pixel(r),I0=pixel(L),J0=pixel(R);
                            for(int m=0;m<nmask;m++){
                                if(r>l)covered[m]+=ht*length(masks[m],row,l,r,i,j);
                                if(R>L)outside[m]+=ht*(R-L-length(masks[m],row,L,R,I0,J0));
                            }
                        }
                    }
                    for(int m=0;m<nmask;m++)lb[m]=std::min(lb[m],std::max(covered[m],den-outside[m]));
                }
            }
            for(auto z:lb){if(z<0||z>den)return 9;std::int16_t val=z*fac/den;out.write(reinterpret_cast<char*>(&val),sizeof(val));}
        }
    }
    return out?0:10;
}
