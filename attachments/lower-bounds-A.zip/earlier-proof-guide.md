# Lower bounds for 166 square counts

The registration request is the 166-row table in claims-166.csv. The proof_directory column identifies the proof giving the requested endpoint. The comparison column bounds from above the strongest earlier public or pending lower endpoint used in the comparison, including implications from smaller counts. The gain is an exact fraction. Historical files inside the proof directories include superseded rows and comparisons with private intermediate results. Use claims-166.csv for the claims in this submission.

## Reproduction

Extract both ZIP files into the same directory. Run `python3 prepare.py` there. The script checks the SHA-256 of the shared reference archive before unpacking it. Python 3.10 or later and a C++17 compiler on PATH as c++ are needed to run the proofs. Use Python with assertions enabled.

| Directory | Command from that directory | Evidence |
|---|---|---|
| seven | `python3 -B replay.py --workers 4` | Seven final tilt-resolved endpoints, with exact tests for the orientation of each square. Append `--only 318` for the highlighted case. |
| wall | `python3 -B verify.py --workers 4` followed by `python3 -B controls.py` | Wall and uncovered-area checks. The issue retains 17 endpoints from this pass. |
| thirteen | `python3 -B verify.py --workers 4` | Occupancy and captured-mass bounds. The issue uses the strongest surviving endpoints. |
| baseline | `python3 -B verify.py --jobs 2 --workers 3 --full-history` then `python3 -B audit.py` and `python3 -B check_geometry.py` | Earlier certificates, references and per-count comparisons. |

The README and proof in each directory state its hypotheses, provenance and scope. The 60 rows marked in evidence_note use Hosono's reported T-180 for coverage away from the modified corners. The small-count proofs at 28 and 42 use wand125's pinned foundation certificates. The underlying periodic family measures are due to Mohsen Khalili and Sara Gharabaghi. Sources and licenses are retained in the proof directories.
