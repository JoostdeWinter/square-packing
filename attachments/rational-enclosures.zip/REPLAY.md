Optional supplementary precision evidence. For each row, compare only to the named exact input. Lower numerical scores exist for some counts.

Run python3 -B check_vertices.py 105/candidate.json.gz 127/candidate.json.gz 130/candidate.json.gz 156/candidate.json.gz 180/candidate.json.gz 182/candidate.json.gz 260/candidate.json.gz 270/candidate.json.gz 272/candidate.json.gz 299/candidate.json.gz 304/candidate.json.gz 307/candidate.json.gz 308/candidate.json.gz
