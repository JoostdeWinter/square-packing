from pathlib import Path
import subprocess,sys,shutil
root=Path(__file__).resolve().parent
subprocess.run([sys.executable,root/'prepare.py'],cwd=root,check=True)
shutil.copyfile(root/'wall-bounds/parallel-nov21/additional-counts/four-input.zip',root/'overnight/additional-counts/four-input.zip')
