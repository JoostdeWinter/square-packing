"""Search and replay additional wall extensions of the thirteen-count certificate."""
from pathlib import Path
import tempfile,subprocess,argparse,gzip,json,hashlib,sys,io,inspect
from zipfile import ZipFile
from fractions import Fraction as F
from math import isqrt
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
here=Path(__file__).resolve().parent
def read(p):return json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())
def optimize(old,claim,q,B,E,floors):
    import numpy as np
    from scipy.optimize import linprog
    original=claim['terms']
    terms=list(original)
    marks={(r[1],r[2]) for r in terms if r[0]=='P'}
    candidates=set()
    for i,j in marks:
        for x,y in ((i+1,j),(i-1,j),(i,j-1),(i,j+1),(i+1,j+1),(i-1,j-1)):
            key=tuple(sorted((x,y)))
            if 0<=min(key) and max(key)<=q*5 and key not in marks:candidates.add(key)
    terms += [['P',x,y,1] for x,y in sorted(candidates)]
    src=inspect.getsource(old.capture_certificate)
    src=src.replace('if cells[p] < t','').replace('assert all(v>=t for v in paid.values())','return list(paid.values()),total_budget')
    env=old.__dict__.copy();exec(src,env)
    width=28;mask=(1<<width)-1;low=52
    for keep_complex in [True,False]:
        active=[r for r in terms if keep_complex or r[0] not in ('A','K')]
        dummy=dict(claim,terms=[r[:-1]+[1<<(low+i*width)] for i,r in enumerate(active)])
        try:codes,budget=env['capture_certificate'](dummy,q,B,E,floors)
        except AssertionError:continue
        envelope={}
        for value in codes:
            patt,raw=divmod(value,1<<low);envelope[patt]=min(raw,envelope.get(patt,raw))
        def unpack(patt):
            v=[]
            for r in active:v.append(patt&mask);patt>>=width
            assert not patt
            return v
        arr=np.array([unpack(k) for k in envelope],dtype='int64')
        raw=np.array(list(envelope.values()),dtype='int64')
        caps=np.array(unpack(budget>>low),dtype='int64')
        t=claim['intercept'];scale=1e8
        res=linprog(np.append(caps,-claim['n']),A_ub=np.column_stack((-arr,np.ones(len(arr)))),b_ub=(raw-t)/scale,bounds=[(0,None)]*len(active)+[(None,None)],method='highs')
        if not res.success:continue
        prices=[max(0,round(x*scale)) for x in res.x[:-1]]
        t=min(int(v)+sum(int(a)*b for a,b in zip(row,prices)) for v,row in zip(raw,arr))
        c=claim['n']*t-sum(int(a)*b for a,b in zip(caps,prices))
        trial=dict(claim,terms=[r[:-1]+[b] for r,b in zip(active,prices) if b],intercept=t,capture=c)
        assert old.capture_certificate(trial,q,B,E,floors)==c
        return c,t,trial['terms']
    raise ValueError("no verified dual")
def main():
    ap=argparse.ArgumentParser();ap.add_argument('case',nargs='+');ap.add_argument('--source',type=Path,default=here/'four-input.zip');ap.add_argument('--search',action='store_true');ap.add_argument('--full',action='store_true');ap.add_argument('--optimize',action='store_true');ap.add_argument('--refine-floors',action='store_true',help='Bisect failed angular-mass targets before dual optimization');a=ap.parse_args()
    assert __debug__ and hashlib.sha256(a.source.read_bytes()).hexdigest()=='7488b81cc5f8624a4b9c32bdc2b5e9a3b31e7a10b2e3b53a7cba0d74a87a576b'
    with tempfile.TemporaryDirectory() as t:
        w=Path(t);outer=w/'reference';base=w/'base';wall=w/'wall'
        with ZipFile(a.source) as z:z.extract('mass.py',wall);z.extract('prior_certificates.zip',wall)
        with ZipFile(wall/'prior_certificates.zip') as z:z.extractall(outer)
        with ZipFile(outer/'baseline.zip') as z:z.extractall(base)
        sys.path[:0]=list(map(str,[outer,base,wall]));import importlib.util
        spec=importlib.util.spec_from_file_location('old_verify',outer/'verify.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
        from context_v8 import coverage
        from mass import public_weights
        ck=public_weights(base,w)
        exe=w/'regional';subprocess.run(['c++','-O3','-std=c++17',base/'prior/regional.cpp','-o',exe],check=True)
        initial=read(outer/'claims.json')
        originals={}
        for name in a.case:
            n,delta=map(int,name.split('-')[:2]);r=next(r for r in initial if r['n']==n).copy();orig=F(r['side']);loc=w/name;loc.mkdir();out=here/'wallplus'/name
            shellpath=outer/r['shell'];field=base/r['field'];meta=read(field/'geometry.json');B=meta['b_micro']
            if shellpath not in originals:originals[shellpath]=shellpath.read_bytes()
            shellpath.write_bytes(originals[shellpath]);shell=read(shellpath);E=shell['extra_micro']+delta;q=isqrt(n)+1
            if a.search:
                coverage.once(field,ck,loc,exe,1,False)
                def scan(row):
                    i,j,axis,target,iv=row;lo=0;inp=''
                    for hi,weight in iv:inp+=f'{j} {lo} {hi}\n';lo=hi
                    def test(tar):
                        cmd=[str(x) for x in [exe,loc/'measure11.txt',B,tar,i,120000,-1,E,axis]]
                        lines=subprocess.check_output(cmd,input=inp,text=True).splitlines()
                        if len(lines)==len(iv) and all(z.split()[4]=='PASS' for z in lines):
                            return [[int(z.split()[3]),int(z.split()[5])] for z in lines]
                    failed=None
                    for cost in [0,100000,1000000,3000000,10000000,30000000,100000000,300000000,1000000000,10000000000,100000000000,1000000000000,2000000000000]:
                        tar=max(1,target-cost);passed=test(tar)
                        if passed is None:
                            failed=tar
                            continue
                        if a.refine_floors and failed is not None:
                            for _ in range(10):
                                probe=(tar+failed)//2
                                if probe<=tar:break
                                receipt=test(probe)
                                if receipt is None:failed=probe
                                else:tar,passed=probe,receipt
                        return [i,j,axis,tar,passed]
                    raise ValueError('unresolved wall')
                suffix='-fine' if a.refine_floors else ''
                cache=here/'wallcache'/f'{n}-{delta}{suffix}.json.gz'
                if cache.exists():shell=read(cache)
                else:
                    with ThreadPoolExecutor(2) as pool:shell['walls']=list(pool.map(scan,shell['walls']))
                    cache.parent.mkdir(exist_ok=True);cache.write_bytes(gzip.compress(json.dumps(shell).encode()))
                shell['extra_micro']=E;floors=read(field/'floors.json.gz')
                for i,j,axis,target,iv in shell['walls']:floors[i][j]=min(floors[i][j],target)
                src=inspect.getsource(old.capture_certificate).replace('assert all(v>=t for v in paid.values())','t=min(t,min(paid.values()))').replace('assert checked >= claim["capture"]','').replace('return checked','return checked,t')
                ns=old.__dict__.copy();exec(src,ns)
                newterms=None
                try:
                    if a.optimize:capture,t0,newterms=optimize(old,r,q,B,E,floors)
                    else:capture,t0=ns['capture_certificate'](r,q,B,E,floors)
                except (AssertionError,ValueError):print('unresolved capacity',name,flush=True);continue
                margin=F(capture-meta['total_masses'][str(q)],2*10**12)
                if margin<=0:print('inconclusive',name,str(margin),flush=True);continue
                side=F(q*10**6+2*E,B);assert side>orig
                result=dict(n=n,side=str(side),prior=str(orig),gain=str(side-orig),margin=str(margin),intercept=t0,capture=capture,relation='>=')
                if newterms is not None:result['terms']=newterms
            else:shell=read(out/'wall.json.gz');result=read(out/'result.json')
            assert result['prior']==str(orig) and F(result['side'])-orig==F(result['gain'])>0
            shellpath.write_bytes(gzip.compress(json.dumps(shell).encode()))
            claims=[x.copy() for x in initial];c=next(x for x in claims if x['n']==n)
            if 'terms' in result:c['terms']=result['terms']
            for k in ['side','margin','capture','intercept','relation']:c[k]=result[k]
            (outer/'claims.json').write_text(json.dumps(claims))
            cmd=[sys.executable,'-B',str(outer/'verify.py'),'--only',str(n),'--workers','2','--receipt',str(loc/'receipt.json')]
            if not a.full:cmd.append('--reuse-baseline')
            subprocess.run(cmd,check=True)
            if a.search:
                out.mkdir(parents=True,exist_ok=True);(out/'result.json').write_text(json.dumps(result));(out/'wall.json.gz').write_bytes(shellpath.read_bytes());(out/'receipt.json').write_bytes((loc/'receipt.json').read_bytes())
            print('PASS extension',name,result['side'],result['gain'],flush=True)
if __name__=='__main__':main()
