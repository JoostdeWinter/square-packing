"""Bracket and refine the largest verified wall displacement at each supported count."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source',type=Path,default=root/'four-input.zip')
parser.add_argument('--stop',type=float,default=datetime(2026,11,21,5,tzinfo=timezone.utc).timestamp())
a=parser.parse_args()
counts=[115,219,282,138,317]
attempts={n:set() for n in counts}
def choose(n):
    proven={int(p.parent.name.split('-')[1]) for p in (root/'wallplus').glob(f'{n}-*/receipt.json') if json.loads(p.read_bytes())['claims'][0]['status']=='PASS'}
    lo=max(proven|{0});known=attempts[n]
    hi=min((d for d in known if d>lo),default=None)
    if hi is None:return max(20,2*lo)
    if hi-lo<2:return None
    return (lo+hi)//2
while time.time()<a.stop:
    progressed=False
    for n in counts:
        d=choose(n)
        if d is None:continue
        remaining=a.stop-time.time()
        if remaining<=0:sys.exit()
        progressed=True;tag=f'{n}-{d}-adaptive';print(datetime.now(timezone.utc).isoformat(),tag,flush=True)
        proc=subprocess.Popen([sys.executable,'-B',str(root/'wallplus.py'),'--source',str(a.source),'--search','--optimize',tag],start_new_session=True,env={**os.environ,'OPENBLAS_NUM_THREADS':'1'})
        try:proc.wait(timeout=remaining)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGTERM);sys.exit()
        attempts[n].add(d)
    if not progressed:break
