"""Extend the successful small-board cases while time remains."""
from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
import subprocess,time,json,sys
w=Path(__file__).resolve().parent
stop=datetime(2026,11,21,5,tzinfo=timezone.utc).timestamp()
source=Path(sys.argv[1]) if len(sys.argv)>1 else w/'four-input.zip'
done=set()
while time.time()<stop:
    progress=False
    for p in sorted(w.glob('small-*.json')):
        result=json.loads(p.read_bytes());n=result['n'];gain=F(result['gain'])
        step=next((F(i,10**6) for i in [5,15,35,75,125,225,400,700,1000] if F(i,10**6)>gain and (n,i) not in done),None)
        if step is None:continue
        k=int(step*10**6);done.add((n,k));progress=True
        remain=stop-time.time()
        if remain<=0:break
        try:
            subprocess.run([sys.executable,'-B',str(w/'small_search.py'),'--source',str(source),'--only',str(n),'--increment',str(step)],timeout=remain,check=True)
        except subprocess.TimeoutExpired:sys.exit(0)
    if not progress:time.sleep(min(40,max(0,stop-time.time())))
