"""Continue the small-board boundary proofs by enclosing the extra strips at a larger side."""
import argparse,csv,gzip,json,sys,tempfile,shutil,subprocess
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
here=Path(__file__).resolve().parent
def main():
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,default=here/'four-input.zip')
    p.add_argument('--only',nargs='+',type=int,default=[37,42,27,39,30,26,29,31,28,38,40,41,43]);p.add_argument('--increment',type=F);p.add_argument('--refinement',type=int,default=1);p.add_argument('--full',action='store_true');a=p.parse_args()
    assert __debug__ and sha256(a.source.read_bytes()).hexdigest()=='7488b81cc5f8624a4b9c32bdc2b5e9a3b31e7a10b2e3b53a7cba0d74a87a576b'
    with tempfile.TemporaryDirectory() as tmp:
        w=Path(tmp);wall=w/'wall';base=w/'base'
        with ZipFile(a.source) as z:z.extractall(wall)
        with ZipFile(wall/'prior_certificates.zip') as z:z.extract('baseline.zip',w)
        with ZipFile(w/'baseline.zip') as z:z.extractall(base)
        sys.path.insert(0,str(wall))
        import small
        from small import verify_boundary
        initial_compiler=small.compile_batch
        binaries={}
        def compile_once(checker,output):
            key=checker.resolve()
            if key not in binaries:
                binary=w/f'batch-{len(binaries)}'
                try:initial_compiler(checker,binary)
                except subprocess.CalledProcessError:
                    # The upstream builder has already emitted its exact C++ source.
                    subprocess.run(['c++','-O1','-g0','-std=c++17',binary.with_suffix('.cpp'),'-o',binary],check=True)
                binaries[key]=binary
            shutil.copyfile(binaries[key],output);output.chmod(0o700)
        small.compile_batch=compile_once
        rs={r['n']:r for r in json.loads((wall/'claims.json').read_bytes())}
        for n in a.only:
            r=rs[n].copy();assert r['family']=='boundary'
            path=here/f'small-{n}.json';old=F(r['side'])
            s=old+a.increment if a.increment else F(json.loads(path.read_bytes())['side'])
            assert s>old
            if a.increment and path.exists() and F(json.loads(path.read_bytes())['side'])>=s:continue
            factor=a.refinement if a.increment else json.loads(path.read_bytes()).get('angular_subdivision',1)
            assert factor in (1,2,4,8,16,32)
            if factor>1:
                src=wall/r['angles']
                angles=json.loads(gzip.decompress(src.read_bytes()))
                checker=base/'prior/previous_168/previous_164/previous_142/previous_75/first_66/checker'
                sys.path.insert(0,str(checker))
                from boundary import angle_supported
                children=sorted({(axis,k*factor,j*factor+i) for axis,k,j in angles
                                 for i in range(-(factor//2),factor//2+1)
                                 if angle_supported(k*factor,j*factor+i)})
                r['angles']=f'refined-{n}.json.gz'
                (wall/r['angles']).write_bytes(gzip.compress(json.dumps(children).encode()))
                r['angle_intervals']=len(children)
            r['side']=str(s);d=w/f'{n}';d.mkdir()
            try:receipt=verify_boundary(n,r,base,d,2,False,a.full)
            except AssertionError:
                if not a.increment:raise
                print('unresolved',n,s,flush=True);continue
            data=dict(n=n,relation='>',side=str(s),prior=str(old),gain=str(s-old),receipt=receipt)
            if factor>1:data["angular_subdivision"]=factor
            if a.increment:
                if not path.exists() or s>F(json.loads(path.read_bytes())['side']):path.write_text(json.dumps(data,indent=2)+'\n')
            else:assert json.loads(path.read_bytes())==data
            print('PASS',n,float(s),float(s-old),flush=True)
if __name__=='__main__':main()
