"""Stronger parallel-chord bounds using four earlier clipped-board certificates."""
from fractions import Fraction as F
from pathlib import Path
from math import isqrt
from zipfile import ZipFile
from tempfile import TemporaryDirectory
from hashlib import sha256
import argparse,json,sys,subprocess
here=Path(__file__).resolve().parent
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--source',type=Path,default=here/'four-input.zip')
 ap.add_argument('--lemma',type=Path,default=here.parent/'parallel-chords')
 ap.add_argument('--probe',type=F);ap.add_argument('--search',action='store_true');ap.add_argument('--full',action='store_true')
 ap.add_argument('--analytic-line',action='store_true');ap.add_argument('--layered',action='store_true');ap.add_argument('--digits',type=int,default=9,choices=range(6,16))
 ap.add_argument('--only',nargs='+',type=int,default=[190,247,249,280])
 a=ap.parse_args()
 assert __debug__ and sha256(a.source.read_bytes()).hexdigest()=='7488b81cc5f8624a4b9c32bdc2b5e9a3b31e7a10b2e3b53a7cba0d74a87a576b'
 sys.path.insert(0,str(here))
 from chords import missing_area,check_constants
 assert check_constants()
 with TemporaryDirectory() as td:
    tmp=Path(td);wall=tmp/'wall'
    with ZipFile(a.source) as z:z.extractall(wall)
    if a.full:subprocess.run([sys.executable,'-B',str(wall/'verify.py'),'--workers','2','--only',*map(str,a.only)],check=True)
    outer=tmp/'outer';base=tmp/'base'
    with ZipFile(wall/'prior_certificates.zip') as z:z.extractall(outer)
    with ZipFile(outer/'baseline.zip') as z:z.extractall(base)
    sys.path[:0]=[str(wall),str(base)]
    from mass import certificate,capture_surplus,public_weights,compile_checker,read
    from context_v8 import coverage,previous
    from independent import audited_line
    from line_gaps import missing_line,profiles
    oldrows={r['n']:r for r in read(wall/'claims.json')}
    checkout=public_weights(base,tmp)
    bin=tmp/'intervals'
    source=previous.WEIGHTED/'asymmetric/intervals.cpp'
    # Keep the original independent Bellman upper-bound verifier, but only
    # store live indices in each producer deque instead of one full grid per class.
    code=source.read_text()
    changes={"std::vector<int> queue; int begin=0,end=0;":"std::deque<int> queue;",
             "g.queue.resize(cells+1);g.begin=g.end=0;":"g.queue.clear();",
             "g.begin<g.end && g.queue[g.begin]<lo)++g.begin;":"!g.queue.empty() && g.queue.front()<lo)g.queue.pop_front();",
             "g.begin<g.end && score(g.queue[g.end-1])<=score_hi)--g.end;":"!g.queue.empty() && score(g.queue.back())<=score_hi)g.queue.pop_back();",
             "g.queue[g.end++]=hi;":"g.queue.push_back(hi);",
             "score(g.queue[g.begin])":"score(g.queue.front())"}
    for needle,replace in changes.items():
        assert code.count(needle)==1,needle
        code=code.replace(needle,replace)
    (tmp/'intervals.cpp').write_text(code)
    (tmp/'dual.hpp').write_bytes(source.with_name('dual.hpp').read_bytes())
    compile_checker(tmp/'intervals.cpp',bin)
    import importlib.util
    for n in a.only:
        path=here/f'n{n}.json'
        use_layers=a.layered or (not a.search and not a.probe and read(path).get('area_lemma')=='layered')
        analytic=a.analytic_line or (not a.search and not a.probe and read(path).get('line_lemma')=='analytic')
        area_fn=missing_area
        if use_layers:
            spec=importlib.util.spec_from_file_location('refined_chords',a.lemma/'chords.py')
            layers=importlib.util.module_from_spec(spec);spec.loader.exec_module(layers)
            assert layers.check_constants()
            area_fn=layers.missing_area
        d=tmp/f'{n}';d.mkdir()
        r=oldrows[n];orig=F(r['side']);q=isqrt(n)+1;c=q-F(38,5)
        cl,f,m,E=certificate(base,outer,n);B=m['b_micro'];b=F(B,10**6);e=F(E,10**6);peak=(q+2*e)/b
        table=coverage.get_table(f,checkout);pr=profiles(table,q,coverage)
        def margin(S,cross=False):
            ar=area_fn(c,b,((q+2*e)/S-b)/2)
            if analytic or r['family']=='clipped_disk':
                ln=missing_line(q,B,E,S,pr)
                if cross:assert ln==audited_line(table,q,b,e,S)
            else:
                mesh=(cl['mesh'],cl['length_classes'],cl['angle_classes']) if n==280 else cl['dp']
                ln=previous.surplus(f,q,n,S,*mesh,executable=bin,work=d,checkout=checkout)[4]
            sur=capture_surplus(n,S,cl,m);return sur+ar+ln
        path=here/f'n{n}.json'
        known_margin=None
        if a.probe:
            S=orig+a.probe
            limit=peak
            if not analytic and r['family']=='clipped_disk_dp':
                mesh=cl['mesh'] if n==280 else cl['dp'][0]
                limit=min(limit,q/(b+F(2,mesh)))
            if S<peak and S<=limit:known_margin=margin(S,True)
            if known_margin is None or known_margin<=0:
                print('unresolved probe',n,str(S),flush=True);continue
        elif a.search:
            scale=10**a.digits
            lo=int(orig*scale);hi=int(peak*scale)+1
            if not analytic and r['family']=='clipped_disk_dp':
                mesh=cl['mesh'] if n==280 else cl['dp'][0]
                hi=min(hi,int((q/(b+F(2,mesh)))*scale)+1)
            while hi-lo>1:
                mid=(lo+hi)//2
                if margin(F(mid,scale))>0:lo=mid
                else:hi=mid
            S=F(lo,scale)
            if S<=orig:
                print('no gain',n,flush=True);continue
        else:S=F(read(path)['side'])
        mrg=margin(S,True) if known_margin is None else known_margin;assert orig<S<peak and mrg>0
        result=dict(n=n,relation='>',side=str(S),prior=str(orig),gain=str(S-orig),margin=str(mrg))
        if analytic:result['line_lemma']='analytic'
        if use_layers:result['area_lemma']='layered'
        if a.search or a.probe:
            if not path.exists() or F(read(path)['side'])<S:path.write_text(json.dumps(result,indent=2)+'\n')
        else:assert result==read(path)
        print('PASS',n,float(S),float(S-orig),flush=True)
if __name__=='__main__':main()
