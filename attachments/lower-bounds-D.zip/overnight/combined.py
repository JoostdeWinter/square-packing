"""Apply the parallel-chord missing-area lemma to a replayed enlarged-wall capture."""
import argparse,hashlib,json,subprocess,sys,tempfile
from pathlib import Path
from fractions import Fraction as F
from math import isqrt
from zipfile import ZipFile
def read(p):return json.loads(p.read_bytes())
def main():
    ap=argparse.ArgumentParser();ap.add_argument('n',nargs='+',type=int);ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);ap.add_argument('--discover',type=Path);ap.add_argument('--saved-capture',action='store_true',help='Check the new area/line proof against the enclosed native wall receipt');ap.add_argument('--fine',action='store_true');ap.add_argument('--full',action='store_true');a=ap.parse_args();root=a.root.resolve()
    assert __debug__
    src=root/'parallel-chords/tilt-input.zip'
    assert hashlib.sha256(src.read_bytes()).hexdigest()=='81deab2f7a88bd337f3aa5fa745212dbf9d116dcfd7d9784c059b4ad0c71a1dd'
    with tempfile.TemporaryDirectory() as td:
        w=Path(td);t=w/'tilt';f=w/'foundation'
        with ZipFile(src) as z:z.extractall(t)
        with ZipFile(t/'foundations.zip') as z:z.extractall(f)
        base=f/'baseline';sys.path[:0]=[str(root/'parallel-chords'),str(t),str(f/'reference'),str(base)]
        from chords import missing_area,check_constants
        from mass import public_weights
        from context_v8 import coverage
        from line_gaps import profiles,missing_line
        from independent import audited_line
        assert check_constants()
        weights=public_weights(base,w/'sources')
        for n in a.n:
            ext=root/f'wall-extension/n{n}';r=read(ext/'result.json');orig=next(c for c in read(t/'claims.json') if c['n']==n)
            if a.discover or a.saved_capture:receipt=read(ext/'receipt.json')
            else:
                dst=w/f'receipt{n}.json'
                subprocess.run([sys.executable,'-B',str(root/'wall-extension/replay.py'),str(ext),'--receipt',str(dst),*(() if a.full else ('--pinned-floors',))],check=True)
                receipt=read(dst)
            cr=next(c for c in receipt['claims'] if c['n']==n);B=r['B'];E=r['E'];q=isqrt(n)+1
            assert B==orig['B'] and cr['capture']==r['capture'] and cr['side']==r['side']
            field=base/orig['field'];total=read(field/'geometry.json')['total_masses'][str(q)]
            surplus=F(cr['capture']-total,2*10**12);assert surplus==F(cr['capture_surplus'])
            b,e=F(B,10**6),F(E,10**6);cap=(q+2*e)/b;table=coverage.get_table(field,weights);prof=profiles(table,q,coverage)
            path=(a.discover or root/'combined')/f'n{n}.json'
            fine=a.fine or (not a.discover and read(path).get('area_lemma')=='fine')
            area_fn=missing_area
            if fine:
                import fine_chords
                assert fine_chords.check_constants()
                area_fn=fine_chords.missing_area
            def pieces(S):return area_fn(q-F(38,5),b,((q+2*e)/S-b)/2),missing_line(q,B,E,S,prof)
            prior=F(r['side']);path=(a.discover or root/'combined')/f'n{n}.json'
            if a.discover:
                scale=10**15;lo=int(prior*scale);hi=int(cap*scale)+1
                while hi-lo>1:
                    mid=(hi+lo)//2
                    if sum(pieces(F(mid,scale)),surplus)>0:lo=mid
                    else:hi=mid
                S=F(lo,scale)
                if S<=prior:print('no improvement',n,flush=True);continue
            else:S=F(read(path)['side'])
            ar,ln=pieces(S);assert ln==audited_line(table,q,b,e,S) and prior<S<cap and ar+ln+surplus>0
            result=dict(n=n,relation='>',side=str(S),prior=str(prior),gain=str(S-prior),area=str(ar),line=str(ln),surplus=str(surplus),margin=str(surplus+ar+ln))
            if fine:result['area_lemma']='fine'
            if a.discover:
                if not path.exists() or S>F(read(path)['side']):path.write_text(json.dumps(result,indent=2))
            else:assert result==read(path)
            print('PASS combined',n,S,float(S-prior),flush=True)
if __name__=='__main__':main()
