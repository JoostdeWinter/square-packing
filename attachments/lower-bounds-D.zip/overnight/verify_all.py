"""Verify the archive manifest, exact comparison arithmetic, and chosen proof for each endpoint."""
import argparse,csv,gzip,hashlib,json,subprocess,sys
from collections import defaultdict
from fractions import Fraction as Q
from pathlib import Path

root=Path(__file__).resolve().parent
def data(p):return json.loads(p.read_bytes())
def same(record,n,s,relation):return int(record['n'])==n and Q(record['side'])==s and record['relation']==relation
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inventory',action='store_true',help='Check manifest, comparison arithmetic and proof selection only')
    parser.add_argument('--full',action='store_true',help='Also recompute inherited geometric inputs')
    parser.add_argument('--upper-only',action='store_true',help='Replay rational packing coordinates only')
    parser.add_argument('--only',type=int,nargs='+')
    a=parser.parse_args()
    if not __debug__:raise RuntimeError('Enable assertions.')
    for line in (root/'SHA256SUMS').read_text().splitlines():
        digest,name=line.split('  ',1);p=root/name
        assert p.resolve().is_relative_to(root)
        with p.open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==digest,name
    rs=list(csv.DictReader((root/'results.csv').open()));ns={int(r['n']) for r in rs}
    assert len(ns)==len(rs) and min(ns)>0 and max(ns)<325
    upper=root/'upper-certificates'
    if upper.exists() and (a.upper_only or not a.only):
        upper_rows=list(csv.DictReader((upper/'results.csv').open()))
        if a.upper_only and a.only:
            assert set(a.only)<={int(r['n']) for r in upper_rows}
            upper_rows=[r for r in upper_rows if int(r['n']) in a.only]
        for r in upper_rows:
            n=int(r['n']);d=upper/str(n);candidate=d/'candidate.json.gz';inp=d/'input.json.gz'
            doc=json.loads(gzip.decompress(candidate.read_bytes()))
            src=json.loads(gzip.decompress(inp.read_bytes()))
            assert doc['input_sha256']==hashlib.sha256(inp.read_bytes()).hexdigest()
            assert int(doc['n'])==n and len(doc['squares'])==n and Q(r['exact_certified_side'])==Q(doc['side'])
            assert Q(src['side'])-Q(doc['side'])==Q(r['gain_vs_rational_input'])>0
            if not a.inventory:subprocess.run([sys.executable,'-B',str(upper/'check_vertices.py'),str(candidate)],check=True)
        print(('Inventory' if a.inventory else 'Vertex replay')+' passed for '+str(len(upper_rows))+' exact upper witnesses.',flush=True)
        if a.upper_only:return
    if a.only:assert set(a.only)<=ns
    chords=list(csv.DictReader((root/'parallel-chords/records.csv').open()))
    finepath=root/'parallel-chords/fine_records.csv'
    finer=list(csv.DictReader(finepath.open())) if finepath.exists() else []
    jobs=defaultdict(list)
    for r in rs:
        n=int(r['n']);s=Q(r['endpoint']);rel=r['relation']
        if a.only and n not in a.only:continue
        assert s-Q(r['prior_best'])==Q(r['exact_gain'])>0 and s>Q(r['highest_monotone_or_border_comparator'])
        assert s-Q(r['latest_handoff_comparator'])==Q(r['gain_over_latest_handoff'])
        add=root/'additional-counts';ext=root/f'wall-extension/n{n}'
        combined=root/f'combined/n{n}.json'
        if combined.exists() and same(data(combined),n,s,rel):
            assert Q(data(combined)['prior'])==Q(data(ext/'result.json')['side'])
            jobs['combined'].append(str(n))
        elif any(same(x,n,s,rel) for x in finer):jobs['finer'].append(str(n))
        elif any(same(x,n,s,rel) for x in chords):jobs['chords'].append(str(n))
        elif (ext/'result.json').exists() and same(data(ext/'result.json'),n,s,rel):
            assert any(same(x,n,s,rel) for x in data(ext/'receipt.json')['claims'])
            jobs['ext'].append(str(ext))
        elif (add/f'n{n}.json').exists() and same(data(add/f'n{n}.json'),n,s,rel):jobs['four'].append(str(n))
        elif (add/f'small-{n}.json').exists() and same(data(add/f'small-{n}.json'),n,s,rel):jobs['small'].append(str(n))
        else:
            matches=[p for p in (add/'wallplus').glob(f'{n}-*/result.json') if same(data(p),n,s,rel)]
            assert matches,(n,s)
            p=matches[0];receipt=data(p.parent/'receipt.json')['claims']
            assert any(x['n']==n and x['relation']==rel and Q(x['exact_side'])==s and x['status']=='PASS' for x in receipt)
            jobs['plus'].append(p.parent.name)
    if not a.inventory:
        full=['--full'] if a.full else []
        def run(script,*opts):subprocess.run([sys.executable,'-B',str(root/script),*map(str,opts)],check=True)
        if jobs['combined']:run('combined.py',*jobs['combined'],*full)
        if jobs['finer']:run('parallel-chords/fine_verify.py','--only',*jobs['finer'],*full)
        if jobs['chords']:run('parallel-chords/verify.py','--only',*jobs['chords'],*full)
        for d in jobs['ext']:run('wall-extension/replay.py',d,*([] if a.full else ['--pinned-floors']))
        if jobs['four']:run('additional-counts/verify.py','--only',*jobs['four'],*full)
        if jobs['small']:run('additional-counts/small_search.py','--only',*jobs['small'],*full)
        if jobs['plus']:run('additional-counts/wallplus.py',*jobs['plus'],*full)
    print(('Inventory' if a.inventory else 'Replay')+' passed for '+str(sum(map(len,jobs.values())))+' exact endpoints.')
if __name__=='__main__':main()
