"""Interval certificate for the parallel-chord bound, with exact rational arithmetic."""
from fractions import Fraction as Q
from functools import lru_cache
from math import ceil

RHO=Q(34,1000)
EXTENT=Q(101,100)
PI_LO=Q(31415926535,10**10)
ROOT2_HI=Q(1414213562374,10**12)
PI_HI=Q(31415926536,10**10)

@lru_cache(None)
def layer_bounds():
    buckets=[0]*203
    def cut(h,H,u,U,v,V):
        # Enclose y for every point (x,y) on the slice, with x in [h,H].
        def prod(a,b,c,d):
            seq=(a*c,a*d,b*c,b*d);return min(seq),max(seq)
        def div(a,b,c,d):return prod(a,b,1/d,1/c)
        vl,vh=prod(v,V,h,H)
        lo,hi=div(vl-Q(1,2),vh+Q(1,2),u,U)
        if v:
            ul,uh=prod(u,U,h,H)
            a,b=div(-Q(1,2)-uh,Q(1,2)-ul,v,V)
            lo=max(lo,a);hi=min(hi,b)
        return lo,hi
    # Machin identity follows from tangent addition and both angles lying in (0,pi/2).
    def atan_bounds(x):
        partial=sum((-1)**k*x**(2*k+1)/(2*k+1) for k in range(8))
        return partial,partial+x**17/17
    alo,ahi=atan_bounds(Q(1,5));blo,bhi=atan_bounds(Q(1,239))
    assert PI_LO<16*alo-4*bhi and 16*ahi-4*blo<PI_HI
    assert ROOT2_HI**2>2
    def w(t): return (1-t*t+2*t)/(1+t*t)
    for k in range(830):
        x,y=Q(k,2000),Q(k+1,2000)
        if x*x+2*x>=1:break
        # w is increasing until sqrt(2)-1. Handle the last cell with an upper enclosure.
        a=w(x);b=w(y) if y*y+2*y<=1 else ROOT2_HI
        # cos(theta) branch of the reciprocal of the central chord length.
        assert y*(1-x)**2/(4*(1+x*x))<RHO
        u,U=(1-y*y)/(1+y*y),(1-x*x)/(1+x*x)
        v,V=2*x/(1+x*x),2*y/(1+y*y)
        for j in range(64):
            z,Z=Q(j,64),Q(j+1,64)
            h,H=(1+(a-1)*z)/2,(1+(b-1)*Z)/2
            p,P=cut(h,H,u,U,v,V)
            f,G=cut(h-Q(3,5),H-Q(3,5),u,U,v,V)
            assert max(P-f,G-p)<=EXTENT,(k,j,P-f,G-p)
            dist=max(abs(h-Q(3,5)),abs(H-Q(3,5)))
            den=a/2-dist
            # z(1-z) is concave with maximum at 1/2.
            mid=min(Z,max(z,Q(1,2)))
            ratio=max(y*(1-x)**2*mid*(1-mid)/(1+x*x),(b-1)**2*mid*(1-mid)/(2*den))
            assert den>0 and ratio<RHO
            end=ceil(200*max(P-f,G-p))
            buckets[end]=max(buckets[end],ceil(10**9*ratio))
    cap=0;mass=0
    for k in range(202,0,-1):
        cap=max(buckets[k],cap);mass+=cap
    return Q(max(buckets),10**9),Q(mass,200*10**9)

def check_constants():
    r,m=layer_bounds()
    assert 0<r<=RHO and 0<m<=RHO*EXTENT
    return True

def missing_area(c,b,d):
    if not d:return Q(0)
    # Charge clipped tips to pairwise disjoint chords on an inward parallel line.
    r,mass=layer_bounds()
    D=4*(r*c+2*mass*b)
    m0=ceil(c*c/(b*b))
    factor=1+4*d/b
    inner=max(Q(0),c-2*ROOT2_HI*(b+d))
    bonus=(4-PI_HI)*d*d/(b*b)
    def upper(m):
        rhs=c*c+4*c*d+d*D-PI_LO*d*d*(m-1)
        return min(c*c,m*b*b,rhs/factor,(rhs+bonus*(c*c-inner*inner))/(factor+bonus))
    return c*c-max([Q(0)]+[upper(m) for m in range(1,m0+1)])
