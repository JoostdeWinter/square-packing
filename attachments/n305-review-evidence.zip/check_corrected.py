"""Check the filed centers and the corrected corner witness with the review's original reader and exact pose checker."""
from fractions import Fraction
from pathlib import Path
from hashlib import sha256
import json
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'reviewer'))
from r1052_reader import read_form_j,read_form_c
from r1052_poses import run

def main():
    original=(HERE/'n305_exact.json').read_bytes()
    corrected=(HERE/'n305_witness.yaml').read_bytes()
    assert sha256(original).hexdigest()=='e6c7d0280396a2fa61804a24a7c757365320869dbb89e8cf94316bb8b6a7831f'
    lines = corrected.splitlines(keepends=True)
    original_yaml = b''.join(lines[:2] + lines[5:17] + lines[21:])
    assert sha256(original_yaml).hexdigest() == 'b11a6e65a275d3282e1400b89b4cdbd9ca01cf99d01a8e9f0a38a56c20081a46'
    J=read_form_j(original);C=read_form_c(corrected)
    assert J['n']==C['n']==305 and J['side']==C['side']
    corners=[]
    for x,y,c,s in J['poses']:
        corners.append({(x+(i*c-j*s)/2,y+(i*s+j*c)/2) for i in (-1,1) for j in (-1,1)})
    assert all(p==set(q) for p,q in zip(corners,C['corners'],strict=True))
    out=run(C['side'],corners=C['corners'])
    assert len(out['margins'])==46360 and all(out['unit']) and min(out['margins'].values())>=0
    assert min(min(row) for row in out['walls'])>=0
    S=C['side'];xs=[x for square in corners for x,y in square];ys=[y for square in corners for x,y in square]
    wall=[min(xs),S-max(xs),min(ys),S-max(ys)]
    receipt=dict(original_sha256=sha256(original).hexdigest(),corrected_sha256=sha256(corrected).hexdigest(),
                 exact_units=305,exact_pairs=46360,all_original_corners_matched=True,
                 wall_clearances=dict(zip(('left','right','bottom','top'),map(str,wall))),
                 removable_side_padding=str(min(wall[0]+wall[1],wall[2]+wall[3])))
    (HERE/'corrected-check.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('Passed both representations, containment, and 46,360 exact pair checks.')
    print('Wall distances:',[float(v) for v in wall])
    print('Removable side padding:',float(Fraction(receipt['removable_side_padding'])))
if __name__=='__main__':main()
