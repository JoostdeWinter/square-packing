"""Test quarter turns at the filed rational centers and enclosing side, using exact fractions."""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
from functools import lru_cache
import json

def separated(p, q):
    dx,dy=q[0]-p[0],q[1]-p[1]
    for tile in (p,q):
        u,v=tile[2:]
        for a,b in ((u,v),(-v,u)):
            radii=sum(abs(a*c+b*s)+abs(b*c-a*s) for _,_,c,s in (p,q))
            if 2*abs(dx*a+dy*b)>=radii:
                return True
    return False

def main():
    here=Path(__file__).resolve().parent
    data=json.loads((here/'n305_exact.json').read_bytes())
    board=F(data['side'])
    old=[tuple(map(F,k)) for k in data['squares']]
    assert len(old)==305 and all(c*c+s*s==1 for x,y,c,s in old)
    ids=[i for i,(_,_,c,s) in enumerate(old) if 0<min(abs(c),abs(s))<F(1,10**9)]
    def turn(i):
        x,y,c,s=old[i]
        return (x,y,1 if c>0 else -1,F(0)) if abs(c)>abs(s) else (x,y,F(0),1 if s>0 else -1)
    options=[[k,turn(i)] if i in ids else [k] for i,k in enumerate(old)]
    invalid=[]
    for i,poses in enumerate(options):
        for state,(x,y,c,s) in enumerate(poses):
            radius=(abs(c)+abs(s))/2
            if min(x,y,board-x,board-y)<radius:invalid.append(((i,state),))
    for i,j in combinations(range(305),2):
        x,y=old[i][0]-old[j][0],old[i][1]-old[j][1]
        if x*x+y*y>=2:continue
        for a,p in enumerate(options[i]):
            for b,q in enumerate(options[j]):
                if not separated(p,q):invalid.append(((i,a),(j,b)))
    # A forbidden pattern records only the squares whose directions are variable.
    pattern=[tuple((ids.index(i),bool(a)) for i,a in clause if i in ids) for clause in invalid]
    assert all(any(a for _,a in clause) for clause in pattern)
    def failures(bits):
        return [k for k,P in enumerate(pattern) if all(bool(bits & (1<<j))==v for j,v in P)]
    @lru_cache(None)
    def best(bits):
        bad=failures(bits)
        if not bad:return bits
        # Every feasible subset of 'bits' must switch off at least one current true entry here.
        P=min((pattern[k] for k in bad),key=lambda clause:sum(v for j,v in clause))
        return max((best(bits & ~(1<<j)) for j,v in P if v),key=int.bit_count)
    # The following five exact overlap tests already force five original turns.
    # IDs in the proof and in the output below are one-based.
    forced_pairs = [(54,0,108,1),(140,0,150,1),(143,0,153,1),(153,0,164,1),(164,0,175,1)]
    for i,a,j,b in forced_pairs:
        assert ((i-1,a),(j-1,b)) in invalid
    assert not {54,140,143}.intersection(i+1 for i in ids)
    all_bits=(1<<len(ids))-1
    win=best(all_bits)
    assert not failures(win)
    def named(items):return [i+1 for i in items]
    def experiment(bits):
        return [[(i+1,a) for i,a in invalid[k]] for k in failures(bits)]
    receipt=dict(tested=named(ids),individually_feasible=named(i for j,i in enumerate(ids) if not failures(1<<j)),
                 maximum_simultaneous_count=win.bit_count(),one_maximum_set=named(i for j,i in enumerate(ids) if win&(1<<j)),
                 all_snapped_failures=experiment(all_bits),moderate_pair_only=experiment(sum(1<<ids.index(i) for i in (107,149))),
                 count_all_original_pairs=305*304//2,forced_original_turns=[108,150,153,164,175])
    (here/'quarter-turn-results.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print({k:v for k,v in receipt.items() if k not in ('all_snapped_failures','moderate_pair_only','tested')})
    print('When all are snapped:',len(receipt['all_snapped_failures']),'failed pair/wall checks.')
if __name__=='__main__':main()
