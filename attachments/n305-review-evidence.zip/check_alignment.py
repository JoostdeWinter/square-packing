"""Reconstruct the 37 reorientations and nine shifts, then verify all walls and pairs."""
import csv
from fractions import Fraction
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE/'reviewer'))
from r1052_reader import read_form_j
from r1052_poses import run


def main():
    original = read_form_j((HERE/'n305_exact.json').read_bytes())
    variant = read_form_j((HERE/'n305_37_aligned.json').read_bytes())
    side = original['side']
    assert original['n'] == variant['n'] == 305 and side == variant['side']
    shifts = {}
    with (HERE/'axis-alignment-moves.csv').open() as stream:
        for row in csv.DictReader(stream):
            i = int(row['square_id'])
            assert i not in shifts
            shifts[i] = (Fraction(row['delta_x']), Fraction(row['delta_y']))
    assert len(shifts) == 9
    assert all(bool(dx) != bool(dy) and dx*dx+dy*dy<Fraction(2,10**11)**2
               for dx,dy in shifts.values())
    near, changed, original_upright, variant_upright = [], [], 0, 0
    for i, ((x,y,c,s), target) in enumerate(zip(original['poses'], variant['poses'], strict=True),1):
        expected_c, expected_s = c,s
        original_upright += int(c*s==0)
        if 0<min(abs(c),abs(s))<Fraction(1,10**9):
            near.append(i)
            if abs(c)>abs(s):
                expected_c,expected_s = (1 if c>0 else -1),0
            else:
                expected_c,expected_s = 0,(1 if s>0 else -1)
        elif i==43:
            expected_c,expected_s = 1,0
        if (expected_c,expected_s)!=(c,s):
            changed.append(i)
        dx,dy = shifts.get(i,(0,0))
        assert (x+dx,y+dy,expected_c,expected_s)==target
        variant_upright += int(expected_c*expected_s==0)
    assert len(near)==36 and set(changed)==set(near)|{43}
    assert original_upright==176 and variant_upright==213
    result = run(side, poses=variant['poses'])
    assert all(result['unit'])
    assert len(result['margins'])==46360 and min(result['margins'].values())>=0
    assert len(result['walls'])==305 and min(min(row) for row in result['walls'])>=0
    # The same nine positions work when square 43 retains its filed angle.
    restored=list(variant['poses'])
    restored[42]=(*restored[42][:2],*original['poses'][42][2:])
    unchanged_43=run(side,poses=restored)
    assert all(unchanged_43['unit']) and len(unchanged_43['margins'])==46360
    assert min(unchanged_43['margins'].values())>=0 and min(min(row) for row in unchanged_43['walls'])>=0
    largest_id = max(shifts,key=lambda i: sum(x*x for x in shifts[i]))
    magnitude = max(map(abs,shifts[largest_id]))
    print(f'PASS 37 reorientations, 213 axis-aligned tiles, 9 moved centers, original exact side.')
    print(f'Largest displacement is {float(magnitude):.14g} at square {largest_id}.')
    print('PASS 305 containments and 46,360 exact pair checks for each choice of square 43.')


if __name__ == '__main__':
    main()
