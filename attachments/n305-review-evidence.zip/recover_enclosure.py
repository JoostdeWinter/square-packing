"""Recover an exact factorization of all the filed centers and the side."""
import gzip, hashlib, json, math
from fractions import Fraction as F
from pathlib import Path

def main():
    here=Path(__file__).resolve().parent
    data=json.loads((here/'n305_exact.json').read_bytes())
    S=F(data['side'])
    poses=[tuple(map(F,v)) for v in data['squares']]
    Q=10**82
    factor=1+F(3,Q)
    unscaled=[(x/factor,y/factor,c,s) for x,y,c,s in poses]
    assert all((coord*Q).denominator==1 for p in unscaled for coord in p[:2])
    assert all((s*Q/(1+c)).denominator==1 for x,y,c,s in poses)
    for ax in range(2):
        values=[p[ax]*Q**2 for p in poses]
        assert all(v.denominator==1 for v in values)
        assert math.gcd(*(int(v-values[0]) for v in values))==Q+3
    H=max(max(x,y)+(abs(c)+abs(s))/2 for x,y,c,s in unscaled)
    assert H==S-F(54,Q) and S==F(math.ceil(Q*factor*H),Q)
    for ax in range(2):
        fixed=[p for p in poses if p[2:]==(1,0)]
        assert min(p[ax] for p in fixed)==factor/2
        assert min(p[ax]-(abs(p[2])+abs(p[3]))/2 for p in poses)==F(3,2*Q)
    first_raw=gzip.decompress((here/'stages/first.json.gz').read_bytes())
    intermediate=(here/'stages/intermediate.json.gz').read_bytes()
    assert hashlib.sha256(first_raw).hexdigest()=='c245c042067daba937cb87d6ff2fccba503680f579d5dba458d4b2d98fe8f110'
    assert hashlib.sha256(intermediate).hexdigest()=='8bdc089b8d9a4fc74e891e594c7306db6a915795dd4aadb49eb8b0894a7e0b9c'
    first=json.loads(first_raw)['squares'];second=json.loads(gzip.decompress(intermediate))['squares']
    ids=[i for i,(x,y,c,s) in enumerate(poses) if 0<min(abs(c),abs(s))<F(1,10**9)]
    assert len(first)==len(second)==len(poses)==305
    for f,g,p in zip(first,second,poses):
        assert max(abs(F(f[j])-p[j]) for j in (0,1))<F(3,10**30)
        assert max(abs(F(g[key])-p[j]) for j,key in enumerate(('cx','cy')))<F(2,10**39)
    assert sum(F(first[i][3])==0 for i in ids)==27 and all(F(second[i]['t'])!=0 for i in ids)
    for i in (107,149):
        assert F(2,10**11)<F(first[i][3])<F(21,10**12)
    print('Recovered the 82-digit grid, common expansion and outer rounding exactly.')
    print('27 of the 36 near-axis angles were exactly zero in the first saved certificate.')
if __name__=='__main__':main()
