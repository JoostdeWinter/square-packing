"""Verify the nine-center lower bound in the stated local alignment problem."""
import ctypes
from ctypes.util import find_library
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations
import json
from pathlib import Path
from shutil import which
import subprocess

HERE = Path(__file__).resolve().parent
RADIUS = F(2,10**11)


def number(x):
    x=F(x)
    v=str(abs(x.numerator))
    if x.denominator!=1:
        v=f'(/ {v} {x.denominator})'
    return f'(- {v})' if x<0 else v


def constraints(selected, keep_43):
    original=json.loads((HERE/'n305_exact.json').read_bytes())
    assert len(original['squares'])==305
    side=F(original['side'])
    poses={}
    formula=['(set-logic QF_LRA)']
    for i,p in enumerate(original['squares'],1):
        if i not in selected:continue
        x,y=map(F,p[:2])
        c,s=map(F,p[2:])
        if 0<min(abs(c),abs(s))<F(1,10**9):
            if abs(c)>abs(s):
                c,s=F(1 if c>0 else -1),F(0)
            else:
                c,s=F(0),F(1 if s>0 else -1)
        elif i==43 and not keep_43:
            c,s=F(1),F(0)
        assert c*c+s*s==1
        poses[i]=(x,y,c,s)
        half=(abs(c)+abs(s))/2
        for axis,coord in [('x',x),('y',y)]:
            var=f'{axis}{i}'
            low=max(-RADIUS,half-coord)
            high=min(RADIUS,side-half-coord)
            formula.extend([f'(declare-const {var} Real)',
                            f'(assert (<= {number(low)} {var}))',
                            f'(assert (<= {var} {number(high)}))'])
        formula.extend([f'(declare-const fixed{i} Bool)',
                        f'(assert (=> fixed{i} (and (= x{i} 0) (= y{i} 0))))'])

    pairs=0
    for (i,p),(j,q) in combinations(poses.items(),2):
        dx,dy=q[0]-p[0],q[1]-p[1]
        # Each relative center vector can change by at most 2 sqrt(2) RADIUS.
        if dx*dx+dy*dy>2*(1+2*RADIUS)**2:
            continue
        axes=set()
        for c,s in (p[2:],q[2:]):
            axes.update(((c,s),(-s,c),(-c,-s),(s,-c)))
        options=[]
        for a,b in sorted(axes):
            width=sum(abs(a*c+b*s)+abs(b*c-a*s) for c,s in (p[2:],q[2:]))/2
            slack=a*dx+b*dy-width
            variation=2*RADIUS*(abs(a)+abs(b))
            if slack>=variation:
                break
            if slack < -variation:
                continue
            terms=[f'(* {number(v)} {var})' for v,var in
                   ((a,f'x{i}'),(b,f'y{i}'),(-a,f'x{j}'),(-b,f'y{j}')) if v]
            options.append('(<= (+ '+' '.join(terms)+') '+number(slack)+')')
        else:
            assert options
            test=options[0] if len(options)==1 else '(or '+' '.join(options)+')'
            formula.append(f'(assert {test})')
            pairs+=1
    return formula


def exact_solver(problem):
    executable=which('z3')
    if executable:
        return subprocess.run([executable,'-in'],input=problem,text=True,
                              capture_output=True,check=True).stdout
    name=find_library('z3')
    if not name:
        raise SystemExit('Install the Z3 executable or shared library to replay the local lower bound.')
    lib=ctypes.CDLL(name)
    lib.Z3_mk_config.argtypes=[]
    lib.Z3_mk_config.restype=ctypes.c_void_p
    lib.Z3_mk_context.argtypes=[ctypes.c_void_p]
    lib.Z3_mk_context.restype=ctypes.c_void_p
    lib.Z3_eval_smtlib2_string.argtypes=[ctypes.c_void_p,ctypes.c_char_p]
    lib.Z3_eval_smtlib2_string.restype=ctypes.c_char_p
    cfg=lib.Z3_mk_config()
    ctx=lib.Z3_mk_context(cfg)
    try:
        return lib.Z3_eval_smtlib2_string(ctx,problem.encode()).decode()
    finally:
        lib.Z3_del_context.argtypes=[ctypes.c_void_p]
        lib.Z3_del_config.argtypes=[ctypes.c_void_p]
        lib.Z3_del_context(ctx)
        lib.Z3_del_config(cfg)


@lru_cache(None)
def can_hit(groups, budget):
    if not groups:return True
    if budget==0:return False
    smallest=min(groups,key=len)
    return any(can_hit(tuple(g for g in groups if i not in g),budget-1) for i in smallest)


def main():
    if not __debug__:raise SystemExit('Enable Python assertions.')
    records=json.loads((HERE/'local-move-conflicts.json').read_text())
    groups=tuple(tuple(row['fixed']) for row in records)
    assert all(g and len(set(g))==len(g) and min(g)>=1 and max(g)<=305 for g in groups)
    for record in records:
        local=set(record['squares'])
        group=record['fixed']
        assert set(group)<=local<=set(range(1,306))
        fixed=' '.join(f'fixed{i}' for i in group)
        # Omit every tile outside this subset. Infeasibility of even this smaller
        # instance rules out a complete packing with these centers fixed.
        for keep_43 in (True,False):
            problem=constraints(local,keep_43)
            problem.append(f'(check-sat-assuming ({fixed}))')
            verdict=exact_solver('\n'.join(problem)+'\n').strip()
            assert verdict=='unsat',(group,keep_43,verdict)
    assert not can_hit(groups,8) and can_hit(groups,9)
    print(f'PASS all {len(groups)} geometric conflict groups are infeasible with their listed centers fixed, with square 43 upright or at its filed angle.')
    print('PASS eight centers cannot hit all groups; nine suffice. Coordinate shift limit is 2e-11.')


if __name__=='__main__':main()
