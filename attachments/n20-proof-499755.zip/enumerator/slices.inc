// A transverse line has at most the side length of the board available.
// Every packing tile contributes a chord disjoint in length from the others.
struct ChordConstants {I height,plateau,product;};
ChordConstants chord_constants(const Row&r,I D){
    auto endpoint=[](I p,I q){return array<I,3>{q*q-p*p,2*p*q,q*q+p*p};};
    auto l=endpoint(r.ki,r.gi),u=endpoint(r.ki+1,r.gi);
    I height=D,plateau=2*D,product_hi=0;
    for(auto v:{l,u}){
        height=min(height,fl((W)D*(v[0]+v[1]),2*v[2]));
        plateau=min(plateau,fl((W)D*v[2],max(v[0],v[1])));
        product_hi=max(product_hi,-fl(-(W)D*v[0]*v[1],(W)v[2]*v[2]));
    }
    if(l[0]>=l[1] && u[0]<=u[1])product_hi=(D+1)/2;
    return {height,plateau,product_hi};
}
I inner_chord(const P& poly,int axis,I level){
    if(poly.size()<3)return 0;
    I high=INT64_MIN,low=INT64_MAX;auto a=poly.back();
    for(auto v:poly){
        I x=axis?a.y:a.x,y=axis?a.x:a.y;
        I X=axis?v.y:v.x,Y=axis?v.x:v.y;
        if(y==level){high=max(high,x);low=min(low,x);}
        if((y<level && level<Y)||(Y<level && level<y)){
            I den=Y-y;W num=(W)x*den+(W)(X-x)*(level-y);
            high=max(high,fl(num,den));low=min(low,-fl(-num,den));
        }
        a=v;
    }
    return high<low?0:high-low;
}
bool slice_filter(const vector<int>& O,const vector<Row>&rows,vector<vector<P>>& C,
                  const vector<P>& H,I U,I D,int& witness){
    const int B=rows.size(),Z=H.size();vector<ChordConstants> coeff;
    for(const auto&r:rows)coeff.push_back(chord_constants(r,D));
    vector<vector<Bound>> boxes(B,vector<Bound>(Z));vector<vector<int>> live(Z);
    for(int k=0;k<B;k++)for(int i:O)if(!C[k][i].empty()){boxes[k][i]=bbox(C[k][i]);live[i].push_back(k);}
    for(int i:O)if(live[i].empty()){witness=i;return false;}
    for(int axis=0;axis<2;axis++){
        vector<I> levels;
        for(I v=D/10;v<U;v+=D/12)levels.push_back(v);
        for(int i:O)if(!H[i].empty()){auto box=bbox(H[i]);levels.push_back(axis?(box.l+box.r)/2:(box.b+box.t)/2);}
        sort(levels.begin(),levels.end());levels.erase(unique(levels.begin(),levels.end()),levels.end());
        for(I level:levels){
            vector<I> val(Z);I total=0;
            for(int i:O){
                I v=2*D;
                for(int k:live[i]){
                    auto b=boxes[k][i];I low=axis?b.l:b.b,high=axis?b.r:b.t;
                    I delta=max(abs(level-low),abs(level-high));
                    auto q=coeff[k];
                    I chord=delta>=q.height?0:min(q.plateau,fl((W)D*(q.height-delta),q.product));
                    v=min(v,chord);if(v==0)break;
                }
                val[i]=max(v,inner_chord(H[i],axis,level));total+=val[i];
            }
            if(total>U){witness=O.front();return false;}
            if(total+1414214<=U)continue;
            for(int i:O){
                I room=U-total+val[i];
                if(room>=1414214)continue;
                for(int k:live[i]){
                    P&p=C[k][i];if(p.empty())continue;auto q=coeff[k];if(q.plateau<=room)continue;
                    I rad=q.height-(-fl(-(W)(room+1)*q.product,D));if(rad<=0)continue;
                    I a=level-rad,b=level+rad;auto box=boxes[k][i];
                    I low=axis?box.l:box.b,high=axis?box.r:box.t;
                    if(high<=a || low>=b)continue;
                    // The whole open stripe is forbidden. Either remaining
                    // half-plane is necessary if its opposite side is empty.
                    if(low>a&&high<b){p.clear();continue;}
                    if(low>a){HP hp=axis?HP{-1,0,-b}:HP{0,-1,-b};p=cut(p,hp);}
                    else if(high<b){HP hp=axis?HP{1,0,a}:HP{0,1,a};p=cut(p,hp);}
                }
            }
        }
    }
    return true;
}
