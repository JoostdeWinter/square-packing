"""A twenty-tile end-to-end positive control with every center and every moved mark known."""
import argparse,itertools,subprocess,sys,tempfile,shutil,os,json
from fractions import Fraction as F
from pathlib import Path
h=Path(__file__).resolve().parents[1];up=h/'base496/upstream'
sys.path[:0]=[str(h/'base496'),str(up)]
from prereqs import checked_sources
from deepbuild import build as pair_build
from strongbuild import build as strong_build
import nearest_rack,rack_lattice_input,check_stabs
from verify_nearest_lower import certified_init
from verify_arc_lower import build
def control():
 with tempfile.TemporaryDirectory() as td:
  d=Path(td);u=d/'up';u.mkdir();checked_sources(u,up);os.chdir(u)
  # Work in millionths; the outer square has side 5.04 and the grid pitch is 1.005.
  cap=5040000;coords=[510000+1005000*i for i in range(5)];removed={(0,0),(0,4),(4,0),(4,4),(2,2)}
  centers=sorted((coords[i],coords[j]) for i,j in itertools.product(range(5),repeat=2) if (i,j) not in removed)
  m=cap//2;pts=sorted(centers+[(m-80000,m),(m+80000,m)])
  assert len(centers)==20 and all(max(abs(x-u),abs(y-v))>1000000 for (x,y),(u,v) in itertools.combinations(centers,2))
  assert all(min(x,y,cap-x,cap-y)>500000 for x,y in centers)
  def md(ignored):return [(F(x,10**6),F(y,10**6)) for x,y in pts]
  spec={'cap':'5.04','erosion':'1/100000','marks':22}
  for mod in [nearest_rack,rack_lattice_input,check_stabs]:mod.marks=md
  native=d/'native';native.mkdir();build(native);pair_build(native/'r.cc',native/'pair')
  strong_build(native/'pair.cpp',native/'strong')
  e=d/'terminal';e.mkdir()
  for file in ['slices.inc','build.py','search.inc']:shutil.copy(h/'enumerator'/file,e/file)
  shutil.copy(native/'strong.cpp',e/'kernel.cpp');subprocess.run([sys.executable,e/'build.py'],check=True)
  b=32;table=d/'table';certified_init(spec,b,table)
  lines=[f'22 {cap}']
  for x,y in pts:lines.append(f'{x} {y} 2 {x-1000} {y} {x+1000} {y}')
  marks=d/'moves';marks.write_text('\n'.join(lines)+'\n')
  blue=[(cap-y,x) for x,y in pts];owners=[pts.index(p) for p in centers];blues=[blue.index(p) for p in centers]
  mask=sum(1<<i for i in owners)
  assert mask==sum(1<<j for j in blues)
  profiles=d/'profiles';profiles.mkdir()
  p=subprocess.check_output([native/'pair','profile',table,'16',profiles],text=True,input=f'{mask}\n').split()
  assert p==[str(mask),'0']
  args=[e/'enumerate','match',table,profiles,marks,str(mask),str(mask),'8','1']
  result=subprocess.run(args,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
  assignments=[list(map(int,z.split())) for z in result.stdout.splitlines()]
  assert blues in assignments
  args[1]='check';row=' '.join(map(str,blues))+'\n'
  allowed=subprocess.check_output([*args,'-1,-1,-1,-1'],text=True,input=row).split()
  assert allowed[0]=='OPEN'
  # A known tile in the lower-left part of the board cannot have x>=5, so that intentional control must close.
  excluded=subprocess.check_output([*args,'-1,-1,-1,-1','0,0,-1,5000000'],text=True,input=row).split()
  assert excluded[0]=='CLOSED'
  print(json.dumps({'side':'126/25','units':20,'grid_pitch':'201/200','actual_matching_retained':True,'retained_matching_count':len(assignments),'four_unused_marks_outside':allowed,'impossible_center_cut':excluded}))
if __name__=='__main__':control()
