"""Enumerate every ownership branch, including an uncaptured mark."""
import argparse, concurrent.futures, itertools, json, os, subprocess
from pathlib import Path
h=Path(__file__).resolve().parent
root=h.parent.parent
def atomic_json(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,sort_keys=True)+'\n');tmp.replace(path)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=4);ap.add_argument('--rounds',type=int,default=32);ap.add_argument('--cycles',type=int,default=2);ap.add_argument('--side',type=int,default=497);ap.add_argument('--bins',type=int,default=64);ap.add_argument('--dir',type=Path,default=h.parent/'runs'/'owner497')
    args=ap.parse_args();base=args.dir;base.mkdir(exist_ok=True,parents=True)
    matches=(h.parent/'runs'/'central_matches.txt').read_text().splitlines()
    if len(matches)!=1:raise ValueError('expected the one remaining matching')
    command=[str(h/'enumerate'),'check',str(root/'target20'/'work'/f'b{args.side}'/f'i{args.bins}'),str(root/'important_20261120'/f'd{args.side}_{args.bins}_60'),str(h/f'marks{args.side}.txt'),'3932151','3932151',str(args.rounds),str(args.cycles)]
    def test(owners):
        stem='_'.join(map(str,owners));log=base/(stem+'.json')
        if log.is_file():return json.loads(log.read_text())
        state=base/(stem+'.state');cut=','.join(map(str,owners))
        r=subprocess.run([*command,cut,'-',str(state)],text=True,input=matches[0]+'\n',stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
        line=r.stdout.strip().split()
        assert ((line[0]=='CLOSED' and len(line)==2) or (line[0]=='OPEN' and len(line)==5))
        result={'owners':owners,'result':line[0],'data':list(map(int,line[1:]))}
        atomic_json(log,result)
        return result
    nodes=[(-2,)*4];levels=[];full=[]
    with concurrent.futures.ThreadPoolExecutor(args.workers) as ex:
        while nodes:
            next_nodes=[];closed=0;unsettled=0
            for i,o in enumerate(ex.map(test,nodes)):
                owners=o['owners'];data=o['data']
                if o['result']=='CLOSED':closed+=1;continue
                if -2 not in owners:full.append(o);continue
                index=min((k for k,v in enumerate(owners) if v==-2),key=lambda j:(data[j].bit_count(),j))
                for who in [-1]+[k for k in range(20) if data[index]>>k&1]:
                    arr=list(owners);arr[index]=who;next_nodes.append(tuple(arr))
                unsettled+=1
            levels.append({'nodes':len(nodes),'closed':closed,'branched':unsettled,'next':len(next_nodes),'full_open':len(full)})
            print(levels[-1],flush=True);atomic_json(base/'progress.json',{'levels':levels,'full_open':full});nodes=next_nodes
    atomic_json(base/'result.json',{'matching':matches[0],'levels':levels,'full_open':full})
if __name__=='__main__':main()
