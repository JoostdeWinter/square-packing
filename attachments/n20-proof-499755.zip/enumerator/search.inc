#include <functional>
#include <set>
#include <iomanip>
struct Movement {
    vector<Point> mark;
    vector<P> moves;
    Movement(const string& file,I side) {
        ifstream f(file);int n; I cap; f>>n>>cap;
        if(!f||cap!=side||n!=22)throw runtime_error("bad movement header");
        for(int i=0;i<n;++i) {
            int count;Point p;f>>p.x>>p.y>>count;
            if(!f||count<0||count>150)throw runtime_error("bad move count");
            mark.push_back(p);P q(count);
            for(auto& z:q) {f>>z.x>>z.y;if(!f||min(z.x,z.y)<0||max(z.x,z.y)>side)throw runtime_error("bad move coordinate");}
            moves.push_back(q);
        }
        string extra;if(f>>extra)throw runtime_error("extra movements");
    }
    void rotate(I side){for(auto& p:mark)p={side-p.y,p.x};for(auto& v:moves)for(auto& p:v)p={side-p.y,p.x};}
};
P convex_union(P a,const P& b){merge_vertices(a,b);return hull(move(a));}
// Every vertex of a seed lies strictly inside its physical tile. The closed
// convex hulls of two sets of such vertices must be disjoint, including when
// either hull is a segment or point.
bool inside_closed(Point x,const P& p){
    if(p.empty())return false;
    if(p.size()==1)return x==p[0];
    if(p.size()==2){const auto b=bbox(p);return !cross(p[0],p[1],x)&&x.x>=b.l&&x.x<=b.r&&x.y>=b.b&&x.y<=b.t;}
    for(const auto& f:facets(p))if(eval(f,x)>0)return false;
    return true;
}
bool intersect_closed(const P& a,const P& b){
    if(a.empty()||b.empty()||!bmatch(bbox(a),bbox(b)))return false;
    if(a.size()>=3&&b.size()>=3)return meets(a,b);
    for(const auto& p:a)if(inside_closed(p,b))return true;
    for(const auto& p:b)if(inside_closed(p,a))return true;
    for(size_t i=0;i<a.size();++i)for(size_t j=0;j<b.size();++j){
        Point x=a[i],y=a[(i+1)%a.size()],p=b[j],q=b[(j+1)%b.size()];
        auto ax=cross(x,y,p),ay=cross(x,y,q),bx=cross(p,q,x),by=cross(p,q,y);
        if(((ax<0&&ay>0)||(ax>0&&ay<0))&&((bx<0&&by>0)||(bx>0&&by<0)))return true;
    }
    return false;
}
P restrict_to_anchors(P p,const Row& row,const P& anchors){
    for(auto f:row.axes){
        if(p.empty())break;
        f.k+=mn(anchors,f);
        if(mn(p,f)>f.k)return {};
        if(mx(p,f)>f.k)p=cut(p,f);
    }
    return p;
}
P avoid_mark(P p,const Row& row,Point mark){
    if(p.empty())return p;
    auto f=row.fac;for(auto& z:f)z.k+=dot(z,mark);
    return noninterior_hull(p,f);
}
const int N=20;
struct Choices {
    const Movement &red,&blue;
    vector<int> A,B; vector<int> hole[2]; I side;
    Choices(const Movement& a,const Movement& b,vector<int> aIds,vector<int> bIds,I u):
            red(a),blue(b),A(move(aIds)),B(move(bIds)),side(u){
        if(A.size()!=N||B.size()!=N)throw runtime_error("expected twenty");
        for(int c=0;c<2;++c)for(int j=0;j<22;++j){
            const auto& ids=c?B:A;
            if(find(ids.begin(),ids.end(),j)==ids.end())hole[c].push_back(j);
        }
    }
    vector<P> alternatives(int color,int i,const vector<int>& owners)const{
        const auto& sites=color?blue:red;int index=(color?B:A)[i];
        vector<P> out;P hit;
        bool has=false;
        for(int h=0;h<2;++h){
            int owner=owners[2*color+h];auto m=sites.mark[hole[color][h]];
            if(owner==i){hit.push_back(m);has=true;}
        }
        if(has)return {hull(move(hit))};
        P required=sites.moves[index];required.push_back(sites.mark[index]);out.push_back(hull(move(required)));
        for(int h=0;h<2;++h)if(owners[2*color+h]==-2)
            out.push_back({sites.mark[hole[color][h]]});
        return out;
    }
};
bool contract_disjunction(Engine& x,const Choices& records,const vector<int>& owners,int& removed){
    auto old=x.seed;removed=0;
    for(int i=0;i<N;++i){
        int id=records.A[i];
        auto red=records.alternatives(0,i,owners),blue=records.alternatives(1,i,owners);
        vector<P> out(x.B),core_choices;
        for(const auto& r:red)for(const auto& b:blue){
            P req=convex_union(convex_union(x.seed[id],r),b);
            bool impossible=false;
            for(int other:records.A)if(other!=id&&intersect_closed(req,old[other])){impossible=true;break;}
            if(impossible)continue;
            vector<HP> all;
            for(int k=0;k<x.B;++k){
                P p=x.init[k][id];if(p.empty())continue;
                p=restrict_to_anchors(move(p),x.rows[k],req);
                for(int h=0;h<4&&!p.empty();++h){
                    if(owners[h]==-2||owners[h]==i)continue;
                    const auto& rack=h>=2?records.blue:records.red;
                    p=avoid_mark(move(p),x.rows[k],rack.mark[records.hole[h/2][h%2]]);
                }
                if(p.empty())continue;
                for(auto h:x.rows[k].fac){h.k+=mn(p,h);all.push_back(h);}
                merge_vertices(out[k],p);
            }
            if(!all.empty())core_choices.push_back(convex_union(req,safe(all,x.U)));
        }
        if(core_choices.empty())return false;
        vector<const P*> refs;for(auto& p:core_choices)refs.push_back(&p);
        guaranteed_intersection(x.seed[id],refs,x.U);
        for(int k=0;k<x.B;++k){
            if(!x.init[k][id].empty()&&out[k].empty())++removed;
            x.init[k][id]=hull(move(out[k]));
        }
    }
    return true;
}
bool propagate(Engine& x,const Choices& data,const vector<int>& owners,int cycles,int rounds,int& reason){
    int w,it,removed;
    for(int j=0;j<cycles;++j){
        if(!contract_disjunction(x,data,owners,removed)){reason=8;return false;}
        if((reason=x.run(data.A,rounds,w,it)))return false;
    }
    return true;
}
void save_state(const Engine& x,const vector<int>& A,const string& filename){
    ofstream f(filename);if(!f)throw runtime_error("state file open");
    f<<x.B<<" "<<x.Z<<" "<<x.U<<"\n";
    for(int id:A){write_poly(f,x.seed[id]);for(int k=0;k<x.B;k++)write_poly(f,x.init[k][id]);}
}
void enumerate_matchings(Engine x,Engine y,const vector<int>& A,const vector<int>& B,int cycles,int rounds){
    vector<Mask> allowed(N,(Mask(1)<<N)-1),live;int w,it;
    for(int i=0;i<cycles;++i){
        if(pair_filter(x,y,A,B,&allowed,&live)){cerr<<"no pair matching\n";return;}
        allowed=live;
        if(x.run(A,rounds,w,it)||y.run(B,rounds,w,it)){cerr<<"closed during pair contraction\n";return;}
    }
    if(pair_filter(x,y,A,B,&allowed,&live))return;
    vector<vector<P>> cores(N,vector<P>(N));
    for(int i=0;i<N;++i)for(int j=0;j<N;++j)if(live[i]>>j&1){
        vector<HP> centers;
        for(int k=0;k<x.B;++k){
            P p=intersect_outer(x.init[k][A[i]],y.init[k][B[j]]);
            if(p.empty())continue;
            for(auto h:x.rows[k].fac){h.k+=mn(p,h);centers.push_back(h);}
        }
        cores[i][j]=convex_union(x.seed[A[i]],y.seed[B[j]]);
        if(centers.empty()){live[i]&=~(Mask(1)<<j);continue;}
        cores[i][j]=convex_union(cores[i][j],safe(centers,x.U));
    }
    vector<int>sol(N,-1);long nodes=0,count=0;
    function<void(vector<Mask>,int)> visit=[&](vector<Mask> opts,int depth){
        ++nodes;
        if(depth==N){for(int i=0;i<N;i++)cout<<(i?" ":"")<<B[sol[i]];cout<<'\n';++count;return;}
        int row=-1,num=N+1;
        for(int i=0;i<N;++i)if(sol[i]<0&&__builtin_popcountll(opts[i])<num){num=__builtin_popcountll(opts[i]);row=i;}
        if(num==0)return;
        Mask v=opts[row];
        while(v){
            int j=__builtin_ctzll(v);v&=v-1;auto next=opts;next[row]=Mask(1)<<j;
            bool possible=true;
            for(int i=0;i<N&&possible;++i)if(i!=row&&sol[i]<0){
                next[i]&=~(Mask(1)<<j);Mask choices=next[i];
                while(choices){int q=__builtin_ctzll(choices);choices&=choices-1;
                    if(intersect_closed(cores[row][j],cores[i][q]))next[i]&=~(Mask(1)<<q);}
                possible=next[i]!=0;
            }
            if(possible&&perfect(next)){sol[row]=j;visit(move(next),depth+1);sol[row]=-1;}
        }
    };
    visit(live,0);cerr<<"enumerated "<<count<<" assignments in "<<nodes<<" nodes\n";
}
int main(int argc,char**argv){try{
    if(argc<8)throw runtime_error("mode table profilefolder moves mask-red mask-blue rounds [cycles] [owners] [cuts]");
    string mode=argv[1];Engine base(argv[2]);string dir=argv[3];Movement p(argv[4],base.U),q=p;q.rotate(base.U);
    Mask ma=stoull(argv[5]),mb=stoull(argv[6]);int rounds=stoi(argv[7]),cycles=argc>8?stoi(argv[8]):2;
    Profile r(dir+"/"+to_string(ma),false),b(dir+"/"+to_string(mb),true);
    if(r.m!=ma||b.m!=mb||r.U!=base.U||b.U!=base.U||r.B!=base.B||b.B!=base.B||r.shut||b.shut)throw runtime_error("missing or closed profile");
    Engine x=base,y=base;x.init=r.c;x.seed=r.h;y.init=b.c;y.seed=b.h;
    if(mode=="match"){enumerate_matchings(move(x),move(y),r.O,b.O,cycles,rounds);return 0;}
    vector<int> B(N);for(int& j:B)if(!(cin>>j))throw runtime_error("missing matching");
    auto sorted=B;sort(sorted.begin(),sorted.end());if(sorted!=b.O)throw runtime_error("bad matching");
    for(int i=0;i<N;++i){int id=r.O[i],j=B[i];x.seed[id]=convex_union(x.seed[id],y.seed[j]);for(int k=0;k<x.B;++k)x.init[k][id]=intersect_outer(x.init[k][id],y.init[k][j]);}
    Choices data(p,q,r.O,B,x.U);vector<int> owners(4,-2);
    if(argc>9){istringstream s(argv[9]);char sep;for(int i=0;i<4;i++){if(i)s>>sep;if(!(s>>owners[i])||owners[i]<-2||owners[i]>=N)throw runtime_error("owner range");}}
    if(argc>10&&string(argv[10])!="-"){istringstream s(argv[10]);int i,axis,sign;I bound;char sep;
        while(s>>i>>sep>>axis>>sep>>sign>>sep>>bound){if(i<0||i>=N||axis<0||axis>2||(sign!=1&&sign!=-1))throw runtime_error("cut range");
            for(int k=0;k<x.B;++k){auto& a=x.init[k][r.O[i]];if(a.empty())continue;
                if(axis==2){if((sign==1&&x.rows[k].ki>=bound)||(sign==-1&&x.rows[k].ki+1<=bound))a.clear();}
                else{HP h{axis==0?sign:0,axis==1?sign:0,sign*bound};if(mx(a,h)>h.k)a=cut(a,h);}
            }s>>sep;}
    }
    int reason=0;
    if(!propagate(x,data,owners,cycles,rounds,reason)){cout<<"CLOSED "<<reason<<endl;return 0;}
    if(mode!="check")throw runtime_error("unsupported mode");
    if(argc>11)save_state(x,r.O,argv[11]);
    cout<<"OPEN";
    for(int h=0;h<4;h++){
        Mask possible=0;const auto& rack=h>=2?q:p;Point mark=rack.mark[data.hole[h/2][h%2]];
        for(int i=0;i<N;++i){
            auto req=convex_union(x.seed[r.O[i]],{mark});bool bad=false;
            for(int j=0;j<N;++j)if(i!=j&&intersect_closed(req,x.seed[r.O[j]])){bad=true;break;}
            if(bad)continue;
            for(int k=0;k<x.B;++k)if(!restrict_to_anchors(x.init[k][r.O[i]],x.rows[k],req).empty()){possible|=Mask(1)<<i;break;}
        }
        cout<<" "<<possible;
    }
    cout<<endl;return 0;
}catch(exception&e){cerr<<e.what()<<endl;return 2;}}
