"""Replay the final marked-pair case using only authenticated initial data."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess, itertools
def read_marks(file):
 lines=file.read_text().splitlines();n,cap=map(int,lines[0].split());assert n==22 and len(lines)==23
 pts=[];changes=set()
 for i,line in enumerate(lines[1:]):
  x,y,k,*moves=map(int,line.split());assert len(moves)==2*k
  pts.append((x,y));changes.update((i,a,b) for a,b in zip(moves[::2],moves[1::2]))
 return cap,pts,changes
def verify_movements(file,expected,cap,workers):
 from coverage import sweep
 u,pts,moves=read_marks(file);assert u==cap and pts==expected
 actions=[]
 for flipx,flipy in itertools.product(range(2),repeat=2):
  def f(z,fx=flipx,fy=flipy):return (u-z[0] if fx else z[0],u-z[1] if fy else z[1])
  actions.append(([pts.index(f(p)) for p in pts],f))
 reps=set()
 for i,x,y in moves:
  orbit={(perm[i],*f((x,y))) for perm,f in actions}
  assert orbit<=moves
  reps.add(min(orbit))
 def check(a):
  i,x,y=a;tentative=pts.copy();tentative[i]=(x,y);leaves=sweep(tentative,u)
  assert leaves>0,(i,x,y)
  return leaves
 with ThreadPoolExecutor(workers) as pool:counts=list(pool.map(check,sorted(reps)))
 return {'moved_sites':len(moves),'reflected_representatives':len(reps),'least_angle_intervals':min(counts),'most_angle_intervals':max(counts)}
def replay_final(folder,table,profiles,moves,ma,mb,binary,workers):
 cmd=[str(binary),'match',str(table),str(profiles),str(moves),str(ma),str(mb),'16','2']
 match=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
 matches=match.stdout.splitlines()
 cmd[1]='check';cmd[-2:] = ['32','2']
 def verify_matching(m):
  assert len(set(map(int,m.split())))==20
  nodes=[(-2,)*4];hist=[];reasons={}
  while nodes:
   def run(st):
    r=subprocess.check_output([*cmd,','.join(map(str,st))],text=True,input=m+'\n').split()
    return st,r
   children=[];terminals=0
   with ThreadPoolExecutor(workers) as pool:
    for st,r in pool.map(run,nodes):
     if r[0]=='CLOSED':
      assert len(r)==2 and int(r[1]) in (1,2,7,8);reasons[r[1]]=reasons.get(r[1],0)+1;terminals+=1;continue
     assert r[0]=='OPEN' and len(r)==5
     assert -2 in st,('unresolved full set of four owners',st)
     masks=list(map(int,r[1:]));assert all(0<=v<1<<20 for v in masks)
     index=min((h for h in range(4) if st[h]==-2),key=lambda h:(masks[h].bit_count(),h))
     for owner in [-1]+[j for j in range(20) if masks[index]>>j&1]:
      ns=list(st);ns[index]=owner;children.append(tuple(ns))
   hist.append([len(nodes),terminals,len(children)]);nodes=children
  return {'assignment':list(map(int,m.split())),'ownership_levels':hist,'closed_by_reason':reasons}
 return {'match_log':match.stderr.strip(),'assignments':list(map(verify_matching,matches))}
