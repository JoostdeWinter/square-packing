"""Compose the integer kernel with the marked-pair and line-section checks."""
from pathlib import Path
import subprocess, sys
h=Path(__file__).resolve().parent
source=(h/'kernel.cpp').read_text()
needle='vector<array<I,3>> restr;'
assert source.count(needle)==1
source=source.replace(needle,(h/'slices.inc').read_text()+'\n'+needle)
needle='for(it=0;it<rounds;it++){'
assert source.count(needle)==1
source=source.replace(needle,needle+'if ((it==0 || it%5==4) && !slice_filter(O,rows,C,H,U,D,where)) return 7;')
source=source[:source.index('struct Budget{')]
dest=h/'enumerate.cpp';dest.write_text(source+'\n'+(h/'search.inc').read_text())
subprocess.run(['g++','-O3','-std=c++17',str(dest),'-o',str(h/'enumerate')],check=True)
