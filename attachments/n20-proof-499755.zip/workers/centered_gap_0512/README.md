# Centered-grid feedback for uniform independent tilts

Research direction: Joost de Winter. AI author: GPT6.2 Astra.

## Result

Let 20 freely translated and independently rotated unit squares fit in a board
of side `S=5-delta<5`, and let every reduced tilt be at most `e<=1/101`.
Then

    delta <= [40e B(e)+5e^2]/(1+4e),                (1)

where

    F(e)=e-e^2/2+e^4/24,  B(e)=F(e)(1+F(e)).

At the cap `e=1/101`, this is the exact conditional bound

    5-S <= 69774052333375753/16372793389096571112,
    S >= 81794192893149479807/16372793389096571112
      = 4.995738414901159... .                        (2)

The simpler corollary

    delta <= ((45+40e)/(1+4e))e^2

already gives `S>=4.9957193739...`; (1) uses a sharper exact trigonometric
majorant.  Both strengthen the earlier uncentred certificate
`delta<=(45+40e)e^2`, whose cap value gave `S>=4.995549844...`.
It remains conditional: a hypothetical endpoint packing may contain a tile
with reduced tilt greater than `1/101`.

## Centered lane lemma

Use the two four-lane unit-chord decompositions from
`workers/uniform_small_tilt_0412`.  In one ordered lane let

    a_i = u_i(u_i-1),  u_i=cos(phi_i)+sin(phi_i),
    A = sum_{i in lane} a_i.

The five unit-chord intervals have lengths `1-a_i`.  If `g_0,...,g_5` are the
wall and inter-interval gaps, then

    sum g_j = S-sum(1-a_i) = A-delta.                (3)

For the `k`-th interval centre `z_k`, the ordinary grid coordinate gives

    z_k-(k-1/2)
      = (g_0+...+g_{k-1})
        -(a_1+...+a_{k-1}+a_k/2).

The first parenthesis lies in `[0,A-delta]`, the second in `[0,A]`.  Therefore,
relative to the board-centred grid site

    q_k = k-1/2-delta/2,

one has the sharper symmetric bound

    |z_k-q_k| <= A-delta/2.                          (4)

The same holds in the other coordinate.  Translating all five grid coordinates
by `-delta/2` does not alter unit spacings.  In the proof of
`geometry/near_grid.md`, the two endpoint wall margins occur only through their
sum `S-4=1-delta`; the centred margins are both `(1-delta)/2`, so its
simultaneous turning-chain estimate is unchanged.

## Feedback calculation

Let `a(e)=(cos e+sin e)(cos e+sin e-1)`.  The alternating Taylor inequalities
on this interval give

    cos(e)+sin(e)-1 <= F(e)=e-e^2/2+e^4/24,
    a_i <= a(e) <= B(e)=F(e)(1+F(e)) <= (1+e)e.

Equation (4) gives the common coordinate error

    r <= 5a(e)-delta/2
      <= 5B(e)-delta/2.                              (5)

For `e<=1/101`, the positive upper bound in (5) is below `1/20`, so the checked
near-grid theorem applies:

    delta <= 8re+5e^2
          <= 8e(5B(e)-delta/2)+5e^2.

Moving the feedback term to the left yields

    (1+4e)delta <= 40eB(e)+5e^2,

which is (1).  Replacing `B(e)` by the coarser `(1+e)e` gives the displayed
simpler corollary.  The broad permutation-vacancy reduction is valid here because
`1/101<53/800`.  Wall contacts, tile contacts, coincident chord endpoints and
non-lattice centre positions remain covered by the underlying open-interval
lane proof.

## Reproduce

    python3 verify_centered_gap.py receipt.json

Expected output:

    PASS: centered-grid feedback certificate

