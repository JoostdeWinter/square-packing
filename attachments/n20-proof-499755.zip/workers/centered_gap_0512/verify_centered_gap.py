#!/usr/bin/env python3
"""Exact symbolic/rational check of centered-grid feedback."""

from fractions import Fraction as F
import json
import sys

import sympy as sp


def Q(value):
    return F(str(value))


def main(path):
    with open(path, "r", encoding="utf-8") as handle:
        receipt = json.load(handle)

    # Exact interval for d=P-N+delta/2 when 0<=P<=A-delta and 0<=N<=A.
    A, delta, P, N = sp.symbols("A delta P N", nonnegative=True)
    d = P - N + delta / 2
    lower = sp.expand(d.subs({P: 0, N: A}))
    upper = sp.expand(d.subs({P: A-delta, N: 0}))
    assert lower == -A + delta/2
    assert upper == A - delta/2
    assert receipt["centered_coordinate_error"] == "A-delta/2"

    e = sp.symbols("e", nonnegative=True)
    Fpoly = e - e**2/2 + e**4/24
    Bpoly = sp.expand(Fpoly * (1 + Fpoly))
    r_upper = 5 * Bpoly - delta / 2
    rhs = sp.expand(8 * r_upper * e + 5 * e**2)
    feedback = sp.expand((1 + 4*e) * delta - 40*e*Bpoly - 5*e**2)
    assert sp.expand(delta - rhs - feedback) == 0
    assert receipt["taylor_f_formula"] == "e-e^2/2+e^4/24"
    assert receipt["taylor_a_formula"] == "F(e)(1+F(e))"
    assert receipt["uniform_centered_radius"] == "5B(e)-delta/2"
    assert receipt["feedback_inequality"] == "(1+4e)delta <= 40eB(e)+5e^2"

    cap = Q(receipt["tilt_cap"])
    r0 = 5 * (1 + cap) * cap
    assert cap == F(1, 101)
    assert r0 == Q(receipt["uncentered_radius_cap"]) == F(510, 10201)
    assert r0 < Q(receipt["near_grid_radius_limit"]) == F(1, 20)

    fcap = cap - cap*cap/2 + cap**4/24
    bcap = fcap * (1 + fcap)
    improved = (40*cap*bcap + 5*cap*cap) / (1 + 4*cap)
    simple = ((45 + 40*cap) / (1 + 4*cap)) * cap * cap
    old = (45 + 40*cap) * cap * cap
    assert fcap == Q(receipt["taylor_f_at_cap"]) == F(24604813, 2497449624)
    assert simple == Q(receipt["simple_side_deficit_at_cap"]) == F(131, 30603)
    assert improved == Q(receipt["side_deficit_at_cap"]) == F(69774052333375753, 16372793389096571112)
    assert old == Q(receipt["previous_side_deficit_at_cap"]) == F(4585, 1030301)
    assert improved < simple < old
    assert 5 - improved == Q(receipt["side_lower_bound_at_cap"]) == F(81794192893149479807, 16372793389096571112)

    assert receipt["attribution"] == {
        "research_direction": "Joost de Winter",
        "ai_author": "GPT6.2 Astra",
    }
    print("PASS: centered-grid feedback certificate")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: verify_centered_gap.py receipt.json")
    main(sys.argv[1])

