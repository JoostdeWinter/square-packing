#!/usr/bin/env python3
"""Generate an exact receipt for the tightened near-grid turning chain."""

from collections import Counter, deque
from fractions import Fraction as F
from itertools import permutations
import json


R = F(1, 250)
C = F(51, 100)
WALL = [F(4), F(51, 25), F(201, 100), F(2009, 1000), F(20083, 10000), F(200823, 100000)]
NEIGHBOR = [
    F(1004, 125), F(83, 20), F(1013, 250), F(81, 20),
    F(40495, 10000), F(404946, 100000), F(4049453, 1000000),
]


def q(x):
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def permutation_radius_receipt():
    aggregate = Counter()
    maximum = 0
    patterns = 0
    for p in permutations(range(5)):
        holes = {(x, p[x]) for x in range(5)}
        occupied = {(x, y) for x in range(5) for y in range(5)} - holes
        boundary = {v for v in occupied if 0 in v or 4 in v}
        distance = {v: 0 for v in boundary}
        todo = deque(boundary)
        while todo:
            x, y = todo.popleft()
            for w in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
                if w in occupied and w not in distance:
                    distance[w] = distance[(x, y)] + 1
                    todo.append(w)
        assert len(distance) == 20
        maximum = max(maximum, max(distance.values()))
        aggregate.update(distance.values())
        patterns += 1
    return patterns, maximum, aggregate


def main():
    patterns, maximum, aggregate = permutation_radius_receipt()
    E = WALL[-1] + 2 * NEIGHBOR[-1]
    coefficient = 8 * E + 5 * E * E
    receipt = {
        "claim": "5-S <= (28888089776/48828125) r^2 < 591.63 r^2",
        "scope": "permutation-vacancy near-grid case, freely independently rotated",
        "r_max": q(R),
        "taylor_quadratic_majorant": q(C),
        "vacancy_permutations": patterns,
        "occupied_sites_checked": sum(aggregate.values()),
        "aggregate_boundary_distances": {str(k): aggregate[k] for k in sorted(aggregate)},
        "max_occupied_steps_to_boundary": maximum,
        "wall_majorants": [q(x) for x in WALL],
        "neighbor_majorants": [q(x) for x in NEIGHBOR],
        "global_angle_constant": q(E),
        "exact_side_deficit_coefficient": q(coefficient),
        "advertised_decimal_constant": "591.63",
        "attribution": {
            "research_direction": "Joost de Winter",
            "ai_author": "GPT6.2 Astra",
        },
    }
    print(json.dumps(receipt, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

