#!/usr/bin/env python3
"""Independent exact checker for receipt.json and its 120 finite cases."""

from collections import Counter
from fractions import Fraction as F
from itertools import permutations
import json
import sys


def frac(s):
    return F(str(s))


def finite_check():
    totals = Counter()
    worst = 0
    count = 0
    for p in permutations((0, 1, 2, 3, 4)):
        missing = frozenset((column, p[column]) for column in range(5))
        vertices = frozenset((x, y) for x in range(5) for y in range(5) if (x, y) not in missing)
        frontier = {v for v in vertices if v[0] in (0, 4) or v[1] in (0, 4)}
        levels = {v: 0 for v in frontier}
        layer = 0
        while frontier:
            next_frontier = set()
            for x, y in frontier:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    w = (x + dx, y + dy)
                    if w in vertices and w not in levels:
                        levels[w] = layer + 1
                        next_frontier.add(w)
            layer += 1
            frontier = next_frontier
        assert len(levels) == len(vertices) == 20
        worst = max(worst, max(levels.values()))
        totals.update(levels.values())
        count += 1
    return count, worst, totals


def main(path):
    with open(path, "r", encoding="utf-8") as handle:
        data = json.load(handle)

    R = F(1, 250)
    C = F(51, 100)
    assert frac(data["r_max"]) == R
    assert frac(data["taylor_quadratic_majorant"]) == C

    # Taylor coefficient: 1/2 + x/6 <= 38/75 < 51/100 for x <= 1/25.
    assert F(1, 2) + F(1, 25) / 6 == F(38, 75) < C

    wall = [frac(x) for x in data["wall_majorants"]]
    assert wall == [F(4), F(51, 25), F(201, 100), F(2009, 1000), F(20083, 10000), F(200823, 100000)]
    for old, new in zip(wall, wall[1:]):
        assert new >= 2 + C * old ** 2 * R
    assert wall[0] * R <= F(1, 25)

    neighbor = [frac(x) for x in data["neighbor_majorants"]]
    assert neighbor == [F(1004, 125), F(83, 20), F(1013, 250), F(81, 20), F(40495, 10000), F(404946, 100000), F(4049453, 1000000)]
    assert neighbor[0] == 8 + 8 * R
    for old, new in zip(neighbor, neighbor[1:]):
        assert new >= 4 + 4 * R + C * old ** 2 * R
    assert neighbor[0] * R <= F(1, 25)

    # Squaring verifies the Euclidean-distance majorant for every r >= 0.
    # (1+2r+2r^2)^2 - ((1+2r)^2+(2r)^2) = 8r^3+4r^4.
    assert 8 * R ** 3 + 4 * R ** 4 >= 0

    patterns, worst, totals = finite_check()
    assert patterns == data["vacancy_permutations"] == 120
    assert worst == data["max_occupied_steps_to_boundary"] == 2
    asserted_totals = {int(k): int(v) for k, v in data["aggregate_boundary_distances"].items()}
    assert dict(sorted(totals.items())) == asserted_totals
    assert sum(totals.values()) == data["occupied_sites_checked"] == 2400

    E = wall[-1] + worst * neighbor[-1]
    assert E == frac(data["global_angle_constant"]) == F(157924, 15625)
    assert E * R < F(1, 20)
    coefficient = 8 * E + 5 * E ** 2
    assert coefficient == frac(data["exact_side_deficit_coefficient"]) == F(28888089776, 48828125)
    assert coefficient < frac(data["advertised_decimal_constant"]) == F(59163, 100)
    assert data["attribution"]["research_direction"] == "Joost de Winter"
    assert data["attribution"]["ai_author"] == "GPT6.2 Astra"
    print("PASS: exact 591.63 near-grid turning-chain certificate")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: verify_turning_chain.py receipt.json")
    main(sys.argv[1])

