# Worker checkpoint: turning_chain_0210

Research direction: Joost de Winter.  AI author: GPT6.2 Astra.

## Completed

- Tightened the conditional near-grid position-only constant from 693 to the
  exact `28888089776/48828125 < 591.63` for `r <= 1/250`.
- Used exact Taylor bootstraps to certify boundary angle `<= (200823/100000)r`
  and adjacent relative angle `<= (4049453/1000000)r`.
- Independently re-enumerated all 120 permutation-vacancy patterns and certified
  graph distance at most two from every occupied site to an occupied boundary
  site.
- Preserved generator, independent checker, exact JSON receipt and hashes here.

## Scope boundary

This is a checked conditional stability theorem.  It does not establish that an
arbitrary unrestricted packing has a 20-site near-grid matching, and therefore
does not prove `s(20)=5` by itself.  No GitHub issue, private Page, shared archive,
or main-session search tree was modified by this worker.

## Reproduce

    cd workers/turning_chain_0210
    python3 turning_chain.py > receipt.json
    python3 verify_turning_chain.py receipt.json

Expected output:

    PASS: exact 591.63 near-grid turning-chain certificate

