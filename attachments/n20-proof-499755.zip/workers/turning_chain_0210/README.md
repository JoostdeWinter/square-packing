# Exact tightening of the near-grid turning chain

Research direction: Joost de Winter.  AI author: GPT6.2 Astra.

## Result

Use the hypotheses and notation of `geometry/near_grid.md`.  Thus 20 unit-square
centres are within coordinate distance `r` of 20 distinct sites of the aligned
5 by 5 grid, all squares are contained in a board of side `S <= 5`, and the
missing sites form a permutation whenever no grid row or column is full.

For

    0 <= r <= 1/250,

the freely and independently rotated squares satisfy the stronger exact bound

    5 - S <= (28888089776/48828125) r^2 < 591.63 r^2.

This replaces the constant 693 in the position-only corollary of
`geometry/near_grid.md`.  It is still a local/conditional result: it does not
prove that an arbitrary packing near side 5 has the required grid-site matching.

## Analytic proof

Angles are reduced modulo 90 degrees to `[0, pi/4]`.  Put

    f(x) = cos(x) + sin(x) - 1.

Concavity gives `f(x) >= x/2` throughout this interval.  One completely
elementary endpoint check is

    f(pi/4) - pi/8 = sqrt(2) - 1 - pi/8 > 7/5 - 1 - (22/7)/8 > 0,

and the function on the left is concave, with value zero at zero.  Once
`x <= 1/25`, the alternating Taylor bounds give

    f(x) >= x - x^2/2 - x^3/6
         >= x - (51/100) x^2.                         (1)

### Boundary tile

For an occupied boundary grid site, wall containment gives `f(theta) <= 2r`.
The coarse inequality first gives `theta <= 4r <= 1/25`.  If a current bound is
`theta <= M r`, (1) improves it to

    theta <= (2 + (51/100) M^2 (1/250)) r.

The following exact majorants are successive valid iterates:

    4, 51/25, 201/100, 2009/1000, 20083/10000, 200823/100000.

Consequently every occupied boundary-site tile has

    theta <= (200823/100000) r.                       (2)

### Adjacent tiles

Two centres assigned to horizontally or vertically adjacent sites are at
distance at most

    sqrt((1+2r)^2 + (2r)^2) <= 1 + 2r + 2r^2.

The separating-axis theorem therefore gives, for their relative reduced angle
`d`,

    (1 + cos(d) + sin(d))/2 <= 1 + 2r + 2r^2,

or `f(d) <= 4r + 4r^2`.  The coarse inequality gives

    d <= (8 + 8/250)r = (1004/125)r < 1/25.

If `d <= D r`, (1) improves it to

    d <= (4 + 4/250 + (51/100) D^2 (1/250)) r.

Successive exact majorants are

    1004/125, 83/20, 1013/250, 81/20,
    40495/10000, 404946/100000, 4049453/1000000.

Thus every occupied grid-adjacent pair has

    d <= (4049453/1000000) r.                         (3)

### Propagation and side deficit

For each of the 120 permutation-vacancy patterns, the exhaustive checker below
confirms that every occupied site is connected to an occupied boundary site by
at most two occupied grid-adjacent steps.  Equations (2) and (3) imply that every
tile tilt is at most

    e <= (200823/100000 + 2(4049453/1000000))r
      = (157924/15625)r.

At `r <= 1/250`, this is below `1/20`, so the already checked turning-chain
theorem in `geometry/near_grid.md` applies:

    5 - S <= 8 r e + 5 e^2
          <= (8(157924/15625) + 5(157924/15625)^2) r^2
           = (28888089776/48828125) r^2
           < 591.63 r^2.

All numerical comparisons in this proof are checked over exact rationals by
`verify_turning_chain.py`; the combinatorial radius-two statement is recomputed
independently there rather than trusted from the generated receipt.

## Reproduction

Run from this directory:

    python3 turning_chain.py > receipt.json
    python3 verify_turning_chain.py receipt.json

Expected final line:

    PASS: exact 591.63 near-grid turning-chain certificate

