#!/usr/bin/env python3
"""Exact symbolic/rational checker for the four-lane gap theorem."""

from fractions import Fraction as F
from itertools import product
import json
import sys

import sympy as sp


def Q(value):
    return F(str(value))


def main(path):
    with open(path, "r", encoding="utf-8") as handle:
        receipt = json.load(handle)

    e = Q(receipt["angle_cap_radians"])
    a_max = Q(receipt["a_upper_bound"])
    ell_min = Q(receipt["unit_chord_length_lower_bound"])
    six_min = Q(receipt["six_interval_length_lower_bound"])
    assert e == F(1, 20)
    assert (1 + e) * e == a_max == F(21, 400)
    assert 1 - a_max == ell_min == F(379, 400)
    assert 6 * ell_min == six_min == F(1137, 200) > 5

    # With at most four lanes and at most five tiles per lane, the only way to
    # hold all twenty tiles is the exact 5+5+5+5 distribution.
    distributions = [v for v in product(range(6), repeat=4) if sum(v) == 20]
    assert distributions == [(5, 5, 5, 5)]
    assert receipt["maximum_lanes"] == 4
    assert receipt["tiles"] == 20
    assert receipt["tiles_per_lane"] == 5

    # Uniform lane sums yield a distinct 20-site 5x5-grid matching.
    r_uniform = 5 * (1 + e) * e
    assert r_uniform == F(21, 80)
    assert 8 * r_uniform * r_uniform == Q(receipt["same_site_distance_squared_bound_at_e_1_20"])
    assert 8 * r_uniform * r_uniform == F(441, 800) < 1
    assert receipt["grid_matching_error_bound"] == "5(1+e)e"

    refined_e = Q(receipt["refined_tilt_cap"])
    refined_r = 5 * (1 + refined_e) * refined_e
    refined_K = Q(receipt["refined_side_coefficient"])
    assert refined_e == F(1, 1020)
    assert refined_r == Q(receipt["refined_radius_at_cap"]) == F(1021, 208080)
    assert refined_r < Q(receipt["refined_radius_limit"]) == F(1, 203)
    assert refined_K == F(29716073741801, 50000000000)
    assert refined_K * refined_r * refined_r == Q(receipt["side_deficit_at_refined_tilt_cap"])

    u = sp.symbols("u", real=True)
    cs = (u**2 - 1) / 2
    ell = u - 2 * cs
    a = 1 - ell
    inside_area = 1 - cs
    excess_area = inside_area - ell
    assert sp.expand(ell - (1 + u - u**2)) == 0
    assert sp.expand(a - u * (u - 1)) == 0
    assert sp.expand(excess_area - (u - 1)**2 / 2) == 0
    assert receipt["slice_cap_area"] == "(u^2-1)/2"
    assert receipt["slice_excess_area"] == "(u-1)^2/2"

    # Formal coefficient check behind each five-tile lane:
    # sum(1-a_i) <= 5-delta iff sum(a_i) >= delta.
    delta, asum = sp.symbols("delta asum", nonnegative=True)
    assert sp.expand((5 - delta) - (5 - asum) - (asum - delta)) == 0

    assert receipt["attribution"] == {
        "research_direction": "Joost de Winter",
        "ai_author": "GPT6.2 Astra",
    }
    print("PASS: four-lane chord-gap conservation certificate")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: verify_gap.py receipt.json")
    main(sys.argv[1])

