# Four-lane unit-chord gap conservation

Research direction: Joost de Winter. AI author: GPT6.2 Astra.

## Theorem

Let 20 freely translated and independently rotated unit squares fit in a board
of side

    S = 5-delta < 5,

and suppose every reduced tile angle `phi_i` lies in `[0,1/20]` radians.  Put

    u_i = cos(phi_i)+sin(phi_i),
    a_i = u_i(u_i-1).

For each of the two board axes, the tiles admit a partition into four lanes of
exactly five tiles such that the five corresponding unit-chord intervals have
pairwise disjoint interiors.  Every lane `C` satisfies the exact conservation
inequality

    sum(i in C) a_i >= delta.                         (1)

Thus there are two, generally different, orthogonal partitions of the 20 tiles
into five-step chains, and all eight chains individually carry at least the
whole side deficit.  Summing either partition recovers

    sum_i a_i >= 4 delta,

but (1) is strictly more structural than the aggregate inequality.

If the five intervals of a lane are ordered along the axis and `z_k` is the
coordinate of the centre of its `k`-th tile, then, with

    A_C = sum(i in C) a_i,

one also has

    |z_k-(k-1/2)| <= A_C,  k=1,...,5.                (2)

Ranking a tile in its two orthogonal lanes assigns it a site of the aligned
5 by 5 grid.  These 20 assigned sites are distinct, and every tile centre is
within coordinate distance

    r_e = 5(1+e)e                                    (3)

of its site when every reduced tilt is at most `e<=1/20`.  Thus the theorem
supplies an exact bridge from uniform small independent tilts and arbitrary
translations to a 20-site near-grid matching.  It is a necessary endpoint
structure, not by itself a proof of `s(20)=5`.

## Proof

Fix one board axis and slice perpendicular to it.  For a tile of angle `phi`,
write `c=cos(phi)`, `s=sin(phi)`, `u=c+s`.  The set `J` of slice coordinates
where the tile chord has length at least one is a centred interval of length

    ell = u-2cs = 1+u-u^2 = 1-a.                    (3)

The open interiors of five such intervals cannot share a coordinate.  At such
a coordinate the interiors of five tiles would cut five pairwise
interior-disjoint open chords, each of length at least one, from a board segment
of length strictly below five.  Hence the interval family has depth at most
four.  The interval graph is therefore four-colourable; equivalently, the
intervals split into at most four lanes with pairwise disjoint interiors.

The small-angle hypothesis gives, using `cos(phi)<=1` and `sin(phi)<=phi`,

    a = u(u-1) <= (1+phi)phi <= 21/400,
    ell >= 379/400.

Six intervals in one lane would have total length at least
`6(379/400)=1137/200>5>=S`, impossible.  Thus each lane has at most five tiles.
Twenty tiles in at most four lanes force exactly four lanes of exactly five.

For a lane `C`, disjointness and board containment give

    sum ell_i <= S.

Using (3) and `|C|=5` gives

    5-sum a_i <= 5-delta,

which is (1).  This proof uses open interval interiors, so wall contacts,
tile contacts, coincident interval endpoints and horizontal/vertical tiles are
all included without a general-position assumption.

For (2), let `g_0,...,g_5` be the nonnegative wall and inter-interval gaps in
an ordered lane.  Their sum is

    sum g_j = S-sum ell_i = A_C-delta <= A_C.

The exact centre formula is

    z_k-(k-1/2)
      = (g_0+...+g_{k-1})
        -(a_1+...+a_{k-1}+a_k/2).

Both the positive and negative parts have magnitude at most `A_C`, proving
(2).  Repeating after turning the board by 90 degrees gives the second
partition.  Under a uniform cap `e`, every lane has

    A_C <= 5(1+e)e,

which proves the coordinate error (3).  If two tiles received the same pair
of ranks, their centre distance would be at most `2 sqrt(2) r_e`.  At the
largest allowed cap, `r_e<=21/80` and

    (2 sqrt(2) r_e)^2 <= 8(21/80)^2 = 441/800 < 1.

But every unit square contains the open disk of radius `1/2` about its centre,
so two interior-disjoint tiles have centre distance at least one.  The rank
pairs, hence the grid sites, are therefore distinct.

## Second-order endpoint corollary

Combining this matching with the independently checked refined near-grid
turning-chain certificate gives, whenever

    e <= 1/1020,

the exact implication

    r_e <= 1021/208080 < 1/203,
    5-S <= (29716073741801/50000000000)[5(1+e)e]^2. (4)

At the endpoint value `e=1/1020`, the right side of (4) is exactly

    1822191389851575073/127344960000000000000

(about `0.0143091`).  More importantly, (4) is a rationally checked quadratic
stability law for arbitrary translations and independently varying small
tilts; it is not restricted to a pre-supplied grid matching.

## Additional exact slice identities

The two caps outside `J` have total area `cs=(u^2-1)/2`.  The area inside `J`
is `1-cs`, and its chord-length excess over the baseline unit interval is

    integral_J (chord-1) = (u-1)^2/2.

The checker verifies all algebraic identities and every rational comparison.

## Reproduce

    python3 verify_gap.py receipt.json

Expected output:

    PASS: four-lane chord-gap conservation certificate

