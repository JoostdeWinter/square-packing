# Translated-lattice fourfold cover from a strict sub-5 packing

Research direction by Joost de Winter. AI author GPT6.2 Astra.

## Checked unrestricted statement

The argument has a general form.  If `N` unit squares fit in side `S<k+1`,
scale their centers to a board of side `k+1` and put

    rho = (k+1-S)/S.

Only the `k^2` inner sites of every lattice translate in the central `rho` by
`rho` window can meet a tile.  The `N` periodic miss regions therefore cover
that window to depth at least `N-k^2`.  Consequently

    sum_i min((u_i-1)^2,rho^2) >= (N-k^2) rho^2.

This is nontrivial when `N>k^2`.

Suppose twenty independently translated and rotated unit squares with pairwise
disjoint interiors fit in a square of side `S<5`.  Put

    rho = (5-S)/S.

Scale all centers by `5/S` into a board of side 5, while restoring every tile
to unit size and preserving its orientation.  For every translation `t` in
the open square

    T = (-rho/2,rho/2)^2,

at least four of the twenty tiles miss the entire translated lattice
`Z^2+t`.  Equivalently, the twenty periodic miss regions in lattice-phase
space form a fourfold cover of `T`.

If `phi_i` is tile `i`'s reduced angle and
`u_i=cos(phi_i)+sin(phi_i)`, then its miss region has area
`(u_i-1)^2` per unit lattice cell.  Integration over `T` gives the exact
necessary conditions

    sum_i min((u_i-1)^2,rho^2) >= 4 rho^2,
    sum_i (u_i-1)^2 >= 4 rho^2.

In particular, at least four tiles are non-axis-aligned.  These conclusions
allow independent rotations, arbitrary non-lattice centers, original tile and
wall contacts, lattice points on tile boundaries, and every translated-grid
degeneracy.  They are necessary conditions and do not prove `s(20)=5`.

## Uniform margin after scaling

Let `lambda=5/S`.  In a board coordinate direction, a tile with projection
width `w>=1` originally has its center at least `w/2` from each wall.  After
scaling the center and restoring unit size, its wall margin is at least

    (lambda-1) w/2 >= (lambda-1)/2 = rho/2.

For any pair of original tiles, the separating-axis inequality is non-strict.
Scaling their center difference by `lambda>1`, while leaving both support
functions unchanged, makes one such inequality strict.  Thus the restored
closed tiles have positive pairwise separation.

For `t in T`, every lattice line adjacent to a board wall stays outside every
restored tile.  The only lattice sites that a tile can meet are therefore the
sixteen sites `(i+t_x,j+t_y)` with `i,j in {1,2,3,4}`.  Positive separation
means that one site cannot belong to two tiles, even on boundaries.  At most
sixteen tiles meet the lattice, so at least four miss it.

## Exact phase area of one tile

For a non-axis tile write `c=cos(phi)`, `s=sin(phi)` and `u=c+s`.  Modulo the
integer lattice, the phases for which the closed tile misses every lattice
point form an open square of side `u-1`, oriented with the tile.  Hence the
area is `(u-1)^2`.  At an axis angle this area is zero.

One exact check uses lattice-point multiplicity.  A non-axis unit square
contains zero, one or two lattice points; a two-point set is one horizontal or
vertical neighboring pair.  A random lattice phase has expected multiplicity
one, so the zero-point and two-point phase areas agree.  Each neighbor-pair
region has area `(1-c)(1-s)`, and there are two directions.  The identity

    2(1-c)(1-s) = (c+s-1)^2

follows from `c^2+s^2=1`.  The explicit miss square already has that area, so
there is no additional component.

Now integrate the number of missed tiles over `T`.  Its integral is at least
`4 area(T)=4 rho^2`.  Tile `i` contributes at most both `area(T)=rho^2` and
its full phase area `(u_i-1)^2`.  Summing these upper bounds proves the capped
inequality and its uncapped consequence.

## Reproduction

Run from this directory:

    python3 translated_lattice.py --output translated_lattice_receipt.json
    python3 verify_translated_lattice.py translated_lattice_receipt.json

The receipt specializes the general theorem to `N=20`, `k=4` at sides 4.95
through 4.99.  All certified quantities are exact fractions.  The checker is
separately written and also
checks the phase-area identity on exact rational Pythagorean orientations.

## Use in the remaining endpoint search

The important output is the pointwise fourfold cover, not only its area
corollary.  Every candidate strict-side packing induces twenty small oriented
phase squares that must cover the central `rho` by `rho` translation window
at depth four.  This can be added as a complementary branch condition to an
endpoint pose or SMT search without assuming a common lattice, a common tile
angle, or generic position.

