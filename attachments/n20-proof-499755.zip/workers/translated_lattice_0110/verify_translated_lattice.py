#!/usr/bin/env python3
"""Independent exact checker for translated_lattice_receipt.json."""

from __future__ import annotations

import json
import sys
from fractions import Fraction
from pathlib import Path


def frac(text: str) -> Fraction:
    a, b = text.split("/")
    return Fraction(int(a), int(b))


def add(*polys: dict[tuple[int, int], int]) -> dict[tuple[int, int], int]:
    out: dict[tuple[int, int], int] = {}
    for poly in polys:
        for monomial, coefficient in poly.items():
            out[monomial] = out.get(monomial, 0) + coefficient
    return {m: a for m, a in out.items() if a}


def multiply(
    left: dict[tuple[int, int], int], right: dict[tuple[int, int], int]
) -> dict[tuple[int, int], int]:
    out: dict[tuple[int, int], int] = {}
    for (i, j), a in left.items():
        for (k, ell), b in right.items():
            monomial = (i + k, j + ell)
            out[monomial] = out.get(monomial, 0) + a * b
    return {m: a for m, a in out.items() if a}


def poly_scale(poly: dict[tuple[int, int], int], factor: int):
    return {m: factor * a for m, a in poly.items() if factor * a}


def main() -> None:
    data = json.loads(Path(sys.argv[1]).read_text())
    assert data["arithmetic"] == "exact fractions"
    rows = data["rows"]
    assert len(rows) == 5
    previous = Fraction(0)
    for row in rows:
        side = frac(row["side"])
        scale = frac(row["scale_to_five"])
        margin = frac(row["uniform_wall_margin_at_least"])
        rho = frac(row["translation_window_side"])
        area = frac(row["translation_window_area"])
        integrated = frac(row["integrated_miss_measure_at_least"])
        squared = frac(row["sum_squared_tilt_width_at_least"])
        assert previous < side < 5
        previous = side
        assert scale == 5 / side > 1
        assert rho == (5 - side) / side == scale - 1
        assert margin == rho / 2
        assert area == rho * rho
        assert row["pointwise_missed_tiles_at_least"] == 4
        assert integrated == squared == 4 * area

    # Symbolically expand the exact phase-area identity.  The difference is
    # 1-c^2-s^2 and therefore vanishes on the unit circle.
    one = {(0, 0): 1}
    cpoly = {(1, 0): 1}
    spoly = {(0, 1): 1}
    left = poly_scale(
        multiply(add(one, poly_scale(cpoly, -1)), add(one, poly_scale(spoly, -1))), 2
    )
    right = multiply(
        add(cpoly, spoly, poly_scale(one, -1)),
        add(cpoly, spoly, poly_scale(one, -1)),
    )
    assert add(left, poly_scale(right, -1)) == {
        (0, 0): 1,
        (2, 0): -1,
        (0, 2): -1,
    }

    # Also evaluate it at independent rational Pythagorean angles.
    # c^2+s^2=1 and 0<c,s<1 imply two neighbor-pair regions of total
    # area 2(1-c)(1-s), equal to the square miss region (c+s-1)^2.
    for c, s in [
        (Fraction(3, 5), Fraction(4, 5)),
        (Fraction(5, 13), Fraction(12, 13)),
        (Fraction(20, 29), Fraction(21, 29)),
    ]:
        assert c * c + s * s == 1 and 0 < c < 1 and 0 < s < 1
        pair_area = 2 * (1 - c) * (1 - s)
        miss_area = (c + s - 1) ** 2
        assert pair_area == miss_area > 0

    print(
        "PASS: 5 strict sides; exact margin, fourfold integral, and phase-area identities verified"
    )


if __name__ == "__main__":
    main()

