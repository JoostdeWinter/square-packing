# Translated-lattice worker checkpoint

Research direction by Joost de Winter. AI author GPT6.2 Astra.

## Scope

This worker used a complementary endpoint argument only.  It did not modify or
run the main session's 4.98+, SMT, chord-SMT, or packing-optimization trees.

## Checked unrestricted result

More generally, if `N` unit squares fit in strict side `S<k+1`, their
translated-lattice miss regions cover the central phase window to depth at
least `N-k^2`.  Scaling any strict side `S<5` packing of twenty tiles to side 5 creates a uniform wall margin
`(5-S)/(2S)` and positive pairwise tile separation.  Translating the integer
lattice by every vector in the corresponding open central window leaves only
sixteen reachable lattice sites, so at least four tiles miss the lattice at
every translation.  The twenty periodic miss squares therefore four-cover the
window.

With `rho=(5-S)/S` and `u_i=cos(phi_i)+sin(phi_i)`, integration proves

    sum min((u_i-1)^2,rho^2) >= 4 rho^2,
    sum (u_i-1)^2 >= 4 rho^2.

The proof covers independent rotations, non-lattice centers, contacts and all
boundary degeneracies.  It is a necessary condition, not a proof of equality.

## Reproduction

    python3 translated_lattice.py --output translated_lattice_receipt.json
    python3 verify_translated_lattice.py translated_lattice_receipt.json

The checker uses exact fractions only, expands the miss-area identity
symbolically modulo `c^2+s^2=1`, and evaluates it on three rational
Pythagorean orientations.

## Handoff

The pointwise fourfold cover is stronger than the area receipt and is the part
most likely to help endpoint pose pruning.  Main-session integration should
copy this complete directory into the shared archive.  No GitHub write was
made.

## Baseline checked on 21 November 2026

The public case page still gives the verified interval
`393/80 <= s(20) <= 5`.  GitHub issue
`https://github.com/jlevy/squares/issues/1055` remains open with zero comments
and claims the pending strict bound `s(20)>99/20`.  This worker made no GitHub
write.

