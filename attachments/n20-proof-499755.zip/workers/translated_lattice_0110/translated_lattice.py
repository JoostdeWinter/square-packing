#!/usr/bin/env python3
"""Exact receipt for translated-lattice averaging below side five.

Research direction: Joost de Winter.
AI author: GPT6.2 Astra.
"""

from __future__ import annotations

import argparse
import json
from fractions import Fraction
from pathlib import Path


SIDES = (
    Fraction(99, 20),
    Fraction(124, 25),
    Fraction(497, 100),
    Fraction(249, 50),
    Fraction(499, 100),
)


def ftext(x: Fraction) -> str:
    return f"{x.numerator}/{x.denominator}"


def row(side: Fraction) -> dict[str, object]:
    rho = (5 - side) / side
    margin = rho / 2
    area = rho * rho
    return {
        "side": ftext(side),
        "scale_to_five": ftext(Fraction(5, 1) / side),
        "uniform_wall_margin_at_least": ftext(margin),
        "translation_window_side": ftext(rho),
        "translation_window_area": ftext(area),
        "pointwise_missed_tiles_at_least": 4,
        "integrated_miss_measure_at_least": ftext(4 * area),
        "sum_squared_tilt_width_at_least": ftext(4 * area),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output", type=Path, default=Path("translated_lattice_receipt.json")
    )
    args = parser.parse_args()
    receipt = {
        "theorem": (
            "If N unit squares fit in strict side S<k+1, their translated-lattice "
            "miss regions (N-k^2)-cover the central phase square of side "
            "rho=(k+1-S)/S."
        ),
        "specialization": "N=20, k=4",
        "area_corollary": (
            "With u_i=cos(phi_i)+sin(phi_i) and rho=(5-S)/S, "
            "sum min((u_i-1)^2,rho^2)>=4rho^2."
        ),
        "arithmetic": "exact fractions",
        "rows": [row(side) for side in SIDES],
        "attribution": {
            "research_direction": "Joost de Winter",
            "ai_author": "GPT6.2 Astra",
        },
    }
    args.output.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()

