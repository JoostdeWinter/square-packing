#!/usr/bin/env python3
"""Generate exact refined turning-chain data without floating point."""

from collections import Counter, deque
from fractions import Fraction as F
from itertools import permutations
import json


REGIMES = {
    "r250": {
        "R": F(1, 250),
        "wall": [F(4), F(51, 25), F(2009, 1000), F(10041, 5000), F(12551, 6250), F(251019, 125000)],
        "adjacent": [F(1004, 125), F(83, 20), F(4051, 1000), F(10123, 2500), F(80983, 20000), F(4049143, 1000000)],
    },
    "r203": {
        "R": F(1, 203),
        "wall": [F(4), F(51, 25), F(2011, 1000), F(20101, 10000), F(201009, 100000), F(502521, 250000)],
        "adjacent": [F(1632, 203), F(419, 100), F(508, 125), F(4061, 1000), F(406087, 100000), F(4060859, 1000000)],
    },
}


def q(x):
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def enumerate_patterns():
    by_radius = Counter()
    aggregate = Counter()
    for p in permutations(range(5)):
        holes = {(x, p[x]) for x in range(5)}
        occupied = {(x, y) for x in range(5) for y in range(5)} - holes
        boundary = {v for v in occupied if v[0] in (0, 4) or v[1] in (0, 4)}
        distance = {v: 0 for v in boundary}
        todo = deque(boundary)
        while todo:
            x, y = todo.popleft()
            for w in ((x-1, y), (x+1, y), (x, y-1), (x, y+1)):
                if w in occupied and w not in distance:
                    distance[w] = distance[(x, y)] + 1
                    todo.append(w)
        assert len(distance) == 20
        by_radius[max(distance.values())] += 1
        aggregate.update(distance.values())
    return by_radius, aggregate


def regime_receipt(spec):
    R = spec["R"]
    D0 = 8 + 8 * R
    C = F(1, 2) + D0 * R / 6
    wall = spec["wall"]
    adjacent = spec["adjacent"]
    E1 = wall[-1] + adjacent[-1]
    E2 = wall[-1] + 2 * adjacent[-1]
    K1 = 8 * E1 + 5 * E1 * E1
    K2 = 8 * E2 + 5 * E2 * E2
    return {
        "radius_cap": q(R),
        "initial_adjacent_constant": q(D0),
        "taylor_coefficient": q(C),
        "wall_majorants": [q(x) for x in wall],
        "adjacent_majorants": [q(x) for x in adjacent],
        "one_step_angle_constant": q(E1),
        "two_step_angle_constant": q(E2),
        "one_step_side_coefficient": q(K1),
        "two_step_side_coefficient": q(K2),
    }


def main():
    by_radius, aggregate = enumerate_patterns()
    out = {
        "claim": "uniform r<=1/203 coefficient <594.33; r<=1/250 coefficient <591.56",
        "vacancy_permutations": sum(by_radius.values()),
        "patterns_by_max_boundary_distance": {str(k): by_radius[k] for k in sorted(by_radius)},
        "aggregate_boundary_distances": {str(k): aggregate[k] for k in sorted(aggregate)},
        "regimes": {name: regime_receipt(spec) for name, spec in REGIMES.items()},
        "attribution": {"research_direction": "Joost de Winter", "ai_author": "GPT6.2 Astra"},
    }
    print(json.dumps(out, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

