# Refined near-grid turning-chain certificate

Research direction: Joost de Winter. AI author: GPT6.2 Astra.

## Checked result

Under the hypotheses of `geometry/near_grid.md` (20 independently rotated unit
squares, centres coordinatewise within `r` of 20 distinct sites of the aligned
5 by 5 grid, and board side `S <= 5`), the position-only corollary is strengthened
in two ways:

1. For `r <= 1/250`,

       5-S <= (29577597461961/50000000000) r^2 < 591.56 r^2.

2. The certified radius extends to `r <= 1/203`, where

       5-S <= (29716073741801/50000000000) r^2 < 594.33 r^2.

The previous checked statements were `693 r^2` at radius `1/250`, followed by
the first refinement `591.63 r^2` at the same radius.  The new certificate both
tightens the small-radius coefficient and enlarges the radius by a factor
`250/203`.

This remains a conditional stability theorem.  It does not prove that every
unrestricted packing below side 5 has a matching to these 20 grid sites.

## Proof

Reduce each tilt modulo 90 degrees to `[0,pi/4]` and set

    f(x)=cos(x)+sin(x)-1.

As in the prior certificate, concavity gives `f(x)>=x/2` on this interval.  If
`x<=X`, Taylor's inequalities give the sharper adaptive estimate

    f(x) >= x-x^2/2-x^3/6
         >= x-(1/2+X/6)x^2.                         (1)

For a radius cap `R`, a boundary-site tile first satisfies `theta<=4r`, while
two occupied adjacent-site tiles first satisfy

    d <= (8+8R)r.

Both initial angles are at most `X=(8+8R)R`.  This is below `1/25` for both
`R=1/250` and `R=1/203`.  We may therefore take the exact coefficient

    C_R = 1/2 + (8+8R)R/6.

The wall and adjacent-pair bootstraps are respectively

    M_new = 2+ C_R M_old^2 R,
    D_new = 4+4R + C_R D_old^2 R.                   (2)

The JSON receipt records a finite exact-rational chain of majorants for (2).
Its endpoints are:

| Radius cap | Wall `M` | Adjacent `D` | `M+2D` |
| --- | ---: | ---: | ---: |
| `1/250` | `251019/125000` | `4049143/1000000` | `5053219/500000` |
| `1/203` | `502521/250000` | `4060859/1000000` | `5065901/500000` |

The finite checker independently enumerates all 120 permutation-vacancy
patterns.  In 102 patterns every occupied site is within two occupied
grid-adjacent steps of an occupied boundary site; in the other 18, one step
suffices.  Thus the worst absolute tilt is at most `(M+2D)r`.  For `R=1/203`,

    (5065901/500000)(1/203) < 1/20,

so the hypotheses `r,e<=1/20` of the turning-chain theorem in
`geometry/near_grid.md` are discharged.  Substitution in

    5-S <= 8re+5e^2

gives the two displayed coefficients.  The 18 one-step patterns separately
obey coefficients below `231.92` at radius `1/250` and below `232.85` at radius
`1/203`; these pattern-specific improvements are recorded but are not needed
for the uniform theorem.

## Reproduce

    python3 generate_refined.py
    python3 verify_refined.py receipt.json

Expected checker output:

    PASS: refined near-grid radius and coefficient certificate

