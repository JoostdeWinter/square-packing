#!/usr/bin/env python3
"""Independent rational and finite-case verification of the refined receipt."""

from collections import Counter
from fractions import Fraction as F
from itertools import permutations
import json
import sys


def Q(value):
    return F(str(value))


EXPECTED = {
    "r250": {
        "R": F(1, 250),
        "wall": [F(4), F(51, 25), F(2009, 1000), F(10041, 5000), F(12551, 6250), F(251019, 125000)],
        "adjacent": [F(1004, 125), F(83, 20), F(4051, 1000), F(10123, 2500), F(80983, 20000), F(4049143, 1000000)],
        "limit": F(59156, 100),
        "coefficient": F(29577597461961, 50000000000),
    },
    "r203": {
        "R": F(1, 203),
        "wall": [F(4), F(51, 25), F(2011, 1000), F(20101, 10000), F(201009, 100000), F(502521, 250000)],
        "adjacent": [F(1632, 203), F(419, 100), F(508, 125), F(4061, 1000), F(406087, 100000), F(4060859, 1000000)],
        "limit": F(59433, 100),
        "coefficient": F(29716073741801, 50000000000),
    },
}


def independent_pattern_counts():
    maxima = Counter()
    totals = Counter()
    for p in permutations((0, 1, 2, 3, 4)):
        vertices = {(x, y) for x in range(5) for y in range(5) if y != p[x]}
        levels = {v: 0 for v in vertices if v[0] in (0, 4) or v[1] in (0, 4)}
        frontier = set(levels)
        level = 0
        while frontier:
            nxt = set()
            for x, y in frontier:
                for dx, dy in ((1,0),(-1,0),(0,1),(0,-1)):
                    w = (x+dx, y+dy)
                    if w in vertices and w not in levels:
                        levels[w] = level + 1
                        nxt.add(w)
            frontier = nxt
            level += 1
        assert len(levels) == 20
        maxima[max(levels.values())] += 1
        totals.update(levels.values())
    return maxima, totals


def verify_regime(data, expected):
    R = Q(data["radius_cap"])
    assert R == expected["R"]
    D0 = 8 + 8 * R
    assert Q(data["initial_adjacent_constant"]) == D0
    X = D0 * R
    assert X < F(1, 25)
    C = F(1, 2) + X / 6
    assert Q(data["taylor_coefficient"]) == C

    wall = [Q(x) for x in data["wall_majorants"]]
    adjacent = [Q(x) for x in data["adjacent_majorants"]]
    assert wall == expected["wall"]
    assert adjacent == expected["adjacent"]
    assert wall[0] == 4 and adjacent[0] == D0
    for old, new in zip(wall, wall[1:]):
        assert new >= 2 + C * old * old * R
    for old, new in zip(adjacent, adjacent[1:]):
        assert new >= 4 + 4 * R + C * old * old * R

    E1 = wall[-1] + adjacent[-1]
    E2 = wall[-1] + 2 * adjacent[-1]
    assert Q(data["one_step_angle_constant"]) == E1
    assert Q(data["two_step_angle_constant"]) == E2
    assert E2 * R < F(1, 20)
    K1 = 8 * E1 + 5 * E1 * E1
    K2 = 8 * E2 + 5 * E2 * E2
    assert Q(data["one_step_side_coefficient"]) == K1
    assert Q(data["two_step_side_coefficient"]) == K2 == expected["coefficient"]
    assert K2 < expected["limit"]
    return K1


def main(path):
    with open(path, "r", encoding="utf-8") as handle:
        receipt = json.load(handle)
    maxima, totals = independent_pattern_counts()
    assert dict(sorted(maxima.items())) == {1: 18, 2: 102}
    assert dict(sorted(totals.items())) == {0: 1536, 1: 648, 2: 216}
    assert receipt["vacancy_permutations"] == 120
    assert {int(k): v for k, v in receipt["patterns_by_max_boundary_distance"].items()} == dict(maxima)
    assert {int(k): v for k, v in receipt["aggregate_boundary_distances"].items()} == dict(totals)

    k250 = verify_regime(receipt["regimes"]["r250"], EXPECTED["r250"])
    k203 = verify_regime(receipt["regimes"]["r203"], EXPECTED["r203"])
    assert k250 < F(23192, 100)
    assert k203 < F(23285, 100)
    assert receipt["attribution"] == {"research_direction": "Joost de Winter", "ai_author": "GPT6.2 Astra"}
    print("PASS: refined near-grid radius and coefficient certificate")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: verify_refined.py receipt.json")
    main(sys.argv[1])

