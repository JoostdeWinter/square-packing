#!/usr/bin/env python3
"""Exact arithmetic certificate for the unrestricted near-axis count lemma.

Research direction: Joost de Winter.
AI author: GPT6.2 Astra.

The geometric proof is in README.md.  This program checks the exact rational
thresholds used at the active sides and emits a machine-readable receipt.
No floating-point value is used to establish the inequalities.
"""

from __future__ import annotations

import argparse
import json
from fractions import Fraction
from pathlib import Path

import mpmath as mp


SIDES = (Fraction(99, 20), Fraction(124, 25), Fraction(497, 100),
         Fraction(249, 50), Fraction(499, 100))


def record(side: Fraction) -> dict[str, object]:
    assert 1 + 2 * mp.sqrt(2) < mp.mpf(side.numerator) / side.denominator < 5
    # r is the exact lower bound for c+s on at least four tiles.
    r = Fraction(4, 1) / (side - 1)
    sin_two_phi = r * r - 1
    assert 0 < sin_two_phi < 1
    mp.mp.dps = 80
    x = mp.mpf(sin_two_phi.numerator) / sin_two_phi.denominator
    phi = mp.asin(x) / 2
    return {
        "side": f"{side.numerator}/{side.denominator}",
        "side_decimal": mp.nstr(mp.mpf(side.numerator) / side.denominator, 20),
        "large_tilt_count_at_least": 4,
        "cos_plus_sin_at_least": f"{r.numerator}/{r.denominator}",
        "sin_twice_tilt_at_least":
            f"{sin_two_phi.numerator}/{sin_two_phi.denominator}",
        "tilt_radians_at_least": mp.nstr(phi, 40),
        "tilt_degrees_at_least": mp.nstr(mp.degrees(phi), 40),
    }


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--output", type=Path, default=Path("strict_axis_receipt.json"))
    args = p.parse_args()
    rows = [record(side) for side in SIDES]
    receipt = {
        "theorem": (
            "For N pairwise interior-disjoint unit squares in a board of side B, "
            "at most q^2 tiles can satisfy cos(phi)+sin(phi)<q/(B-1)."
        ),
        "specialization": (
            "For N=20, q=4 and 1+2*sqrt(2)<B<5, at least four tiles "
            "satisfy cos(phi)+sin(phi)>=4/(B-1)."
        ),
        "arithmetic": "exact fractions; decimals are display-only",
        "rows": rows,
        "attribution": {
            "research_direction": "Joost de Winter",
            "ai_author": "GPT6.2 Astra",
        },
    }
    args.output.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
