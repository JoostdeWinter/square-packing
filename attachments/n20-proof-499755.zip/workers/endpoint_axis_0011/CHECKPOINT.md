# Endpoint axis worker checkpoint

Research direction by Joost de Winter. AI author GPT6.2 Astra.

## Scope and coordination

This worker took the complementary unrestricted near-axis and near-lattice
endpoint branch.  It did not run or modify the main worker's 4.97 cold replay,
4.98 marked-case search, or trial files.

## Checked unrestricted result

For unit squares with pairwise disjoint interiors in a board of side `B`, at
most `q^2` tiles can satisfy

    cos(phi) + sin(phi) < q/(B-1),

where `phi` is the angle modulo 90 degrees in `[0,45 degrees]`.  The proof uses
only concentric board-aligned subsquares, a `q`-strip partition of the center
domain, and projection overlap.  It explicitly covers independent rotations,
non-lattice centers, tile contacts, strip-boundary degeneracies, and equality
at the final threshold.

For `N=20` and `q=4`, at least four tiles in every hypothetical packing below
side 5 must satisfy

    cos(phi) + sin(phi) >= 4/(B-1).

Exact specializations checked by two programs:

| Side | Exact `cos(phi)+sin(phi)` threshold | Minimum angle for at least four tiles |
| --- | --- | ---: |
| 4.95 | 80/79 | 0.729932280520123981 degrees |
| 4.96 | 100/99 | 0.581708176705212195 degrees |
| 4.97 | 400/397 | 0.434618150175280308 degrees |
| 4.98 | 200/199 | 0.288646787147296214 degrees |
| 4.99 | 400/399 | 0.143778996420934731 degrees |

`strict_axis_count.py` emits the exact rational receipt and
`verify_strict_axis.py` independently verifies all five rows.  Its run ended:

    PASS: 5 exact side thresholds; unrestricted count lemma receipt consistent

This is a genuine unrestricted endpoint reduction, not a proof of `s(20)=5`:
the remaining branch contains at least four sufficiently tilted tiles.

## Independent replay of the common-tilt certificates

While this worker was running, the main workspace completed the nearby exact
common-orientation certificate path.  This worker had copied the discovery
inputs before that output appeared and independently ran the symbolic
reconstruction.  Both produced a byte-identical certificate file:

    SHA-256 69d6488bef85ab0e80072958eb9ccd9f0db40f3812725b44123586cb8815560c

The copied integer-only verifier passed:

- 120 hole permutations;
- 33 rotational classes;
- 1,686 separation graphs in representatives;
- 5,685 graphs with all permutations counted;
- 41 exact polynomial duals;
- positive common half-angle tangent through `1/31`.

This replay is conditional on all 20 squares sharing that common small nonzero
tilt.  It must not be reported as an unrestricted proof.

## Baseline checked

On 21 November 2026 the public SquareMath case page still records the official
verified interval `393/80 <= s(20) <= 5`.  GitHub issue `jlevy/squares#1055`
is open with no comments and claims the pending strict bound `s(20)>99/20`.
The private workspace separately has a complete clean 4.96 replay over 53,361
ordered pairs and a closed 4.97 discovery tree; the clean 4.97 replay remains
owned by the main worker.  Nothing was posted to or modified on GitHub.

## Open cases handed forward

1. Combine the four-large-tilt lemma with the four lattice-missing tiles.  The
   two sets need not coincide, so an additional incidence argument is required.
2. Branch endpoint marked-pattern cases on at least four angles meeting the
   exact side threshold.  At 4.98 this is `sin(2 phi)>=399/39601`.
3. The near-grid stability proof still permits a quadratic side deficit and
   therefore does not close the unrestricted endpoint.
4. The exact equality `s(20)=5` remains open in this checkpoint.
