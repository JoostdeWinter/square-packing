#!/usr/bin/env python3
"""Independent exact checker for strict_axis_receipt.json."""

from __future__ import annotations

import json
import sys
from fractions import Fraction
from pathlib import Path


def frac(text: str) -> Fraction:
    a, b = text.split("/")
    return Fraction(int(a), int(b))


def main() -> None:
    data = json.loads(Path(sys.argv[1]).read_text())
    assert data["arithmetic"].startswith("exact fractions")
    seen = []
    for row in data["rows"]:
        B = frac(row["side"])
        r = frac(row["cos_plus_sin_at_least"])
        z = frac(row["sin_twice_tilt_at_least"])
        assert Fraction(4, 1) == r * (B - 1)
        assert z == r * r - 1
        assert 0 < z < 1
        assert B < 5
        assert row["large_tilt_count_at_least"] == 4
        seen.append(B)
    assert seen == sorted(seen)
    assert len(seen) == len(set(seen)) == 5
    print("PASS: 5 exact side thresholds; unrestricted count lemma receipt consistent")


if __name__ == "__main__":
    main()
