# Unrestricted near-axis endpoint lemma

Research direction by Joost de Winter. AI author GPT6.2 Astra.

## Statement

Let unit squares with pairwise disjoint interiors lie in a square board of side
`B`.  Write `phi` for a tile's angle modulo 90 degrees, reduced to
`0 <= phi <= 45 degrees`.  For every positive integer `q`, at most `q^2` tiles
can satisfy

    cos(phi) + sin(phi) < q/(B-1).

For `B<5`, take `q=4`.  Among any 20 tiles, at least four therefore satisfy

    cos(phi) + sin(phi) >= 4/(B-1).

Equivalently, when `1+2*sqrt(2) < B < 5`, at least four have

    phi >= (1/2) asin(16/(B-1)^2 - 1).

This is an unconditional necessary condition.  The tiles may be independently
translated and rotated; no lattice, common angle, generic position, or strict
noncontact assumption is used.

## Proof

A unit square at reduced angle `phi` contains the concentric board-aligned
square of side

    a(phi) = 1/(cos(phi)+sin(phi)).

Every tile center is at least `1/2` from every board wall, because the tile
contains its centered radius-`1/2` disk.  Hence all centers lie in a closed
board-aligned square of side `B-1`.

Fix any collection of tiles for which `cos(phi)+sin(phi) <= M` and suppose
`M(B-1)<q`.  Their concentric board-aligned subsquares all have side at least
`1/M`.  Partition the center square into `q` vertical strips of equal width.
The width is `(B-1)/q < 1/M`.  Two centers assigned to one strip therefore have
horizontal distance less than `1/M`; the interiors of their inscribed squares
overlap in horizontal projection.  Since the original tiles, and hence the
inscribed squares, have disjoint interiors, their vertical intervals have
disjoint interiors.  Their center heights differ by at least `1/M`.

Thus `q+1` centers in one strip would span at least `q/M > B-1`, impossible.
Each strip contains at most `q` selected centers, for a total of at most `q^2`.

For the strict threshold in the statement, suppose more than `q^2` tiles had
`cos(phi)+sin(phi) < q/(B-1)`.  The maximum `M` over any `q^2+1` of them would
still satisfy `M(B-1)<q`, contradicting the proved bound.  This limiting step
also covers every degeneracy: centers on strip boundaries, tile contacts, and
equality at the final threshold.

## Reproduction

Run:

    python3 strict_axis_count.py --output strict_axis_receipt.json
    python3 verify_strict_axis.py strict_axis_receipt.json

The first program uses exact rational arithmetic for every certified
inequality.  Decimal angles are display values only.  The second program is an
independently written parser and exact checker for the receipt.

## Consequence for the endpoint search

At sides 4.95, 4.96, 4.97, 4.98 and 4.99 the exact thresholds are recorded in
`strict_axis_receipt.json`.  In particular, a hypothetical packing at 4.97 has
at least four tiles tilted by about 0.4347 degrees or more.  This rules out the
entire all-near-axis branch uniformly and gives a four-tile branching premise
for unrestricted marked-pattern searches.  It does not prove `s(20)=5` by
itself, because the required four tilted tiles remain possible.
