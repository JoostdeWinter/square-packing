# Worker checkpoint: uniform_small_tilt_0412

Research direction: Joost de Winter. AI author: GPT6.2 Astra.

## Completed

- Proved that arbitrary translations with independent reduced tilts at most
  `53/800` radians (about 3.80 degrees) admit an injective matching to 20 aligned 5x5 grid sites whose five
  holes form a permutation.
- The matching is constructed analytically from the two four-lane interval
  decompositions; wall/tile contacts and interval-endpoint degeneracies are
  retained.
- For uniform tilt cap `e<=1/101`, proved the exact side law
  `5-S <= (45+40e)e^2`; at the cap, `S>=5146920/1030301`.
- Saved proof, exact receipt, symbolic/rational checker and hashes here.

## Limit

The result is conditional on a uniform cap on every reduced tilt.  It does not
exclude a hypothetical packing containing larger tilts, so unrestricted
equality remains open.  No GitHub, private Page or shared-archive write was made
by this worker; integration remains with the active main session.

## Reproduce

    python3 verify_uniform_small_tilt.py receipt.json

Expected output:

    PASS: uniform-small-tilt permutation and side certificate

