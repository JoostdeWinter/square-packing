# Uniform-small-tilt reduction to permutation vacancies

Research direction: Joost de Winter. AI author: GPT6.2 Astra.

## Results

Let 20 freely translated and independently rotated unit squares fit in a square
of side `S<5`.  Reduce every tilt modulo 90 degrees to `phi_i in [0,pi/4]`.

### Global permutation reduction

If every `phi_i<=e<=53/800`, then the centres can be assigned injectively to 20
distinct sites of the aligned 5 by 5 grid so that

    coordinate error <= r_e := 5(1+e)e.              (1)

Moreover, the five unassigned grid sites contain exactly one site in each row
and exactly one in each column: the holes form one of the 120 permutations.
This conclusion allows arbitrary translations, contacts, degeneracies and
independently varying tilts.

### Exact second-order endpoint law

If every `phi_i<=e<=1/101`, then `r_e<1/20`, and the checked simultaneous
turning-chain theorem in `geometry/near_grid.md` applies directly:

    5-S <= 8 r_e e + 5e^2
        = (45+40e)e^2.                               (2)

At the cap `e=1/101`, this gives the exact conditional lower bound

    S >= 5146920/1030301
      = 4.995549844171752... .                        (3)

Equivalently, any packing with smaller side must contain a tile whose reduced
tilt exceeds `1/101` radians (about 0.567 degrees).  This is an unrestricted-
translation, independently-rotating conditional theorem, but it does not rule
out packings with a larger tilt and therefore does not prove `s(20)=5`.

## Proof of the permutation reduction

For each board axis, use the same unit-chord intervals as in
`workers/chord_gap_conservation_0324`.  If

    u_i=cos(phi_i)+sin(phi_i),  a_i=u_i(u_i-1),

the interval for tile `i` is centred at the corresponding centre coordinate
and has length `1-a_i`.  Interval depth is at most four.  At `e<=53/800`,

    a_i <= (1+e)e <= 45209/640000,
    1-a_i >= 594791/640000.

Consequently the intervals split into four lanes of exactly five tiles.
Ordering the intervals within a lane gives ranks `1,...,5`; for a tile of rank
`k` its centre coordinate differs from `k-1/2` by at most the lane sum of the
`a_i`.  This is at most `5(1+e)e`, proving (1) for each coordinate.

The orthogonal rank pair is injective.  At the largest cap the error is at most
`45209/128000`, so two tiles with the same pair would have squared centre distance at
most

    8(45209/128000)^2
      = 2043853681/2048000000 < 1.

But each unit square contains the open disk of radius `1/2` around its centre;
interior-disjoint tiles have centre distance at least one.

It remains to show that the five holes form a permutation.  If all five sites
of a grid row were occupied, consider the board line through that row.  For a
tile assigned to that row, its centre is at distance at most `45209/128000` from the
line, while the half-length of its unit-chord interval is at least

    (594791/640000)/2 = 594791/1280000.

Since `45209/128000=452090/1280000<594791/1280000`, the line cuts all five tiles in pairwise
interior-disjoint chords of length at least one.  They cannot fit in a board
section of length below five.  Thus every grid row has a hole.  The same proof
applies to columns.  Five holes among five rows and five columns therefore give
exactly one per row and column.

## Proof of the side law

For `e<=1/101`, (1) gives

    r_e <= 5(1+1/101)(1/101) = 510/10201 < 1/20.

The near-grid theorem accepts independently varying tilts bounded by `e`, so
substitution gives (2).  At `e=1/101`,

    (45+40e)e^2 = 4585/1030301,

which is equivalent to (3).  The exact checker below verifies every rational
comparison and the symbolic substitution.

## Reproduce

    python3 verify_uniform_small_tilt.py receipt.json

Expected output:

    PASS: uniform-small-tilt permutation and side certificate

