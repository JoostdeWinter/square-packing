#!/usr/bin/env python3
"""Independent exact checker for the uniform-small-tilt reduction."""

from fractions import Fraction as F
from itertools import permutations
import json
import sys

import sympy as sp


def Q(value):
    return F(str(value))


def main(path):
    with open(path, "r", encoding="utf-8") as handle:
        receipt = json.load(handle)

    e0 = Q(receipt["broad_tilt_cap"])
    a0 = Q(receipt["a_upper_bound"])
    ell0 = Q(receipt["unit_chord_length_lower_bound"])
    r0 = Q(receipt["lane_center_error_bound_at_broad_cap"])
    half0 = Q(receipt["unit_chord_half_length_lower_bound"])
    assert e0 == F(53, 800)
    assert (1 + e0) * e0 == a0 == F(45209, 640000)
    assert 1 - a0 == ell0 == F(594791, 640000)
    assert 6 * ell0 == Q(receipt["six_interval_length_lower_bound"])
    assert 6 * ell0 == F(1784373, 320000) > 5
    assert 5 * a0 == r0 == F(45209, 128000)
    assert ell0 / 2 == half0 == F(594791, 1280000)
    assert r0 == F(452090, 1280000) < half0

    # Same rank pair would force centre distance below one.
    distance_sq = 8 * r0 * r0
    assert distance_sq == Q(receipt["same_site_distance_squared_bound"])
    assert distance_sq == F(2043853681, 2048000000) < 1

    # Exactly five holes, and one in every one of five rows and columns, are
    # precisely the graphs of the 5! permutations.
    patterns = {tuple((x, p[x]) for x in range(5)) for p in permutations(range(5))}
    assert len(patterns) == receipt["permutation_hole_patterns"] == 120
    assert receipt["assigned_sites"] == 20
    assert receipt["grid_sites"] == 25
    assert receipt["holes"] == 5

    e = Q(receipt["turning_chain_tilt_cap"])
    r = 5 * (1 + e) * e
    assert e == F(1, 101)
    assert r == Q(receipt["turning_chain_radius_at_cap"]) == F(510, 10201)
    assert r < Q(receipt["turning_chain_radius_limit"]) == F(1, 20)

    # Symbolically replay 8*r*e+5e^2 with r=5(1+e)e.
    x = sp.symbols("e", nonnegative=True)
    expression = sp.expand(8 * (5 * (1 + x) * x) * x + 5 * x**2)
    assert sp.expand(expression - (45 + 40 * x) * x**2) == 0
    assert receipt["side_deficit_formula"] == "(45+40e)e^2"
    deficit = (45 + 40 * e) * e * e
    assert deficit == Q(receipt["side_deficit_at_cap"]) == F(4585, 1030301)
    lower = 5 - deficit
    assert lower == Q(receipt["side_lower_bound_at_cap"]) == F(5146920, 1030301)

    assert receipt["attribution"] == {
        "research_direction": "Joost de Winter",
        "ai_author": "GPT6.2 Astra",
    }
    print("PASS: uniform-small-tilt permutation and side certificate")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: verify_uniform_small_tilt.py receipt.json")
    main(sys.argv[1])

