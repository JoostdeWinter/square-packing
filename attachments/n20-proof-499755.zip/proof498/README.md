# The side 249/50 exclusion

The check covers every independent translation and rotation of twenty closed unit squares in the board. Start from a fresh directory at the root of this archive, with Python 3 and a C++17 compiler.

    python3 proof498/prepare.py fresh498 --jobs 4
    python3 proof498/verify.py fresh498 --jobs 4

The first command authenticates all twenty upstream Git blobs and builds the geometry programs. It verifies that every possible tile hits the primary marked pattern, all certified single replacements and twenty auxiliary patterns. It creates two separate profile tables for every one of the 231 ways to omit two of the 22 primary marks. The second command enumerates every ordered pair of red and blue choices, reduces it under all eight symmetries of the board and tests every remaining assignment and possible owner of each unused mark. It writes verified.json only after all cases pass. A valid 20-square control with movable independent tiles can be replayed by running python3 enumerator/positive_control.py from the archive root.

The reductions use necessary conditions. When a red or blue mark is replaced by a certified alternative, a tile containing neither unused mark of that color and assigned the replaced mark must also contain the alternative. The other nineteen selected marks already belong to nineteen different tiles. For an auxiliary pattern, a tile can use any site compatible with its center and angle. A matching must assign distinct possible sites to every tile. Conditioning on one of those choices gives a smaller center domain and an additional inner polygon. The union of the alternative center domains is enlarged by a convex hull. The actual tile contains the intersection of the corresponding inner polygons. The integer-grid resource follows from geometry/integer_grid.md.

The refined calculation subdivides half-angle intervals while retaining outward center polygons. It splits one tile's poses into two angular groups and four closed center quadrants. Each of these eight parts has a polygon guaranteed to lie in that tile. For a second tile at a specified angle, the Minkowski sum of this polygon and its own centered inner polygon bounds a forbidden interior for its center. Every center in the intersection of all applicable forbidden interiors is impossible. The subsequent propagation also checks transverse chords, other marked patterns and geometric intersection of certified tile cores. A tree node is excluded only when all its children are excluded. The verifier treats any cutoff as an open result.

One difficult angular exclusion also has a separately implemented rational witness checker:

    python3 advanced/check_audit.py proof498/cluster_trace.txt.gz

The trace starts from one refined root of the enumerator. The independent checker tests conditional containment for the fixed tile and the inclusion of every relevant rational half-plane section of the other center polygons in each replacement domain. Thus it independently verifies the final implication from those incoming polygons. It does not independently establish the earlier steps of the complete 53,361-pair proof.
