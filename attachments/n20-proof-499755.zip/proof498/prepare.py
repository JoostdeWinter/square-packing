"""Cold-source initialization for the exhaustive 4.98 calculation."""
from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction as F
from itertools import combinations,product
from pathlib import Path
import argparse,json,os,shutil,subprocess,sys
here=Path(__file__).resolve().parent;h=here.parent
sys.path[:0]=[str(h/'base496'),str(h/'enumerator')]
from prereqs import SPEC,checked_sources,marks
from coverage import sweep
from deepbuild import build as pair_build
from strongbuild import build as strong_build
from central_replay import verify_movements
def atomic(p,obj):
 t=p.with_suffix('.part');t.write_text(json.dumps(obj,sort_keys=True,separators=(',',':'))+'\n');t.replace(p)
def main(d,jobs):
 if d.exists() and any(d.iterdir()):raise ValueError('use an empty directory for a cold replay')
 d.mkdir(exist_ok=True,parents=True);u=d/'upstream';u.mkdir();checked_sources(u,h/'base496/upstream')
 sys.path.insert(0,str(u));os.chdir(u)
 import check_stabs,nearest_rack,rack_lattice_input
 from verify_arc_lower import build
 from verify_nearest_lower import certified_init
 from verify_rack_angle import check_rack
 spec=dict(SPEC,cap='4.98');pts=[(int(x*10**6),int(y*10**6)) for x,y in marks(spec)]
 for mod in [check_stabs,nearest_rack,rack_lattice_input]:mod.marks=marks
 proof=check_rack(spec);assert proof['status']=='STRICT_STABBING';num=sweep(pts,4980000);assert num>0
 print('two global angle-cover checks passed',num,flush=True)
 newmoves=verify_movements(h/'enumerator/marks498.txt',pts,4980000,jobs)
 print('all individual moved marks verified',newmoves,flush=True)
 n=d/'native';n.mkdir();build(n);pair_build(n/'r.cc',n/'pair');strong_build(n/'pair.cpp',n/'strong')
 term=d/'enumerator';term.mkdir()
 for f in ['build.py','slices.inc','search.inc']:shutil.copy(h/'enumerator'/f,term/f)
 shutil.copy(n/'strong.cpp',term/'kernel.cpp')
 subprocess.run([sys.executable,term/'build.py'],check=True)
 adv=d/'advanced';adv.mkdir()
 for f in ['build.py','extra.inc','endpoint_chords.inc','cluster.inc','tree.inc','build_tree.py']:
  shutil.copy(h/'advanced'/f,adv/f)
 subprocess.run([sys.executable,adv/'build.py'],check=True);subprocess.run([sys.executable,adv/'build_tree.py'],check=True)
 table=d/'i64';certified_init(spec,64,table)
 base=d/'basic';base.mkdir();strong=d/'strongprofiles';strong.mkdir()
 masks=sorted((1<<22)-1-(1<<i)-(1<<j) for i,j in combinations(range(22),2))
 settings={}
 for n_racks in [3,5,20]:
  fn=h/'advanced'/f'racks498_{n_racks}.txt';lines=fn.read_text().splitlines();U,nr=map(int,lines[0].split());assert U==4980000 and nr==n_racks==len(lines)-1
  for line in lines[1:]:
   n,*v=map(int,line.split());assert len(v)==2*n and n>=20
   rack=tuple(zip(v[::2],v[1::2]))
   if rack not in settings:
    c=sweep(rack,U);assert c>0;settings[rack]=c
 print('additional full cover patterns',len(settings),flush=True)
 env=dict(os.environ,N20_EXTRA_RACKS=str(h/'advanced/racks498_3.txt'))
 def profile(m):
  raw=subprocess.check_output([d/'native/pair','profile',table,'65',base],text=True,input=f'{m}\n').split()
  assert len(raw)==2 and int(raw[0])==m
  new=subprocess.check_output([adv/'advanced','profile',table,strong,h/'enumerator/marks498.txt',str(m),str(m),'12','2'],text=True,env=env).split()
  assert len(new)==2 and int(new[0])==m
  return int(raw[1]),int(new[1])
 with ThreadPoolExecutor(jobs) as ex:profiles=list(ex.map(profile,masks))
 assert all(a==b==0 for a,b in profiles)
 result={'side':'249/50','primary_cover':proof,'angle_cover_intervals':num,'movements':newmoves,'other_exact_racks':len(settings),'additional_cover_interval_counts':sorted(settings.values()),'usual_profiles':len(masks),'advanced_profiles':len(masks)}
 atomic(d/'prepared.json',result);print('preparation complete',flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('work',type=Path);ap.add_argument('--jobs',default=4,type=int);args=ap.parse_args();main(args.work.resolve(),args.jobs)
