"""Exhaust every ordered nearest-mark pair by symmetry and continuous geometry."""
import argparse,json,sys,subprocess,os,time
from collections import Counter
from fractions import Fraction as F
from concurrent.futures import ThreadPoolExecutor,as_completed
from itertools import combinations,product
from pathlib import Path
from prepare import here,h,marks,SPEC,atomic
def orbits(side=4980000):
 P=[(int(x*10**6),int(y*10**6)) for x,y in marks(dict(SPEC,cap=str(F(side,10**6))))];Q=[(side-y,x) for x,y in P]
 holes=list(combinations(range(22),2));full=(1<<22)-1;canonical={}
 actions=[]
 for sw,rx,ry in product(range(2),repeat=3):
  def f(z):return (side-z[sw] if rx else z[sw],side-z[1-sw] if ry else z[1-sw])
  a=list(map(f,P));b=list(map(f,Q))
  swap=set(a)==set(Q)
  targets=(Q,P) if swap else (P,Q)
  assert set(a)==set(targets[0]) and set(b)==set(targets[1])
  def masked(z,src):
   p,q=z;return full^(1<<src[p])^(1<<src[q])
  g=[targets[0].index(z) for z in a];j=[targets[1].index(z) for z in b]
  actions.append((swap,{v:masked(v,g) for v in holes},{v:masked(v,j) for v in holes}))
 assert len(actions)==8
 for a,b in product(holes,repeat=2):
  k=min((z[b],y[a]) if sw else (y[a],z[b]) for sw,y,z in actions)
  canonical[k]=canonical.get(k,0)+1
 assert sum(canonical.values())==53361 and len(canonical)==6787
 return canonical
def main(d,jobs,only=None):
 assert __debug__
 init=json.loads((d/'prepared.json').read_text());regular=json.loads((here/'regular.json').read_text())
 orbs=orbits();items=sorted(orbs);valid={f'{a}_{b}' for a,b in items};assert set(regular)<=valid and len(regular)==3786
 reg=d/'standard';reg.mkdir(exist_ok=True);extra=d/('secondary' if only else 'checks');extra.mkdir(exist_ok=True)
 # Retain simple integer-kernel reasons and exact counts from the discovery record.
 def plain(batch):
  params,entries=batch;cmd=[d/'native/pair','pairs',d/'i64',d/'basic',*map(str,params)]
  input=''.join(f'{a} {b}\n' for a,b,rc,it in entries)
  got=subprocess.check_output(cmd,text=True,input=input).splitlines();assert len(got)==len(entries)
  for target,res in zip(entries,got,strict=True):
   assert tuple(map(int,res.split()))==target and target[2]>0
  return len(entries)
 groups={}
 for k,(cycles,r,rc,it) in regular.items():
  a,b=map(int,k.split('_'));groups.setdefault((cycles,r),[]).append((a,b,rc,it))
 batches=[(s,rows[i:i+8]) for s,rows in groups.items() for i in range(0,len(rows),8)]
 if only:count=3786
 else:
  with ThreadPoolExecutor(jobs) as pool:count=sum(pool.map(plain,batches))
 assert count==3786;print('verified standard marked-pair cases',count,flush=True)
 all_extra=[(a,b) for a,b in items if f'{a}_{b}' not in regular]
 if only:
  assert only in {f'{a}_{b}' for a,b in all_extra};all_extra=[tuple(map(int,only.split('_')))]
 def one(case):
  a,b=case;key=f'{a}_{b}';out=extra/(key+'.json')
  # A clean work directory is created by prepare.py. That directory may be
  # resumed after interruption; the final cold log must come from one fresh run.
  if out.exists():return json.loads(out.read_text())
  cmd=[d/'enumerator/enumerate','match',d/'i64',d/'basic',h/'enumerator/marks498.txt',str(a),str(b),'8','1']
  rr=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
  matches=[tuple(map(int,v.split())) for v in rr.stdout.splitlines()]
  assert len(matches)==len(set(matches))
  for m in matches:
   assert len(m)==20 and len(set(m))==20 and sum(1<<j for j in m)==b
  stats=Counter({'matchings':len(matches)});hist=Counter();failure=[]
  def geom(m,owners,r,cy,mode,nrack,fine=4):
   env=dict(os.environ,N20_EXTRA_RACKS=str(h/'advanced'/f'racks498_{nrack}.txt'))
   exe=d/'advanced'/('advanced' if mode=='check' else 'tree')
   if mode=='tree':
    env.update(N20_FINE=str(fine),N20_TREE_LIMIT='1800' if fine==4 else '50',N20_TREE_DEPTH='19' if fine==4 else '7',N20_TREE_CHECKS='6' if fine==4 else '3')
   args=[exe,mode,d/'i64',d/'strongprofiles',h/'enumerator/marks498.txt',str(a),str(b),str(r),str(cy),','.join(map(str,owners))]
   line=subprocess.check_output(args,text=True,env=env,input=' '.join(map(str,m))+'\n').split()
   if line[0]=='CLOSED':assert len(line)==2 and int(line[1]) in (1,2,7,8,9)
   elif line[0]=='OPEN':assert mode=='check' and len(line)==5 and all(0<=int(x)<1<<20 for x in line[1:])
   else:assert mode=='tree' and line[0] in ('CLOSED_TREE','OPEN_TREE') and len(line)==2
   return line
  for m in matches:
   owners=(-2,)*4;base=geom(m,owners,12,2,'check',3)
   if base[0]=='CLOSED':stats['root_closed']+=1;continue
   stats['root_open']+=1;stack=[owners]
   while stack:
    v=stack.pop();stats['owner_nodes']+=1;result=geom(m,v,28,3,'check',5)
    if result[0]=='CLOSED':hist['owner_'+result[1]]+=1;continue
    if -2 not in v:
     stats['fully_specified']+=1
     if only:
      result=geom(m,v,24,2,'tree',5,2)
      if result[0]=='OPEN_TREE':result=geom(m,v,40,4,'tree',20)
     else:result=geom(m,v,40,4,'tree',20)
     if result[0] in ('CLOSED','CLOSED_TREE'):
      stats['final_closed']+=1;stats['tree_nodes']+=int(result[1]) if result[0]=='CLOSED_TREE' else 0;hist[result[0]]+=1;continue
     failure.append([m,v,result]);continue
    avail=list(map(int,result[1:]));t=min((i for i,x in enumerate(v) if x==-2),key=lambda i:(avail[i].bit_count(),i))
    for who in [-1]+[j for j in range(20) if avail[t]>>j&1]:
     w=list(v);w[t]=who;stack.append(tuple(w))
  ans={'mask_pair':[a,b],'counts':dict(stats),'reasons':dict(hist),'unresolved':failure};atomic(out,ans);return ans
 totals=Counter();reasons=Counter();failed=[];nomatch=0;t=time.monotonic()
 with ThreadPoolExecutor(jobs) as pool:
  for i,fu in enumerate(as_completed([pool.submit(one,c) for c in all_extra]),1):
   z=fu.result();totals.update(z['counts']);reasons.update(z['reasons']);failed.extend(z['unresolved']);nomatch+=z['counts'].get('matchings',0)==0
   if i%100==0 or i==len(all_extra):print(i,'of',len(all_extra),'expanded',totals['matchings'],'unresolved',len(failed),'elapsed',int(time.monotonic()-t),flush=True)
 if only:
  assert not failed;print('one complete mask pair closed',only,dict(totals),flush=True);return
 result={'side':'249/50','ordered_patterns':sum(orbs.values()),'symmetry_classes':len(orbs),'standard':count,'extended':len(all_extra),'extended_with_no_matching':nomatch,'counts':dict(totals),'reasons':dict(reasons),'unresolved':failed,'initialization':init}
 atomic(d/'status.json',result);assert not failed,('unresolved',len(failed))
 atomic(d/'verified.json',result)
 print(json.dumps(result,indent=2),flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('work',type=Path);ap.add_argument('--jobs',type=int,default=4);ap.add_argument('--only');v=ap.parse_args();main(v.work.resolve(),v.jobs,v.only)
