"""Integer-only verification of the parallel-square exclusion for 0 < tan(theta/2) <= 1/31."""
import json,math,itertools
from pathlib import Path
from graphs import choices,rotate_holes
h=Path(__file__).resolve().parent
def add(a,b):
 z=[(a[i] if i<len(a) else 0)+(b[i] if i<len(b) else 0) for i in range(max(len(a),len(b)))]
 while z and not z[-1]:z.pop()
 return z
def mult(a,b):
 z=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):z[i+j]+=x*y
 return add([],z)
def scale(a,s):return [s*v for v in a]
def bernstein(a,Q=31):
 d=len(a)-1
 return [sum(a[i]*Q**(d-i)*math.comb(d-i,k-i) for i in range(k+1)) for k in range(d+1)]
def positive(a,strict=False,Q=31):
 if not a:return not strict
 res=bernstein(a,Q)
 return min(res)>=0 and (not strict or (any(z>0 for z in res) and res[-1]>0))
def verify_weights(row):
 c=[1,0,-1];s=[0,2];d=[1,0,1];cs=add(c,s);coeff=[[] for _ in range(41)];rhs=[]
 rules=list(map(tuple,row['rules']));assert len(set(rules))==len(rules)==len(row['multipliers'])
 for rule,v in zip(rules,row['multipliers']):
  assert all(type(a)is int for a in v) and positive(v)
  kind,i,*tail=rule;assert kind in range(6) and i in range(20)
  if kind<4:
   assert tail==[];axis=kind//2
   a=mult(v,scale(d,2 if kind%2 else -2))
   coeff[2*i+axis]=add(coeff[2*i+axis],a)
   if kind%2:coeff[40]=add(coeff[40],scale(a,-1))
   rhs=add(rhs,mult(v,scale(cs,-1)))
  else:
   j,=tail;assert j in range(20) and j!=i
   ux,uy=(c,s) if kind==4 else (scale(s,-1),c)
   for dim,component in enumerate((ux,uy)):
    a=mult(v,scale(component,2))
    coeff[2*i+dim]=add(coeff[2*i+dim],a);coeff[2*j+dim]=add(coeff[2*j+dim],scale(a,-1))
   rhs=add(rhs,mult(v,scale(d,-2)))
 assert all(not x for x in coeff[:40])
 margin=add(scale(coeff[40],5),scale(rhs,-1))
 assert margin==row['margin'] and positive(margin,strict=True)
 return set(rules)
def graph_rules(record,sol):
 pts=[tuple(p) for p in record['points']];lookup={p:i for i,p in enumerate(pts)};rules={(k,i) for k in range(4) for i in range(20)}
 for i,(x,y) in enumerate(pts):
  for k,z in [(4,(x+1,y)),(5,(x,y+1))]:
   if z in lookup:rules.add((k,i,lookup[z]))
 for v,(i,j) in zip(sol,record['diagonals']):
  if v>0:rules.add((4,i,j))
  else:rules.add((5,i,j) if pts[i][1]<pts[j][1] else (5,j,i))
 return rules
def main():
 cert=json.loads((h/'parallel_certificates.json').read_text());terms=[verify_weights(x) for x in cert]
 # b=(c+s)(5-c-s)/5, b < 1-5t implies b<1.
 # The numerator of 5(1+t²)²(1-5t-b) is tested exactly.
 d=[1,0,1];u=[1,2,-1]
 diff=add(mult(scale(mult(d,d),5),[1,-5]),scale(mult(u,add(scale(d,5),scale(u,-1))),-1))
 assert positive(diff,True) and diff[0]>0
 counts={};total=0
 for p in itertools.permutations(range(5)):
  orbit=[];q=p
  for _ in range(4):orbit.append(q);q=rotate_holes(q)
  k=min(orbit)
  if k not in counts:
   g=choices(k)
   for sol in g['solutions']:
    rules=graph_rules(g,sol)
    assert any(need.issubset(rules) for need in terms),(k,sol)
   counts[k]=len(g['solutions'])
  total+=counts[k]
 assert (len(counts),sum(counts.values()),total)==(33,1686,5685)
 result={'common_orientation':True,'half_tangent_max':'1/31','positive_angle_only':True,'hole_permutations':120,'rotational_classes':len(counts),'separation_graphs_in_representatives':sum(counts.values()),'all_separation_graphs':total,'polynomial_duals':len(cert)}
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
