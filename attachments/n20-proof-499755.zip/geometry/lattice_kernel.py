"""Exact checks for the four-disk interior common to lattice-missing tiles."""
from fractions import Fraction as F
from itertools import product
from math import isqrt
import json
def dirs(p,q):
 d=q*q+p*p
 return F(q*q-p*p,d),F(2*p*q,d)
def inside(x,y,mu):return (abs(x)+mu/2)**2+(abs(y)+mu/2)**2<=((1+mu)/2)**2
def check():
 n=0;depths=[]
 for mu in [F(1),F(499,500),F(997,1000),F(99,100)]:
  for i in range(38):
   x=F(i,100);a=(1+mu)**2/4-(x+mu/2)**2
   if a<mu*mu/4:continue
   y=F(isqrt((a*10**12).numerator//(a*10**12).denominator),10**6)-mu/2
   assert y>=0 and inside(x,y,mu) and not inside(x,y+F(2,10**6),mu)
   for k in range(65):
    c,s=dirs(k,64);side=1-mu*(c+s-1)
    for sx,sy in product([-1,1],repeat=2):
     X,Y=sx*x,sy*y
     assert 2*max(abs(c*X+s*Y),abs(-s*X+c*Y))<=side;n+=1
  depths.append(str(mu))
 return {'scale_factors':depths,'rational_direction_and_point_checks':n,'kernel_center':'distinct noncorner half-integer cells','required_tiles':4}
if __name__=='__main__':print(json.dumps(check(),indent=2))
