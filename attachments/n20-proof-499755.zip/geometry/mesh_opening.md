# A tilted square forces a local opening in a mesh of aligned squares

Research direction by Joost de Winter. AI author GPT6.2 Astra.

Consider four axis-aligned unit squares, one containing each corner of a unit grid cell in its interior, or more generally with the four nonnegative openings specified below. A fifth, independently translated square misses the integer lattice in that cell and has positive reduced tilt θ ≤ π/4. All five squares have disjoint interiors. The horizontal openings between the two bottom and two top owners, plus the vertical openings between the two left and two right owners, have sum

    G ≥ 2 + 2t²/(1+t),       t = tan(θ/2).

The bound is sharp for the local configuration, allowing limiting contact positions. It yields a restriction on a hypothetical 20-square packing with sixteen board-aligned tiles. Only 632 of the 5,985 possible unordered choices of four noncorner cells survive the two geometric tests below.

## Four corner configurations

Put the cell center at the origin. Number its corners by (a,b) in {−1,1}². The center of the aligned tile at that corner is (a/2,b/2)+z_ab, with each coordinate of z_ab between −1/2 and 1/2. The horizontal opening along each cell edge joining two horizontally adjacent anchors is the difference between the two x offsets. The vertical opening is the analogous y difference. Assume all four openings are nonnegative. This holds for the mesh application because aligned tiles covering neighboring sites in one row meet the horizontal line through the sites in unit intervals with disjoint interiors. The vertical argument is identical. It also holds for the positive limiting examples.

Write c=cos θ, s=sin θ, u=c+s, d=(u−1)/2 and λ=(c−s)/s. Reflection takes the signed angle into [0,π/4]. For the central tile's offset (x,y), the lattice-miss condition gives

    |cx+sy| ≤ d,       |−sx+cy| ≤ d.

For each corner use U=a(z_x−x), V=b(z_y−y). Summing U+V over the four corners gives G because the central offsets cancel. The separating-axis theorem requires the projection of the center difference along at least one of the signed cardinal or tilted axes to be at least (1+u)/2. The inward-pointing cardinal direction cannot do this: the coordinate of the central center is at most ud < 1/2 in absolute value. On a tilted axis, a direction whose component signs do not both point toward the corner has projection at most c+d < 1+d=(1+u)/2. Consequently each corner must satisfy either its outward horizontal test U ≥ u/2, its outward vertical test V ≥ u/2, or its one outward tilted test. For the tilted test, write M for U or V according to which coefficient is c, and m for the other variable. Then

    cM+sm ≥ 1/2,       U+V ≥ (1+t)/2 + λ times the signed central major coordinate.

For the second inequality use M ≤ 1/2 minus that signed coordinate and (1−c)/s=t. The major coordinates at northeast, northwest, southwest and southeast are respectively x, y, −x and −y.

If every corner satisfies its tilted test, summing yields G ≥ 2+2t. An outward cardinal test requires a signed central displacement at most −d in the same coordinate. Both |x| and |y| cannot be at least d: the tilted normal in the quadrant of (x,y) would then have projection at least (c+s)d>d. Opposite cardinal directions cannot both occur either. Thus all cardinal tests that are needed have the same signed direction. Rotate the whole picture by a multiple of 90° to make that direction rightward. Put X=−x≥d. From the lattice-miss inequalities,

    −dt ≤ (cX−d)/s ≤ y ≤ (d−sX)/c ≤ d(1−s)/c,       X+y ≥ 0.

The two left corners use their tilted tests and together contribute at least 1+t+λ(X+y). There are three possibilities on the right.

* If both right corners use horizontal separation, their U terms sum to at least u. Their V terms sum to the nonnegative opening on the right edge. Thus G ≥ 1+t+u.
* If only northeast uses horizontal separation, sum the other three tilted inequalities. Their signed major coordinates sum to X. The northeast contribution is at least u/2−1/2−y. Hence G ≥ 1+(3t+u)/2 + λd − d(1−s)/c = 2+2t²/(1+t).
* If only southeast uses horizontal separation, its U is at least u/2. At northeast the tilted test implies U ≥ (1−s)/(2c)+(s/c)y. Again the two right-hand V terms sum to a nonnegative quantity. Combining the left and right lower bounds gives G ≥ 1+t+u/2+(1−s)/(2c)−(s/c)dt. Its excess over 2+2t²/(1+t) is t(1−2t−t²)/(1+t²), which is nonnegative because t ≤ √2−1.

The first two simpler bounds 2+2t and 1+t+u exceed the stated lower bound when t>0. For sharpness use x=−d, y=d(1−s)/c, and the four owner offsets in southwest, northwest, southeast, northeast order

    (−1/2,−(2t²−t+1)/(2(1+t))), (−1/2,1/2), (t−1/2,−1/2), (1/2,−1/2).

The three tilted separations and the northeast horizontal separation are equalities. The checker verifies the symbolic identities. These configurations realize equality for the closed local displacement constraints. Strict miss and strict contacts are unnecessary for the lower estimate.

## Consequences with sixteen aligned tiles

Normalize a hypothetical sub-5 packing to a board of side 5 with positive wall and intertile clearance. Each aligned tile contains an integer site. With sixteen such tiles all 16 interior integer sites have different aligned owners. The four remaining tiles miss the lattice and occupy different noncorner cells by the lattice-miss lemma. Their tilts are nonzero. For cells next to a wall, put virtual unit squares completely outside the board, one at each bordering grid site with its center displaced normally outward by 1/2. At the four exterior corner sites displace both coordinates outward by 1/2. On the interior lines of this 6 by 6 mesh the five nonnegative openings telescope to 1 each. On an outer line any opening bordering a noncorner cell is zero, since the tangential offsets of both virtual owners vanish. Thus the total distinct edge openings available to the four cells are at most 8. The local bound exceeds 2 for each of them. At least two of the four cells must share an edge.

Each of the four cells must also admit representatives on distinct horizontal integer lines and on distinct vertical integer lines. A tilted square with u=c+s cuts the integer horizontal lines in total chord length at least 2/(1+u). Indeed the periodic line nearest the center either cuts a plateau of length 1/c≥1 or meets a sloping side. If it is the only line meeting the tile, its distance from the center is at most 1−u/2, so its chord is at least (u−1)/(cs). If two lines meet the sloping sides, their distances from the center sum to 1, giving total chord length exactly (u−1)/(cs)=2/(1+u). This argument applies in the vertical direction as well. The central tile can meet only the two integer lines bordering its cell in each direction since its coordinate displacement from the cell center plus its half-width is at most u²/2≤1.

The four aligned tiles at any one interior horizontal integer line use length 4 there. At most 1 is available to the tilted tiles. Any r ≤ 4 of them use at least r·2/(1+√2)>r−1, so they need at least r distinct lines. Hall's theorem gives the representatives. Together, the two line matchings alone leave 1,617 cell choices. Requiring an edge-adjacent pair leaves 632. The full unrestricted search allows other numbers of aligned tiles.
