"""Explore four aligned lattice owners surrounding one lattice-missing tile."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json,argparse,math,time
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import csr_matrix
h=Path(__file__).resolve().parents[1]
def parameters(t):
 return (1-t*t)/(1+t*t),2*t/(1+t*t)
def search(t,diagonal=True):
 c,s=map(float,parameters(t));u=c+s;H=(1+u)/2;r=(u-1)/2
 vec=[(1,0),(0,1),(c,s),(-s,c)];vec+=[(-x,-y) for x,y in vec[:]]
 sites=list(product((-1,1),repeat=2))
 lo=[-.5]*8+[-.4]*2;hi=[.5]*8+[.4]*2;integers=[0]*10;rows=[];rhs=[]
 def simple(row,b):rows.append(row);rhs.append(b)
 def disj(opts):
  good=[]
  for row,b in opts:
   maxv=sum(q*(hi[i] if q>0 else lo[i]) for i,q in row.items())
   if maxv>=b-1e-10:good.append((row,b))
  if len(good)==1:simple(*good[0]);return
  ix=[]
  for row,b in good:
   m=b-sum(q*(lo[i] if q>0 else hi[i]) for i,q in row.items());n=len(lo);lo.append(0);hi.append(1);integers.append(1);ix.append(n)
   rr=dict(row);rr[n]=-m;simple(rr,b-m)
  simple({n:1 for n in ix},1)
 for n in vec[2:4]:
  for v in (-1,1):simple({8:v*n[0],9:v*n[1]},-r)
 for i,(a,b) in enumerate(sites):
  disj([({2*i:x,2*i+1:y,8:-x,9:-y},H-(a*x+b*y)/2) for x,y in vec])
 for i,(a,b) in enumerate(sites):
  for j,(aa,bb) in enumerate(sites[i+1:],i+1):
   if a==aa:simple({2*j+1:1,2*i+1:-1},0)
   elif b==bb:simple({2*j:1,2*i:-1},0)
   elif diagonal:
    sy=1 if bb>b else -1;disj([({2*j:1,2*i:-1},0),({2*j+1:sy,2*i+1:-sy},0)])
 A=np.zeros((len(rows),len(lo)));obj=np.zeros(len(lo))
 for i,row in enumerate(rows):
  for j,v in row.items():A[i,j]=v
 for i,(a,b) in enumerate(sites):obj[2*i]=a;obj[2*i+1]=b
 q=milp(obj,integrality=integers,bounds=Bounds(lo,hi),constraints=LinearConstraint(csr_matrix(A),rhs,np.inf),options={'mip_rel_gap':1e-8,'time_limit':40})
 return {'half_tangent':str(t),'gap':float(q.fun) if q.fun is not None else None,'solution':q.x[:10].tolist() if q.x is not None else None,'status':int(q.status),'has_diagonal_constraints':diagonal}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--full',action='store_true');p.add_argument('--output',type=Path);v=p.parse_args()
 ts=[F(1,10000),F(1,160),F(1,40),F(1,20),F(1,10),F(1,5),F(3,10),F(2,5),F(41,100)]
 if v.full:ts+=[F(k,200) for k in range(1,84)]
 z=[]
 for t in sorted(set(ts)):
  q=search(t);z.append(q);print(q['half_tangent'],q['gap'],q['status'],flush=True)
 if v.output:v.output.write_text(json.dumps(z,indent=2))
