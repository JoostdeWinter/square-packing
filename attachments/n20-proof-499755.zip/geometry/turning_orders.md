# Constraints on the signs and order of small independent tilts

Research direction by Joost de Winter. AI author GPT6.2 Astra.

Suppose twenty unit squares fit into a board of side S below 5, with signed tilts θ measured from the board axes and maximum absolute tilt e ≤ 1/10 radian. Let u=cos(e)+sin(e), and let d=u(u−1). The rank argument in global_small_tilt.md assigns the centers to a five-by-five grid with one vacancy in each row and column. Consider any occupied diagonal pair that can join a complete horizontal chain and a complete vertical chain, with three straight steps in each chain. Pick the chain in whose direction the diagonal pair actually has an edge-normal separation. It has five tiles and one diagonal step. Rotate the axes by a multiple of ninety degrees so this chain runs left to right. Write h=+1 for a rising step and h=−1 for a falling step.

With i,j the two tiles at the diagonal step and L,R the two wall-end tiles, put

    E = ( |θ_L| + |θ_R| + sum_straight |θ_a−θ_b| − h(θ_i+θ_j) ) / 2.

The triangle inequality along the two arms gives E ≥ 0. More precisely,

    (5−S) + E ≤ 17 d e + (24/5)e² + e³/6.

Consequently the opposing-sign part of either tile angle on the chosen diagonal is at most this quadratic error. In particular, if the two diagonal tiles tilt in opposite directions, the smaller absolute tilt is bounded by the right-hand side. In every sequence of hypothetical improving packings with e tending to zero, normalize all angles by e and pass to a subsequence. Along both arms of the selected chain the limiting signed angles, multiplied by h, are nonnegative and nondecreasing from each wall toward the diagonal pair.

For the inequality, write dx,dy for a horizontal chain step in the rank coordinates. Each center difference has dx positive. Separation along a near-horizontal normal belonging to either endpoint gives

    dx ≥ 1 + |θ_a−θ_b|/2 − (4/15)(θ_a−θ_b)² − dy sin(θ_k).

Here k is one of a,b. This follows from the exact support (1+cos Δ+|sin Δ|)/2, the upper bound dx cos(θ_k) ≤ dx and the elementary trigonometric bounds in global_small_tilt.md. On a straight step |dy|≤4d. On the diagonal step |dy−h|≤5d. Use |sin(θ_k)−θ_k|≤e³/6 and 2hθ_k≤h(θ_a+θ_b)+|θ_a−θ_b|. Wall support contributes the two terms |θ_L|/2 and |θ_R|/2, with quadratic loss at most (4/15)(θ_L²+θ_R²). Summing all four steps and both walls gives the stated constants. The limit statement uses the identity that total variation equals net increase precisely for a nondecreasing sequence.

For all such bridges simultaneously, turning_orders.py enumerates the two choices of chain and computes the transitive closure of the implied weak orders. Across the 120 vacancy permutations there are 2,496 routings. Each orders at least 20 unordered pairs of leading tilt coefficients and constrains the sign of at least 13 tiles. Four vacancy permutations force at least four leading tilt coefficients to coincide for every routing. These restrictions apply to improving sequences approaching a grid.
