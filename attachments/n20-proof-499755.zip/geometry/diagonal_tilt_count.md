# At most eighteen squares can all be close to a diagonal

Research direction by Joost de Winter. AI author GPT6.2 Astra.

Write a tile's absolute tilt from the nearest board axis as θ, with 0≤θ≤π/4. In any square board of side at most 5, at most eighteen unit tiles can simultaneously have θ≥a for any threshold a satisfying (5−cos a−sin a)cos a<55/21. In particular a=2 arctan(19/48) qualifies. A packing of twenty tiles therefore has at least two with tilt strictly below 43.191 degrees, including any packing exactly at side five.

Place the origin at the center of the board. Each of the specified tiles has width and height at least cos a+sin a. It contains the concentric diamond |x|+|y|≤1/(2 cos a). Indeed the largest projection of this diamond onto either tile axis is at most cos θ/(2 cos a)≤1/2. Thus distinct centers have ℓ¹ distance at least 1/cos a. Send a center (x,y) to (u,v)=cos a·(x+y,x−y). The distance between the transformed centers in the maximum norm is at least one, and each satisfies |u|+|v|≤W=(5−cos a−sin a)cos a.

Round each coordinate on the lattice of denominator B=21 using i=floor(Bu+1/2), j=floor(Bv+1/2). Two centers with real maximum norm distance at least one have integer maximum norm distance at least B, including equality. Since |i|+|j|≤BW+1<56, the integer centers lie in the diamond of radius M=55. Each B-by-B block of integer sites contains at most one. The 55 orbits of blocks with nonnegative rational weights in proofs/diamond_two_tilts.json cover every integer site in that diamond with total weight at least one. Their total weight over all symmetry images is 189677614/10000007<19. Summing the weights at the centers bounds their integer count by eighteen. The independent geometric argument uses only containment and separation and permits arbitrary relative rotations.

    python3 geometry/diagonal_tilt_count.py proofs/diamond_two_tilts.json

The verifier expands the block orbits, checks their parity and every symmetry class of integer sites, and sums exact fractions.
