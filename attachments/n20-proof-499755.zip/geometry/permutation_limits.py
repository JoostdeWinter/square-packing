"""Exact labelled grid-limit enumeration for twenty centers, including ownership."""
from pathlib import Path
from itertools import permutations
from collections import Counter
import json
from grid_limits import h,grid,positions,dist,P,Q,U,D
masks=[(p,((1<<25)-1)^sum(1<<(5*x+y) for x,y in enumerate(p))) for p in permutations(range(5))]
def limits(k,match,owner):
 a,b=map(int,k.split('_'));ids=[i for i in range(22) if a>>i&1]
 holes=[(z,j) for z,m in enumerate((a,b)) for j in range(22) if not m>>j&1]
 edges=[]
 for t,(i,j) in enumerate(zip(ids,match,strict=True)):
  s=positions[i,j]
  if owner is not None:
   for record,(z,u) in zip(owner,holes,strict=True):
    if record==-2:continue
    p=(Q if z else P)[u];s=[g for g in s if (2*dist(grid[g],p)<=D if record==t else 2*dist(grid[g],p)>=D)]
  e=sum(1<<v for v in s)
  if not e:return []
  edges.append(e)
 def feasible(allowed):
  avail=[e&allowed for e in edges]
  if 0 in avail:return False
  order=sorted(range(20),key=lambda i:avail[i].bit_count());own=[-1]*25
  def aug(i,seen):
   m=avail[i]
   while m:
    bit=m&-m;m-=bit;v=bit.bit_length()-1
    if v in seen:continue
    seen.add(v)
    if own[v]==-1 or aug(own[v],seen):own[v]=i;return True
   return False
  return all(aug(i,set()) for i in order)
 return [p for p,m in masks if feasible(m)]
def main():
 result={}
 for name,folder,mode in [('screen','fixed500_e32root','raw'),('refined','cap5000000_ep1','refined')]:
  count=Counter();hist=Counter();samples=[]
  for f in sorted((h/'trials'/folder).glob('*.json')):
   a=json.loads(f.read_text())
   vals=[(f.stem,v['matching'],None) for v in a['live']] if mode=='raw' else [(a['mask_pair'],a['matching'],o) for o in a['open_leaves']]
   for k,m,o in vals:
    w=limits(k,m,o);count['examined']+=1;count['with_permutation_grid_limit']+=bool(w);hist[len(w)]+=1
    if w and len(samples)<7:samples.append({'key':k,'match':m,'owners':o,'permutations':w})
  result[name]={'counts':count,'multiplicity':hist,'examples':samples}
 (h/'runs/permutation_limits.json').write_text(json.dumps(result,indent=2));print({k:z['counts'] for k,z in result.items()},flush=True)
if __name__=='__main__':main()
