"""Fixed-angle experiments for adjacent lattice-missing unit squares."""
from itertools import combinations,product
from fractions import Fraction as F
from pathlib import Path
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix
import json,time,argparse
from cell_opening import parameters
h=Path(__file__).resolve().parents[1]
shapes={'one':[(0,0)],'domino':[(0,0),(0,1)],'straight3':[(0,0),(0,1),(0,2)],'elbow3':[(0,0),(0,1),(1,0)],'square':list(product((0,1),repeat=2)),'straight4':[(0,0),(0,1),(0,2),(0,3)],'zigzag':[(0,0),(0,1),(1,1),(1,2)],'T':[(0,0),(1,0),(2,0),(1,1)],'L':[(0,0),(0,1),(0,2),(1,0)]}
class P:
 def __init__(self,n):
  self.lo=[-.5]*n;self.hi=[.5]*n;self.integer=[0]*n;self.rows=[];self.rhs=[]
 def add(self,row,b):self.rows.append({j:v for j,v in row.items() if v});self.rhs.append(b)
 def disj(self,opts):
  good=[]
  for row,b in opts:
   high=sum(q*(self.hi[i] if q>0 else self.lo[i]) for i,q in row.items())
   low=sum(q*(self.lo[i] if q>0 else self.hi[i]) for i,q in row.items())
   if low>=b-1e-12:return
   if high>=b-1e-11:good.append((row,b, max(0,b-low)))
  if len(good)==1:self.add(*good[0][:2]);return
  ix=[]
  for row,b,m in good:
   j=len(self.lo);self.lo.append(0);self.hi.append(1);self.integer.append(1);ix.append(j)
   rr=dict(row);rr[j]=-m;self.add(rr,b-m)
  self.add({i:1 for i in ix},1)
 def solve(self,obj,seconds):
  r=[];c=[];v=[]
  for i,row in enumerate(self.rows):
   for j,w in row.items():r.append(i);c.append(j);v.append(w)
  A=coo_matrix((v,(r,c)),shape=(len(self.rows),len(self.lo))).tocsr()
  return milp(np.r_[obj,np.zeros(len(self.lo)-len(obj))],integrality=self.integer,bounds=Bounds(self.lo,self.hi),constraints=LinearConstraint(A,self.rhs,np.inf),options={'mip_rel_gap':1e-9,'time_limit':seconds})
def solve(C,ts,seconds=15):
 corners=sorted({(x+i,y+j) for x,y in C for i,j in product((0,1),repeat=2)});index={z:i for i,z in enumerate(corners)};n=len(corners);base=corners+[(x+.5,y+.5) for x,y in C];N=len(base);p=P(2*N);obj=np.zeros(2*N)
 edges=set()
 for x,y in C:
  for ix in [0,1]:edges.add(((x+ix,y),(x+ix,y+1),1));edges.add(((x,y+ix),(x+1,y+ix),0))
 for A,B,d in sorted(edges):obj[2*index[B]+d]+=1;obj[2*index[A]+d]-=1
 ang=[(1.,0.)]*n+[tuple(map(float,parameters(t))) for t in ts]
 for i in range(n,N):
  c,s=ang[i];rad=(abs(c)+abs(s)-1)/2
  for x,y in [(c,s),(-s,c),(-c,-s),(s,-c)]:p.add({2*i:x,2*i+1:y},-rad)
 for i,j in combinations(range(N),2):
  dx,dy=base[j][0]-base[i][0],base[j][1]-base[i][1];a,b=ang[i];c,s=ang[j]
  if i<n and j<n:
   if dx==0 and dy==1:p.add({2*j+1:1,2*i+1:-1},0);continue
   if dx==1 and dy==0:p.add({2*j:1,2*i:-1},0);continue
  dot=a*c+b*s;cross=a*s-b*c;H=(1+abs(dot)+abs(cross))/2
  ns=set([(a,b),(-b,a),(c,s),(-s,c)]);ns|={(-x,-y) for x,y in ns}
  p.disj([({2*j:x,2*j+1:y,2*i:-x,2*i+1:-y},H-x*dx-y*dy) for x,y in ns])
 q=p.solve(obj,seconds)
 return {'shape':C,'t':list(map(str,ts)),'status':q.status,'minimum':None if q.fun is None else float(q.fun),'lower':None if getattr(q,'mip_dual_bound',None) is None else float(q.mip_dual_bound),'offsets':q.x[:2*N].tolist() if q.x is not None else None}
def main(v):
 d=h/'trials/polyomino';d.mkdir(exist_ok=True);rng=np.random.default_rng(9280)
 for name in v.shapes:
  C=shapes[name];vals=[F(1,50),F(1,10),F(1,5),F(2,5)]
  cases=[(t,)*len(C) for t in vals]+[tuple(t*(-1 if j%2 else 1) for j in range(len(C))) for t in vals]
  if len(C)==2:cases+=list(product(vals,[*vals,*[-x for x in vals]]))
  cases +=[tuple(F(int(rng.integers(1,82)),200)*int(rng.choice((-1,1))) for j in C) for r in range(v.random)]
  for k,ts in enumerate(dict.fromkeys(cases)):
   f=d/f'{name}_{k:03}.json'
   if f.exists():continue
   z=solve(C,ts,v.seconds);f.write_text(json.dumps(z));print(name,k,z['t'],z['minimum'],z['lower'],z['status'],flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('shapes',nargs='+');p.add_argument('--seconds',type=int,default=15);p.add_argument('--random',type=int,default=25);main(p.parse_args())
