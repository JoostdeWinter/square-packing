"""First-order contact graphs for equal tilt magnitude and independent signs."""
from itertools import product,permutations,combinations
from collections import Counter
from functools import lru_cache
from equal_tilt_signs import assignments
from pathlib import Path
import time,json,argparse
@lru_cache(maxsize=12)
def pattern(p):
 A=sorted((x,y) for x,y in product(range(5),repeat=2) if y!=p[x]);idx={q:i for i,q in enumerate(A)}
 diag=[(i,j) for i,(x,y) in enumerate(A) for j,(X,Y) in enumerate(A) if X==x+1 and abs(Y-y)==1];index={v:1<<k for k,v in enumerate(diag)};paths=[]
 for dim in (0,1):
  layers=[[i for i,xy in enumerate(A) if xy[dim]==k] for k in range(5)]
  for path in product(*layers):
   tr=[A[i][1-dim] for i in path];ds=[v-u for u,v in zip(tr,tr[1:])]
   if max(map(abs,ds))>1:continue
   ed=0;straight=[];steps=[]
   for i,j,z in zip(path,path[1:],ds):
    if not z:straight.append((i,j));continue
    ed|=index[tuple(sorted((i,j)))];steps.append((i,j,z if dim==0 else -z))
   paths.append((dim,ed,straight,steps))
 return A,diag,paths
def constraints(p,signs):
 A,diag,paths=pattern(p);s=[1 if signs>>i&1 else -1 for i in range(20)];clauses=set()
 for dim,edges,straight,turns in paths:
  cost=1+sum(s[i]!=s[j] for i,j in straight)-sum(z*(s[i]+s[j])//2 for i,j,z in turns)
  if cost>=1:clauses.add((edges,0) if dim else (0,edges))
 # A positive literal means that the edge chooses horizontal separation.
 clauses=sorted(clauses,key=lambda z:(z[0]|z[1]).bit_count());out=[]
 for x,y in clauses:
  if not any((u&x)==u and (v&y)==v for u,v in out):out.append((x,y))
 return out
def models(cl,n,first=True):
 all_=(1<<n)-1;out=[]
 def dfs(x,y):
  while True:
   todo=[];nx=0;ny=0;best=all_;scores=Counter()
   for a,b in cl:
    if x&a or y&b:continue
    l=a&~y;r=b&~x;s=l|r
    if not s:return False
    if not s&(s-1):nx|=l;ny|=r
    else:todo.append((l,r))
   if nx&ny:return False
   if not nx and not ny:break
   x|=nx;y|=ny
  if x|y==all_:out.append(x);return first
  if todo:
   width=min((l|r).bit_count() for l,r in todo)
   for l,r in todo:
    m=l|r
    if m.bit_count()==width:
     while m:b=m&-m;m-=b;scores[b]+=1
   b=max(scores,key=scores.get)
  else:b=all_&~(x|y);b&=-b
  return dfs(x|b,y) or dfs(x,y|b)
 dfs(0,0);return out
def main(v):
 summary=Counter();minor=Counter();hist=Counter();examples=[];tic=time.monotonic();data={}
 for ip,p in enumerate(permutations(range(5))):
  Z=assignments(p);_,edges,_=pattern(p);keep=[]
  for s in Z:
   cl=constraints(p,s);ms=models(cl,len(edges))
   if ms:
    keep.append(s);minor[min(s.bit_count(),20-s.bit_count())]+=1
    if len(examples)<3 and s not in (0,1048575):examples.append((p,s,len(cl)))
  hist[len(keep)]+=1;summary['before']+=len(Z);summary['after']+=len(keep);data[','.join(map(str,p))]=sorted(keep)
  if ip%20==19:print(ip+1,summary,int(time.monotonic()-tic),flush=True)
 result={'counts':dict(summary),'minority_size':dict(sorted(minor.items())),'survivors_by_pattern':dict(sorted(hist.items())),'examples':examples};print(result,flush=True)
 if v.out:v.out.write_text(json.dumps(result,indent=2)+'\n')
 if v.keep:v.keep.write_text(json.dumps(data,separators=(',',':'))+'\n')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path);p.add_argument('--keep',type=Path);main(p.parse_args())
