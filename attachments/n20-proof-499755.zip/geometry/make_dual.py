"""Recover exact polynomial multipliers from sparse trial LP supports."""
import json,math
from pathlib import Path
import sympy as sp
from sympy.polys.matrices import DomainMatrix
from sympy import QQ
h=Path(__file__).resolve().parent
t=sp.Symbol('t')
def exact_rows(rules):
 d=1+t*t;c=1-t*t;s=2*t;rows=[];rhs=[]
 for r in rules:
  k,i,*z=r;a=[sp.S.Zero]*41
  if k<4:
   q=k//2;a[2*i+q]=2*d*(1 if k%2 else -1)
   if k%2:a[40]=-2*d
   b=-(c+s)
  else:
   j=z[0];u,v=(c,s) if k==4 else (-s,c)
   a[2*i:2*i+2]=[2*u,2*v];a[2*j:2*j+2]=[-2*u,-2*v];b=-2*d
  rows.append(a);rhs.append(b)
 return sp.Matrix(rows).T,sp.Matrix(rhs)
def make(rules):
 P,b=exact_rows(rules);target=sp.zeros(41,1);target[40]=-1
 rows=P.subs(t,sp.Rational(1,77)).T.rref()[1];assert len(rows)==len(rules)
 A=P.extract(rows,range(len(rules)));v=target.extract(rows,[0])
 L=DomainMatrix.from_Matrix(A).convert_to(QQ.poly_ring(t));V=DomainMatrix.from_Matrix(v).convert_to(L.domain)
 nums,den=L.solve_den(V);weights=[sp.Poly(sp.cancel(x),t) for x in nums.to_Matrix()]
 d=weights[0]
 for n in weights[1:]:d=sp.gcd(d,n)
 weights=[w.exquo(d) for w in weights]
 denom=sp.ilcm(*[q.q for w in weights for q in w.all_coeffs()]);weights=[sp.Poly(w.as_expr()*denom,t) for w in weights]
 nums=[int(c) for w in weights for c in w.all_coeffs()];g=math.gcd(*nums)
 sign=1 if any(w.eval(sp.Rational(1,77))>0 for w in weights) else -1
 weights=[sp.Poly(w.as_expr()*sign/g,t) for w in weights]
 assert all(w.eval(sp.Rational(1,77))>0 for w in weights)
 residual=P*sp.Matrix([w.as_expr() for w in weights])
 assert all(sp.expand(v)==0 for v in residual[:-1])
 margin=sp.Poly(sp.expand(5*residual[40]-sum(k*w.as_expr() for k,w in zip(b,weights))),t)
 assert margin.eval(sp.Rational(1,77))>0
 co=lambda w:[int(w.nth(i)) for i in range(w.degree()+1)]
 return {'rules':rules,'multipliers':[co(w) for w in weights],'margin':co(margin)}
def main():
 examples=json.loads((h/'dual_candidates.json').read_text())
 out=[]
 for e in examples:out.append(make(e['active']))
 (h/'parallel_certificates.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
 print('exact duals',len(out),'maximal multiplier degree',max(len(w)-1 for row in out for w in row['multipliers']),flush=True)
if __name__=='__main__':main()
