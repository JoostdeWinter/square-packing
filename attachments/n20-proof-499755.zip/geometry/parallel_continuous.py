from parallel_cover import trig
from fractions import Fraction as F
from itertools import product
from math import ceil,floor,comb
from pathlib import Path
import json,argparse,subprocess
h=Path(__file__).resolve().parent
def clip(p,ax,sign,k):
 out=[]
 for a,b in zip(p,p[1:]+p[:1]):
  x=sign*a[ax]-k;y=sign*b[ax]-k
  if x<=0:out.append(a)
  if x*y<0:out.append(tuple((u*y-v*x)/(y-x) for u,v in zip(a,b)))
 return out
def domains(a,b,S,D):
 c,s=trig((a+b)/2);ends=[trig(t) for t in (a,b)]
 half=max(S-x-y for x,y in ends)*max(c*x+s*y+abs(c*y-s*x) for x,y in ends)/2
 poly=[(c*x+s*y,-s*x+c*y) for x,y in [(-half,-half),(half,-half),(half,half),(-half,half)]]
 m=max(max(p) for p in poly);assert m*(2*D)/5+2<D
 cells=[]
 for i,j in product(range(5),repeat=2):
  p=poly
  for axis,k in ((0,i),(1,j)):
   p=clip(p,axis,-1,m*(1-F(2*k,5)));p=clip(p,axis,1,m*(F(2*(k+1),5)-1))
  if p:
   z=set(q for v in p for q in product(*(set((floor(x*D),ceil(x*D))) for x in v)))
   cells.append(sorted(z))
 return cells
def check(a,b,cap,D,limit,out):
 vals=domains(a,b,cap,D);key=f'{a.numerator}_{a.denominator}_{b.numerator}_{b.denominator}_{cap.numerator}_{cap.denominator}_{D}_{limit}'
 fname=out/(key+'.txt');dest=out/(key+'.json')
 if dest.exists():return json.loads(dest.read_text())
 fname.write_text(f'{len(vals)} {D}\n'+'\n'.join(' '.join(map(str,[len(s),*(k for xy in s for k in xy)])) for s in vals)+'\n')
 r=subprocess.run([h/'parallel_continuous',fname,str(limit)],capture_output=True,text=True,check=True);lines=r.stdout.splitlines();words=lines[-1].split();assert words[0]=='RESULT';nums=list(map(int,words[1:]));assert sum(nums[1:4])==comb(nums[0],20)
 res=dict(interval=[str(a),str(b)],cap=str(cap),denominator=D,limit=limit,cells=nums[0],explicit_closed=nums[1],excluded_by_subsets=nums[2],open=nums[3],search_nodes=nums[4],learned_subsets=nums[5],depth=nums[6],unresolved_graphs=nums[7]);dest.write_text(json.dumps(res,indent=2));return res
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--ranges',nargs='+',required=True);ap.add_argument('--cap',default='5');ap.add_argument('--den',type=int,default=10**6);ap.add_argument('--limit',type=int,default=150);ap.add_argument('--subdivide',type=int,default=0);v=ap.parse_args()
 out=h.parent/'trials/parallel_continuous';out.mkdir(exist_ok=True)
 def test(a,b,level):
  print('analyzing',a,b,flush=True);r=check(a,b,F(v.cap),v.den,v.limit,out);print('finished',a,b,r['open'],r['search_nodes'],r['learned_subsets'],flush=True)
  if r['open'] and level:
   m=(a+b)/2;test(a,m,level-1);test(m,b,level-1)
 for z in v.ranges:test(*map(F,z.split(',')),v.subdivide)
