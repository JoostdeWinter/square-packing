"""Extract short, independently checkable exclusion subsets for all middle-angle intervals."""
from pathlib import Path
from fractions import Fraction as F
from concurrent.futures import ThreadPoolExecutor
import json,os,subprocess,tempfile
from parallel_continuous import domains
h=Path(__file__).resolve().parent
def main():
 src=(h/'parallel_continuous.cpp').read_text()
 k='s.masks(0,20,0);';assert src.count(k)==1
 src=src.replace(k,k+'if(const char* f=getenv("N20_BAD_FILE")){ofstream os(f);for(auto v:s.bad)os<<v<<"\\n";}')
 out=h.parent/'trials/parallel_continuous';code=out/'certify.cpp';binary=out/'certify';code.write_text(src);subprocess.run(['g++','-std=c++17','-O3',code,'-o',binary],check=True)
 qs=json.loads((h.parent/'runs/common_all.json').read_text())['native_intervals']
 def extract(r):
  a,b=map(F,r['interval']);D=r['denominator'];cc=domains(a,b,F(r['cap']),D)
  with tempfile.TemporaryDirectory() as temp:
   d=Path(temp);p=d/'in';bad=d/'bad';p.write_text(f'{len(cc)} {D}\n'+'\n'.join(' '.join(map(str,[len(z),*(c for t in z for c in t)])) for z in cc)+'\n')
   ans=subprocess.check_output([binary,p,'150'],text=True,env=dict(os.environ,N20_BAD_FILE=str(bad)));result=list(map(int,ans.splitlines()[-1].split()[1:]))
   assert result[3]==result[4]==0 and result[5]==r['learned_subsets']
   masks=list(map(int,bad.read_text().split()));assert len(masks)==len(set(masks))==result[5]
   return {'interval':r['interval'],'masks':masks,'scale':D}
 with ThreadPoolExecutor(2) as ex:G=list(ex.map(extract,qs))
 (h/'common_interval_masks.json').write_text(json.dumps(G,separators=(',',':')))
 print(len(G),sum(len(z['masks']) for z in G),flush=True)
if __name__=='__main__':main()
