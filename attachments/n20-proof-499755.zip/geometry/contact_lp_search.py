"""Search the unresolved marked configurations for an actual counterexample.
A fixed choice of separating axis per pair gives an LP in all centers and the
board side. Its dual gives the angular gradient used for discovery."""
from pathlib import Path
from itertools import combinations
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor,as_completed
import numpy as np
from scipy.optimize import linprog,minimize
from scipy.sparse import coo_matrix
import json,os,subprocess,argparse,time,sys,hashlib
h=Path(__file__).resolve().parents[1];sys.path.insert(0,str(h/'global'));from branches import paths
from repair_optimizations import test
N=20;ii,jj=np.triu_indices(N,1);r=np.arange(len(ii));cent=np.arange(N);nlin=2*N+1
def basis(C,a):
 dx=C[jj]-C[ii];co=np.cos(a);si=np.sin(a)
 U=np.stack([np.stack([co[ii],si[ii]],1),np.stack([-si[ii],co[ii]],1),np.stack([co[jj],si[jj]],1),np.stack([-si[jj],co[jj]],1)],1)
 proj=np.einsum('ijk,ik->ij',U,dx);choices=np.argmax(abs(proj),axis=1);sign=np.sign(proj[r,choices]);sign[sign==0]=1
 return choices,sign
def solve(a,choices,sgn):
 co=np.cos(a);si=np.sin(a);angles=a[jj]-a[ii];ca,sa=np.cos(angles),np.sin(angles)
 req=.5*(1+abs(ca)+abs(sa));df=.5*(-sa*np.sign(ca)+ca*np.sign(sa))
 H=.5*(abs(co)+abs(si));dH=.5*(-si*np.sign(co)+co*np.sign(si))
 who=np.where(choices<2,ii,jj);rot=choices%2
 nx=sgn*np.where(rot,-si[who],co[who]);ny=sgn*np.where(rot,co[who],si[who])
 arows=[r,r,r,r];cols=[2*ii,2*ii+1,2*jj,2*jj+1];values=[nx,ny,-nx,-ny];b=[-req];offset=len(r)
 for ax,d in [(0,-1),(1,-1),(0,1),(1,1)]:
  arows.append(offset+cent);cols.append(2*cent+ax);values.append(np.full(N,d))
  if d>0:arows.append(offset+cent);cols.append(np.full(N,2*N));values.append(np.full(N,-1))
  b.append(-H);offset+=N
 M=coo_matrix((np.concatenate(values),(np.concatenate(arows),np.concatenate(cols))),shape=(offset,nlin)).tocsr();c=np.zeros(nlin);c[-1]=1
 opt=linprog(c,A_ub=M,b_ub=np.concatenate(b),bounds=(None,None),method='highs',options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
 if not opt.success:return None
 x=opt.x;C=x[:-1].reshape(N,2);L=x[-1];mu=opt.ineqlin.marginals;lam=mu[:len(r)];delta=C[ii]-C[jj];dn=delta[:,0]*(-ny)+delta[:,1]*nx
 grad=np.zeros(N);np.add.at(grad,ii,lam*df);np.add.at(grad,jj,-lam*df);np.add.at(grad,who,-lam*dn);grad-=mu[len(r):].reshape(4,N).sum(axis=0)*dH
 return float(L),C,grad
def optimize(C,a,rng):
 best=(float('inf'),C,a);history=[]
 for step in range(6):
  choices,sgn=basis(C,a);last={}
  def fun(v):
   vals=solve(v,choices,sgn)
   if vals is None:return 50.,np.zeros(N)
   value,pts,grad=vals
   if value<last.get('best',999):last.update(best=value,ang=v.copy(),center=pts)
   return value,grad
  first=fun(a)[0]
  res=minimize(fun,a,jac=True,method='L-BFGS-B',bounds=[(v-.24,v+.24) for v in a],options={'ftol':1e-13,'maxiter':32,'maxls':12})
  if 'best' not in last:break
  L=last['best'];C=last['center'];a=last['ang'];history.append([first,L])
  if L<best[0]:best=L,C.copy(),a.copy()
  if step and (history[-2][1]-L)<1e-8:
   a=a+rng.normal(0,.012/(step+1),N)
   if step>=3:break
 return best,history
def loadpose(z,owner,out):
 p=paths(5000000,64);env=dict(os.environ,N20_EXTRA_RACKS=str(p['racks'](6)),N20_DEPTH_TABLE=str(p['dep']))
 a,b=z['mask_pair'].split('_');cmd=[h/'advanced/deeper','check',p['tab'],p['profiles'],p['moves'],a,b,'28','3',','.join(map(str,owner)),'-',out]
 res=subprocess.check_output(cmd,input=' '.join(map(str,z['matching']))+'\n',text=True,env=env).split()
 if res[0]=='CLOSED':return None
 assert res[0]=='OPEN';lines=iter(out.read_text().splitlines());b,Z,U=map(int,next(lines).split())
 def poly():
  q,*u=map(int,next(lines).split());return np.array(u).reshape(-1,2)/1e6
 rows=[]
 for i in range(N):
  P=poly();polys=[poly() for k in range(b)];rows.append((P,polys))
 return b,rows
def search(z,owner,seed,folder):
 key=z['mask_pair']+'_'+hashlib.sha256(bytes(z['matching'])).hexdigest()[:12]+'_'+','.join(map(str,owner))+'_'+str(seed);dest=folder/(key+'.json')
 if dest.exists():return json.loads(dest.read_text())
 temp=folder/(key+'.state');charts=loadpose(z,owner,temp)
 if charts is None:return None
 b,rows=charts;rng=np.random.default_rng(78387+seed);C=[];a=[]
 for X,ps in rows:
  active=np.array([k for k in range(b) if len(ps[k])]);w=np.array([max(.0001,np.prod(np.ptp(ps[k],axis=0))**.35) for k in active])
  if seed%3==0:w*=np.exp(-np.minimum(active,b-1-active)/7)
  k=rng.choice(active,p=w/w.sum());C.append(.75*ps[k].mean(0)+.25*X.mean(0));a.append(2*np.arctan((k+.5)/b))
 best,history=optimize(np.asarray(C),np.asarray(a),rng);L,C,a=best
 if not np.isfinite(L):return None
 r={'mask_pair':z['mask_pair'],'matching':z['matching'],'owners':owner,'seed':seed,'coordinates':[*C.ravel().tolist(),*a.tolist(),L],'history':history,'search_only':True}
 cap,scale,at=test(r,True);r.update(repaired_side=str(cap),repaired_decimal=float(cap),below_five=bool(cap<5))
 dest.write_text(json.dumps(r,separators=(',',':')));temp.unlink(missing_ok=True);return r
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--max',type=int,default=180);ap.add_argument('--workers',type=int,default=1);v=ap.parse_args();folder=h/'trials/contact_lp';folder.mkdir(exist_ok=True);seen=set();completed=0
 while completed<v.max:
  jobs=[]
  for p in sorted((h/'trials/cap5000000_ep1').glob('*.json')):
   z=json.loads(p.read_text())
   if z['open_leaves']:
    for seed in (0,1,2):
     for o in z['open_leaves']:
      if (p.name,tuple(o),seed) not in seen:jobs.append((z,o,seed,folder));seen.add((p.name,tuple(o),seed))
  if not jobs:time.sleep(25);continue
  with ThreadPoolExecutor(v.workers) as pool:
   for f in as_completed([pool.submit(search,*job) for job in jobs[:v.max-completed]]):
    res=f.result();completed+=1
    if res:print(completed,res['repaired_decimal'],res['below_five'],res['mask_pair'],flush=True)
if __name__=='__main__':main()
