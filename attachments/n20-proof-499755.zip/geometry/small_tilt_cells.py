"""Exact square-packing band thresholds and the endpoint permutation count."""
from fractions import Fraction as F
from itertools import permutations
from math import acos,asin,pi,sqrt
import json
def check():
 # u0=(1+3/sqrt(5))/2 solves u^2-u-1/5=0. Its bracket below is verified by signs.
 a,b=F(1170820393,10**9),F(1170820394,10**9)
 p=lambda v:v*v-v-F(1,5)
 assert p(a)<0<p(b) and 1<a<b<F(5,4)
 assert F(1,1)/b>F(4,5) and 2*F(2,5)==F(4,5)
 assert F(2,5)**2+F(4,5)**2<1 and 1-F(4,5)**2==F(3,5)**2
 # r=(1+u-u^2)/2, and u0 is the larger root of the required equation.
 assert -p(a)/2==(1+a-a*a)/2-F(2,5)
 count=sum(1 for _ in permutations(range(5)));assert count==120
 u=(1+3/sqrt(5))/2
 return {'rational_bracket_for_cos_plus_sin':[str(a),str(b)],'threshold_degrees_approximate':asin(u*u-1)*90/pi,'vacancy_permutations':count,'row_capacity_for_small_tilt':4,'cell_capacity_for_unrestricted_tilts':2}
if __name__=='__main__':print(json.dumps(check(),indent=2))
