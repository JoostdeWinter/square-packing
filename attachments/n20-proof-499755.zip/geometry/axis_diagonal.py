"""A strict-board verifier with independent choices of 0 or 45 degree angles.

The only irrational constant is a linear parameter r = 1000000*sqrt(2).
An exact rational enclosure is sufficient for a one-sided UNSAT proof.
"""
from pathlib import Path
from functools import lru_cache
from fractions import Fraction as F
from itertools import combinations,product
from collections import Counter
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,math,sys,json,hashlib,time
h=Path(__file__).resolve().parents[1];sys.path[:0]=[str(h/'global'),str(h/'advanced')]
from branches import stamp,atomic
from z3_lra import run
D=1000000;U=5*D
dirs=[(1,0),(0,1),(1,1),(1,-1)]
def dot(p,n):return p[0]*n[0]+p[1]*n[1]
def bounds(p):return [(min(dot(q,n) for q in p),max(dot(q,n) for q in p)) for n in dirs] if p else None
def parse(row,blue):
 n,*z=map(int,row.split());assert len(z)==2*n;p=list(zip(z[::2],z[1::2]));return [(U-y,x) for x,y in p] if blue else p
@lru_cache(maxsize=600)
def prof(directory,mask,blue):
 f=directory/f'p64/{mask}';s=f.read_text().splitlines();head=list(map(int,s[0].split()));assert head==[U,64,22,mask,0]
 ids=[i for i in range(22) if mask>>i&1];assert len(s)==1+20+20*64 and len(ids)==20
 # t=0 represents every axis square. tan(pi/8)=sqrt(2)-1 lies in 26/64..27/64.
 assert (64+26)**2<2*64**2<(64+27)**2
 return {n:(bounds(parse(s[1+i],blue)),[bounds(parse(s[21+i*64+k],blue)) for k in (0,26)]) for i,n in enumerate(ids)}
def number(a):
 if isinstance(a,F) and a.denominator!=1:return '(/ '+number(a.numerator)+' '+str(a.denominator)+')'
 a=int(a);return str(a) if a>=0 else '(- '+str(-a)+')'
def dis(xs):
 xs=list(xs);return 'false' if not xs else xs[0] if len(xs)==1 else '(or '+' '.join(xs)+')'
def and_(xs):
 xs=list(xs);return 'true' if not xs else xs[0] if len(xs)==1 else '(and '+' '.join(xs)+')'
def neg(x):return '(not '+x+')'
def lt(a,b):return '(< '+a+' '+b+')'
def add(a,b):return '(+ '+a+' '+b+')'
def sub(a,b):return '(- '+a+' '+b+')'
def implies(a,b):return '(=> '+a+' '+b+')'
def fresh(dir,k,m,marks_only=False,local_marks=False):
 ma,mb=map(int,k.split('_'))
 if marks_only or local_marks:
  # Deduce all domains from just the assigned original marks and board walls.
  rows=(h/'proofs/cap5000000/moves.txt').read_text().splitlines();pts=[tuple(map(int,ln.split()[:2])) for ln in rows[1:]];assert rows[0]=='22 5000000' and len(pts)==22
  rect=[(0,0),(0,U),(U,U),(U,0)];board=bounds(rect)
  blobs=[list(map(int,ln.split())) for ln in rows[1:]]
  move=[[tuple(z) for z in zip(v[3::2],v[4::2])] for v in blobs]
  racks=[[pts,move],[[(U-y,x) for x,y in pts],[[(U-y,x) for x,y in opts] for opts in move]]]
  extra=[]
  if local_marks:
   lines=(h/'proofs/cap5000000/racks14.txt').read_text().splitlines();assert lines[0]=='5000000 14'
   for ln in lines[1:]:
    n,*vals=map(int,ln.split());assert len(vals)==2*n;extra.append(list(zip(vals[::2],vals[1::2])))
  def initial(mask,blue):
   return {j:(bounds([(U-y,x) if blue else (x,y)]),[board,board]) for j,(x,y) in enumerate(pts) if mask>>j&1}
  A=initial(ma,False);B=initial(mb,True)
 else:A=prof(dir,ma,False);B=prof(dir,mb,True)
 assert len(m)==20 and set(m)==set(B);S=[];r='r';half='(/ r 2)'
 inputs=[];axisSites={};shapes=[]
 emit=lambda term:S.append('(assert '+term+')')
 def var(k,ty):S.append('(declare-fun '+k+' () '+ty+')');return k
 S.extend(['(set-logic QF_LRA)','(declare-fun r () Real)'])
 # With rational constants an UNSAT proof proves the actual irrational parameter.
 den=10**12;lo=F(math.isqrt(2*(D*den)**2),den);hi=lo+F(1,den);assert lo*lo<2*D*D<hi*hi
 emit(lt(number(lo),r));emit(lt(r,number(hi)))
 for i,(a,b) in enumerate(zip(A,m)):
  sx,pa=A[a];sy,pb=B[b];seed=[(min(x[0],y[0]),max(x[1],y[1])) for x,y in zip(sx,sy)]
  x=var(f'x{i}','Real');y=var(f'y{i}','Real');pos=(x,y,add(x,y),sub(x,y));diag=var(f'g{i}','Bool');inputs.append((pos,diag));row=[]
  for typ,g in enumerate((neg(diag),diag)):
   p,q=pa[typ],pb[typ];clauses=[]
   if not p or not q:emit(neg(g));row.append(None);continue
   bound=[[max(v[0],w[0]),min(v[1],w[1])] for v,w in zip(p,q)];radius=half if typ else str(D//2);approx=(math.floor(lo/2),math.ceil(hi/2)) if typ else (D//2,D//2)
   for j in (0,1):
    bound[j][0]=max(bound[j][0],approx[0]);bound[j][1]=min(bound[j][1],U-approx[0]);clauses.extend([lt(radius,pos[j]),lt(pos[j],sub(str(U),radius))])
   for j in ((2,3) if typ else (0,1)):
    l,v=seed[j];bound[j][0]=max(bound[j][0],v-approx[1]);bound[j][1]=min(bound[j][1],l+approx[1])
    clauses.extend(['(<= '+sub(number(v),radius)+' '+pos[j]+')','(<= '+pos[j]+' '+add(number(l),radius)+')'])
   # Project the intersection consistently into the four coordinate axes.
   for a0 in range(3):
    (xl,xh),(yl,yh),(pl,ph),(ml,mh)=bound
    cand=[((pl+ml)//2,-(-(ph+mh)//2)),((pl-mh)//2,-(-(ph-ml)//2)),(xl+yl,xh+yh),(xl-yh,xh-yl)]
    bound=[(max(l,L),min(v,V)) for (l,v),(L,V) in zip(bound,cand)]
   if any(l>v for l,v in bound):emit(neg(g));row.append(None);continue
   for j,(l,v) in enumerate(bound):clauses.extend(['(<= '+number(l)+' '+pos[j]+')','(<= '+pos[j]+' '+number(v)+')'])
   if local_marks:
    js=(2,3) if typ else (0,1)
    def inside(pt):
     alltests=[]
     for kk in js:
      zz=dot(pt,dirs[kk]);l,u=bound[kk]
      if u<zz-approx[1] or l>zz+approx[1]:return 'false'
      if l<zz-approx[0]:alltests.append('(>= '+pos[kk]+' '+sub(number(zz),radius)+')')
      if u>zz+approx[0]:alltests.append('(<= '+pos[kk]+' '+add(number(zz),radius)+')')
     return and_(alltests)
    for col,(idx,mask_) in enumerate(((a,ma),(b,mb))):
     pp,mv=racks[col];z=pp[idx];dist=var(f'near_{i}_{typ}_{col}','Real')
     for j0 in js:
      c0=number(dot(z,dirs[j0]));clauses.extend(['(>= '+dist+' '+sub(pos[j0],c0)+')','(>= '+dist+' '+sub(c0,pos[j0])+')'])
     clauses.append('(<= '+dist+' '+radius+')')
     for k0,pt in enumerate(pp):
      if k0==idx:continue
      terms=[];trivial=False
      for kk in js:
       l,u=bound[kk];zz=dot(pt,dirs[kk])
       if l-zz>=approx[1] or zz-u>=approx[1]:trivial=True;break
       if u>=zz:terms.append('(>= '+sub(pos[kk],number(zz))+' '+dist+')')
       if l<=zz:terms.append('(>= '+sub(number(zz),pos[kk])+' '+dist+')')
      if not trivial:clauses.append(dis(terms))
     holes=[inside(pt) for kk,pt in enumerate(pp) if not mask_>>kk&1];assert len(holes)==2
     clauses.append(dis([*holes,and_(inside(q0) for q0 in mv[idx])]))
    for pattern in extra:
     alt=[inside(p0) for p0 in pattern]
     if 'true' not in alt:clauses.append(dis(q0 for q0 in alt if q0!='false'))
   if not typ:
    poss=[]
    for px,py in product(range(1,5),repeat=2):
     c=[px*D,py*D];cells=[]
     if any(bound[n][1]<=c[n]-D//2 or bound[n][0]>=c[n]+D//2 for n in (0,1)):continue
     sel=var(f'a{i}_{px}_{py}','Bool');poss.append(sel);axisSites.setdefault((px,py),[]).append(sel)
     for j in (0,1):cells.extend([lt(number(c[j]-D//2),pos[j]),lt(pos[j],number(c[j]+D//2))])
     emit(implies(sel,and_([g,*cells])))
    clauses.append(dis(poss))
   emit(implies(g,and_(clauses)));row.append(bound)
  shapes.append(row)
 for sel in axisSites.values():
  for i,j in combinations(sel,2):emit(dis([neg(i),neg(j)]))
 for i,j in combinations(range(20),2):
  X,g=inputs[i];Y,v=inputs[j]
  for a,b in product((0,1),repeat=2):
   A=shapes[i][a];B=shapes[j][b]
   if A is None or B is None:continue
   if a==b==0:tests=[(k,str(D),D,D) for k in (0,1)]
   elif a==b==1:tests=[(k,r,lo,hi) for k in (2,3)]
   else:tests=[(k,add(str(D//2),half),D//2+lo/2,D//2+hi/2) if k<2 else (k,add(str(D),half),D+lo/2,D+hi/2) for k in range(4)]
   ok=False;alts=[]
   for k,threshold,lb,ub in tests:
    for (lo1,hi1),(lo2,hi2),p,q in [(A[k],B[k],X[k],Y[k]),(B[k],A[k],Y[k],X[k])]:
     if hi1-lo2<=lb:continue
     if lo1-hi2>ub:ok=True;break
     alts.append(lt(add(q,threshold),p))
    if ok:break
   if not ok:emit(implies(and_([g if a else neg(g),v if b else neg(v)]),dis(alts)))
 return '\n'.join(S)+'\n(check-sat)\n'
def main(v):
 d=v.cold.resolve();screen=v.screen.resolve();out=v.out.resolve();out.mkdir(exist_ok=True,parents=True)
 z=json.loads((screen/'open_matchings.json').read_text());n=json.loads((screen/'screen_verified.json').read_text());assert n['side_micro']==U
 tasks=[(k,m) for k,arr in z.items() for m in arr];assert len(tasks)==n['counts']['surviving']==1142
 clock=time.monotonic();ct=Counter()
 def one(job):
  k,m=job;f=out/(stamp(k,m)+'.json')
  if f.is_file():
   old=json.loads(f.read_text())
   if old['status']=='unsat' or not v.retry:return old
  s=fresh(d,k,m,v.marks_only,v.local_marks);status,other=run(s,v.time*1000)
  assert status in ('unsat','sat','unknown');res={'key':k,'matching':m,'sha256':hashlib.sha256(s.encode()).hexdigest(),'status':status}
  if status=='sat':
   keys=[f'{nm}{i}' for i in range(20) for nm in ('g','x','y')];_,model=run(s,v.time*1000,'(get-value (r '+' '.join(keys)+'))');res['model']=model
  atomic(f,res);return res
 if v.limit:tasks=tasks[:v.limit]
 with ThreadPoolExecutor(v.jobs) as ex:
  for j,t in enumerate(as_completed([ex.submit(one,job) for job in tasks]),1):
   row=t.result();ct[row['status']]+=1
   if j%25==0 or row['status']=='sat':print(j,dict(ct),int(time.monotonic()-clock),flush=True)
 if len(tasks)==1142:
  receipt={'method':'exact_linear_arithmetic_with_sqrt2_enclosure','angle_choices_degrees':[0,45],'marks_only':v.marks_only,'nearest_moves_and_racks':v.local_marks,'screened_matchings':len(tasks),'counts':ct,'pending':len(tasks)-ct['unsat']};atomic(out/'summary',receipt)
  if not receipt['pending']:atomic(out/'verified',receipt)
 print('finished',dict(ct),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('cold',type=Path);p.add_argument('screen',type=Path);p.add_argument('out',type=Path);p.add_argument('--time',type=int,default=10);p.add_argument('--jobs',type=int,default=3);p.add_argument('--limit',type=int);p.add_argument('--retry',action='store_true');p.add_argument('--marks-only',action='store_true');p.add_argument('--local-marks',action='store_true');main(p.parse_args())
