"""Search small-tilt obstructions with one aligned tile and nineteen independently reflected equal tilts."""
from itertools import permutations,product,combinations
from functools import lru_cache
from collections import Counter
from signed_angle_graphs import pattern,models
from near_grid import bridges
from turning_orders import arms
from pathlib import Path
import argparse,json,time,gzip
h=Path(__file__).resolve().parents[1]
@lru_cache(maxsize=None)
def patterns(p,z):
 A,_,_=pattern(p);idx={q:i for i,q in enumerate(A)};bs=bridges(set(enumerate(p)));opts=[]
 for j,q in enumerate(bs):
  pair=[]
  for k in range(2):
   sig,L,R=arms(q,k);l=[idx[i] for i in L];r=[idx[i] for i in R]
   if z in l[1:] or z in r[1:]:pair.append(None);continue
   bits=sum(1<<i for i in l+r if i!=z);pair.append((bits,0) if sig>0 else (0,bits))
  opts.append(pair)
 possible=set();all_=((1<<20)-1)^(1<<z)
 for choices in product(*opts):
  pos=neg=0
  if None in choices:continue
  for a,b in choices:pos|=a;neg|=b
  if pos&neg:continue
  free=all_^(pos|neg);tail=free
  while True:
   possible.add(pos|tail)
   if not tail:break
   tail=(tail-1)&free
 return sorted(possible)
@lru_cache(maxsize=120)
def images(p):
 A,_,_=pattern(p);out=[]
 for swap,fx,fy in product((0,1),repeat=3):
  def transform(x,y):
   if swap:x,y=y,x
   return (4-x if fx else x,4-y if fy else y)
  P=tuple(y for x,y in sorted(transform(*q) for q in enumerate(p)));pts=sorted(map(lambda z:transform(*z),A));mapping=tuple(pts.index(transform(*u)) for u in A);out.append((P,mapping,swap^fx^fy))
 return out
def canon(p,s,z):
 a=[]
 for P,mapper,flip in images(p):
  Z=mapper[z];S=sum(1<<j for i,j in enumerate(mapper) if i!=z and ((s>>i&1)^flip));a.append((P,S,Z))
 return min(a)
def signs(s,z):return tuple(0 if v==z else 1 if s>>v&1 else -1 for v in range(20))
def clauses(p,s,z):
 from equal_path_polynomial import full_paths
 st=set();sig=signs(s,z)
 for dim,mask,rows,idx in full_paths(p):
  a=[sig[i] for i in idx]
  cost=abs(a[0])+abs(a[-1])+sum(abs(v-u) if j==k else -(k-j)*(v+u) for u,v,j,k in zip(a,a[1:],rows,rows[1:]))
  if cost>0:st.add((mask,0) if dim else (0,mask))
 out=[]
 for x,y in sorted(st,key=lambda q:(q[0]|q[1]).bit_count()):
  if not any(a&x==a and b&y==b for a,b in out):out.append((x,y))
 return out
def rule_pair(pos,i,j,dim,sg):
 old_a,old_b=i,j
 if pos[i][dim]>pos[j][dim]:i,j=j,i
 ai=sg[i];aj=sg[j];ci=5*pos[i][0]+pos[i][1];cj=5*pos[j][0]+pos[j][1];trans=pos[j][1-dim]-pos[i][1-dim]
 if ai==aj:return ('aligned' if ai==0 else 'same',ci,cj,dim,ai)
 if ai and aj:return ('mixdiag' if trans else 'mixedstraight',ci,cj,dim,trans)
 # If the tilted normal leans in the helpful direction on a diagonal,
 # the board-axis separation implies its tilted inequality, since
 # the transverse displacement is greater than H*t. In the unfavorable
 # direction a tilted separation already implies board-axis separation.
 tilt=ai or aj;n=tilt if dim==0 else -tilt
 if not trans:return ('zero_straight',ci,cj,dim,0)
 if n*trans>0:return ('zero_favored',ci,cj,dim,n)
 return ('zero_flat',ci,cj,dim,0)
def rows(p,s,z,m):
 pos,diags,_=pattern(p);sg=signs(s,z);idx={q:i for i,q in enumerate(pos)};out=[]
 for i,(x,y) in enumerate(pos):
  ci=5*x+y
  for dim,q in enumerate((x,y)):
   for k in (-1,1):out.extend([('wall' if sg[i] else 'wall0',ci,dim,k),('rank',ci,dim,k,q)])
   other=(x+(dim==0),y+(dim==1))
   if other in idx:out.append(rule_pair(pos,i,idx[other],dim,sg))
 for j,(u,v) in enumerate(diags):out.append(rule_pair(pos,u,v,0 if m>>j&1 else 1,sg))
 return tuple(out)
def main(v):
 from fractions import Fraction as F
 assert (20*(1+F(1,64))+F(24,5)+F(2,3*64))/64<F(1,2)
 d=h/'trials/one_axis';d.mkdir(exist_ok=True);todo=set();count=0;tic=time.monotonic()
 for i,p in enumerate(permutations(range(5))):
  for z in range(20):
   ls=patterns(p,z);count+=len(ls);todo.update(canon(p,s,z) for s in ls)
  if i%20==19:print('signs',i+1,count,len(todo),int(time.monotonic()-tic),flush=True)
 out=[];graphs=0;tot=0
 for i,(p,s,z) in enumerate(sorted(todo)):
  A,E,_=pattern(p);cs=clauses(p,s,z);ms=models(cs,len(E),v.first)
  if ms:out.append((p,s,z,len(ms)));graphs+=len(ms)
  if i%250==249:print('reps',i+1,len(todo),len(out),graphs,int(time.monotonic()-tic),flush=True)
 dest=d/('feasible_only.json' if v.first else 'full_counts.json');dest.write_text(json.dumps({'initial_sign_cases':count,'canonical':len(todo),'retained_count':len(out),'total_graphs_or_first_witnesses':graphs,'records':out},separators=(',',':')));print('complete',count,len(todo),len(out),graphs,flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--first',action='store_true');main(p.parse_args())
