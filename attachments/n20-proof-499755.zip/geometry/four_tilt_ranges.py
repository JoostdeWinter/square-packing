"""Replay exact linear outer enclosures for four independent nonzero tilt ranges.

Each positive half-angle interval is supplemented by its reflected interval.
UNSAT on the full union is sufficient for exclusion for arbitrary positions.
"""
from four_tilt_smt import *
from four_tilt_palette import z3_lra
def reflected(bands):
 raw=sorted(set(list(bands)+[((1-b)/(1+b),(1-a)/(1+a)) for a,b in bands]))
 assert all(0<=a<=b<=1 for a,b in raw);return raw
def check(i,C,bands,timelimit,mode):
 opts=[bands]*4
 if mode=='physical':data=model(C,len(bands),opts,details=True,strict_physical=True)
 elif mode=='mesh':
  from mesh_chord_intervals import generate
  data=generate(C,len(bands),opts,full=False)
 else:
  from mesh_chord_intervals import generate
  data=generate(C,len(bands),opts,full=True)
 status,_=z3_lra.run(data,timelimit*1000)
 assert status in ('unknown','unsat','sat')
 return {'case':i,'cells':C,'intervals':[[str(a),str(b)] for a,b in bands],'status':status,'sha256':hashlib.sha256(data.encode()).hexdigest(),'mode':mode}
def main(v):
 bands=reflected([tuple(map(F,z.split(':'))) for z in v.ranges.split(',')]);d=h/f'trials/mesh_ranges_{v.tag}';d.mkdir(exist_ok=True);total=Counter();start=time.monotonic()
 def one(job):
  i,C=job;f=d/f'{i:02}.json'
  if f.exists():
   prior=json.loads(f.read_text())
   if prior['status']=='unsat' or not v.retry:return prior
  result=check(i,C,bands,v.time,v.mode);f.write_text(json.dumps(result));return result
 items=list(enumerate(sets()))
 with ThreadPoolExecutor(v.jobs) as ex:
  for a in as_completed([ex.submit(one,j) for j in items]):
   r=a.result();total[r['status']]+=1;print(r['case'],r['status'],dict(total),int(time.monotonic()-start),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('ranges');p.add_argument('--mode',choices=('physical','mesh','full'),default='physical');p.add_argument('--tag',required=True);p.add_argument('--jobs',type=int,default=2);p.add_argument('--time',type=int,default=20);p.add_argument('--retry',action='store_true');main(p.parse_args())
