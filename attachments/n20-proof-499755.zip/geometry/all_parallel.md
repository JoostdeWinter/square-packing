# Twenty parallel unit squares

Twenty parallel unit squares can be packed into a square of side 5. A packing at any common tilt different from zero modulo 90° requires a board strictly larger than 5. Translations of all twenty squares are independent. Thus the minimum in the common-orientation problem is exactly 5, and every packing at that side uses a board-axis orientation.

Use the tile axes as coordinates for the centers. Two parallel unit squares have disjoint interiors exactly when at least one coordinate difference of their centers has absolute value at least 1. Write t=tan(θ/2), and use board symmetry to reduce the common angle to 0≤θ≤45°. The grid establishes feasibility at zero. Below 5, axis-parallel centers lie in an axis-parallel box of width less than 4, which can be split into sixteen squares of width less than 1.

For 0<t≤1/31, the 41 polynomial certificates and their exhaustive assignment check are described in parallel.md. They exclude the closed board of side 5.

For 1/31≤t≤3/20, the proof uses 31 rational intervals. At each common tilt the center of a tile must have its two board coordinates within a centered square of side 5−cos(θ)−sin(θ). In the tile frame this square is rotated by −θ. For an angular interval use its rational half-angle midpoint as a reference. Enlarge the reference square by the maximum of the side at the endpoints and by the maximum of cos(Δ)+|sin(Δ)| over the interval. The latter maximum occurs at an endpoint. This gives a single rational polygon containing the full center domain. Its coordinate bounding box can be divided into 25 closed cells of width less than 1 along both coordinates. Assign each center to one cell that contains it. Two centers cannot occupy one cell.

Each of the 53,130 choices of twenty cells contains a certified impossible subset. A subset is eliminated using outer polygons for its possible centers. If only one signed coordinate can separate a pair by 1, the present extrema of each polygon give necessary bounds for the other. A candidate center also cannot lie in the open rectangle in which every possible position of its neighbor would be less than 1 away in both coordinates. These operations use integer geometry with intersections rounded outward. A contradiction occurs when a necessary center domain is empty or a pair has no possible separating coordinate. The independent verifier checks all 7,360 small subsets from their initial polygons and exhausts all twenty-cell choices in each interval.

For 3/20≤t≤√2−1, twenty-seven certificates cover intervals reaching 21/50>√2−1. Each gives a fractional cover of the center domain by half-open unit windows with total weight less than 20. Every admissible center receives weight at least 1. A half-open unit window contains at most one center, including when other tiles touch. The checker includes grid boundaries of the closed center domain, including its top and right extremes. It uses rational arithmetic for the geometry and integer arithmetic for every weight sum. The largest of the twenty-seven total weights is 19.8571571.

The complete verification requires Python's standard library and the certificate files:

    python3 geometry/check_common.py --workers 3 --receipt common-verified.json

Translations remain independent throughout. The unrestricted problem allows relative rotations too.
