"""Independent standard-library verifier of the all-parallel five-square endpoint."""
from fractions import Fraction as F
from itertools import combinations,product
from math import floor,ceil,comb
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from collections import defaultdict
import json,argparse
from verify_parallel import main as verify_axis
from common_all import rows_closed
from parallel_fractional import certify
import parallel_fractional
h=Path(__file__).resolve().parent
def orient(t):return (1-t*t)/(1+t*t),2*t/(1+t*t)
def cross(o,a,b):return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
def hull(points):
 s=sorted(set(points))
 if len(s)<3:return s
 def seq(items):
  b=[]
  for p in items:
   while len(b)>1 and cross(b[-2],b[-1],p)<=0:b.pop()
   b.append(p)
  return b[:-1]
 return seq(s)+seq(s[::-1])
def clip(poly,axis,sign,bound,rational):
 if not poly:return []
 output=[];p=poly[-1];u=sign*p[axis]-bound
 for q in poly:
  v=sign*q[axis]-bound
  if (u<0<v) or (u>0>v):
   d=u-v;x=q[0]*u-p[0]*v;y=q[1]*u-p[1]*v
   if rational:output.append((x/d,y/d))
   else:output.extend(product((x//d,-((-x)//d)),(y//d,-((-y)//d))))
  if v<=0:output.append(q)
  p,u=q,v
 return output if rational else hull(output)
def cells(a,b,scale):
 lc,ls=orient(a);rc,rs=orient(b);c,s=orient((a+b)/2)
 width=max(5-lc-ls,5-rc-rs)
 factor=max(c*x+s*y+abs(s*x-c*y) for x,y in [(lc,ls),(rc,rs)])
 t=width*factor/2
 rect=[(c*x+s*y,c*y-s*x) for x,y in [(-t,-t),(t,-t),(t,t),(-t,t)]]
 lim=max(max(point) for point in rect);intervals=[-lim+2*lim*i/5 for i in range(6)];result=[]
 for i,j in product(range(5),repeat=2):
  p=rect
  for dim,k in enumerate((i,j)):
   p=clip(p,dim,-1,-intervals[k],True);p=clip(p,dim,1,intervals[k+1],True)
  if p:
   rr=hull(z for pt in p for z in product(*[(floor(q*scale),ceil(q*scale)) for q in pt]))
   bb=bbox(rr);assert bb[1]-bb[0]<scale and bb[3]-bb[2]<scale
   result.append(rr)
 return result
def bbox(poly):
 xs,ys=zip(*poly);return min(xs),max(xs),min(ys),max(ys)
def bad(ori,D):
 P=[list(q) for q in ori];n=len(P)
 for it in range(100):
  B=list(map(bbox,P));fixed=[];change=False
  for i,j in combinations(range(n),2):
   opts=[];certain=False
   for k in (0,1):
    d=2*k
    for x,y in ((i,j),(j,i)):
     if B[y][d]-B[x][d+1]>=D:certain=True
     if B[y][d+1]-B[x][d]>=D:opts.append((x,y,k))
   if certain:continue
   if not opts:return True
   if len(opts)==1:fixed.extend(opts)
  for i,j,k in fixed:
   d=2*k;bound=B[j][d+1]-D
   if B[i][d+1]>bound:
    if B[i][d]>bound:return True
    q=clip(P[i],k,1,bound,False)
    if not q:return True
    if q!=P[i]:P[i]=q;B[i]=bbox(q);change=True
   bound=B[i][d]+D
   if B[j][d]<bound:
    if B[j][d+1]<bound:return True
    q=clip(P[j],k,-1,-bound,False)
    if not q:return True
    if q!=P[j]:P[j]=q;B[j]=bbox(q);change=True
  if it%3==0:
   for j in range(n):
    for i in range(n):
     if i==j:continue
     x,X,y,Y=B[j];l,r,b,t=X-D,x+D,Y-D,y+D
     x,X,y,Y=B[i]
     if X<=l or x>=r or Y<=b or y>=t:continue
     if x>l and X<r and y>b and Y<t:return True
     if not any(l<x<r and b<y<t for x,y in P[i]):continue
     q=hull(pt for c in [(0,1,l),(0,-1,-r),(1,1,b),(1,-1,-t)] for pt in clip(P[i],*c,False))
     if not q:return True
     if q!=P[i]:P[i]=q;B[i]=bbox(q);change=True
  if not change:return False
 return False
def stage(row):
 a,b=map(F,row['interval']);D=row['scale'];P=cells(a,b,D);n=len(P);masks=row['masks'];assert n==25
 for m in masks:
  assert 0<m<1<<n and bad([v for j,v in enumerate(P) if m>>j&1],D),(a,b,m)
 # Enumerate every possible set of twenty occupied cells and exhibit an
 # already excluded subset. A five-cell vacancy masks an excluded subset
 # exactly when their bit sets are disjoint.
 count=0
 for holes in combinations(range(n),n-20):
  z=sum(1<<j for j in holes)
  assert any(z&m==0 for m in masks),(a,b,holes)
  count+=1
 return str(a),str(b),len(masks),count
def main(workers):
 verify_axis()
 data=json.loads((h/'common_interval_masks.json').read_text());pos=F(1,31)
 with ProcessPoolExecutor(workers) as e:rows=list(e.map(stage,data))
 for a,b,_,_ in rows:
  assert F(a)==pos;pos=F(b)
 assert pos==F(3,20)
 parallel_fractional.pixel_intervals=rows_closed
 fdata=h.parent/'trials/parallel_fractional';controls=[]
 for j in range(15,42):
  a,b=F(j,100),F(j+1,100);f=fdata/f'cert_{a.numerator}_{a.denominator}_{b.numerator}_{b.denominator}.json'
  r=json.loads(f.read_text());assert list(map(F,r['interval']))==[a,b]
  least,total=certify(r);assert least>=r['weight_denominator'] and total<20*r['weight_denominator']
  controls.append(F(total,r['weight_denominator']))
 assert (1+F(21,50))**2>2
 out={'all_common_orientations':True,'nonzero_common_tilt_excludes_closed_side_five':True,'center_positions':'all independent translations','polynomial_duals_near_zero':41,'middle_angle_intervals':len(rows),'middle_excluded_subsets':sum(r[2] for r in rows),'twenty_site_choices_per_interval':comb(25,20),'fractional_covers':len(controls),'largest_fractional_mass':str(max(controls))}
 print(json.dumps(out,indent=2));return out
if __name__=='__main__':ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=2);ap.add_argument('--receipt',type=Path);v=ap.parse_args();ans=main(v.workers);v.receipt and v.receipt.write_text(json.dumps(ans,indent=2))
