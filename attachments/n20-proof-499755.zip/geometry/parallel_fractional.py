"""Search and exactly replay fractional unit-square covers in a fixed tile frame."""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
from itertools import product
import json,sys,argparse
from parallel_cover import pixel_intervals
h=Path(__file__).resolve().parent
def certify(row):
 a,b=map(F,row['interval']);q=row['scale'];off=list(map(F,row['offset']));tiles=row['windows'];den=row['weight_denominator'];rs=pixel_intervals(a,b,q,off)
 assert den>0 and all(type(u)is int and type(v)is int and type(w)is int and w>=0 for u,v,w in tiles)
 least=10**20
 for y,(l,r) in rs.items():
  events=defaultdict(int)
  for x,Y,w in tiles:
   if Y<=y<Y+q:
    events[x]+=w;events[x+q]-=w
  mass=sum(w for x,w in events.items() if x<=l);least=min(least,mass)
  for x,v in sorted(events.items()):
   if l<x<r:mass+=v;least=min(least,mass)
 total=sum(w for x,y,w in tiles)
 return least,total
def solve(a,b,q,offset):
 import numpy as np
 from scipy.optimize import linprog
 from scipy.sparse import coo_matrix
 rows=pixel_intervals(a,b,q,offset);xl=min(x for x,z in rows.values());X=max(z for x,z in rows.values());yl=min(rows);Y=max(rows)+1
 # Weights at lower-left points x,y within the bounding rectangle, shifted so
 # each q by q window lies inside that rectangle. Shifting exterior windows
 # inward can only increase coverage of the target pixels.
 nx=X-xl-q+1;ny=Y-yl-q+1
 def ix(i,j):
  if i<0 or j<0:return -1
  return min(i,nx-1)*ny+min(j,ny-1)
 data=[];col=[];starts=[0];rhs=[]
 # Variables are the cumulative sums of window weights. Finite differences
 # enforce nonnegative weights; a q by q rectangle sum gives each pixel's coverage.
 def eq(terms,y):
  for i,j,v in terms:
   k=ix(i,j)
   if k>=0:col.append(k);data.append(v)
  starts.append(len(col));rhs.append(y)
 for i,j in product(range(nx),range(ny)):
  eq([(i,j,-1),(i-1,j,1),(i,j-1,1),(i-1,j-1,-1)],0)
 for y,(l,r) in rows.items():
  j=y-yl
  for x in range(l,r):
   i=x-xl;eq([(i,j,-1),(i-q,j,1),(i,j-q,1),(i-q,j-q,-1)],-1)
 from scipy.sparse import csr_matrix
 A=csr_matrix((data,col,starts),shape=(len(rhs),nx*ny));obj=np.zeros(nx*ny);obj[-1]=1
 opt=linprog(obj,A_ub=A,b_ub=rhs,bounds=(0,None),method='highs',options={'time_limit':110})
 if not opt.success:return None,str(opt.message)
 total=opt.fun;out=[]
 V=np.pad(opt.x.reshape(nx,ny),((1,0),(1,0)));W=V[1:,1:]-V[:-1,1:]-V[1:,:-1]+V[:-1,:-1]
 den=10**7
 for i,j in zip(*np.nonzero(W>1e-9)):
  out.append([int(i)+xl,int(j)+yl,int(np.ceil((W[i,j]+2e-8)*den))])
 row={'interval':[str(a),str(b)],'scale':q,'offset':list(map(str,offset)),'weight_denominator':den,'windows':out}
 least,k=certify(row)
 if least<=0:raise ValueError('zero covering')
 row['weight_denominator']=min(den,least)
 assert certify(row)[0]>=row['weight_denominator']
 return row,float(k/row['weight_denominator'])
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--q',type=int,default=12);ap.add_argument('--ranges',nargs='+',default=['1/20,1/20','1/10,1/10','3/20,3/20','1/5,1/5','1/4,1/4','3/10,3/10','7/20,7/20','2/5,2/5']);ap.add_argument('--verify');v=ap.parse_args()
 if v.verify:
  row=json.loads(Path(v.verify).read_text());least,total=certify(row);assert least>=row['weight_denominator'] and total<20*row['weight_denominator'];print(least,total);return
 out=h.parent/'trials/parallel_fractional';out.mkdir(exist_ok=True)
 for z in v.ranges:
  a,b=map(F,z.split(','));row,score=solve(a,b,v.q,[F(0),F(0)])
  print(z,'scale',v.q,'cover',score,flush=True)
  if row and score<20:
   f=out/f'cert_{a.numerator}_{a.denominator}_{b.numerator}_{b.denominator}.json';f.write_text(json.dumps(row,separators=(',',':')))
if __name__=='__main__':main()
