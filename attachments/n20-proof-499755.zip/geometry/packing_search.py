"""Search for a counterexample by allowing the 20 tiles to translate and rotate separately."""
import numpy as np
from scipy.optimize import minimize
from pathlib import Path
from itertools import permutations,combinations,product
import json,os,sys,time
h=Path(__file__).resolve().parents[1]
def canonical(p):
 pts=set(enumerate(p));variants=[]
 for sw,a,b in product(range(2),repeat=3):
  G=[(4-x if a else x,4-y if b else y) for x,y in [((y,x) if sw else (x,y))for x,y in pts]]
  variants.append(tuple(dict(G)[i] for i in range(5)))
 return min(variants)
def optimize(p,seed,angles,radius):
 rng=np.random.default_rng(seed)
 P=np.array([[x+.5,y+.5] for x,y in product(range(5),repeat=2) if p[x]!=y])
 n=len(P);jj,kk=np.triu_indices(n,1)
 if radius<.38 and angles<.25:
  take=np.max(abs(P[jj]-P[kk]),axis=1)<2;jj=jj[take];kk=kk[take]
 q=len(jj);rows=np.arange(q);coords=np.arange(n);nvar=3*n+1;cache={}
 def con(z,jac):
  if 'z' in cache and np.array_equal(z,cache['z']) and (not jac or cache.get('J') is not None):return cache['J'] if jac else cache['f']
  C=z[:2*n].reshape(n,2);a=z[2*n:-1];S=z[-1]
  co=np.cos(a);si=np.sin(a);u=(abs(co)+abs(si))/2
  du=(-si*np.sign(co)+co*np.sign(si))/2
  delta=C[kk]-C[jj];alpha=a[kk]-a[jj]
  F=.5*(1+abs(np.cos(alpha))+abs(np.sin(alpha)))
  dF=.5*(-np.sin(alpha)*np.sign(np.cos(alpha))+np.cos(alpha)*np.sign(np.sin(alpha)))
  ids=np.stack((jj,jj,kk,kk),axis=1)
  nx=np.column_stack([co[jj],-si[jj],co[kk],-si[kk]])
  ny=np.column_stack([si[jj],co[jj],si[kk],co[kk]])
  dots=nx*delta[:,0,None]+ny*delta[:,1,None];choice=np.argmax(abs(dots),axis=1)
  f=np.concatenate((abs(dots[rows,choice])-F,C[:,0]-u,C[:,1]-u,S-u-C[:,0],S-u-C[:,1]))
  cache['f']=f;cache['z']=z.copy();cache['J']=None
  if not jac:return f
  J=np.zeros((q+4*n,nvar));sgn=np.sign(dots[rows,choice]);vx=nx[rows,choice];vy=ny[rows,choice]
  for axis,d in enumerate([vx,vy]):
   J[rows,2*jj+axis]=-sgn*d;J[rows,2*kk+axis]=sgn*d
  J[rows,2*n+jj]=dF;J[rows,2*n+kk]=-dF
  J[rows,2*n+ids[rows,choice]]+=sgn*(-vy*delta[:,0]+vx*delta[:,1])
  for j in range(4):
   r=q+j*n+coords
   J[r,2*coords+j%2]=1 if j<2 else -1;J[r,2*n+coords]=-du
   if j>=2:J[r,-1]=1
  cache['J']=J;return J
 x0=np.r_[(P+rng.normal(0,min(.02,radius*.2),P.shape)).ravel(),rng.normal(0,angles*.4,n).clip(-angles,angles),5.15]
 bounds=[(v-radius,v+radius) for v in P.ravel()]+[(-angles,angles)]*n+[(4.8,5.6)]
 obj=np.zeros(nvar);obj[-1]=1
 result=minimize(lambda z:z[-1],x0,jac=lambda z:obj,bounds=bounds,constraints=[{'type':'ineq','fun':lambda z:con(z,False),'jac':lambda z:con(z,True)}],method='SLSQP',options={'ftol':2e-11,'maxiter':180})
 r=result.x;v=float(min(con(r,False)));s=float(r[-1]);err=max(0.,-v)
 return {'permutation':p,'seed':seed,'angle_limit':angles,'center_radius':radius,'side':s,'minimum_margin':v,'iterations':int(result.nit),'success':bool(result.success),'coordinates':r.tolist(),'discovery_only':True}
def main():
 reps=sorted({canonical(p) for p in permutations(range(5))});assert len(reps)==23
 d=h/'trials/packing_optimization';d.mkdir(exist_ok=True)
 for seed in range(2300):
  path=d/f'{seed:05}.json'
  if path.is_file():continue
  thermal=seed//len(reps);angles=[.075,.16,.36,.70,.035][thermal%5];radius=[.20,.32,.52,.65,.12][thermal%5]
  t=time.monotonic();res=optimize(reps[(seed*7)%23],seed+57301,angles,radius)
  path.write_text(json.dumps(res))
  if seed%10==0 or res['side']<4.99999:print(seed,res['side'],res['minimum_margin'],res['iterations'],round(time.monotonic()-t,2),flush=True)
if __name__=='__main__':main()
