"""Exact rank, turning-chain and small-angle constants with rational examples."""
from fractions import Fraction as F
from itertools import permutations
from collections import Counter
from near_grid import bridges
import json
def check():
 e=F(1,10);d=e*(1+e)
 assert d==F(11,100) and 2*(4*d)**2<1
 assert (1+3*d)*e+4*d<1 and (1-5*d)*(1-e*e/2)>(1+3*d)*e
 assert F(1,2)+F(1,5)/6==F(8,15)
 assert 3*4+3==15 and F(4,15)*(4*4+2)==F(24,5)
 assert F(24,5)+15==F(99,5)
 pat=Counter(len(bridges(list(enumerate(q)))) for q in permutations(range(5)))
 assert pat=={4:92,5:24,6:4}
 def lo(k):return F(1,2)+k-k*d
 def hi(k):return F(1,2)+k+(4-k)*d
 assert all(hi(k)-lo(k)==4*d for k in range(5))
 assert all(hi(k+1)-lo(k)==1+3*d and lo(k+1)-hi(k)==1-5*d for k in range(4))
 # Archimedes' strict upper bound pi<22/7 is sufficient for these conservative displays.
 examples=[]
 for degrees in [F(1,10),F(1,2),F(1),F(2),F(5)]:
  rad=degrees*F(22,7*180);assert rad<=e
  deficit=(F(99,5)+15*rad)*rad*rad
  examples.append({'max_tilt_degrees':str(degrees),'side_at_least_conservative':str(5-deficit),'decimal_rounded_down':f'{((5-deficit)*10**8).__floor__()/10**8:.8f}'})
 return {'angles_independent':True,'center_assumption':'none','max_tilt_radians':'1/10','permutations':sum(pat.values()),'turning_pairs':dict(pat),'examples':examples}
if __name__=='__main__':print(json.dumps(check(),indent=2))
