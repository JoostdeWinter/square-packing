"""Exact leading-sign possibilities for equal and independently reflected tilts."""
from itertools import product,permutations
from collections import Counter
from near_grid import bridges
from turning_orders import arms
from pathlib import Path
import json,argparse
def routings(p):
 vacant=set(enumerate(p));points=sorted(set(product(range(5),repeat=2))-vacant);ids={p:i for i,p in enumerate(points)};E=bridges(vacant);sets=set()
 for m in range(1<<len(E)):
  pos=neg=0
  for j,q in enumerate(E):
   sg,A,B=arms(q,m>>j&1);occupied=sum(1<<ids[z] for z in A+B)
   if sg>0:pos|=occupied
   else:neg|=occupied
  if not pos&neg:sets.add((pos,neg))
 return sorted(sets)
def assignments(p):
 all_=(1<<20)-1;out=set()
 for a,b in routings(p):
  free=all_^a^b;subset=free
  while True:
   out.add(a|subset)
   if not subset:break
   subset=(subset-1)&free
 return out
def main():
 hist=Counter();minor=Counter();free=Counter();some=[]
 for p in permutations(range(5)):
  a=assignments(p);r=routings(p);hist[len(a)]+=1
  for z in a:minor[min(z.bit_count(),20-z.bit_count())]+=1
  for x,y in r:free[20-(x|y).bit_count()]+=1
  if len(a)>2 and len(some)<3:some.append([p,len(a)])
 return {'vacancy_permutations':120,'total_sign_assignments':sum(k*v for k,v in hist.items()),'number_of_sign_assignments_by_pattern':dict(sorted(hist.items())),'minority_size':dict(sorted(minor.items())),'free_at_consistent_routing':dict(sorted(free.items())),'sample':some}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path);v=p.parse_args();s=main();print(json.dumps(s))
 if v.output:v.output.write_text(json.dumps(s,indent=2)+'\n')
