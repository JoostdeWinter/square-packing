"""Verify polynomial Farkas identities with integer arithmetic."""
from pathlib import Path
from math import gcd
from verify_parallel import add,mult,scale,positive
import json
C=[1,0,-1];S=[0,2];D=[1,0,1];Z=add(C,S);ZD=add(Z,scale(D,-1));D2=mult(D,D);CD2=mult(C,D2);CDZ=mult(mult(C,D),Z);ZZD=mult(Z,ZD)
def polyrow(rule):
 k,i,*z=rule
 assert i in range(25)
 if k in ('wall','wall0','rank'):
  ax,sd=z[:2];assert ax in (0,1) and sd in (-1,1);pos=[(2*i+ax,scale(C,sd))]
  if k in ('wall','wall0'):
   assert len(z)==2;return pos,add(scale(CD2,10 if sd==1 else 0),scale(CD2 if k=='wall0' else CDZ,-1))
  assert len(z)==3;g=z[2];assert g==(i//5,i%5)[ax];n=4-g if sd==1 else g
  return pos,add(scale(CD2,sd*(2*g+1)),scale(mult(C,ZZD),2*n))
 j,ax,sg=z;assert k in ('same','mixdiag','mixedstraight','aligned','zero_flat','zero_straight','zero_favored') and j in range(25) and ax in (0,1)
 assert (j//5-i//5,j%5-i%5)[ax]==1
 if k=='same':assert sg in (-1,1);other=scale(S,sg*(1 if ax==0 else -1));b=scale(mult(D2,D),-2)
 elif k.startswith('zero_') or k=='aligned':
  delta=(j//5-i//5,j%5-i%5)[1-ax];other=[]
  if k=='aligned':assert sg==0;b=scale(CD2,-2)
  elif k=='zero_favored':
   assert sg==delta and abs(sg)==1;other=scale(S,sg);b=scale(mult(D2,add(D,Z)),-1)
  else:
   assert sg==0;b=scale(add(CD2,CDZ),-1)
   if k=='zero_straight':assert delta==0;b=add(b,scale(mult(S,ZZD),8))
   else:assert abs(delta)==1
 else:
  b=scale(CDZ,-2)
  if k=='mixdiag':
   assert sg==(j//5-i//5,j%5-i%5)[1-ax] and abs(sg)==1;other=scale(S,sg)
  else:assert sg==0 and (j//5-i//5,j%5-i%5)[1-ax]==0;other=[];b=add(b,scale(mult(S,ZZD),8))
 return [(2*i+ax,C),(2*j+ax,scale(C,-1)),(2*i+1-ax,other),(2*j+1-ax,scale(other,-1))],b
def verify_cert(row,Q=64):
 weights=row['multipliers'];assert len(weights)==len(row['rules']) and len(weights)>1;total=[[] for i in range(50)];rhs=[]
 for r,w in zip(row['rules'],weights):
  assert w and all(type(x)==int for x in w) and positive(w,Q=Q)
  A,b=polyrow(r)
  for k,c in A:total[k]=add(total[k],mult(c,w))
  rhs=add(rhs,mult(b,w))
 assert not any(total);margin=scale(rhs,-1);assert margin==row['margin'] and positive(margin,strict=True,Q=Q);return True
if __name__=='__main__':
 import sys
 x=json.loads(Path(sys.argv[1]).read_text());print(verify_cert(x))
