# How different must the twenty tile angles be?

Research direction by Joost de Winter. AI author GPT6.2 Astra.

Suppose twenty unit squares fit in a board of side strictly below five. Let α and β be the minimum and maximum angles from a nearest board axis, measured in radians in [0,π/4], and put t = tan(β/2). Then

    β − α > (9/10)t².

This applies with independent positions, rotations and tilt signs for all twenty tiles. It excludes a neighborhood around every configuration with equal absolute tilts. The size of that neighborhood approaches zero as β approaches zero.

**Small angles.** Assume β > 0 and β − α ≤ c t² with c = 9/10. Replace each unit tile by a concentric square of side a = 1 − c t² at the signed angle +β or −β that agrees with its original tilt. For angular discrepancy δ, the new square projects to width a(cos δ + sin δ) on each old axis. Since cos δ + sin δ ≤ 1+δ and δ ≤ ct², this width is at most one. The original tile centers still satisfy the five rank bands in global_small_tilt.md, with the bands calculated using their original maximum tilt β. Thus every separation, wall and chain constraint in equal_magnitude.md holds for the new orientations, with the support widths multiplied by a. The rank bounds keep their original widths. On 0 < t ≤ 1/23 the chains exclude all 992 incorrectly signed bridges and every surviving separation graph has a polynomial contradiction after the decrease in support widths. Uniform sign patterns are included.

The verifier sums the same nonnegative multipliers against the changed inequalities. With C=1−t², D=1+t² and Z=1−t²+2t, the increase in the unweighted right hand side, divided by ct², is CDZ for a wall, 2D³ for a same-sign separation, 2CDZ for an opposite-sign separation, and zero for a rank bound. It checks exact cancellation of every center coefficient, verifies the adjusted strict scalar margin over the entire parameter interval, and checks all signed graphs. The saved bank contains 139 certificates. Enumeration covers 31,465 graphs on 307 representatives. An independent Boolean encoding checks 120 sign instances and 463 separation instances.

**Larger angles.** For t ≥ 1/23, the derivative of arctan gives 2(arctan t−arctan(1/24)) ≥ 2(t−1/24)/(1+t²). The polynomial 2(t−1/24)−ct²(1+t²) is concave for positive t. The verifier checks it at 1/23 and 5/12. This interval contains tan(π/8) at its upper end. It follows that α ≥ 2 arctan(1/24). The already verified unrestricted large-angle exclusion in runs/tilt_24_verified.json rules this out. At β=0 the aligned squares already require side at least five.

    python3 geometry/angle_diversity.py --Q 23 --loss 9/10 --seed proofs/angular_diversity_90.json.gz
    python3 geometry/check_equal_boolean.py proofs/angular_diversity_90.json.gz --Q 23 --loss 9/10 --jobs 3

The large-angle replay commands are in README.md. The checked statements and coverage counts are saved in runs/angular_spread90_standalone_verified.json and runs/angular_spread90_boolean_verified.json. This condition still permits some angular spreads for every positive β.

## A bound in terms of the maximum absolute tilt

For arbitrary signed tilts of twenty squares in a board of side below five, the strengthened result is

    β − α > 2 tan²(β/2).

Write μ=(α+β)/2, r=tan(μ/2), and η=(11/10)r². If the whole angular range had width at most 2η, each tile would contain a concentric square of side 1−η with the same tilt sign and common magnitude μ. In the small range 0<r≤1/23 the boundary and separation estimates for these contained squares are the same as in the first proof with its chosen reference replaced by μ. The rank errors are determined by the original tiles. Put u(x)=cos x+sin x and d(x)=u(x)(u(x)−1). Since |u′|≤1 on the relevant angular interval, u(β)≤u(μ)+η. The verifier checks 2u(μ)−1+η≤3/2 using u(μ)≤1+2r. Consequently d(β)≤d(μ)+(3/2)η. The changed rank inequalities and straight-edge inequalities use this larger error. The five-step path inequalities include the same allowance in their transverse errors.

The small-range polynomial verifier rules out all 992 incorrect paired-bridge sign patterns and all 31,465 remaining graphs using 134 certificates. The second encoding returns UNSAT for all 120 sign and 463 graph instances. At r≥1/23, the assumption puts every original tile at least 2 arctan(1/24) from an axis. The proof uses concavity of 2(r−1/24)−(11/10)r²(1+r²) to check this implication at the endpoints. The full continuous-angle exclusion at that threshold is in runs/tilt_24_verified.json. Together these facts give β−α>(11/5)r².

For the conversion put t=tan(β/2) and T=1/22, and suppose β−α≤2t². If t≤T, the mean value theorem gives r≥t[1−(1+T²)2T/4]. The square of the bracket times 11/5 exceeds 2. If t≥T, concavity gives 2(t−1/24)≥2t²(1+t²) up to t=5/12, again forcing α≥2 arctan(1/24). The two cases prove the stated inequality. The aligned case has minimum five by direct counting.

    python3 geometry/angle_diversity.py --Q 23 --loss 11/10 --midpoint --seed proofs/midpoint_spread_22.json.gz --out fresh_midpoint.json
    python3 geometry/check_equal_boolean.py proofs/midpoint_spread_22.json.gz --Q 23 --loss 11/10 --midpoint --jobs 3
    python3 geometry/spread_convert.py fresh_midpoint.json runs/tilt_24_verified.json 2

## The two possible signs near a board axis

Every sub-five packing has a tile whose absolute tilt is at most 2 arctan(5/123), approximately 4.65563018 degrees. There is a stronger alternative. Either a tile lies within 2 arctan(1/32) of an axis, approximately 3.57982122 degrees, or both a clockwise and a counterclockwise tile lie within 2 arctan(5/123) of their respective axes.

The verified 64-bin band checker for [1/24,23/25] retains exactly the closed normalized half-tangent bins indexed 2 through 58. Its construction in advanced/build_bands.py applies the band filter once before all finer geometric checks. The two rational cutoffs never enter the kernel again. Every normalized half-angle strictly inside (2/64,59/64) thus has a covering bin among those retained. The same statement holds after reflecting the whole board. If the smallest absolute half-tangent exceeds 1/32, the original packing can escape the retained band only via a raw half-tangent at least 59/64. That tile has the negative tilt sign and absolute half-tangent at most (1−59/64)/(1+59/64)=5/123. Reflection gives a tile with the other sign satisfying the same bound. When the smallest absolute half-tangent is at most 1/32, the first alternative applies. The argument uses open intervals for the raw angles and keeps equality in its conclusions.

    python3 geometry/signed_near_axis.py runs/tilt_24_verified.json

For a specified side there is also a direct inequality. Set Δ=β−α. Within each tile place the concentric square of side 1/(cos(Δ/2)+sin(Δ/2)) whose tilt has the original sign and absolute magnitude (α+β)/2. Its projection fits on both original axes since the angular discrepancy is at most Δ/2. The twenty contained squares have a common absolute tilt, so equal_magnitude.md gives S≥5/(cos(Δ/2)+sin(Δ/2)). This holds over the full range of angles.


The sharper signed threshold also improves the spread bound to Δ>(1051/500)tan²(β/2). Take T=16/375, C=1051/500 and a=5/123. For t=tan(β/2)≥T, the smallest absolute tilt satisfies α≤2 arctan(a). The mean value theorem gives Δ≥2(t−a)/(1+t²)>Ct². For the strict inequality it suffices to test the concave polynomial 2(t−a)−Ct²(1+t²) at T and 5/12. For t≤T, if Δ≤Ct², the midpoint half-tangent r is at least t[1−CT(1+T²)/4]. The square of this bracket times 11/5 exceeds C. This contradicts Δ>(11/5)r². The calculation uses the same 31,465 exhaustively verified graphs as the earlier midpoint estimate.

    python3 geometry/spread_convert.py runs/angular_midpoint22_standalone_verified.json runs/tilt_24_verified.json 1051/500 --signed
