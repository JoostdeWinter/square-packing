"""Exact five-tile path exclusions with one board-aligned tile."""
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from collections import Counter
from equal_path_polynomial import full_paths
from verify_parallel import add,mult,scale,positive
from check_signed_duals import C,S,D,Z,CDZ,CD2,D2,ZZD
def divide_sum(signs,rows,Q):
 return exclude(tuple(signs),tuple(rows),Q)
@lru_cache(maxsize=None)
def check_profile(w0,w1,ns,no,nf,na,H,K,Q):
 # Multiply the entire side difference by 2*C*D^2.
 wall=add(scale(CDZ,w0+w1),scale(CD2,2-w0-w1))
 b=add(wall,scale(CD2,-10));b=add(b,scale(mult(D2,D),2*ns));b=add(b,scale(CDZ,2*no));b=add(b,scale(mult(D2,add(D,Z)),nf));b=add(b,scale(add(CD2,CDZ),na))
 b=add(b,scale(mult(S,D2),-2*H));b=add(b,scale(mult(S,ZZD),-2*K))
 return positive(b,Q=Q)
@lru_cache(maxsize=None)
def exclude(signs,rows,Q):
 assert signs.count(0)<=1
 steps=[];dirs=[b-a for a,b in zip(rows,rows[1:])]
 for u,v,h in zip(signs,signs[1:],dirs):
  if u==v:steps.append([(u,'same')])
  elif u*v:steps.append([(h,'mixed')] if h else [(-1,'mixed'),(1,'mixed')])
  elif h*(u+v)>0:steps.append([(u+v,'fav')])
  elif h:steps.append([(0,'flat')])
  else:steps.append([(0,'flat'),(u+v,'fav')])
 for ls in product(*steps):
  ns,no,nf,na=[sum(key==s for _,key in ls) for s in ('same','mixed','fav','flat')]
  lam=[v for v,k in ls];H=sum(x*y for x,y in zip(lam,dirs))
  coeff=[-lam[0],*(u-v for u,v in zip(lam,lam[1:])),lam[-1]];K=sum(w*((4-k) if w>0 else -k) for w,k in zip(coeff,rows))
  if not check_profile(abs(signs[0]),abs(signs[-1]),ns,no,nf,na,H,K,Q):return False
 return True
def bridges_exact(Q):
 stats=Counter();first=[]
 for k in range(4):
  for a in range(5):
   for b in (a-1,a+1):
    if b not in range(5):continue
    d=b-a;rows=(a,)*(k+1)+(b,)*(4-k)
    for z in range(-1,5):
     for nonzero in product((-1,1),repeat=5-(z>=0)):
      s=nonzero if z<0 else nonzero[:z]+(0,)+nonzero[z:]
      arm1=s[:k+1];arm2=s[k+1:][::-1]
      if all(v*d>=0 for v in s) and all(sorted(abs(v) for v in arm)==[abs(v) for v in arm] for arm in (arm1,arm2)):continue
      val=exclude(s,rows,Q);stats[val]+=1
      if not val and len(first)<5:first.append([rows,s])
 return stats,first
def clauses(p,s,z,Q):
 sig=[0 if i==z else 1 if s>>i&1 else -1 for i in range(20)];st=set()
 for dim,mask,rows,idx in full_paths(p):
  if exclude(tuple(sig[i] for i in idx),rows,Q):st.add((mask,0) if dim else (0,mask))
 out=[]
 for a,b in sorted(st,key=lambda q:(q[0]|q[1]).bit_count()):
  if not any(x&a==x and y&b==y for x,y in out):out.append((a,b))
 return out
if __name__=='__main__':
 import sys
 for q in map(int,sys.argv[1:]):
  h,g=bridges_exact(q);print(q,h,g[:1],flush=True)
