"""Determine which live endpoint matchings can converge to some 20-of-25 grid."""
from itertools import combinations,product
from pathlib import Path
from collections import Counter
import json
h=Path(__file__).resolve().parents[1];U=5000000;D=1000000
P=[tuple(map(int,x.split()[:2])) for x in (h/'enumerator/marks500.txt').read_text().splitlines()[1:]];Q=[(U-y,x) for x,y in P]
grid=[((2*i+1)*D//2,(2*j+1)*D//2) for i,j in product(range(5),repeat=2)]
def dist(a,b):return max(abs(a[0]-b[0]),abs(a[1]-b[1]))
def closest(g,r):
 d=[dist(g,p) for p in r];v=min(d);return {i for i,z in enumerate(d) if z==v}
positions={(i,j):[k for k,g in enumerate(grid) if i in closest(g,P) and j in closest(g,Q)] for i,j in product(range(22),repeat=2)}
def witness(key,matching,owners=None,allowed=None):
 a,b=map(int,key.split('_'));ids=[i for i in range(22) if a>>i&1];holes=([(0,i) for i in range(22) if not a>>i&1]+[(1,i) for i in range(22) if not b>>i&1])
 assert len(ids)==20 and len(holes)==4
 edges=[]
 for n,(i,j) in enumerate(zip(ids,matching)):
  e=set(positions[i,j]);e=e if allowed is None else e&allowed
  if owners is not None:
   for owner,(color,index) in zip(owners,holes):
    if owner==-2:continue
    p=(Q if color else P)[index]
    if owner==n:e={k for k in e if 2*dist(grid[k],p)<=D}
    else:e={k for k in e if 2*dist(grid[k],p)>=D}
  edges.append(e)
 if any(not r for r in edges):return None
 assigned={}
 def dfs(i,vis):
  for k in edges[i]:
   if k in vis:continue
   vis.add(k)
   if k not in assigned or dfs(assigned[k],vis):assigned[k]=i;return True
  return False
 if not all(dfs(i,set()) for i in sorted(range(20),key=lambda i:len(edges[i]))):return None
 assert len(assigned)==20
 return [next(k for k,v in assigned.items() if v==i) for i in range(20)]
def main():
 orig=h/'trials/fixed500_e32root';work=h/'trials/cap5000000_ep1';counts=Counter();samples={};leaves={}
 for f in orig.glob('*.json'):
  z=json.loads(f.read_text())
  for v in z['live']:
   w=witness(f.stem,v['matching']);counts['screened_matchings']+=1;counts['screened_with_grid_limit']+=w is not None
   if w and len(samples)<5:samples[f.stem]=[v['matching'],w]
 for f in work.glob('*.json'):
  z=json.loads(f.read_text());key=z['mask_pair']
  for o in z['open_leaves']:
   w=witness(key,z['matching'],o);counts['refined_leaves']+=1;counts['refined_with_grid_limit']+=w is not None
   if w and len(leaves)<5:leaves[f.stem+str(o)]=w
 result={'counts':counts,'screen_examples':samples,'refined_examples':leaves}
 (h/'runs/grid_limits.json').write_text(json.dumps(result,indent=2));print(dict(counts),flush=True)
if __name__=='__main__':main()
