"""Exact covers of a common-angle center domain by unit squares in its own frame."""
from fractions import Fraction as F
from functools import lru_cache
from math import ceil,floor
from pathlib import Path
import argparse,json,itertools,sys
h=Path(__file__).resolve().parent
def trig(t):return (1-t*t)/(1+t*t),2*t/(1+t*t)
def boundary(a,b):
 m=(a+b)/2;c,s=trig(m)
 directions=[trig(a),trig(b)]
 width=max(5-x-y for x,y in directions)
 fac=max(c*x+s*y+abs(c*y-s*x) for x,y in directions)
 H=width*fac/2
 return [(c*x+s*y,-s*x+c*y) for x,y in [(-H,-H),(H,-H),(H,H),(-H,H)]]
def pixel_intervals(a,b,q,offset):
 x0,y0=offset;poly=[(q*x+x0,q*y+y0) for x,y in boundary(a,b)]
 low=floor(min(y for x,y in poly));high=ceil(max(y for x,y in poly))
 ranges=[]
 for y in range(low,high):
  xl=[]
  for p,t in zip(poly,poly[1:]+poly[:1]):
   x1,y1=p;x2,y2=t
   if y<=y1<=y+1:xl.append(x1)
   if y1==y2:continue
   for Y in (y,y+1):
    if min(y1,y2)<=Y<=max(y1,y2):xl.append(x1+(x2-x1)*(Y-y1)/(y2-y1))
  if xl:ranges.append((y,floor(min(xl)),ceil(max(xl))))
 return dict((y,(a,b)) for y,a,b in ranges)
def guillotine(rows,q,res=1):
 xl=min(v[0] for v in rows.values());xh=max(v[1] for v in rows.values());yl=min(rows);yh=max(rows)+1;decision={}
 def trim(xl,xh,yl,yh):
  vals=[(y,max(xl,rows[y][0]),min(xh,rows[y][1])) for y in range(yl,yh) if y in rows and max(xl,rows[y][0])<min(xh,rows[y][1])]
  if not vals:return (0,0,0,0)
  return min(a for _,a,b in vals),max(b for _,a,b in vals),vals[0][0],vals[-1][0]+1
 @lru_cache(None)
 def go(box):
  xl,xh,yl,yh=box;W=xh-xl;H=yh-yl
  if min(W,H)==0:return 0
  if min(W,H)<=q:return (max(W,H)+q-1)//q
  best=((W+q-1)//q)*((H+q-1)//q);which=None
  for axis,lo,hi in [(0,xl,xh),(1,yl,yh)]:
   cuts={lo+q,hi-q}
   if res>1:
    for i in range(1,res):
     cuts.update((lo+(i*q)//res,hi-(i*q)//res))
   for pos in sorted(cuts):
    if not lo<pos<hi:continue
    a,b=(trim(xl,pos,yl,yh),trim(pos,xh,yl,yh)) if axis==0 else (trim(xl,xh,yl,pos),trim(xl,xh,pos,yh))
    val=go(a)+go(b)
    if val<best:best=val;which=(a,b)
  decision[box]=which
  return best
 box=trim(xl,xh,yl,yh);n=go(box)
 def recover(box):
  xl,xh,yl,yh=box
  if xl>=xh or yl>=yh:return []
  split=decision.get(box)
  if split:return recover(split[0])+recover(split[1])
  return [(x,y) for x in range(xl,xh,q) for y in range(yl,yh,q)]
 placed=recover(box);assert len(placed)==n
 return placed
def verify(a,b,q,offset,cover):
 rows=pixel_intervals(a,b,q,offset)
 for y,(lo,hi) in rows.items():
  intervals=sorted((x,x+q) for x,Y in cover if Y<=y<Y+q);end=lo
  for x,X in intervals:
   if x<=end:end=max(end,X)
  if end<hi:return False
 return True
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--q',type=int,default=40);ap.add_argument('--res',type=int,default=1);ap.add_argument('--offsets',type=int,default=1);ap.add_argument('--step',type=int,default=1);ap.add_argument('--den',type=int,default=100);ap.add_argument('--lo',type=int,default=3);ap.add_argument('--hi',type=int,default=42)
 v=ap.parse_args();q=v.q
 dest=h.parent/'trials/parallel_covers';dest.mkdir(exist_ok=True)
 for k in range(v.lo,v.hi,v.step):
  a=F(k,v.den);b=F(min(k+v.step,v.hi),v.den);best=None
  for X,Y in itertools.product(range(v.offsets),repeat=2):
   offset=[F(X,v.offsets),F(Y,v.offsets)];rows=pixel_intervals(a,b,q,offset);tiles=guillotine(rows,q,v.res)
   if best is None or len(tiles)<len(best[1]):best=(offset,tiles)
   if len(tiles)<=19:break
  off,tiles=best
  print(str(a),str(b),len(tiles),flush=True)
  if len(tiles)<=19:
   assert verify(a,b,q,off,tiles)
   (dest/f'cover_{a.numerator}_{a.denominator}_{b.numerator}_{b.denominator}.json').write_text(json.dumps({'interval':[str(a),str(b)],'scale':q,'offset':list(map(str,off)),'cover':tiles}))
if __name__=='__main__':main()
