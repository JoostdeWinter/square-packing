"""Exact linear outer relaxations for the sixteen-aligned, four-tilted case."""
from fractions import Fraction as F
from itertools import product,combinations,permutations
from collections import Counter
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
import argparse,json,gzip,sys,subprocess,hashlib,time
h=Path(__file__).resolve().parents[1]
def sets():
 pts=[z for z in product(range(5),repeat=2) if not all(q in (0,4) for q in z)]
 perm=list(permutations(range(1,5)))
 def valid(P,k):return any(all(p[j] in (z[k],z[k]+1) for j,z in enumerate(P)) for p in perm)
 def canon(P):return min(tuple(sorted((4-x if a else x,4-y if b else y) for X,Y in P for x,y in [(Y,X) if c else (X,Y)])) for a,b,c in product((0,1),repeat=3))
 return [P for P in combinations(pts,4) if P==canon(P) and valid(P,0) and valid(P,1) and any(abs(x-X)+abs(y-Y)==1 for (x,y),(X,Y) in combinations(P,2))]
def trig(t):return (1-t*t)/(1+t*t),2*t/(1+t*t)
def number(x):
 x=F(x)
 if x<0:return '(- '+number(-x)+')'
 return str(x.numerator) if x.denominator==1 else f'(/ {x.numerator} {x.denominator})'
def add(*terms):
 vals=[a for a in terms if a!='0']
 return '0' if not vals else vals[0] if len(vals)==1 else '(+ '+' '.join(vals)+')'
def scale(x,a):
 return '0' if not x or a=='0' else a if x==1 else '(- '+a+')' if x==-1 else '(* '+number(x)+' '+a+')'
def sub(a,b):return add(a,scale(-1,b))
def dot(vec,p):return add(*(scale(w,q) for w,q in zip(vec,p)))
def con(x,op,v):return '('+op+' '+x+' '+number(v)+')'
def joint(rows,op='and'):
 rows=list(dict.fromkeys(rows))
 return 'true' if not rows and op=='and' else 'false' if not rows else rows[0] if len(rows)==1 else '('+op+' '+' '.join(rows)+')'
def dirs(c,s):return [(c,s),(-s,c),(-c,-s),(s,-c)]
def model(C,bins,blocks=None,details=True,linked=False,strict_physical=False):
 phys='>' if strict_physical else '>='
 out=['(set-logic QF_LRA)'];emit=lambda x:out.append('(assert '+x+')')
 def real(k):out.append('(declare-fun '+k+' () Real)');return k
 def disj(x):return joint(x,'or')
 g={(i,j):[real(f'z_{i}_{j}_{k}') for k in (0,1)] for i,j in product(range(1,5),repeat=2)}
 for pair in g.values():
  for v in pair:emit(con(v,'>',-F(1,2)));emit(con(v,'<',F(1,2)))
 for i,j in product(range(6),repeat=2):
  if (i,j) not in g:g[i,j]=[number(-F(1,2) if q==0 else F(1,2) if q==5 else 0) for q in (i,j)]
 for i,j in product(range(1,5),repeat=2):
  if i<4:emit(con(sub(g[i+1,j][0],g[i,j][0]),'>',0))
  if j<4:emit(con(sub(g[i,j+1][1],g[i,j][1]),'>',0))
  if i<4:
   for k in (-1,1):
    if 1<=j+k<=4:emit(disj([con(sub(g[i+1,j+k][0],g[i,j][0]),'>',0),con(scale(k,sub(g[i+1,j+k][1],g[i,j][1])),'>',0)]))
 poses=[];angles=[];radii=[]
 for i,(x,y) in enumerate(C):
  T=[real(f't_{i}_{k}') for k in (0,1)];poses.append(T)
  for w in T:emit(con(w,'>',-F(293,1000)));emit(con(w,'<',F(293,1000)))
  # The small positive number d is half the excess bounding-box width.
  depth=real(f'd_{i}') if linked else None
  if linked:
   emit(con(depth,'>',0));emit(con(depth,'<=',F(207107,10**6)))
   gates={v:f'escape_{i}_{v}' for v in ('E','W','N','S')}
   for v in gates.values():out.append('(declare-fun '+v+' () Bool)')
   emit(disj(gates.values()))
   for v,w in combinations(gates.values(),2):emit('(not (and '+v+' '+w+'))')
   for ax in T:
    for sg in (-1,1):emit(con(sub(scale(sg,ax),scale(F(1414214,10**6),depth)),'<=',0))
   for aa,bb in product((-1,1),repeat=2):emit(con(sub(dot((aa,bb),T),scale(2,depth)),'<=',0))
  sides={}
  for a,b in product((-1,1),repeat=2):
   X,Y=x+(a+1)//2,y+(b+1)//2;sides[a,b]=[scale(a,sub(g[X,Y][0],T[0])),scale(b,sub(g[X,Y][1],T[1]))]
  open_=add(*(q for z in sides.values() for q in z));emit(con(open_,'>',2));opts=[];ds=[]
  endpoints=blocks[i] if blocks else [(F(j,bins),F(j+1,bins)) for j in range(bins)]
  for gno,(p,q) in enumerate(endpoints):
   key=f'b_{i}_{gno}';out.append('(declare-fun '+key+' () Bool)');opts.append(key);d0=trig(p);d1=trig(q);dm=trig((p+q)/2);A=dirs(*d0);B=dirs(*d1);D=dirs(*dm)
   umin=min(sum(d0),sum(d1));umax=max(sum(d0),sum(d1)) if (d0[0]-d0[1])*(d1[0]-d1[1])>=0 else F(1414214,10**6)
   tk=min(p,(1-q)/(1+q));gamma=1-(q-p)**2/2
   extra=[con(open_,'>=',2+2*tk*tk/(1+tk))]
   fhi=max(dm[0]*a+dm[1]*b+abs(dm[0]*b-dm[1]*a) for a,b in (d0,d1));d=(umax-1)/2
   if linked:
    extra.extend([con(depth,'>=',(umin-1)/2),con(depth,'<=',d)])
   for axis in D:
    extra.append(con(sub(dot(axis,T),scale(fhi,depth)),'<=',0) if linked else con(dot(axis,T),'<=',d*fhi))
   for ax,cell in enumerate((x,y)):
    extra.append(con(T[ax],'>',umin/2-F(2*cell+1,2)));extra.append(con(T[ax],'<',5-umin/2-F(2*cell+1,2)))
   for (a,b),V in sides.items():
    if linked:
     xown,yown=g[x+(a+1)//2,y+(b+1)//2];xx=scale(a,xown);yy=scale(b,yown)
     xx='(ite (> '+xx+' 0) '+xx+' 0)';yy='(ite (> '+yy+' 0) '+yy+' 0)'
     kn=[trig(F(j,12)) for j in range(13)];cg=1-F(1,288)
     extra.append(disj([con(dot(n,[xx,yy]),'>',cg-(n[0]+n[1])/2) for n in kn]))
    ix={(1,1):0,(-1,1):1,(-1,-1):2,(1,-1):3}[a,b]
    n1=(a*A[ix][0],b*A[ix][1]);n2=(a*B[ix][0],b*B[ix][1])
    if linked:
     major=0 if min(n1[0]-n1[1],n2[0]-n2[1])>=0 else 1 if max(n1[0]-n1[1],n2[0]-n2[1])<=0 else None
     modes=[con(dot(n,V),'>',gamma/2) for n in (n1,n2)]
     rot=disj(modes)
     if major is not None:
      # For 0 <= phi <= pi/4, sin(phi) <= 2d/(1-tan(phi/2))
      # and 1-cos(phi)=tan(phi/2)*sin(phi). Each |V| < .793.
      mx=max(min(p,(1-p)/(1+p)),min(q,(1-q)/(1+q)));loss=F(793,1000)*2*(1+mx)/(1-mx)
      rot=joint([rot,con(add(V[major],scale(loss,depth)),'>',F(1,2))])
     H=joint([gates['E' if a>0 else 'W'],con(sub(V[0],depth),'>',F(1,2))])
     Vt=joint([gates['N' if b>0 else 'S'],con(sub(V[1],depth),'>',F(1,2))])
     extra.append(disj([H,Vt,rot]))
    else:extra.append(disj([con(V[0],phys,umin/2),con(V[1],phys,umin/2),con(dot(n1,V),phys,gamma/2),con(dot(n2,V),phys,gamma/2)]))
   if details:
    for X,Y in product(range(1,5),repeat=2):
     if X in (x,x+1) and Y in (y,y+1):continue
     dx=F(2*X-2*x-1,2);dy=F(2*Y-2*y-1,2)
     if max(abs(dx),abs(dy))>2:continue
     delta=[add(number(dx),sub(g[X,Y][0],T[0])),add(number(dy),sub(g[X,Y][1],T[1]))];H=(1+umin)/2
     extra.append(disj([con(dot(n,delta),phys,H) for n in dirs(1,0)]+[con(dot(n,delta),phys,H*gamma) for n in A+B]))
   emit('(=> '+key+' '+joint(extra)+')');ds.append((key,A,B,gamma,p,q,d0,d1))
  emit(disj(opts));angles.append(ds)
 for i,j in combinations(range(4),2):
  dx=C[j][0]-C[i][0];dy=C[j][1]-C[i][1]
  if max(abs(dx),abs(dy))>2:continue
  delta=[add(number(v),sub(q,p)) for v,p,q in zip((dx,dy),poses[i],poses[j])]
  if details:
   for key,A,B,g1,aa,ab,d1,d2 in angles[i]:
    for z,C0,C1,g2,ba,bb,v1,v2 in angles[j]:
     H=1 if max(aa,ba)<=min(ab,bb) else min((1+a*x+b*y+abs(a*y-b*x))/2 for a,b in (d1,d2) for x,y in (v1,v2))
     alt=[con(dot(n,delta),phys,H*g1) for n in A+B]+[con(dot(n,delta),phys,H*g2) for n in C0+C1]
     emit('(=> (and '+key+' '+z+') '+disj(alt)+')')
  else:
   r=[]
   for k in (i,j):
    for key,A,B,ga,*_ in angles[k]:r.append('(and '+key+' '+disj([con(dot(n,delta),phys,ga) for n in A+B])+')')
   emit(disj(r))
 return '\n'.join(out)+'\n(check-sat)\n'
def main(v):
 d=h/f'trials/four_tilt_{v.bins}_{v.tag}';d.mkdir(exist_ok=True);items=sets();assert len(items)==84;count=Counter();t=time.monotonic()
 def one(z):
  i,C=z;dest=d/f'{i:02}.json'
  if dest.exists():return json.loads(dest.read_text())
  f=d/f'{i:02}.smt2';s=model(C,v.bins,details=v.full,linked=v.linked);f.write_text(s);status=subprocess.check_output([sys.executable,h/'advanced/z3_lra.py',f,str(1000*v.time)],text=True).strip();assert status in ('sat','unsat','unknown')
  ans={'index':i,'cells':C,'status':status,'bins':v.bins,'full':v.full,'linked':v.linked,'sha256':hashlib.sha256(s.encode()).hexdigest()}
  if status=='unsat' or v.keep:
   with gzip.open(d/f'{i:02}.smt2.gz','wb') as gz:gz.write(s.encode())
  f.unlink();dest.write_text(json.dumps(ans));return ans
 with ThreadPoolExecutor(v.jobs) as ex:
  for fut in as_completed([ex.submit(one,j) for j in enumerate(items)]):
   r=fut.result();count[r['status']]+=1;print(r['index'],r['status'],dict(count),int(time.monotonic()-t),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--bins',type=int,default=4);p.add_argument('--tag',default='loose');p.add_argument('--full',action='store_true');p.add_argument('--linked',action='store_true');p.add_argument('--jobs',type=int,default=2);p.add_argument('--time',type=int,default=20);p.add_argument('--keep',action='store_true');main(p.parse_args())
