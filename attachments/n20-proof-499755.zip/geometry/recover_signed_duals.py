"""Reconstruct the polynomial multipliers on each sparse numeric support."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
from functools import reduce
from math import gcd,lcm
from collections import Counter
import time,json,argparse
from signed_duals_discover import coeff
from check_signed_duals import add,mult,scale,C,S,polyrow,verify_cert
def power(a,k):
 x=[1]
 for j in range(k):x=mult(x,a)
 return x
def make(r,Q=64):
 import sympy as sp
 from sympy.polys.matrices import DomainMatrix
 v=sp.Symbol('v');rs=r['rules'];n=len(rs);a={}
 for j,rule in enumerate(rs):
  for i,value in coeff(rule,v):
   q=sp.sympify(value)
   if q!=0:a[i,j]=a.get((i,j),0)+q
 M=sp.SparseMatrix(50,n,a);L=DomainMatrix.from_Matrix(M);N=L.nullspace();assert N.shape==(1,n),('null dimension',N.shape)
 vals=[sp.Poly(q,v,domain=sp.ZZ) for q in list(N.to_Matrix())];div=reduce(sp.gcd,vals);vals=[q.exquo(div) for q in vals];degree=max(q.degree() for q in vals)
 fac=[mult(power(S,j),power(C,degree-j)) for j in range(degree+1)];ww=[]
 for q in vals:
  p=[]
  for j,a in enumerate(range(degree+1)):p=add(p,scale(fac[j],int(q.nth(j))))
  ww.append(p)
 assert all(ww)
 first=next(z for z in ww[0] if z);sg=1 if first>0 else -1
 g=reduce(gcd,(z for p in ww for z in p));ww=[[sg*x//g for x in p] for p in ww]
 rhs=[]
 for rule,w in zip(rs,ww):rhs=add(rhs,mult(polyrow(rule)[1],w))
 out={'rules':rs,'multipliers':ww,'margin':scale(rhs,-1)}
 assert verify_cert(out,Q);return out
def job(args):
 f,d=args;o=d/f.name
 if o.is_file():return json.loads(o.read_text())
 src=json.loads(f.read_text())
 try:z=make(src);z['verified']=True
 except Exception as err:z={'verified':False,'rules':src['rules'],'error':str(err)}
 z['source_index']=src['index'];o.write_text(json.dumps(z,separators=(',',':'))+'\n');return z
def main(v):
 src=v.inputs;dest=v.dest;dest.mkdir(parents=True,exist_ok=True);seen=set();clock=time.monotonic();ct=Counter()
 while True:
  fs=[f for f in sorted(src.glob('support_*.json')) if f.name not in seen]
  with ProcessPoolExecutor(v.jobs) as ex:
   for f in as_completed([ex.submit(job,(p,dest)) for p in fs]):
    z=f.result();ct[str(z['verified'])]+=1
    if sum(ct.values())%20==0 or not z['verified']:print(sum(ct.values()),dict(ct),z.get('error'),int(time.monotonic()-clock),flush=True)
  seen.update(p.name for p in fs)
  if (src/'summary.json').exists() and not fs:break
  time.sleep(4)
 print('end',dict(ct),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('inputs',type=Path);p.add_argument('dest',type=Path);p.add_argument('--jobs',type=int,default=3);main(p.parse_args())
