"""First- and second-order deformations of twenty near-grid squares.

Explore all vacancy patterns modulo board symmetry. An improvement must
survive reconstruction with rational tile directions and all 190 tests.
MILP optima in this script are discovery data only.
"""
from pathlib import Path
from itertools import permutations,combinations,product
from collections import defaultdict,Counter
from concurrent.futures import ProcessPoolExecutor,as_completed
from fractions import Fraction as F
import argparse,json,math,os,time
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix
from repair_optimizations import test
h=Path(__file__).resolve().parents[1]
def canon(p):
 s=set(enumerate(p));return min(tuple(sorted((4-a if m&1 else a,4-b if m&2 else b) for x,y in s for a,b in [(y,x) if m&4 else (x,y)])) for m in range(8))
PAT=sorted(set(canon(p) for p in permutations(range(5))))
def add(*terms):
 q=defaultdict(float)
 for i,v in terms:q[i]+=v
 return {i:v for i,v in q.items() if abs(v)>1e-14}
def evalform(q,x):return sum(a*x[k] for k,a in q.items())
class Problem:
 def __init__(self,lo,hi):self.lo=list(lo);self.hi=list(hi);self.n=len(lo);self.rows=[];self.int=[0]*self.n
 def constraints(self,alternatives):
  if not alternatives:self.rows.append(({},1));return
  if any(not cons for cons in alternatives):return
  if len(alternatives)==1:self.rows.extend(alternatives[0]);return
  z=[]
  for cs in alternatives:
   idx=len(self.lo);self.lo.append(0);self.hi.append(1);self.int.append(1);z.append(idx)
   for row,rhs in cs:
    # If the witness is selected every inequality belonging to it is needed.
    lower=sum(v*(self.lo[i] if v>=0 else self.hi[i]) for i,v in row.items());M=max(0,rhs-lower)
    q=row.copy();q[idx]=-M;self.rows.append((q,rhs-M))
  self.rows.append(({i:1 for i in z},1.))
 def solve(self,c,timelimit):
  r=[];col=[];v=[];rhs=[]
  for j,(q,b) in enumerate(self.rows):
   rhs.append(b)
   for i,a in q.items():r.append(j);col.append(i);v.append(a)
  mat=coo_matrix((v,(r,col)),shape=(len(rhs),len(self.lo))).tocsr()
  opt=milp(np.r_[c,np.zeros(len(self.lo)-len(c))],integrality=self.int,bounds=Bounds(self.lo,self.hi),constraints=LinearConstraint(mat,rhs,np.inf),options={'time_limit':timelimit,'mip_rel_gap':1e-7})
  return opt.x[:self.n] if opt.x is not None else None
def setup(pat):
 pts=sorted(set(product(range(5),repeat=2))-set(pat));walls=[];pairs=[]
 for i,(x,y) in enumerate(pts):
  for axis,coord in enumerate((x,y)):
   if coord in (0,4):walls.append((i,axis,1 if coord==0 else -1))
 for i,j in combinations(range(20),2):
  x,y=pts[i];X,Y=pts[j];d=(X-x,Y-y)
  if max(map(abs,d))==1:
   modes=[(1 if v>0 else -1,0) if a==0 else (0,1 if v>0 else -1) for a,v in enumerate(d) if abs(v)==1]
   pairs.append((i,j,d,modes))
 return pts,walls,pairs
def ncenter(i,j,n):return [(2*j,n[0]),(2*j+1,n[1]),(2*i,-n[0]),(2*i+1,-n[1])]
def first(walls,pairs,width):
 p=Problem([-width]*40+[-1]*20,[width]*40+[1]*20)
 for i,axis,s in walls:p.constraints([[(add((2*i+axis,s),(40+i,sg*.5)),0) for sg in (-1,1)]])
 for i,j,d,modes in pairs:
  al=[]
  for n in modes:
   l=-n[1]*d[0]+n[0]*d[1];terms=ncenter(i,j,n)
   if l:al.append([(add(*terms,(40+i,.5*l),(40+j,.5*l)),0)])
   else:al.append([(add(*terms,(40+i,.5*s),(40+j,-.5*s)),0) for s in (-1,1)])
  p.constraints(al)
 return p
def second(walls,pairs,vel,limit):
 p=Problem([-limit]*60+[-20],[limit]*60+[20]);eps=1e-7
 for i,axis,s in walls:
  t=vel[40+i];a=s*vel[2*i+axis]
  for u in (-1,1):
   gap=a-u*t*.5
   if gap<-eps:raise ValueError('first-order wall')
   if gap<=eps:p.constraints([[(add((2*i+axis,s),(40+i,-u*.5),(60,int(s==-1))),-.25*t*t)]])
 for i,j,d,modes in pairs:
  al=[];ti,tj=vel[40+i],vel[40+j];dt=tj-ti;dv=vel[2*j:2*j+2]-vel[2*i:2*i+2]
  for n in modes:
   l=-n[1]*d[0]+n[0]*d[1];along=n[0]*dv[0]+n[1]*dv[1];perp=-n[1]*dv[0]+n[0]*dv[1]
   for k in (i,j):
    t=vel[40+k];gaps=[along+l*t-s*.5*dt for s in (-1,1)]
    if min(gaps)<-eps:continue
    rows=[]
    for gap,s in zip(gaps,(-1,1)):
     if gap<=eps:rows.append((add(*ncenter(i,j,n),(40+k,l),(40+i,.5*s),(40+j,-.5*s)),.5*t*t-.25*dt*dt-t*perp))
    if rows not in al:al.append(rows)
  if not al:raise ValueError('first-order pair')
  p.constraints(al)
 return p
def attempt(job):
 fno,seed,base,w,tm=job;d=h/'trials/grid_jets';file=d/f'{fno:02}_{seed:04}_{w}.json'
 if file.is_file():return json.loads(file.read_text())
 pts,walls,pairs=setup(PAT[fno]);rng=np.random.default_rng(780377+fno*5347+seed)
 p=first(walls,pairs,w);objective=rng.normal(size=60);objective[:40]*=[0,.1,.5,1][seed%4]
 a=p.solve(objective,tm)
 if a is None:return {'status':'first_timeout'}
 a=np.array([float(F(float(y)).limit_denominator(20000)) for y in a])
 q=second(walls,pairs,a,base);b=q.solve(np.r_[np.zeros(60),1],tm)
 if b is None:return {'status':'second_timeout'}
 record={'pattern':fno,'vacancies':PAT[fno],'seed':seed,'translation_scale':w,'velocity_nonzero_tilts':sum(abs(x)>1e-8 for x in a[40:]),'second_order_side':b[-1],'first_order':a.tolist(),'second_order':b.tolist(),'status':'sampled'}
 record['velocity_nonzero_tilts']=int(record['velocity_nonzero_tilts'])
 if b[-1]<-1e-7:
  best=None
  for e in [1/40,1/80,1/160,1/320,1/640,1/1250,1/2500]:
   v=np.array(pts,dtype=float)+.5+e*a[:40].reshape(20,2)+e*e*b[:40].reshape(20,2);angles=e*a[40:]+e*e*b[40:60]
   pose={'coordinates':[*v.ravel().tolist(),*angles.tolist(),5+e*e*b[-1]]};cap,scale,pair=test(pose,True)
   if best is None or cap<best[0]:best=(cap,e,scale,pair,pose)
  cap,e,scale,pair,pose=best;record.update(repaired_cap=str(cap),repaired_decimal=float(cap),below_five=cap<5,epsilon=e,pose=pose)
 tmp=file.with_suffix('.part');tmp.write_text(json.dumps(record,separators=(',',':')));tmp.replace(file);return record
def main():
 p=argparse.ArgumentParser();p.add_argument('--seeds',type=int,default=24);p.add_argument('--start',type=int,default=0);p.add_argument('--workers',type=int,default=2);p.add_argument('--width',type=int,default=1);p.add_argument('--base',type=int,default=12);p.add_argument('--time',type=int,default=8);v=p.parse_args();d=h/'trials/grid_jets';d.mkdir(exist_ok=True)
 jobs=[(p,s,v.base,v.width,v.time) for s in range(v.start,v.start+v.seeds) for p in range(23)];hist=Counter();best=1e8;t=time.monotonic()
 with ProcessPoolExecutor(v.workers) as ex:
  for k,g in enumerate(as_completed([ex.submit(attempt,j) for j in jobs]),1):
   z=g.result();hist[z['status']]+=1
   if z.get('below_five'):print('RATIONAL CANDIDATE',z,flush=True)
   if z.get('second_order_side',1e40)<best:
    best=z['second_order_side'];print('new second-order minimum',best,z['pattern'],z['seed'],z.get('repaired_decimal'),flush=True)
   if k%23==0:print('count',k,'of',len(jobs),dict(hist),'best second order',best,'elapsed',int(time.monotonic()-t),flush=True)
if __name__=='__main__':main()
