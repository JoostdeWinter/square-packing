"""Exact finite cell test for a symmetric atomic measure at 0 and 45 degrees.

Discovery uses a linear program on all possible translation cells.  The
standalone replay below uses only integer arithmetic on the positive atoms.
"""
from pathlib import Path
from math import lcm,ceil
from itertools import product
from fractions import Fraction as F
from functools import reduce
import argparse,json,time
h=Path(__file__).resolve().parents[1]
def orbit(x,y,D):
 return tuple(sorted({(5*D-a if i else a,5*D-b if j else b) for a,b in [(x,y),(y,x)] for i,j in product((0,1),repeat=2)}))
def rectangles(coords,D,typ,half,wall):
 if typ:
  xy=[(x+y,x-y) for x,y in coords];limits=[(2*wall,10*D-2*wall),(-5*D+2*wall,5*D-2*wall)]
 else:xy=coords;limits=[(wall,5*D-wall)]*2
 axes=[]
 for j,(lo,hi) in enumerate(limits):
  p=sorted({lo,hi}|{a[j]+k*half for a in xy for k in (-1,1) if lo<a[j]+k*half<hi})
  axes.append([(a,b) for a,b in zip(p,p[1:])])
 for a,b in axes[0]:
  for c,d in axes[1]:
   if typ and max(a,2*wall+c,2*wall-d,2*wall)>=min(b,10*D-2*wall-c,10*D-2*wall+d,10*D-2*wall):continue
   yield (a+b,c+d)
def parameters(q,H):
 D=lcm(q,H.denominator,2);half=int(H*D);assert 2*half**2<D**2 and 0<half
 return D,((0,D//2,D//2),(1,half,half))
def replay(obj):
 q=obj['grid'];H=F(obj['diamond_half']);D,spec=parameters(q,H);assert D==obj['coordinate_denominator']
 coords=[];weights=[]
 for x,y,w in obj['atoms']:
  assert w>0 and x<=y<=5*D//2
  pts=orbit(x,y,D);coords.extend(pts);weights.extend([w]*len(pts))
 assert len(set(coords))==len(coords);total=sum(weights);out=[]
 for typ,half,wall in spec:
  pts=[(x+y,x-y) for x,y in coords] if typ else coords;wmin=total;count=0
  for a,c in rectangles(coords,D,typ,half,wall):
   w=sum(w for (x,y),w in zip(pts,weights) if abs(2*x-a)<2*half and abs(2*y-c)<2*half);count+=1;wmin=min(wmin,w)
  out.append([typ,count,wmin])
 unit=min(r[2] for r in out);return {'directions':[0,45],'translation_cells':out,'sum_integer_weights':total,'least_integer_capture':unit,'mass':str(F(total,unit)) if unit else None,'strictly_below_twenty':total<20*unit}
def discover(q,H,out):
 import numpy as np
 from scipy.optimize import linprog
 from scipy.sparse import csr_matrix
 D,spec=parameters(q,H);step=D//q;O=[];marks=[];members=[];n=[]
 for x in range(step,5*D//2+1,step):
  for y in range(x,5*D//2+1,step):
   o=orbit(x,y,D);n.append(len(o));members.extend([len(O)]*len(o));marks.extend(o);O.append((x,y))
 members=np.array(members);rows=set();num=[]
 for typ,half,wall in spec:
  a=np.array([(x+y,x-y) for x,y in marks] if typ else marks);ct=0
  for u,v in rectangles(marks,D,typ,half,wall):
   sel=(np.abs(2*a[:,0]-u)<2*half)&(np.abs(2*a[:,1]-v)<2*half);rows.add(np.bincount(members[sel],minlength=len(O)).astype('uint8').tobytes());ct+=1
  num.append(ct)
 A=csr_matrix(np.frombuffer(b''.join(sorted(rows)),dtype=np.uint8).reshape(-1,len(O)).astype(float));r=linprog(np.array(n,dtype=float),A_ub=-A,b_ub=-np.ones(A.shape[0]),bounds=(0,None),method='highs')
 if not r.success:print(q,r.message,flush=True);return
 w=[max(0,ceil(10**7*t-1e-8)) for t in r.x]
 data={'grid':q,'diamond_half':str(H),'coordinate_denominator':D,'atoms':[[*o,v] for o,v in zip(O,w) if v],'discovery_mass':r.fun,'full_grid_cells':num}
 data['verification']=replay(data);out.write_text(json.dumps(data,separators=(',',':'))+'\n')
 print(q,r.fun,data['verification'],flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--grids',nargs='+',type=int,default=[5,8,10,12,16,20]);p.add_argument('--H',default='7071/10000');p.add_argument('--verify',type=Path);v=p.parse_args()
 if v.verify:
  obj=json.loads(v.verify.read_text());res=replay(obj);assert res==obj['verification'];print(res)
 else:
  d=h/'trials/axis_measure';d.mkdir(exist_ok=True)
  for q in v.grids:discover(q,F(v.H),d/f'q{q}.json')
