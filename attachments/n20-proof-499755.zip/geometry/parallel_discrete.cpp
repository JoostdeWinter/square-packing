// Exhaustive upper bound for the number of axis-parallel tiles whose centers
// can be rounded into a supplied set of finite pixels. Coordinates are integers.
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <numeric>
#include <stdexcept>
#include <vector>
using namespace std;
struct P {int x,y;};
using Domain=vector<P>;using State=vector<Domain>;
struct Box{int xl,xh,yl,yh;};
Box bounds(const Domain& a){
    Box b{a.front().x,a.front().x,a.front().y,a.front().y};
    for(auto p:a){b.xl=min(b.xl,p.x);b.xh=max(b.xh,p.x);b.yl=min(b.yl,p.y);b.yh=max(b.yh,p.y);}
    return b;
}
bool possible(P p,const Box& b,int q){return max({p.x-b.xl,b.xh-p.x,p.y-b.yl,b.yh-p.y})>=q;}
struct Search{
    int q,limit;long nodes=0,patterns=0,open=0;int maxdepth=0;
    bool contract(State& s){
        bool changed=true;
        while(changed){
            changed=false;
            for(size_t j=0;j<s.size();j++){
                if(s[j].empty())return false;
                auto b=bounds(s[j]);
                for(size_t i=0;i<s.size();i++)if(i!=j){
                    auto& d=s[i];auto first=remove_if(d.begin(),d.end(),[&](P p){return !possible(p,b,q);});
                    if(first!=d.end()){d.erase(first,d.end());changed=true;if(d.empty())return false;}
                }
            }
        }
        return true;
    }
    bool restrict_pair(State& s,int i,int j,int axis,int sign){
        auto a=bounds(s[i]),b=bounds(s[j]);auto coord=[&](P p){return sign*(axis?p.y:p.x);};
        int hi,lo;
        if(!axis){lo=sign>0?a.xl:-a.xh;hi=sign>0?b.xh:-b.xl;}
        else{lo=sign>0?a.yl:-a.yh;hi=sign>0?b.yh:-b.yl;}
        auto& u=s[i];auto& v=s[j];
        u.erase(remove_if(u.begin(),u.end(),[&](P p){return coord(p)>hi-q;}),u.end());
        v.erase(remove_if(v.begin(),v.end(),[&](P p){return coord(p)<lo+q;}),v.end());
        return !u.empty()&&!v.empty();
    }
    bool closed(State s,int depth,int& local){
        ++nodes;if(++local>limit)return false;maxdepth=max(maxdepth,depth);
        if(!contract(s))return true;
        int bi=-1,bj=-1;vector<pair<int,int>> best;
        long score=-1;vector<Box>b;for(auto& d:s)b.push_back(bounds(d));
        // Pick an unresolved pair with the largest forced total narrowing.
        for(int i=0;i<(int)s.size();i++)for(int j=i+1;j<(int)s.size();j++){
            vector<pair<int,int>> ways;long rank=0;bool done=false;
            for(int a:{0,1})for(int sign:{-1,1}){
                int lo=a?b[i].yl:b[i].xl,hi=a?b[i].yh:b[i].xh,L=a?b[j].yl:b[j].xl,H=a?b[j].yh:b[j].xh;
                if(sign<0){int x=lo;lo=-hi;hi=-x;int y=L;L=-H;H=-y;}
                if(L-hi>=q)done=true;
                if(H-lo<q)continue;
                ways.push_back({a,sign});
                rank+=max(0,hi-(H-q))+max(0,lo+q-L);
            }
            if(done)continue;
            if(ways.empty())return true;
            if(rank>0){rank=20000/(int)ways.size()+rank/(int)ways.size();
                if(rank>score){bi=i;bj=j;best=move(ways);score=rank;}}
        }
        if(bi>=0){
            for(auto [a,sign]:best){auto child=s;if(!restrict_pair(child,bi,bj,a,sign))continue;
                // Extrema cuts may be empty for one of several alternatives. A
                // complete partition of a finite domain then makes progress.
                if(child[bi].size()==s[bi].size()&&child[bj].size()==s[bj].size()){bi=-1;break;}
                if(!closed(move(child),depth+1,local))return false;
            }
            if(bi>=0)return true;
        }
        int i=max_element(s.begin(),s.end(),[](const auto& x,const auto& y){return x.size()<y.size();})-s.begin();
        if(s[i].size()==1){cout<<"witness";for(auto& d:s)cout<<" "<<d[0].x<<","<<d[0].y;cout<<"\n";return false;}
        bool axis=b[i].xh-b[i].xl<b[i].yh-b[i].yl;
        sort(s[i].begin(),s[i].end(),[&](auto p,auto v){return axis?make_pair(p.y,p.x)<make_pair(v.y,v.x):make_pair(p.x,p.y)<make_pair(v.x,v.y);});
        auto a=s;size_t mid=s[i].size()/2;a[i].resize(mid);s[i].erase(s[i].begin(),s[i].begin()+mid);
        return closed(move(a),depth+1,local)&&closed(move(s),depth+1,local);
    }
    void subsets(const State& all,size_t j,State& picked){
        if(picked.size()==20){
            patterns++;int local=0;if(!closed(picked,0,local)){open++;if(open<15)cout<<"live "<<patterns<<" nodes "<<local<<"\n";}return;
        }
        if(all.size()-j<20-picked.size())return;
        for(size_t k=j;k<all.size();k++){
            if(all.size()-k<20-picked.size())break;
            picked.push_back(all[k]);
            // Early rejection depends only on occupied cells and covers every
            // way to add the remaining cells.
            State test=picked;
            if(contract(test))subsets(all,k+1,picked);
            picked.pop_back();
        }
    }
};
int main(int argc,char**argv){try{
    if(argc!=3)throw runtime_error("polygon-pixels local_node_limit");
    ifstream in(argv[1]);int q,n;in>>q>>n;if(!in||q<4||q>600||n<1||n>36)throw runtime_error("header");
    State all(n);for(auto& d:all){int m;in>>m;if(m<1||m>q*q)throw runtime_error("invalid cell size");
        for(int j=0;j<m;j++){P p;in>>p.x>>p.y;if(!in)throw runtime_error("truncated");d.push_back(p);}
        auto b=bounds(d);if(b.xh-b.xl>=q||b.yh-b.yl>=q)throw runtime_error("two centers per cell possible");}
    // Put the smallest boundary cells first so impossible subsets are pruned early.
    stable_sort(all.begin(),all.end(),[](const auto& a,const auto& b){return a.size()<b.size();});
    Search calc{q,stoi(argv[2])};State prefix;calc.subsets(all,0,prefix);
    cout<<"RESULT "<<n<<" "<<calc.patterns<<" "<<calc.nodes<<" "<<calc.open<<" "<<calc.maxdepth<<endl;
}catch(const exception& e){cerr<<e.what()<<endl;return 2;}}
