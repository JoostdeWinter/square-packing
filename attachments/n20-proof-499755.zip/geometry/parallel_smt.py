"""Exact linear real arithmetic with persistent Boolean choices for a common tilt.

A rational outer polygon contains the center domain throughout its angle
interval. For each previously unexcluded 20-cell selection, SMT checks all
separating-axis decisions at once. The unrestricted proof never uses this
common-orientation test.
"""
from parallel_continuous import domains
from fractions import Fraction as F
from pathlib import Path
from math import gcd,comb
from itertools import combinations
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
import argparse,os,sys,subprocess,json,hashlib
h=Path(__file__).resolve().parent;sys.path.insert(0,str(h.parent/'advanced'));from check_audit import hull,facets
def model(cells,mask,D):
 C=[hull(z) for i,z in enumerate(cells) if mask>>i&1];assert len(C)==20
 out=['(set-logic QF_LRA)'];B=[]
 for i,p in enumerate(C):
  assert len(p)>=3
  out+=['(declare-const x%d Real) (declare-const y%d Real)'%(i,i)]
  b=tuple((min(z[j] for z in p),max(z[j] for z in p)) for j in (0,1));B.append(b)
  for a,b,k in facets(p):
   g=gcd(abs(a),abs(b));assert k%g==0
   out.append(f'(assert (<= (+ (* {a//g} x{i}) (* {b//g} y{i})) {k//g}))')
 for i,j in combinations(range(20),2):
  opts=[];already=False
  for k,jx in enumerate('xy'):
   for a,b in [(i,j),(j,i)]:
    if B[b][k][0]-B[a][k][1]>=D:already=True
    if B[b][k][1]-B[a][k][0]>=D:opts.append(f'(>= (- {jx}{b} {jx}{a}) {D})')
  if already:continue
  if not opts:out.append('(assert false)');break
  out.append('(assert (or '+' '.join(opts)+'))')
 out.append('(check-sat)');return '\n'.join(out)
def test(a,b,v):
 D=v.den;cap=F(v.cap);out=h.parent/'trials/parallel_smt';out.mkdir(exist_ok=True);cells=domains(a,b,cap,D)
 k=f'{a.numerator}_{a.denominator}_{b.numerator}_{b.denominator}_{cap.numerator}_{cap.denominator}_{D}'
 sub=out/k;sub.mkdir(exist_ok=True);inp=sub/'cells.txt';masks=sub/'open_masks.txt';native=sub/'native.txt';final=sub/'result.json'
 if final.is_file():return json.loads(final.read_text())
 inp.write_text(f'{len(cells)} {D}\n'+'\n'.join(' '.join(map(str,[len(z),*(n for p in z for n in p)])) for z in cells)+'\n')
 if not native.is_file():
  r=subprocess.check_output([h/'parallel_continuous',inp,'90'],env=dict(os.environ,N20_MASK_FILE=str(masks)),text=True)
  assert r.splitlines()[-1].startswith('RESULT');native.write_text(r)
 m=list(map(int,masks.read_text().split()));n,cl,skip,left,*_=map(int,native.read_text().splitlines()[-1].split()[1:]);assert len(m)==left and len(set(m))==len(m) and cl+skip+left==comb(n,20)
 # Square-centered quarter-turn equivalence of the enclosing domain is checked
 # against the exact integer vertices, including rounding. Reflections alone
 # need not preserve a tilted outer polygon.
 C=[tuple(sorted(c)) for c in cells];trans=[[C.index(tuple(sorted(transform(*p) for p in c))) for c in C] for transform in [lambda x,y:(x,y),lambda x,y:(-y,x),lambda x,y:(-x,-y),lambda x,y:(y,-x)]]
 reduce=lambda mask:min(sum(1<<perm[i] for i in range(n) if mask>>i&1) for perm in trans)
 reps=sorted({reduce(vv) for vv in m});print('model set',a,b,'masks',len(m),'representatives',len(reps),flush=True)
 def one(q):
  outfile=sub/(str(q)+'.json')
  if outfile.is_file():return json.loads(outfile.read_text())['status']
  s=model(cells,q,D);tmp=sub/(str(q)+'.smt2');tmp.write_text(s)
  ans=subprocess.check_output([sys.executable,h.parent/'advanced/z3_lra.py',tmp,str(v.time)],text=True).strip();assert ans in ('unsat','sat','unknown');tmp.unlink()
  outfile.write_text(json.dumps({'status':ans,'sha256':hashlib.sha256(s.encode()).hexdigest()}));return ans
 with ThreadPoolExecutor(v.workers) as ex:counts=Counter(ex.map(one,reps))
 result={'interval':[str(a),str(b)],'cap':str(cap),'cells':n,'native_closed':cl+skip,'masks_left_by_native':len(m),'symmetry_reps':len(reps),'SMT':counts,'unresolved':sum(val for key,val in counts.items() if key!='unsat')}
 final.write_text(json.dumps(result,indent=2));print('solved',a,b,result,flush=True);return result
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--ranges',nargs='+',required=True);ap.add_argument('--den',type=int,default=10**6);ap.add_argument('--cap',default='5');ap.add_argument('--time',type=int,default=4000);ap.add_argument('--workers',type=int,default=2);ap.add_argument('--subdivide',type=int,default=0);v=ap.parse_args()
 def check(a,b,d):
  c=test(a,b,v)
  if c['unresolved'] and d:
   m=(a+b)/2;check(a,m,d-1);check(m,b,d-1)
 for z in v.ranges:check(*map(F,z.split(',')),v.subdivide)
