"""Recover the full signed angular threshold from the verified 64-bin filter."""
from fractions import Fraction as F
from pathlib import Path
import argparse,json
def check(receipt):
 r=json.loads(receipt.read_text());q=r['ownership'];z=r['terminal_refinements']
 assert q['cold_geometry'] and q['every_tile_constrained'] and q['strict_endpoint']
 assert q['screened_matchings']==z['parent_matchings']==1142 and z['refined_owners']==len(q['unresolved'])==9 and z['pending']==[]
 assert q['half_tangent_range']==z['half_tangent']==['1/24','23/25']
 a,b=map(F,z['half_tangent']);grid=64
 keep=lambda a,b:[k for k in range(grid) if F(k+1,grid)>=a and F(k,grid)<=b]
 expected=list(range(2,59));assert keep(a,b)==expected
 simple=F(2,49);assert keep(simple,(1-simple)/(1+simple))==expected
 p=F(expected[0],grid);high=F(expected[-1]+1,grid)
 m=(1-high)/(1+high);assert m==F(5,123) and p==F(1,32) and m>p
 return {'retained_closed_bins':expected,'coarse_grid':grid,'all_matchings_replayed_in_parent':1142,'hard_leaves_in_parent':9,'orientation_range_included_open':[str(p),str(high)],'some_absolute_half_tangent_at_most':str(m),'or_one_absolute_half_tangent_at_most':str(p),'otherwise_signed_extremes_have_each_sign_at_most':str(m),'strict_simpler_threshold':str(simple)}
if __name__=='__main__':
 q=argparse.ArgumentParser();q.add_argument('original',type=Path);q.add_argument('--out',type=Path);v=q.parse_args();r=check(v.original);print(r)
 if v.out:v.out.write_text(json.dumps(r,indent=2)+'\n')
