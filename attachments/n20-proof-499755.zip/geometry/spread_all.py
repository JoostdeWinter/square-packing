"""Uniform restrictions on independently tilted tiles close to a common nonzero angle."""
from pathlib import Path
from fractions import Fraction as F
from functools import partial
from concurrent.futures import ThreadPoolExecutor
import argparse,json
from parallel_continuous import check
from common_all import contiguous,rows_closed
import parallel_cover,parallel_fractional
h=Path(__file__).resolve().parent
def boundary(a,b,side):
 c,s=parallel_cover.trig((a+b)/2);ends=[parallel_cover.trig(k) for k in (a,b)];fac=max(c*x+s*y+abs(c*y-s*x) for x,y in ends)
 half=max(side-x-y for x,y in ends)*fac/2
 return [(c*x+s*y,-s*x+c*y) for x,y in [(-half,-half),(half,-half),(half,half),(-half,half)]]
def valid_fractional(S):
 root=h.parent/'trials/parallel_fractional';saved=parallel_cover.boundary;old=parallel_fractional.pixel_intervals;ans=[]
 try:
  parallel_cover.boundary=partial(boundary,side=S);parallel_fractional.pixel_intervals=rows_closed
  for f in root.glob('cert_*.json'):
   j=json.loads(f.read_text());lo,tot=parallel_fractional.certify(j)
   if lo>=j['weight_denominator'] and tot<20*j['weight_denominator']:ans.append((*map(F,j['interval']),f.name))
 finally:parallel_cover.boundary=saved;parallel_fractional.pixel_intervals=old
 return ans
def main(cap,start,workers,dep):
 A=F(start);Z=F(21,50);S=F(cap);frac=valid_fractional(S);out=h.parent/'trials/parallel_continuous';certs=[]
 def retained(a,b):return any(l<=a and b<=r for l,r,_ in frac)
 ends=sorted({A,Z,*[F(i,100) for i in range(1,43) if A<F(i,100)<Z]})
 def piece(t):
  a,b,d=t
  if retained(a,b):return []
  # For large tilts the projected center span may exceed five; the finite
  # 5x5 cell check may then be inapplicable. Its absence is an honest gap.
  try:r=check(a,b,S,10**6,120,out)
  except AssertionError:return [{'interval':[str(a),str(b)],'open':-1}]
  if not r['open'] or d==0:return [r]
  m=(a+b)/2;return piece((a,m,d-1))+piece((m,b,d-1))
 with ThreadPoolExecutor(workers) as ex:
  for cs in ex.map(piece,[(a,b,dep) for a,b in zip(ends,ends[1:])]):certs.extend(cs)
 use=frac+[(*map(F,r['interval']),'continuous') for r in certs if r['open']==0]
 # Return the full closed coverage components, including all gaps.
 segments=[]
 for l,r,name in sorted(use):
  if r<=A or l>=Z:continue
  l=max(A,l);r=min(r,Z)
  if segments and l<=segments[-1][1]:segments[-1][1]=max(segments[-1][1],r)
  else:segments.append([l,r])
 result={'tested_container_side':str(S),'maximum_individual_deviation_radians':str((S-5)/5),'range_components':[[str(a),str(b)] for a,b in segments],'native':certs,'fractional':[[str(a),str(b),n] for a,b,n in frac]}
 path=h.parent/'runs'/f'spread_{S.numerator}_{S.denominator}.json';path.write_text(json.dumps(result,indent=2))
 print(cap,result['range_components'],'native',len(certs),'fractional',len(frac),flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--cap',required=True);ap.add_argument('--start',default='9/100');ap.add_argument('--workers',type=int,default=2);ap.add_argument('--depth',type=int,default=3);v=ap.parse_args();main(v.cap,v.start,v.workers,v.depth)
