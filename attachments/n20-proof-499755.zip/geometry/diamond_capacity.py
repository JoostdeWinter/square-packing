"""Find or replay fractional covers for centers of nineteen near-diagonal unit squares."""
from pathlib import Path
from itertools import product
from fractions import Fraction as F
from functools import lru_cache
import json,argparse,time
def orbit(x,y):
 a,b=sorted(map(abs,(x,y)));return a,b
@lru_cache(maxsize=None)
def images(a,b):
 return sorted({(i*u,j*v) for i,j in product((-1,1),repeat=2) for u,v in ((a,b),(b,a))})
def prepare(B,M):
 points=sorted({orbit(x,y) for x in range(M+1) for y in range(M-x+1)});cliques=set()
 for x in range(-M-B+1,M+1):
  for y in range(-M-B+1,M+1):
   a=2*x+B-1;b=2*y+B-1;cliques.add(orbit(a,b))
 return points,sorted(cliques)
def verify(B,M,bank):
 assert isinstance(B,int) and B>0 and isinstance(M,int) and M>=0
 ps,_=prepare(B,M);weights={};mult=0
 for a,b,raw in bank:
  w=F(raw);assert w>=0 and a>=0 and b>=a
  for i,j in images(a,b):
   assert (i-B+1)%2==0 and (j-B+1)%2==0 and (i,j) not in weights;weights[i,j]=w;mult+=w
 for x,y in ps:
  total=sum(w for (i,j),w in weights.items() if abs(2*x-i)<B and abs(2*y-j)<B);assert total>=1
 return mult
def discover(B,M,d):
 import numpy as np
 from scipy.sparse import coo_matrix
 from scipy.optimize import linprog
 ps,cs=prepare(B,M);idx={xy:i for i,xy in enumerate(ps)};I=[];J=[];data=[];cost=[]
 for col,c in enumerate(cs):
  rows={};imgs=images(*c);cost.append(len(imgs))
  for a,b in imgs:
   for x in range(max(0,(a-B+1)//2),min(M,(a+B-1)//2)+1):
    for y in range(max(x,(b-B+1)//2),min(M-x,(b+B-1)//2)+1):
     i=idx.get((x,y))
     if i is not None:rows[i]=rows.get(i,0)+1
  for i,n in rows.items():I.append(i);J.append(col);data.append(-n)
 A=coo_matrix((data,(I,J)),shape=(len(ps),len(cs))).tocsr();z=linprog(cost,A_ub=A,b_ub=-np.ones(len(ps)),bounds=(0,None),method='highs');assert z.success
 Q=10**7
 # Round weights upward then normalize by their achieved minimum coverage.
 raw=[(*c,max(0,int(np.ceil(x*Q)))) for c,x in zip(cs,z.x) if x>1e-10]
 mincov=min(sum(w for a,b,w in raw for u,v in images(a,b) if abs(2*x-u)<B and abs(2*y-v)<B) for x,y in ps)
 assert mincov>0;bank=[(a,b,str(F(w,mincov))) for a,b,w in raw];mass=verify(B,M,bank)
 print(B,M,'open domain limit',M/B,'exact mass',mass,float(mass),len(bank),flush=True)
 if d:
  d.mkdir(exist_ok=True,parents=True);(d/f'diamond_{B}_{M}.json').write_text(json.dumps({'B':B,'M':M,'mass':str(mass),'bank':bank},separators=(',',':')))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--B',type=int);p.add_argument('--M',type=int);p.add_argument('--dest',type=Path);p.add_argument('--verify',type=Path);a=p.parse_args()
 if a.verify:
  z=json.loads(a.verify.read_text());actual=verify(z['B'],z['M'],z['bank']);assert actual==F(z['mass']);print(actual)
 else:discover(a.B,a.M,a.dest)
