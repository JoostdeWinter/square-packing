"""Exact minimum angular-spread test for unrestricted packings near a board-aligned grid."""
from pathlib import Path
from itertools import permutations
from fractions import Fraction as F
from collections import Counter
from functools import lru_cache
import gzip,json,argparse,time
from equal_path_polynomial import exact_clauses,bridge
from verify_equal_magnitude import loadbank
from check_signed_duals import verify_cert,add,mult,scale,positive,CDZ,D2,D,CD2,S
from equal_tilt_signs import assignments
from signed_angle_graphs import pattern,models
from signed_linear import canon,rules
h=Path(__file__).resolve().parents[1]
def robust(row,Q,loss,rank_extra=F(0)):
 try:verify_cert(row,Q)
 except AssertionError:return False
 total=[];rank_total=[]
 for rule,w in zip(row['rules'],row['multipliers']):
  kind=rule[0]
  if rank_extra and kind=='rank':
   q=rule[4];n=4-q if rule[3]==1 else q
   rank_total=add(rank_total,mult(w,scale(CD2,2*n)))
  if rank_extra and kind=='mixedstraight':rank_total=add(rank_total,mult(w,scale(mult(S,D2),8)))
  if kind=='rank':continue
  if kind=='wall':gamma=CDZ
  elif kind=='same':gamma=scale(mult(D2,D),2)
  elif kind in ('mixdiag','mixedstraight'):gamma=scale(CDZ,2)
  else:raise ValueError(kind)
  total=add(total,mult(w,gamma))
 adjusted=add(scale(row['margin'],loss.denominator),scale(mult([0,0,1],total),-loss.numerator))
 if rank_extra:
  adjusted=add(scale(adjusted,rank_extra.denominator),scale(mult([0,0,1],rank_total),-rank_extra.numerator*loss.denominator))
 return positive(adjusted,True,Q)
def classify(v):
 loss=F(v.loss);rank_extra=F(3,2)*loss if v.midpoint else F(0);assert 0<loss<=4 and v.Q>=20 and v.Q<25
 assert (1+F(5,12))**2>2
 for z in (F(1,v.Q),F(5,12)):
  assert 2*(z-F(1,24))>=loss*z*z*(1+z*z),'upper angular range needs a larger overlap'
 assert 2*F(1,v.Q)<=F(1,10) and 1-loss*F(1,v.Q)**2>F(99,100)
 # A perturbed orientation by Delta at most loss*t^2 contains the reference
 # square of side 1-loss*t^2 because cos Delta+sin Delta <=1+Delta.
 if v.midpoint:
  assert 2*F(1,v.Q)+loss*F(1,v.Q)**2<=F(1,10)
  assert 2*(1+2*F(1,v.Q))-1+loss*F(1,v.Q)**2<=F(3,2)
 n,wrong=bridge(v.Q,loss,rank_extra)
 print('paired-chain exclusions',n-len(wrong),'of',n,flush=True)
 if wrong:raise ValueError(('uncovered bridge',wrong[:1]))
 atoms={}
 def encode(rs):
  a=0
  for r in rs:
   r=tuple(r)
   if r not in atoms:atoms[r]=len(atoms)
   a|=1<<atoms[r]
  return a
 bank={};rejected=0
 for f in v.seed:
  for rec in loadbank(f):
   if robust(rec,v.Q,loss,rank_extra):bank[encode(rec['rules'])]=rec
   else:rejected+=1
 ct=Counter();cases=set();failed=[];used={};tic=time.monotonic()
 print('verified robust multipliers',len(bank),'rejected',rejected,flush=True)
 for p in permutations(range(5)):
  signs=assignments(p);ct['sign_assignments']+=len(signs);cases.update(canon(p,s) for s in signs)
 for j,(p,s) in enumerate(sorted(cases)):
  _,E,_=pattern(p);ms=models(exact_clauses(p,s,v.Q,loss,rank_extra),len(E),False)
  if ms:ct['representatives_with_graph']+=1
  for m in ms:
   target=encode(rules(p,s,m));winner=next((i for i in bank if i&target==i),None)
   ct['graphs']+=1
   if winner is None:failed.append([p,s,m]);ct['uncovered']+=1
   else:used[winner]=bank[winner];ct['covered']+=1
  if j%100==99:print(j+1,len(cases),dict(ct),int(time.monotonic()-tic),flush=True)
 rec={'reference':'midpoint' if v.midpoint else 'maximum','rank_extra_over_t_squared':str(rank_extra),'maximum_half_tangent':f'1/{v.Q}','angle_spread_radians_over_t_squared':str(loss),'large_angle_threshold_half_tangent':'1/24','large_range_concavity_checked':True,'all_signed_tilts_independent':True,'incorrect_bridge_patterns_excluded':n,'canonical_signs':len(cases),'counts':ct,'polynomial_certificates_used':len(used),'uncovered':len(failed)}
 print('complete',rec,flush=True)
 if v.holes:
  tmp=v.holes.with_suffix('.partial');tmp.write_text(json.dumps(failed,separators=(',',':')));tmp.replace(v.holes)
 if v.bundle and not failed:
  with gzip.open(v.bundle,'wt') as f:json.dump([{k:r[k] for k in ('rules','multipliers','margin')} for r in used.values()],f,separators=(',',':'))
 if v.out:v.out.write_text(json.dumps(rec,indent=2)+'\n')
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--Q',type=int,default=23);a.add_argument('--loss',default='1/10');a.add_argument('--midpoint',action='store_true');a.add_argument('--seed',type=Path,nargs='+',required=True);a.add_argument('--holes',type=Path);a.add_argument('--bundle',type=Path);a.add_argument('--out',type=Path);classify(a.parse_args())
