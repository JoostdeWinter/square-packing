# Unrestricted stability as the twenty independent tilts approach zero

Research direction by Joost de Winter. AI author GPT6.2 Astra.

Let twenty unit squares fit in a square of side S < 5. Measure each signed tile angle relative to the nearest pair of board axes. Let e be the largest absolute angle, in radians. For 0 ≤ e ≤ 1/10 put u = cos e + sin e and d = u(u−1). Then

    5 − S ≤ 15 d e + (24/5)e² ≤ (99/5 + 15e)e².

All twenty centers and angles may vary independently. In particular, every sequence of hypothetical sub-5 packings whose tilts approach zero approaches a board-aligned grid with one vacant cell in each row and each column, after passing to a subsequence. The shortfall in side length is at most quadratic in the maximum tilt. This conclusion applies without a prior hypothesis on the centers.

## Center ranks from transverse chords

In either coordinate direction, a line whose distance from a tile center is at most r = (1+u−u²)/2 = (1−d)/2 cuts a chord of length at least one in that tile. For an individual tile the exact such radius uses its own cosine-plus-sine, and the radius decreases with that sum. The stated common radius follows for all twenty. The chord formula is proved in boundary_sweep.md. At e=0 the open-side result follows immediately by dividing the center domain into sixteen squares of side less than one. Below assume e>0, so each such chord meets the interior.

Sort the twenty centers in either coordinate, writing x₁ ≤ ⋯ ≤ x₂₀. Five centers in a span of at most 1−d would give five unit chords on their common middle line, impossible at S < 5. Thus xᵢ₊₄−xᵢ > 1−d for 1 ≤ i ≤ 16. The walls also give x₁ ≥ 1/2 and x₂₀ ≤ S−1/2 < 9/2. For k = 0,…,4 the four centers ranked 4k+1 through 4k+4 all have this coordinate in the interval

    [ k+1/2−kd,  k+1/2+(4−k)d ].

Do this in both coordinates. Since u ≤ 1+e, we have d ≤ e(1+e) ≤ 11/100. Each rank interval has width 4d ≤ 0.44. Two centers in the same pair of rank intervals would be less than one apart even in Euclidean distance. Every tile contains the disk of radius 1/2 around its center, so this cannot happen. The twenty centers therefore determine twenty distinct cells of a 5-by-5 grid, with exactly four in every row and column. The five vacant cells form a permutation. The rank intervals also prove the convergence assertion, since d tends to zero. There are finitely many ways to label the limiting grid.

## A pair that serves two spanning chains

For each of the 120 possible vacancy permutations there is an occupied diagonal pair with both of these properties. It is a step in a five-tile left-to-right chain with one tile per column and three horizontal steps. It is also a step in a five-tile bottom-to-top chain with one tile per row and three vertical steps. The finite direct enumeration in near_grid.py constructs every such pair from its cell coordinates. It finds four usable pairs for 92 permutations, five for 24, and six for four.

Write Δx and Δy for center differences along a left-to-right chain. For any step, 1−5d ≤ Δx ≤ 1+3d. A straight step satisfies |Δy| ≤ 4d. On the diagonal step |Δy| ≤ 1+3d. The last bound uses the upper end of the higher rank interval and the lower end of the lower rank interval. The analogous estimates hold for a bottom-to-top chain after a quarter turn.

Two disjoint square interiors have a separating axis normal to an edge of one of the two squares. On a straight horizontal step, neither nearly vertical normal can separate them because its projection of the center difference in absolute value is at most (1+3d)e+4d < 1. On any step the projection on a near-horizontal normal pointing right is positive. Indeed Δx ≥ 1−5d ≥ 0.45 and |Δy| sin e ≤ (1+3d)e ≤ 0.133, while cos e ≥ 1−e²/2. Use the horizontal chain if the diagonal pair has a near-horizontal separating normal. Otherwise use the vertical chain. In the selected coordinate direction all four steps have a correctly signed separating normal.

## Summing the four separations

For a horizontal separating normal at signed angle α, where α is the angle of either incident tile, the separating-axis inequality is

    Δx cos α + Δy sin α ≥ (1 + cos(θⱼ−θᵢ) + |sin(θⱼ−θᵢ)|)/2.

For |t| ≤ 1/5 the usual sine and cosine bounds give cos t + |sin t| ≥ 1 + |t| − (8/15)t². Because Δx is positive, each step gives

    Δx ≥ 1 + |θⱼ−θᵢ|/2 − (4/15)(θⱼ−θᵢ)² − |Δy| |α|.

Each endpoint contributes wall clearance at least 1/2 + |θ|/2 − (4/15)θ². Half the sum of the two endpoint absolute angles and the four absolute differences is at least |α| for the diagonal step, by the triangle inequality along the paths from that incident tile to both chain ends. It pays one unit of the diagonal transverse coefficient. The remaining losses from the transverse terms are bounded by (3·4d+3d)e = 15de. The quadratic angular losses are at most (4/15)(4·4+2)e² = (24/5)e². Adding the wall clearances and the four steps gives the asserted bound.

Run python3 geometry/global_small_tilt.py from the archive root to replay the rational constants, the 120 cell permutations, and numerical examples enclosed by rational bounds on π.
