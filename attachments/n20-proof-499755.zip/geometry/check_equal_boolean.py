"""Independent Boolean and difference-constraint coverage of the small-angle certificates."""
from itertools import permutations,product,combinations
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
from pathlib import Path
import argparse,json,sys,gzip,time
h=Path(__file__).resolve().parents[1];sys.path.insert(0,str(h/'advanced'));from z3_lra import run
from near_grid import bridges
from equal_tilt_signs import assignments
from signed_linear import canon
from check_signed_duals import verify_cert
def join(op,x):return ('('+op+' '+' '.join(x)+')') if x else ('true' if op=='and' else 'false')
def gen(p,s,bank,Q=64,loss=0,rank_extra=0):
 occ=set(range(25))-{5*x+y for x,y in enumerate(p)};by={q:(1 if s>>i&1 else -1) for i,q in enumerate(sorted(occ))}
 S=['(set-logic QF_LRA)'];emit=lambda x:S.append('(assert '+x+')')
 X=lambda i,k:f't{k}_{i}'
 table={}
 for i in sorted(occ):
  for k,v in enumerate(divmod(i,5)):
   S.append('(declare-const '+X(i,k)+' Real)')
   if Q>=64 and v==0:emit('(>= '+X(i,k)+' 1)')
   if Q>=64 and v==4:emit('(<= '+X(i,k)+' (- 1))')
   for sign in [-1,1]:
    table['wall',i,k,sign]='';table['rank',i,k,sign,v]=''
 for i,j in combinations(sorted(occ),2):
  a=divmod(i,5);b=divmod(j,5);ds=[b[k]-a[k] for k in (0,1)]
  if max(map(abs,ds))!=1:continue
  diag=all(ds);gate=f'h{i}_{j}'
  if diag:S.append('(declare-const '+gate+' Bool)')
  for k in (0,1):
   if not ds[k]:continue
   lo,hi=(i,j) if ds[k]>0 else (j,i);h0=divmod(hi,5)[1-k]-divmod(lo,5)[1-k]
   if diag:
    hsg=h0*(1 if k==0 else -1);cost=-hsg*(by[lo]+by[hi])
   else:cost=abs(by[hi]-by[lo])
   c=str(cost) if cost>=0 else '(- '+str(-cost)+')'
   row='(>= (- '+X(hi,k)+' '+X(lo,k)+') '+c+')'
   choice=gate if k==0 else '(not '+gate+')'
   if Q>=64:emit('(=> '+choice+' '+row+')' if diag else row)
   if by[lo]==by[hi]:r=('same',lo,hi,k,by[lo])
   elif diag:r=('mixdiag',lo,hi,k,h0)
   else:r=('mixedstraight',lo,hi,k,0)
   table[r]=(choice if diag else '')
 if Q<64:
  from equal_path_polynomial import excluded
  clauses=set()
  for dim in (0,1):
   levels=[[cell for cell in sorted(occ) if divmod(cell,5)[dim]==level] for level in range(5)]
   for path in product(*levels):
    transverse=tuple(q%5 if dim==0 else 4-q//5 for q in path)
    if any(abs(u-v)>1 for u,v in zip(transverse,transverse[1:])):continue
    if not excluded(transverse,tuple(by[q] for q in path),Q,loss,rank_extra):continue
    lits=[]
    for i,j,u,v in zip(path,path[1:],transverse,transverse[1:]):
     if u==v:continue
     a,b=sorted((i,j));name=f'h{a}_{b}';lits.append(name if dim==0 else '(not '+name+')')
    clauses.add(frozenset(lits))
  for c in sorted(clauses,key=lambda e:(len(e),sorted(e))):
   if not any(d<c for d in clauses):emit('(not '+join('and',sorted(c))+')')
 for keys in bank:
  if all(k in table for k in keys):
   needed=sorted({table[k] for k in keys if table[k]})
   emit('(not '+join('and',needed)+')')
 return '\n'.join(S)+'\n(check-sat)\n'
def sign_cover(p,expected):
 occ=sorted(set(product(range(5),repeat=2))-set(enumerate(p)));id_={q:i for i,q in enumerate(occ)}
 var=[f's{i}' for i in range(20)];T=['(set-logic QF_UF)']+['(declare-const '+q+' Bool)' for q in var]
 def lit(i,b):return var[i] if b else '(not '+var[i]+')'
 for x,y,d in bridges(set(enumerate(p))):
  pair=sorted(((x,y),(x+1,y+d)),key=lambda p:p[1]);k=pair[0][1]
  hs=[(X,y if X<=x else y+d) for X in range(5)];vs=[(pair[0][0] if Y<=k else pair[1][0],Y) for Y in range(5)]
  H=join('and',[lit(id_[q],d>0) for q in hs]);V=join('and',[lit(id_[q],d<0) for q in vs]);T.append('(assert (or '+H+' '+V+'))')
 for s in expected:T.append('(assert '+join('or',[lit(i,not (s>>i&1)) for i in range(20)])+')')
 return '\n'.join(T)+'\n(check-sat)\n'
def main(v):
 with gzip.open(v.certs,'rt') as f:cert=json.load(f)
 from equal_path_polynomial import bridge
 from fractions import Fraction as F
 loss=F(v.loss);rank_extra=F(3,2)*loss if v.midpoint else 0;assert v.Q>=20 and not bridge(v.Q,loss,rank_extra)[1]
 if loss:
  from angle_diversity import robust
  assert all(robust(r,v.Q,loss,rank_extra) for r in cert)
 assert all(verify_cert(r,v.Q) for r in cert);bank=[set(tuple(k) for k in r['rules']) for r in cert];todo=[];canon_cases=set()
 for p in permutations(range(5)):
  expected=assignments(p);todo.append(('sign_cover',sign_cover(p,expected)))
  canon_cases.update(canon(p,s) for s in expected if loss or s not in (0,1048575))
 for p,s in sorted(canon_cases):todo.append(('independent_graph_cover',gen(p,s,bank,v.Q,loss,rank_extra)))
 ct=Counter();start=time.monotonic()
 def one(req):
  kind,src=req;res,_=run(src,60000);assert res=='unsat',(kind,res);return kind
 with ThreadPoolExecutor(v.jobs) as pool:
  for j,r in enumerate(as_completed([pool.submit(one,k) for k in todo]),1):
   ct[r.result()]+=1
   if j%100==0:print(j,dict(ct),int(time.monotonic()-start),flush=True)
 rec={'small_half_tangent_cutoff':f'1/{v.Q}','midpoint':v.midpoint,'loss_over_t_squared':str(loss),'exact_polynomial_certificates':len(cert),'unsatisfiable_by_independent_formulation':ct,'unresolved':0};print(rec,flush=True)
 if v.out:v.out.write_text(json.dumps(rec,indent=2)+'\n')
if __name__=='__main__':
 q=argparse.ArgumentParser();q.add_argument('certs',type=Path);q.add_argument('--out',type=Path);q.add_argument('--Q',type=int,default=64);q.add_argument('--loss',default='0');q.add_argument('--midpoint',action='store_true');q.add_argument('--jobs',type=int,default=3);main(q.parse_args())
