"""Search for dual certificates of the common-orientation subproblem."""
import json
from pathlib import Path
from functools import lru_cache
import numpy as np
from scipy.optimize import linprog
h=Path(__file__).resolve().parent
def constraints(record,solution):
 pts=[tuple(z) for z in record['points']];lookup={p:i for i,p in enumerate(pts)}
 rules=[]
 for i,(x,y) in enumerate(pts):
  for kind in range(4):rules.append((kind,i))
  for k,adj in enumerate([(x+1,y),(x,y+1)]):
   if adj in lookup:rules.append((4+k,i,lookup[adj]))
 for var,(i,j) in zip(solution,record['diagonals'],strict=True):
  if var>0:rules.append((4,i,j))
  elif pts[i][1]<pts[j][1]:rules.append((5,i,j))
  else:rules.append((5,j,i))
 return rules
def system(rules,t):
 # -a*x <= rhs (walls and translations in board coordinates).
 # Variable 40 is the outer side; minimize it.
 c=1-t*t;s=2*t;den=1+t*t;u=(c+s)/2
 A=np.zeros((len(rules),41));b=np.zeros(len(rules))
 for row,r in enumerate(rules):
  k,i,*z=r
  if k<4:
   ax=k//2
   if k%2:
    A[row,2*i+ax]=den;A[row,40]=-den
   else:A[row,2*i+ax]=-den
   b[row]=-u
  else:
   j=z[0]
   a,beta=(c,s) if k==4 else (-s,c)
   A[row,2*i:2*i+2]=a,beta;A[row,2*j:2*j+2]=-a,-beta;b[row]=-den
 return A,b
def solve(rules,t):
 A,b=system(rules,t);obj=np.zeros(41);obj[40]=1
 opt=linprog(obj,A_ub=A,b_ub=b,bounds=(None,None),method='highs')
 if opt.status!=0:raise ArithmeticError(opt.message)
 nz=np.flatnonzero(-opt.ineqlin.marginals>1e-9)
 return opt.fun,[rules[i] for i in nz],(-opt.ineqlin.marginals[nz]).tolist()
def main():
 rows=json.loads((h/'graphs.json').read_text());seen=set();examples=[]
 n=0
 for record in rows:
  for sol in record['solutions']:
   rules=constraints(record,sol)
   if any(s.issubset(rules) for s in seen):continue
   side,active,weights=solve(rules,.013)
   print(len(seen),record['holes'],len(active),side,flush=True) if len(seen)%25==0 else None
   if not side>5+1e-8:print('possible!',float(side),flush=True);return
   s=frozenset(active);seen.add(s);examples.append({'active':active,'w':weights,'side':side})
   n+=1
 (h/'dual_candidates.json').write_text(json.dumps(examples))
 print('distinct positive supports',n,flush=True)
if __name__=='__main__':main()
