# Local stability of every 20-site grid placement

Let 20 centers lie within distance r in both coordinates of 20 distinct sites of the board-aligned grid (i+1/2, j+1/2), for i,j from 0 through 4. Let the absolute tilt of each tile, measured modulo 90 degrees, be at most e radians. For r,e ≤ 1/20 a board containing those squares must satisfy

    5 − S ≤ 8 r e + 5 e².

If only r is specified and r ≤ 1/250, with freely rotating tiles in [0,S]² and S ≤ 5, then 5−S ≤ 693 r².

First consider a fully occupied grid row or column. A line at distance at most (√2−1)/2 from a tile center cuts the unit square in a chord of length at least 1. In the angled case its chord at distance v is the lesser of 1/max(c,s) and ((c+s)/2 − |v|)/(cs), where c,s are the absolute sine and cosine of the angle. The allowable distance is (1+u−u²)/2 with u=c+s; its minimum is (√2−1)/2. The horizontal axis case follows directly. Five such chords on the grid center line force S ≥ 5. Because r < 1/2 here, each tile meets the line through its interior at the potentially degenerate horizontal angle. This handles 53,010 of the 53,130 patterns, even allowing arbitrary tilts.

In the other 120 patterns the holes form a permutation, with one in every row and column. Each has an occupied diagonally adjacent pair that can serve as one step of a left-to-right five-tile chain and also one step of a bottom-to-top five-tile chain. All other steps in the first chain are horizontally adjacent and in the second vertically adjacent. The integer verifier enumerates every possible diagonal. It finds exactly 4 such pairs in 92 patterns, 5 in 24 and 6 in 4. The separating-axis theorem assigns either a nearly horizontal or a nearly vertical separating direction to this diagonal pair. Use the corresponding chain. On its other three (straight) steps the perpendicular separation cannot work because 2r+(1+2r)e < 1.

For a horizontal step from tile i to tile j use the separating normal at angle α, equal to one of their two tilts. It satisfies

    Δx cos α + Δy sin α ≥ (1+cos(θᵢ−θⱼ)+|sin(θᵢ−θⱼ)|)/2.

The normal pointing to the right is forced by the center order and the assumed bounds on r,e. For |t| ≤ 1/10, cos t + |sin t| ≥ 1+|t|−(8/15)t² by the elementary sine and cosine Taylor inequalities. Each ordinary step loses at most 2re to the transverse displacement. The exceptional step loses at most 2re+|α|. Each end of the chain needs an additional wall distance (cos θ+|sin θ|)/2. The sum of the two end absolute angles and the four absolute angle differences along the chain is at least 2|α|, by the triangle inequality along the two paths to the ends. Thus the first-order angular terms pay the entire exceptional step. The sum of the quadratic losses is at most (4/15)(16e²+2e²)<5e². The vertical case follows by rotating the axes. This proves the stated estimate, including the freely varying translation and tilt of every square.

For the position-only version, tilts below always denote the angular distance modulo 90 degrees in [0,π/4]. An edge site satisfies cos θ+sin θ ≤1+2r from its wall clearance. For any occupied horizontally or vertically adjacent sites, the center distance is at most 1+2r+2r². By the separating-axis theorem their relative tilt d satisfies (1+cos d+sin d)/2 ≤1+2r+2r². Concavity of sine plus cosine gives cos d+sin d−1 ≥ d/2 for 0≤d≤π/4. Hence for r≤1/250 these angles are below 0.033, and the preceding quadratic estimate sharpens the wall bound to 2.1r and the neighbor bound to 4.1r. The integer verifier checks that each occupied site in every permutation is within two occupied edge-adjacent steps of a boundary site. Consequently e≤11r. Substitution proves 5−S≤693r². A possible quadratic improvement in the side is still allowed by this result.
