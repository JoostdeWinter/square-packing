# A fixed region inside every tile that misses the integer lattice

Research direction by Joost de Winter. AI author GPT6.2 Astra.

Every packing of twenty independently rotated unit squares in a board of side S < 5 has at least four distinct tiles, each containing an explicit fixed region at a different noncorner cell center. In coordinates normalized to a board of side 5, the region around each selected half-integer site is

    K = { (x,y) : (|x|+1/2)² + (|y|+1/2)² ≤ 1 }.

Here (x,y) is displacement from the site. This is the intersection of the four unit disks centered at the four corners of that cell. Its horizontal and vertical radii are (√3−1)/2, and it contains a disk of radius 1−1/√2. The region is the full intersection forced by missing the integer lattice in that cell, across all possible angles and centers in the plane.

To see this, normalize as in integer_grid.md. At most sixteen of the twenty separated tiles can contain an integer point. For each tile missing the lattice, let q be its half-integer site. At fixed angle θ its center must lie strictly inside the rotated square about q of side u−1, where u = |cos θ|+|sin θ|. Intersecting the unit tile over these translations leaves a square centered at q, aligned with the tile, of side 2−u. Intersect these squares over θ. In any unit direction ν the constraint is

    z · ν + (|νₓ|+|νᵧ|)/2 ≤ 1.

The left side is the support function of z + [−1/2,1/2]², so all these inequalities hold exactly when the four corners of that translated square have Euclidean norm at most one. Their largest squared norm is (|zₓ|+1/2)²+(|zᵧ|+1/2)². This proves the formula and its sharpness for the single-tile lattice-miss condition. Each such tile contains the site itself in its interior, so its site cannot be assigned to a second tile.

There is an exact version in the original board, before normalizing. Write μ = S/5, and use the site μq. During the return from the normalized packing all center displacements from the site are multiplied by μ, while tile side and orientation stay fixed. The forced square at angle θ therefore has side 1−μ(u−1). Its intersection over all angles is

    Kμ = { (x,y) : (|x|+μ/2)² + (|y|+μ/2)² ≤ ((1+μ)/2)² }.

The extra space in this last kernel is available in every quantitative side test. The proof uses no common-orientation or grid-center assumption on any tile.
