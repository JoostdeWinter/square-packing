"""Discover or replay small-angle inequalities for nineteen tilted squares and one aligned square."""
from pathlib import Path
from itertools import permutations
from collections import Counter
import argparse,time,json,gzip,os,hashlib
from one_axis_equal import patterns,canon,rows,clauses,h
from signed_angle_graphs import models,pattern
from verify_equal_magnitude import loadbank
from check_signed_duals import verify_cert
def execute(args):
 from fractions import Fraction as F
 e=F(2,args.Q);d=e*(1+e)
 if args.exact_paths:
  from one_axis_paths import bridges_exact,clauses as exact_clauses
  assert args.Q>=24 and not bridges_exact(args.Q)[1]
 else:
  assert args.Q>=128 and (20*(1+e)+F(24,5)+2*e/3)*e<F(1,2)
 assert 1-5*d>(1+e/2)/args.Q
 dest=args.dest;dest.mkdir(exist_ok=True,parents=True);atoms={};known={};seen=set();failed=[];ct=Counter();used={};started=time.monotonic()
 def encode(rules):
  value=0
  for rule in rules:
   r=tuple(rule)
   if r not in atoms:atoms[r]=len(atoms)
   value|=1<<atoms[r]
  return value
 def register(row,optional=False):
  key=encode(row['rules'])
  if key not in known:
   try:valid=verify_cert(row,args.Q)
   except AssertionError:
    if optional:return
    raise
   assert valid;known[key]=row
 def refresh():
  for f in dest.glob('cert_*.json'):
   if f not in seen:register(json.loads(f.read_text()));seen.add(f)
 def save(row):
  register(row);raw=json.dumps(row,separators=(',',':'));name=hashlib.sha256(raw.encode()).hexdigest();f=dest/('cert_'+name+'.json')
  tmp=f.with_name(f.name+'.'+str(os.getpid()));tmp.write_text(raw);tmp.replace(f)
 for src in args.seed or []:
  for row in loadbank(src):register(row,optional=args.filter_seed)
 refresh();canonical=set()
 catalog=h/'trials/one_axis_sign_catalog.json'
 if args.discover and catalog.exists():
  data=json.loads(catalog.read_text());ct['initial_signs']=data['count'];canonical={(tuple(p),s,z) for p,s,z in data['cases']}
 else:
  for p in permutations(range(5)):
   for z in range(20):
    v=patterns(p,z);ct['initial_signs']+=len(v);canonical.update(canon(p,s,z) for s in v)
  if args.discover:
   tmp=catalog.with_suffix('.'+str(os.getpid()));tmp.write_text(json.dumps({'count':ct['initial_signs'],'cases':sorted(canonical)},separators=(',',':')));tmp.replace(catalog)
 ct['canonical_signs']=len(canonical)
 if args.discover:from repair_signed_duals import phase,make
 for it,(p,s,z) in enumerate(sorted(canonical)):
  if it%args.parts!=args.part or it<args.offset or it>=args.offset+args.count:continue
  receipt=dest/f'rep_{it:04}'
  if args.discover and receipt.exists() and not json.loads(receipt.read_text())['uncovered']:continue
  before=ct['uncovered']
  if args.discover and it%(40*args.parts)==args.part:refresh()
  _,edges,_=pattern(p);forbidden=exact_clauses(p,s,z,args.Q) if args.exact_paths else clauses(p,s,z);ms=models(forbidden,len(edges),False)
  for graph in ms:
   ct['graphs']+=1;rs=rows(p,s,z,graph);mask=encode(rs)
   winner=next((k for k in known if k&mask==k),None)
   if winner is not None:
    ct['bank']+=1;used[winner]=known[winner];continue
   if args.discover:
    found=False
    for seed in range(args.attempts):
     t=(1/84,1/59,1/100,1/72,1/48,1/33)[seed%6] if not args.exact_paths else (0.92,0.65,0.41,0.2,0.98,0.10)[seed%6]/args.Q
     gap,sub=phase(rs,t,seed)
     if gap>=-1e-12:continue
     try:cert=make({'rules':sub},args.Q)
     except (AssertionError,ValueError):continue
     save(cert);used[encode(cert['rules'])]=cert;ct['new']+=1;found=True;break
    if found:continue
   ct['uncovered']+=1
   if len(failed)<5000:failed.append((p,s,z,graph))
  if args.discover:
   tmp=receipt.with_suffix('.'+str(os.getpid()));tmp.write_text(json.dumps({'graphs':len(ms),'uncovered':ct['uncovered']-before}));tmp.replace(receipt)
  if (it//args.parts)%50==49:print(it,len(canonical),dict(ct),'available',len(known),int(time.monotonic()-started),flush=True)
 result={'counts':ct,'uncovered_examples':failed,'verified_bank':len(known),'angular_cutoff':str(args.Q),'exact_chain_inequalities':args.exact_paths,'polynomial_certificates_used':len(used)}
 (dest/f'summary_{args.part}_{args.parts}').write_text(json.dumps(result,separators=(',',':')))
 if args.bundle or args.out:
  assert not args.discover and args.parts==1 and args.offset==0 and args.count>=len(canonical) and ct['uncovered']==0
  assert ct['initial_signs']==29368 and ct['canonical_signs']==3671
  if not args.exact_paths:assert ct['graphs']==273584
  if args.bundle:
   with gzip.open(args.bundle,'wt') as f:json.dump([{k:r[k] for k in ('rules','multipliers','margin')} for r in used.values()],f,separators=(',',':'))
  if args.out:args.out.write_text(json.dumps(result,indent=2)+'\n')
 print('complete',dict(ct),'available',len(known),flush=True)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('dest',type=Path);a.add_argument('--seed',nargs='*',type=Path);a.add_argument('--Q',type=int,default=128);a.add_argument('--discover',action='store_true');a.add_argument('--exact-paths',action='store_true');a.add_argument('--filter-seed',action='store_true');a.add_argument('--part',type=int,default=0);a.add_argument('--parts',type=int,default=1);a.add_argument('--bundle',type=Path);a.add_argument('--out',type=Path);a.add_argument('--attempts',type=int,default=4);a.add_argument('--offset',type=int,default=0);a.add_argument('--count',type=int,default=100000);execute(a.parse_args())
