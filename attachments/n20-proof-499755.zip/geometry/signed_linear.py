"""Search one-parameter linear certificates when the twenty tilt magnitudes agree."""
from signed_angle_graphs import pattern,constraints,models
from equal_tilt_signs import assignments
from itertools import permutations,product
from collections import Counter
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import json,time,argparse,math
h=Path(__file__).resolve().parents[1]
def canon(p,s):
 A,_,_=pattern(p);sign={pt:((s>>i)&1) for i,pt in enumerate(A)};best=None
 for swap,fx,fy in product((0,1),repeat=3):
  def transform(x,y):
   if swap:x,y=y,x
   return (4-x if fx else x,4-y if fy else y)
  parity=swap^fx^fy;v=sorted(transform(*q) for q in enumerate(p));P=tuple(y for x,y in v);o=sorted((transform(*q),b^parity) for q,b in sign.items());S=sum(b<<i for i,(q,b) in enumerate(o))
  if best is None or (P,S)<best:best=P,S
 return best
def rules(p,s,m):
 A,diag,_=pattern(p);I={q:i for i,q in enumerate(A)};sg=lambda i:1 if s>>i&1 else -1;rs=[]
 for i,(x,y) in enumerate(A):
  cid=5*x+y
  for d,k in enumerate((x,y)):
   rs.extend([('wall',cid,d,-1),('wall',cid,d,1),('rank',cid,d,-1,k),('rank',cid,d,1,k)])
   z=(x+(d==0),y+(d==1))
   if z in I:
    j=I[z];cj=5*z[0]+z[1];same=sg(i)==sg(j)
    rs.append(('same' if same else 'mixedstraight',cid,cj,d,sg(i) if same else 0))
 for k,(i,j) in enumerate(diag):
  axis=0 if (m>>k)&1 else 1
  if A[i][axis]>A[j][axis]:i,j=j,i
  ci=5*A[i][0]+A[i][1];cj=5*A[j][0]+A[j][1];dh=A[j][1-axis]-A[i][1-axis]
  if sg(i)==sg(j):rs.append(('same',ci,cj,axis,sg(i)))
  else:rs.append(('mixdiag',ci,cj,axis,dh))
 return tuple(rs)
def numeric(rs,spec):
 import numpy as np
 from scipy.optimize import linprog
 q=spec;c=(1-q*q)/(1+q*q);t=2*q/(1+q*q);u=c+t;d=u*(u-1)
 used=sorted({r[1] for r in rs}|{r[2] for r in rs if r[0] not in ('wall','rank')});idx={q:j for j,q in enumerate(used)};n=2*len(used)
 A=np.zeros((len(rs),n+1));B=np.zeros(len(rs))
 for k,r in enumerate(rs):
  what,i=r[:2];i=idx[i];a=A[k]
  if what=='wall':
   _,_,dim,sd=r;a[2*i+dim]=sd
   if sd==1:a[-1]=-1
   B[k]=-u/2
  elif what=='rank':
   _,_,dim,sd,x=r;a[2*i+dim]=sd;B[k]=sd*(x+.5)+(4-x if sd==1 else x)*d
  else:
   _,_,j,dim,sg=r;j=idx[j];l=(t*sg if dim==0 else -t*sg) if what=='same' else (t*sg if what in ('mixdiag','mixstraight_sign') else 0)
   a[2*i+dim]=c;a[2*j+dim]=-c;a[2*i+1-dim]=l;a[2*j+1-dim]=-l
   B[k]=-1 if what=='same' else -c*u+(4*t*d if what=='mixedstraight' else 0)
 opt=linprog(np.r_[np.zeros(n),1],A_ub=A,b_ub=B,bounds=[(None,None)]*(n+1),method='highs',options={'dual_feasibility_tolerance':1e-10,'primal_feasibility_tolerance':1e-10})
 if opt.status==2:return None,[]
 assert opt.success,(opt.status,opt.message)
 sel=[rs[k] for k,z in enumerate(opt.ineqlin.marginals) if z<-1e-9]
 return opt.fun,sel
def job(J):
 p,s,lim,t0,dest=J;tag=''.join(map(str,p))+'_'+str(s);f=dest/(tag+'.json')
 if f.exists():return json.loads(f.read_text())
 cl=constraints(p,s);A,E,_=pattern(p);ms=models(cl,len(E),False);rows=[];samples=[];supports=[];hist=Counter()
 for m in ms[:lim] if lim else ms:
  rs=rules(p,s,m);v,ss=numeric(rs,t0);label='infeasible' if v is None else 'strict' if v>5+1e-8 else 'equal' if v>=5-1e-8 else 'open';hist[label]+=1
  if label in ('strict','equal'):
   ss=tuple(sorted(ss));supports.append((m,ss))
  elif len(samples)<12:samples.append([m,v])
 rec={'p':p,'s':s,'models':len(ms),'tested':sum(hist.values()),'counts':hist,'samples':samples,'supports':supports};f.write_text(json.dumps(rec,separators=(',',':'))+'\n');return rec
def main(v):
 src=json.loads((h/'trials/signed_graph_kept.json').read_text());todo=set()
 for k,signs in src.items():
  p=tuple(map(int,k.split(',')))
  for s in signs:
   if s not in (0,1048575):todo.add(canon(p,s))
 d=h/f'trials/signed_lps_{v.tag}';d.mkdir(exist_ok=True);start=time.monotonic();histo=Counter();size=0;totalmodels=0
 work=sorted(todo,key=lambda j:(min(j[1].bit_count(),20-j[1].bit_count()),j))
 with ProcessPoolExecutor(v.jobs) as ex:
  for j,f in enumerate(as_completed([ex.submit(job,(p,s,v.limit,v.t,d)) for p,s in work]),1):
   r=f.result();histo.update(r['counts']);size+=r['tested'];totalmodels+=r['models']
   if j%15==0:print(j,len(work),size,totalmodels,dict(histo),int(time.monotonic()-start),flush=True)
 print('done',len(work),size,totalmodels,dict(histo),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--limit',type=int,default=4);p.add_argument('--jobs',type=int,default=2);p.add_argument('--t',type=float,default=.013);p.add_argument('--tag',default='first');main(p.parse_args())
