// Discovery oracle at fixed angles. Searches the weighted cells induced by
// active mark-centered squares inside the projected board-center polygon.
// Any candidate certificate would require a separate exact continuous replay.
#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <iostream>
#include <map>
#include <stdexcept>
#include <tuple>
#include <vector>
using namespace std;
struct M{double x,y,w;};struct W{double mass,x,y;};
pair<double,double> horizontal(double c,double s,double span,double level){
    double lo=-1e60,hi=1e60;
    auto impose=[&](double a,double v){if(abs(a)<1e-15)return;double a0=(-span-v)/a,a1=(span-v)/a;lo=max(lo,min(a0,a1));hi=min(hi,max(a0,a1));};
    impose(c,-s*level);impose(s,c*level);return {lo,hi};
}
int main(int argc,char** argv){double L=stod(argv[1]);int bins=stoi(argv[2]),want=stoi(argv[3]);ifstream f(argv[4]);int n;f>>n;vector<M> marks(n);for(auto& m:marks)f>>m.x>>m.y>>m.w;
    cout.precision(15);
    for(int k=0;k<=bins;k++){
        double ang=acos(-1)*k/(4*bins),c=cos(ang),s=sin(ang),span=(L-c-s)/2,vmax=(c+s)*span;
        vector<M> m;vector<double> events={-vmax,vmax,(-c+s)*span,(c-s)*span};
        for(auto p:marks){p.x-=L/2;p.y-=L/2;M t={c*p.x+s*p.y,-s*p.x+c*p.y,p.w};m.push_back(t);
            for(double w:{t.y-.5,t.y+.5})if(w>-vmax&&w<vmax)events.push_back(w);}
        sort(events.begin(),events.end());vector<W> best;
        for(size_t j=1;j<events.size();j++){
            double bot=events[j-1],top=events[j];if(top-bot<1e-10)continue;
            double mid=(top+bot)/2;auto al=horizontal(c,s,span,bot),at=horizontal(c,s,span,top);
            double xmin=min(al.first,at.first),xmax=max(al.second,at.second),w=0;
            vector<pair<double,double>> changes;
            for(auto p:m)if(abs(p.y-mid)<.5){
                if(p.x-.5<=xmin&&xmin<p.x+.5)w+=p.w;
                if(xmin<p.x-.5&&p.x-.5<xmax)changes.push_back({p.x-.5,p.w});
                if(xmin<p.x+.5&&p.x+.5<xmax)changes.push_back({p.x+.5,-p.w});}
            changes.push_back({xmax,0});sort(changes.begin(),changes.end());double prev=xmin;
            for(auto [x,delta]:changes){
                if(x-prev>1e-9&&w<1.000001){
                    double u=.5*(x+prev);auto ys=horizontal(c,-s,span,u);
                    // x=c*u-s*v, y=s*u+c*v. With v as variable the
                    // admissible interval is horizontal(c,s,span,-u) by a quarter turn.
                    ys=horizontal(c,s,span,-u);
                    double l=max(bot,ys.first),r=min(top,ys.second);
                    if(r-l>1e-10){double v=(l+r)/2,xx=c*u-s*v+L/2,yy=s*u+c*v+L/2;best.push_back({w,xx,yy});}
                }
                w+=delta;prev=x;
            }
        }
        stable_sort(best.begin(),best.end(),[](W a,W b){return a.mass<b.mass;});vector<W> used;
        for(auto z:best){bool near=false;for(auto p:used)if(hypot(p.x-z.x,p.y-z.y)<.04){near=true;break;}
            if(near)continue;used.push_back(z);cout<<k<<" "<<z.mass<<" "<<z.x<<" "<<z.y<<" "<<ang<<"\n";if((int)used.size()>=want)break;}
    }
}
