"""Exact lower bounds for nearly parallel squares of independently chosen angles."""
from pathlib import Path
from fractions import Fraction as F
import json
from verify_parallel import add,mult,scale,positive,verify_weights
h=Path(__file__).resolve().parent
def proof(certs,Q,K):
 d=[1,0,1];u=[1,2,-1];S=[5,0,K]
 # 5d² times the signed difference between the required vertical drift of
 # a four-gap horizontal chain and the width of one of the five bands.
 drift=add([1,-5],scale(mult([0,1],d),-K/2))
 diff=add(mult(scale(mult(d,d),5),drift),scale(mult(u,add(mult(S,d),scale(u,-1))),-1))
 if not positive(diff,strict=True,Q=Q):return False
 # Each old Farkas identity cancels all center coordinates exactly. Only
 # the upper-wall terms have negative coefficients of container side.
 for row in certs:
  side=[]
  for rule,w in zip(row['rules'],row['multipliers']):
   if rule[0] in (1,3):side=add(side,scale(mult(d,w),-2))
  margin=add(row['margin'],mult([0,0,K],side))
  if not positive(margin,strict=True,Q=Q):return False
 return True
def main():
 certs=json.loads((h/'parallel_certificates.json').read_text())
 for row in certs:verify_weights(row)
 results=[]
 for Q in (31,32,33,35,40,45,50,60,64,80,100):
  lo=0;hi=1601
  while hi-lo>1:
   m=(lo+hi)//2
   if proof(certs,Q,F(m,100)):lo=m
   else:hi=m
  results.append({'half_tangent_max':'1/'+str(Q),'K':str(F(lo,100))})
 assert all(F(z['K'])>0 for z in results)
 print(json.dumps(results,indent=2))
if __name__=='__main__':main()
