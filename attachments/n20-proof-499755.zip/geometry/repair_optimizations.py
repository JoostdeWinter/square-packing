"""Repair each numerical candidate by uniformly spacing the centers, and verify the best exactly."""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import json,math
h=Path(__file__).resolve().parents[1];D=10**10
def test(data,exact):
 z=data['coordinates'];n=20;xs=z[:40:2];ys=z[1:40:2];angles=z[40:60]
 if exact:
  xs=[F(round(x*D),D) for x in xs];ys=[F(round(y*D),D) for y in ys];ts=[F(round(math.tan(a/2)*D),D) for a in angles]
  dirs=[((1-t*t)/(1+t*t),2*t/(1+t*t)) for t in ts]
 else:dirs=[(math.cos(a),math.sin(a)) for a in angles]
 k=0;active=None
 for i,j in combinations(range(n),2):
  c,s=dirs[i];C,S=dirs[j];dx=xs[i]-xs[j];dy=ys[i]-ys[j]
  dot=c*C+s*S;sin=c*S-s*C
  need=(1+abs(dot)+abs(sin))/2
  sep=max(abs(dx*c+dy*s),abs(-dx*s+dy*c),abs(dx*C+dy*S),abs(-dx*S+dy*C))
  if need>k*sep:k=need/sep;active=(i,j)
 w=[(abs(c)+abs(s))/2 for c,s in dirs]
 caps=[max(k*v+t for v,t in zip(axis,w))-min(k*v-t for v,t in zip(axis,w)) for axis in (xs,ys)]
 return max(caps),k,active
def main():
 rows=[(f,json.loads(f.read_text())) for f in sorted((h/'trials/packing_optimization').glob('*.json'))];assert len(rows)==2300
 ranked=sorted((test(dat,False)[0],str(f),dat) for f,dat in rows)
 # The top hundred, plus anything within 1e-7 of crossing 5, are reconstructed
 # with rational half-angles. Floating input is only used to propose a rational pose.
 use=[z for i,z in enumerate(ranked) if i<100 or z[0]<5.0000001]
 best=None
 for _,f,dat in use:
  cap,k,p=test(dat,True)
  if best is None or cap<best[0]:best=(cap,k,p,Path(f).name,dat)
 c,k,p,f,r=best
 result={'numerical_starts':len(rows),'repaired_with_all_190_pair_constraints':len(ranked),'rational_reconstructions':len(use),'minimal_certified_side':str(c),'decimal_display':float(c),'center_scale':str(k),'active_pair':p,'discovery_file':f,'candidate':r,'below_five':c<5}
 out=h/'runs/repaired_search.json';out.write_text(json.dumps(result,indent=2));print({k:v for k,v in result.items() if k not in ('minimal_certified_side','candidate','center_scale')})
if __name__=='__main__':main()
