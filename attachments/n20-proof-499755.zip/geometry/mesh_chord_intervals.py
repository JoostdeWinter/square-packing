"""A sparse piecewise-linear enclosure of the four grid-line chord endpoints."""
from four_tilt_smt import *
def generate(C,bins,blocks=None,full=False,strict=True):
 out=[model(C,bins,blocks,details=full,strict_physical=strict).split('(check-sat)')[0]];edges={};margin=F(1414214,10**6)
 def emit(z):out.append('(assert '+z+')')
 def real(z):out.append('(declare-fun '+z+' () Real)');return z
 def dis(x):return joint(x,'or')
 def op(a,sg,b):return '('+sg+' '+a+' '+b+')'
 def off(p,k):
  i,j=p
  if i in range(1,5) and j in range(1,5):return f'z_{i}_{j}_{k}'
  v=p[k];return number(-F(1,2) if v==0 else F(1,2) if v==5 else 0)
 for i,(x,y) in enumerate(C):
  T=[f't_{i}_{j}' for j in (0,1)];V=[real(f'v_{i}_{j}') for j in (0,1)]
  for a,b in product((-1,1),repeat=2):emit(con(dot((a,b),V),'<',2))
  for v in V:emit(con(v,'<',margin));emit(con(v,'>',-margin))
  for axis,cell in enumerate((x,y)):
   if cell==0:emit(con(V[axis],'>',1))
   if cell==4:emit(con(V[axis],'<',-1))
  definitions=[((x,y,0),1,-1,-1,'q','p'),((x,y+1,0),1,1,1,'p','q'),((x,y,1),0,-1,1,'p','q'),((x+1,y,1),0,1,-1,'q','p')]
  parts=[]
  for k,(edge,axis,sg,signA,left,right) in enumerate(definitions):
   X,Y,dim=edge;L=real(f'ell_{i}_{k}');R=real(f'r_{i}_{k}');D=add('1',scale(sg,V[axis]));active=con(D,'>',0)
   aa=off((X,Y),dim);bb=off((X+(dim==0),Y+(dim==1)),dim)
   emit('(=> '+active+' '+joint([op(aa,'<',L),op(L,'<',R),op(R,'<',bb)])+')')
   emit('(=> (not '+active+') '+joint([con(L,'=',0),con(R,'=',0)])+')')
   parts.append((active,L,R,D,axis,signA,left,right));edges.setdefault(edge,[]).append((active,L,R))
  for k in [(0,1),(2,3)]:emit(con(add(*(sub(parts[j][2],parts[j][1]) for j in k)),'>=',F(2)/(1+margin)))
  intervals=blocks[i] if blocks else [(F(j,bins),F(j+1,bins)) for j in range(bins)]
  for j,(a,b) in enumerate(intervals):
   ca,sa=trig(a);cb,sb=trig(b);cm,sm=trig((a+b)/2);u0=min(ca+sa,cb+sb);umax=max(ca+sa,cb+sb) if (ca-sa)*(cb-sb)>=0 else margin
   d0=(u0-1)/2;d1=(umax-1)/2;A0=(cb-sb)/2;A1=(ca-sa)/2
   B={'p':(cb*cb/(1+umax),ca*ca/(1+u0)),'q':(sa*sa/(1+umax),sb*sb/(1+u0))};extra=[]
   factor=max(cm*c+sm*s+abs(cm*s-sm*c) for c,s in [(ca,sa),(cb,sb)])
   for n in dirs(cm,sm):extra.append(con(dot(n,V),'<',factor))
   for t,v in zip(T,V):
    if d0==d1:extra.append(op(t,'=',scale(d0,v)));continue
    pos=joint([con(v,'>=',0),op(scale(d0,v),'<=',t),op(t,'<=',scale(d1,v))])
    neg=joint([con(v,'<=',0),op(scale(d1,v),'<=',t),op(t,'<=',scale(d0,v))]);extra.append(dis([pos,neg]))
   for active,L,R,D,axis,sg,left,right in parts:
    t=T[1-axis];AL,AH=(A0,A1) if sg>0 else (-A1,-A0);l,u=B[left];v,w=B[right]
    terms=[op(add(t,number(AL),scale(-u,D)),'<=',L),op(L,'<=',add(t,number(AH),scale(-l,D))),op(add(t,number(AL),scale(v,D)),'<=',R),op(R,'<=',add(t,number(AH),scale(w,D))),op(scale(1/(1+umax),D),'<=',sub(R,L)),op(sub(R,L),'<=',scale(1/(1+u0),D))]
    extra.append('(=> '+active+' '+joint(terms)+')')
   emit('(=> b_'+str(i)+'_'+str(j)+' '+joint(extra)+')')
 for edge,z in edges.items():
  assert len(z)<=2
  if len(z)==2:
   (a,l,r),(b,L,R)=z
   emit('(=> '+joint([a,b])+' '+dis([op(r,'<',L),op(R,'<',l)])+')')
 return '\n'.join(out)+'\n(check-sat)\n'
def main(v):
 d=h/f'trials/meshfast_{v.tag}';d.mkdir(exist_ok=True);ct=Counter();t=time.monotonic()
 def one(job):
  i,C=job;q=d/f'{i:02}.json'
  if q.is_file():return json.loads(q.read_text())
  s=generate(C,v.bins,full=v.full);p=d/f'{i:02}.smt2';p.write_text(s)
  ans=subprocess.check_output([sys.executable,h/'advanced/z3_lra.py',p,str(1000*v.time)],text=True).strip();assert ans in ('sat','unsat','unknown')
  if ans=='unsat':
   with gzip.open(d/f'{i:02}.smt2.gz','wb') as f:f.write(s.encode())
  p.unlink();z={'index':i,'cells':C,'status':ans,'bins':v.bins,'full':v.full,'sha256':hashlib.sha256(s.encode()).hexdigest()};q.write_text(json.dumps(z));return z
 with ThreadPoolExecutor(v.jobs) as ex:
  for f in as_completed([ex.submit(one,z) for z in enumerate(sets())]):
   z=f.result();ct[z['status']]+=1;print(z['index'],z['status'],ct,int(time.monotonic()-t),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--bins',type=int,default=4);p.add_argument('--full',action='store_true');p.add_argument('--tag',default='low');p.add_argument('--time',type=int,default=15);p.add_argument('--jobs',type=int,default=2);main(p.parse_args())
