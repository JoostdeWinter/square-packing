from pathlib import Path
from fractions import Fraction as F
from signed_duals_discover import coeff,rhs
from signed_linear import rules,h
from recover_signed_duals import make
import json,time,random,sys,argparse
def phase(rs,t,seed,loss=0,rank_extra=0):
 import numpy as np
 from scipy.optimize import linprog
 rng=random.Random(seed);rgs=[rng.choice((.5,.75,1,1.25,1.5,2)) for r in rs];v=2*t/(1-t*t);A=np.zeros((len(rs),51));b=[]
 for i,r in enumerate(rs):
  for k,w in coeff(r,v):A[i,k]+=w
  A[i,-1]=rgs[i];k=r[0];c=(1-t*t)/(1+t*t);u=c+2*t/(1+t*t)
  relax=u/2 if k=='wall' else 1/c if k=='same' else u if k in ('mixdiag','mixedstraight') else 0
  rank=(4-r[4] if r[3]==1 else r[4]) if k=='rank' else 4*v if k=='mixedstraight' else 0
  b.append(rhs(r,t)+t*t*(loss*relax+rank_extra*rank))
 z=linprog(np.r_[np.zeros(50),-1],A_ub=A,b_ub=b,bounds=[(None,None)]*51,method='highs',options={'primal_feasibility_tolerance':1e-10,'dual_feasibility_tolerance':1e-10})
 if not z.success:return 1,()
 return -z.fun,tuple(sorted(r for r,w in zip(rs,z.ineqlin.marginals) if w<0))
def main(args):
 src=args.src
 while not src.exists():time.sleep(4)
 rows=json.loads(src.read_text());dest=args.dest;dest.mkdir(exist_ok=True);ls=[];skipped=0;t0=time.monotonic()
 for f in dest.glob('support_*.json'):
  z=json.loads(f.read_text())
  if z.get('verified') and (not args.loss or (z.get('certified_loss')==str(F(args.loss)) and bool(z.get('midpoint'))==args.midpoint)):ls.append(set(tuple(r) for r in z['rules']))
 print('starting',len(rows),len(ls),flush=True)
 failed=[]
 for p,s,g in rows:
  rs=rules(tuple(p),s,g);target=set(rs)
  if any(a<=target for a in ls):skipped+=1;continue
  found=False
  for seed in range(28):
   t=(1/38,1/55,1/35,1/72,1/24,1/64,1/31)[seed%7]
   loss=F(args.loss or 0);rank_extra=F(3,2)*loss if args.midpoint else 0
   val,sub=phase(rs,t,seed,float(loss),float(rank_extra))
   if val>=-1e-8:continue
   try:z=make({'rules':sub},args.Q)
   except Exception as err:continue
   if args.loss:
    from angle_diversity import robust
    if not robust(z,args.Q,F(args.loss),rank_extra):continue
    z['certified_loss']=str(F(args.loss));z['midpoint']=args.midpoint
   z['verified']=True;ls.append(set(sub));(dest/f'support_{len(ls):05}.json').write_text(json.dumps(z,separators=(',',':'))+'\n');found=True;print('proof',len(ls),'skipped',skipped,'sec',int(time.monotonic()-t0),flush=True);break
  if not found:failed.append([p,s,g])
 (dest/'status').write_text(json.dumps({'initial':len(rows),'new':len(ls),'remaining':failed},separators=(',',':')));print('done',len(ls),len(failed),flush=True)
if __name__=='__main__':
 q=argparse.ArgumentParser();q.add_argument('--src',type=Path,default=h/'trials/equal_missing1.json');q.add_argument('--dest',type=Path,default=h/'trials/signed_repairs64');q.add_argument('--Q',type=int,default=64);q.add_argument('--loss');q.add_argument('--midpoint',action='store_true');main(q.parse_args())
