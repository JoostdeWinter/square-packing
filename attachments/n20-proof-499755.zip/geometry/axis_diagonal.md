# Independently choosing between board alignment and 45 degrees

Research direction by Joost de Winter. AI author GPT6.2 Astra.

The minimum board side for twenty unit squares is exactly 5 if each tile may independently be board-aligned or diagonal at 45 degrees. The positions and the number of tiles assigned to each orientation are free. The 5-by-5 grid gives the upper bound.

Suppose these twenty squares fit into a smaller board. Expand only their centers to a board of side five by first dilating the whole configuration and then shrinking each tile back to unit size at its new center. There is now positive wall and intertile clearance. Each center can undergo a small independent translation to avoid all finitely many lines on which an integer point or an original mark lies on a tile edge. For each primary pattern one of the 1,142 matchings admitted by the unrestricted side-five assignment screen must apply.

Write r = 1,000,000 times the square root of two, measuring all board coordinates in millionths. The centers of the two orientations must be strictly farther from each wall than 500,000 and r/2, respectively. Both assigned marks belong to the tile. An aligned tile contains an interior integer grid point after the stated perturbation. Two aligned tiles cannot use the same grid point.

For any two tiles put dx,dy equal to their center differences. The separating-axis conditions below follow by projecting both tiles on their edge normals. Strict separation is available in the normalized packing.

| Orientations | At least one strict inequality |
| --- | --- |
| Both aligned | max(abs(dx),abs(dy)) > 1,000,000 |
| Both diagonal | max(abs(dx+dy),abs(dx-dy)) > r |
| Mixed | max(abs(dx),abs(dy)) > 500,000+r/2 or max(abs(dx+dy),abs(dx-dy)) > 1,000,000+r/2 |

These are linear inequalities with Boolean choices and one shared parameter r. The program permits r to vary throughout a rational interval of width one trillionth of a microunit. Exact integer squares verify that this interval contains the true value. If the system has no solution on this larger interval, it excludes the geometric value. The four coordinate projections used to discard redundant inequalities and impossible choices are rounded outwards.

The exact linear-arithmetic solver returned UNSAT for all 1,142 matchings. It permits any orientation choice compatible with the independently rebuilt single-pattern center profiles. The endpoint screen, profile data and the restricted proof can all be regenerated from the pinned sources.

    python3 global/verify_screen.py 5000000 fresh500screen --jobs 4
    python3 global/verify_cap.py 5000000 proofs/cap5000000 fresh500geometry fresh500screen --jobs 4 --prepare-only
    python3 geometry/axis_diagonal.py fresh500geometry fresh500screen fresh_two_angles --jobs 3 --time 30

The Python driver uses the system Z3 shared library for exact linear real arithmetic. Its alternate --marks-only formulation derives each center domain directly from the original two assigned marks and the board walls.
