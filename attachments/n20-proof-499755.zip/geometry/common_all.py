"""Certify every possible common orientation on [0,45 degrees]."""
from pathlib import Path
from fractions import Fraction as F
from math import ceil,floor
from concurrent.futures import ThreadPoolExecutor
import argparse,json,subprocess,sys
from parallel_continuous import check
from parallel_cover import trig
import parallel_cover,parallel_fractional
h=Path(__file__).resolve().parent
def rows_closed(a,b,q,offset):
 poly=[(q*x+offset[0],q*y+offset[1]) for x,y in parallel_cover.boundary(a,b)]
 Y=[y for x,y in poly];res={}
 for j in range(floor(min(Y)),floor(max(Y))+1):
  points=[]
  for s,t in zip(poly,poly[1:]+poly[:1]):
   x,y=s;X,Y=t
   if j<=y<=j+1:points.append(x)
   if y==Y:continue
   for lo in (j,j+1):
    if min(y,Y)<=lo<=max(y,Y):points.append(x+(X-x)*(lo-y)/(Y-y))
  if points:res[j]=(floor(min(points)),floor(max(points))+1)
 return res
def covers(certs,close):
 intervals=[]
 for p in sorted(certs.glob('cert_*.json')):
  r=json.loads(p.read_text())
  if F(r['interval'][1])<=F(3,20):continue
  old=parallel_fractional.pixel_intervals
  try:
   if close:parallel_fractional.pixel_intervals=rows_closed
   least,total=parallel_fractional.certify(r)
  finally:parallel_fractional.pixel_intervals=old
  if least>=r['weight_denominator'] and total<20*r['weight_denominator']:intervals.append((*(map(F,r['interval'])),p.name))
 return intervals
def contiguous(certs,start,stop):
 pos=start;files=[]
 while pos<stop:
  cand=[(b,n) for a,b,n in certs if a<=pos<b]
  if not cand:return pos,files
  pos,n=max(cand);files.append(n)
 return pos,files
def main(workers):
 certdir=h.parent/'trials/parallel_fractional';out=h.parent/'trials/parallel_continuous';out.mkdir(exist_ok=True)
 A=F(1,31);M=F(3,20);targets=[(A,F(1,25))]+[(F(i,100),F(i+1,100)) for i in range(4,15)]
 def piece(w):
  a,b=w;r=check(a,b,F(5),10**6,150,out)
  if not r['open']:return [r]
  if b-a<=F(1,30000):return [r]
  t=(a+b)/2;return piece((a,t))+piece((t,b))
 with ThreadPoolExecutor(workers) as p:parts=[r for rs in p.map(piece,targets) for r in rs]
 parts.sort(key=lambda r:F(r['interval'][0]));pos=A
 for r in parts:
  assert F(r['interval'][0])==pos;pos=F(r['interval'][1])
 assert pos==M
 # tan(pi/8) = sqrt(2)-1 and 21/50 is larger.
 assert (1+F(21,50))**2>2
 q={}
 for mode in (False,True):
  pos,files=contiguous(covers(certdir,mode),M,F(21,50));q['closed' if mode else 'strict']={'until':str(pos),'files':files}
 res={'small_nonzero':'0 < t <= 1/31','small_theorem':'geometry/verify_parallel.py','native_intervals':parts,'native_intervals_checked':len(parts),'native_open_intervals':[r['interval'] for r in parts if r['open']],'fractional_certificates':q,'upper_half_tangent':'sqrt(2)-1'}
 (h.parent/'runs/common_all.json').write_text(json.dumps(res,indent=2));print('native intervals',len(parts),'open',res['native_open_intervals'],'fractional',[(k,v['until'],len(v['files'])) for k,v in q.items()],flush=True)
if __name__=='__main__':p=argparse.ArgumentParser();p.add_argument('--workers',type=int,default=2);args=p.parse_args();main(args.workers)
