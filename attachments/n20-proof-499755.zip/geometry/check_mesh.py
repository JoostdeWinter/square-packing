"""Exact elementary algebra and exhaustive cell accounting for mesh_opening.md."""
from fractions import Fraction as F
from itertools import combinations,product,permutations
from collections import Counter
from pathlib import Path
import argparse,json
def norm(a):
 v=list(a) or [0]
 while len(v)>1 and v[-1]==0:v.pop()
 return tuple(v)
def add(a,b):return norm([(a[i] if i<len(a) else 0)+(b[i] if i<len(b) else 0) for i in range(max(len(a),len(b)))])
def mul(a,b):
 out=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):out[i+j]+=x*y
 return norm(out)
class R:
 def __init__(self,n,d=(1,)):
  if isinstance(n,R):self.n,self.d=n.n,n.d;return
  self.n=norm((n,) if isinstance(n,(int,F)) else n);self.d=norm(d);assert self.d!=(0,)
 def __add__(self,y):
  y=R(y);return R(add(mul(self.n,y.d),mul(y.n,self.d)),mul(self.d,y.d))
 __radd__=__add__
 def __neg__(self):return R(tuple(-x for x in self.n),self.d)
 def __sub__(self,y):return self+-R(y)
 def __rsub__(self,y):return R(y)+-self
 def __mul__(self,y):
  y=R(y);return R(mul(self.n,y.n),mul(self.d,y.d))
 __rmul__=__mul__
 def __truediv__(self,y):
  y=R(y);return R(mul(self.n,y.d),mul(self.d,y.n))
 def __rtruediv__(self,y):return R(y)/self
 def __eq__(self,y):
  y=R(y);return mul(self.n,y.d)==mul(y.n,self.d)
def main():
 t=R((0,1));c=(1-t*t)/(1+t*t);s=2*t/(1+t*t);u=c+s;d=(u-1)/2;lam=(c-s)/s;G=2+2*t*t/(1+t);X=d;y=d*(1-s)/c
 assert (1-c)/s==t and (1-s)/c==(1-t)/(1+t) and c*c+s*s==1
 assert 1+(3*t+u)/2+lam*d-d*(1-s)/c==G
 assert 1+t+u/2+(1-s)/(2*c)-s*d*t/c-G==t*(1-2*t-t*t)/(1+t*t)
 assert (2+2*t-G)==2*t/(1+t)
 assert (1+t+u-G)==2*d+t*(1-t)/(1+t)
 assert (u-1)/(c*s)==2/(1+u)
 z=[(-F(1,2),-(2*t*t-t+1)/(2*(1+t))),(-F(1,2),F(1,2)),(t-F(1,2),-F(1,2)),(F(1,2),-F(1,2))]
 dirs=[(-c,-s),(-s,c),(s,-c),(1,0)]
 for (a,b),(px,py),(nx,ny) in zip(product((-1,1),repeat=2),z,dirs):
  assert nx*(F(a,2)+px+X)+ny*(F(b,2)+py-y)==(1+u)/2
 assert sum(a*px+b*py for (a,b),(px,py) in zip(product((-1,1),repeat=2),z))==G
 assert -s*(-X)+c*y==d and t*(1-t)/(1+t*t)==d
 # Four pairs of distinct sites cannot use only three integer lines.
 assert F(25,9)>2  # sqrt(2)<5/3 makes 2/(1+sqrt(2))>3/4.
 sites=[(i,j) for i,j in product(range(5),repeat=2) if not(i in (0,4) and j in (0,4))]
 perms=list(permutations(range(1,5)))
 def match(f,k):return any(all(p[j] in (z[k],z[k]+1) for j,z in enumerate(f)) for p in perms)
 def transform(z):
  return min(tuple(sorted((4-x if a else x,4-y if b else y) for X,Y in z for x,y in [(Y,X) if c else (X,Y)])) for a,b,c in product((0,1),repeat=3))
 hist=Counter();orbit=Counter()
 for f in combinations(sites,4):
  adj=any(abs(x-X)+abs(y-Y)==1 for (x,y),(X,Y) in combinations(f,2))
  good=match(f,0) and match(f,1);hist[adj,good]+=1
  if f==transform(f):orbit[adj,good]+=1
 assert sum(hist.values())==5985 and hist[True,True]==632 and hist[False,True]==985
 return {'cell_sets':sum(hist.values()),'has_line_matchings':hist[True,True]+hist[False,True],'has_adjacent_pair':hist[True,True]+hist[True,False],'satisfies_both':hist[True,True],'remaining_symmetry_classes':orbit[True,True],'local_opening':'2+2t^2/(1+t)','polynomial_identities':'passed'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path);v=p.parse_args();z=main();print(json.dumps(z))
 if v.output:v.output.write_text(json.dumps(z,indent=2)+'\n')
