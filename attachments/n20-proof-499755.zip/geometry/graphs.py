"""Enumerate necessary separating-axis choices for a near-parallel packing."""
from itertools import permutations,product
import json
from pathlib import Path
def rotate_holes(p):
 q=[None]*5
 for x,y in enumerate(p):q[4-y]=x
 return tuple(q)
def choices(p):
 pts=sorted((x,y) for x,y in product(range(5),repeat=2) if p[x]!=y)
 lookup={v:i for i,v in enumerate(pts)}
 edges=sorted((i,j) for i,(x,y) in enumerate(pts) for j,(u,v) in enumerate(pts) if u==x+1 and abs(y-v)==1)
 var={k:i+1 for i,k in enumerate(edges)}
 clauses=set()
 for vertical in (False,True):
  layers=[[i for i,(x,y) in enumerate(pts) if (y if vertical else x)==k] for k in range(5)]
  for path in product(*layers):
   step=lambda i: (pts[i][0] if vertical else pts[i][1])
   if (step(path[-1])<step(path[0]) if vertical else step(path[-1])>step(path[0])):continue
   if any(abs(step(i)-step(j))>1 for i,j in zip(path,path[1:])):continue
   literals=[]
   for i,j in zip(path,path[1:]):
    if step(i)==step(j):continue
    k=var[tuple(sorted((i,j)))]
    literals.append(k if vertical else -k)
   clauses.add(tuple(sorted(literals)))
 def simplify(cs):
  return [c for c in cs if not any(set(v)<set(c) for v in cs)]
 cs=simplify(clauses)
 result=[]
 def solve(part,cs):
  while cs:
   if any(not c for c in cs):return
   units={c[0] for c in cs if len(c)==1}
   if not units:break
   if any(-v in units for v in units):return
   part=part|units
   cs=[tuple(v for v in c if -v not in units) for c in cs if not units.intersection(c)]
  if len(part)==len(edges):result.append(sorted(part,key=abs));return
  unassigned=set(range(1,len(edges)+1))-{abs(v) for v in part}
  if cs:
   minlen=min(len(c) for c in cs)
   k=max(unassigned,key=lambda x:(sum(1 for c in cs if len(c)==minlen and (x in c or -x in c)), -x))
  else:k=min(unassigned)
  for v in (k,-k):solve(part|{v},[tuple(z for z in c if z!=-v) for c in cs if v not in c])
 solve(set(),cs)
 return {'holes':p,'points':pts,'diagonals':edges,'solutions':result}
def main():
 reps={};total=0
 for p in permutations(range(5)):
  q=p;orb=set()
  for j in range(4):orb.add(q);q=rotate_holes(q)
  a=min(orb)
  if a not in reps:reps[a]=choices(a)
  total+=len(reps[a]['solutions'])
 print('rotation representatives',len(reps),'graph count at representatives',sum(len(z['solutions']) for z in reps.values()),'graph count all',total,flush=True)
 (Path(__file__).parent/'graphs.json').write_text(json.dumps(list(reps.values()),separators=(',',':')))
if __name__=='__main__':main()
