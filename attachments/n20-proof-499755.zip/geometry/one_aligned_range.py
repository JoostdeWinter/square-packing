"""Exact interval test for one aligned square and nineteen signed copies of one tilt."""
from pathlib import Path
from itertools import combinations
from fractions import Fraction as F
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
from tempfile import TemporaryDirectory
import json,subprocess,os,time,argparse,sys
h=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(h/'global'),str(h/'advanced')]
from branches import stamp,atomic
from shared_angle_lp import faces
from shared_angle_cases import export
from z3_lra import run
D=1000000
def hull(p):
 p=sorted(set(p))
 if len(p)<3:return tuple(p)
 def chain(seq):
  out=[]
  for x,y in seq:
   while len(out)>=2:
    a,b=out[-2:];v=(b[0]-a[0])*(y-b[1])-(b[1]-a[1])*(x-b[0])
    if v>0:break
    out.pop()
   out.append((x,y))
  return out
 return tuple(chain(p)[:-1]+chain(reversed(p))[:-1])
def neg(t):return (1-t)/(1+t)
def read(p):
 lines=iter(p.read_text().splitlines());U,d,g,n=map(int,next(lines).split());assert U==5000000 and d==D and n==20
 tiles=[]
 for i in range(n):
  next(lines);part=[]
  for j in range(int(next(lines))):
   lo,hi,b,k,*xy=map(int,next(lines).split());assert 0<=lo<=hi<=b and k*2==len(xy)
   part.append((F(lo,b),F(hi,b),tuple(zip(xy[::2],xy[1::2]))))
  tiles.append(tuple(part))
 assert next(lines,None) is None;return tiles
def join(op,v):
 vs=list(dict.fromkeys(v))
 if not vs:return 'true' if op=='and' else 'false'
 return vs[0] if len(vs)==1 else '('+op+' '+' '.join(vs)+')'
def lit(z):return str(z) if z>=0 else '(- '+str(-z)+')'
def term(i,p,q):return '(+ (* '+lit(p)+f' x{i}) (* '+lit(q)+f' y{i}))'
def cross_term(i,j,p,q):return '(- '+term(j,p,q)+' '+term(i,p,q)+')'
def normals(t):
 a,b=t.numerator,t.denominator;c=b*b-a*a;s=2*a*b;return ((c,s),(-s,c)),b*b+a*a
def inner_support(axes,den,size,p,q):return F(D,2*den)*size*sum(abs(p*a+q*b) for a,b in axes)
def poly_options(tiles,L,U):
 out=[];center=(L+U)/2;sizes={v:1/(1+U-L) if v else F(1) for v in [-1,0,1]}
 params={j:(*normals(j*center),sizes[j]) for j in [-1,0,1]}
 for i,tile in enumerate(tiles):
  groups={}
  for sg in (-1,0,1):
   ranges=((L,U),) if sg>0 else ((neg(U),neg(L)),) if sg<0 else ((0,0),(1,1))
   p=hull(v for a,b,ps in tile if any(l<=b and a<=r for l,r in ranges) for v in ps)
   if p:groups[sg]=p
  out.append(groups)
 return out,params
def solve(tiles,L,U,seconds):
 opts,ps=poly_options(tiles,L,U)
 if any(not x for x in opts) or sum(set(q)=={0} for q in opts)>1 or not any(0 in q for q in opts):return 'empty'
 S=['(set-logic QF_LRA)']
 for j in range(20):S+=['(declare-const x%d Real)'%j,'(declare-const y%d Real)'%j]
 def emit(t):S.append('(assert '+t+')')
 def gate(i,s):return 'v%d_%d'%(i,s+1)
 def bounds(i,p,q):return [p*x+q*y for x,y in opts[i][sg]]
 def impose(g,e):emit('(=> '+g+' '+e+')')
 axes_keys=[]
 for i,oset in enumerate(opts):
  for sg,poly in oset.items():
   g=gate(i,sg);S.append('(declare-const '+g+' Bool)')
   for p,q,k in faces(poly):impose(g,'(<= '+term(i,p,q)+' '+lit(k)+')')
   # Some closed domains have dimension one; retaining their bounding boxes is safe.
   for p,q in [(1,0),(0,1),(-1,0),(0,-1)]:
    arr=[p*x+q*y for x,y in poly];impose(g,'(<= '+term(i,p,q)+' '+lit(max(arr))+')')
   aa,den,size=ps[sg];wall=inner_support(aa,den,size,1,0)
   for var in ('x','y'):
    val=f'(* {wall.denominator} {var}{i})';impose(g,'(< '+lit(wall.numerator)+' '+val+' '+lit(5*D*wall.denominator-wall.numerator)+')')
  emit(join('or',[gate(i,x) for x in oset]))
  if 0 in oset:axes_keys.append(gate(i,0))
 emit(join('or',axes_keys))
 for a,b in combinations(axes_keys,2):emit('(or (not '+a+') (not '+b+'))')
 supports={}
 def support(i,sg,p,q):
  key=i,sg,p,q
  if key not in supports:
   vs=[p*x+q*y for x,y in opts[i][sg]];supports[key]=min(vs),max(vs)
  return supports[key]
 for i,j in combinations(range(20),2):
  for si in opts[i]:
   for sj in opts[j]:
    if si==sj==0:continue
    ai,di,zi=ps[si];aj,dj,zj=ps[sj];poss=[];sure=False
    for p,q in dict.fromkeys((*ai,*aj)):
     req=inner_support(ai,di,zi,p,q)+inner_support(aj,dj,zj,p,q)
     il,iu=support(i,si,p,q);jl,ju=support(j,sj,p,q)
     for sign,lo,hi in ((1,jl-iu,ju-il),(-1,il-ju,iu-jl)):
      if lo>req:sure=True;break
      if hi<=req:continue
      expr=cross_term(i,j,p*sign*req.denominator,q*sign*req.denominator);poss.append('(> '+expr+' '+lit(req.numerator)+')')
     if sure:break
    if not sure:impose('(and '+gate(i,si)+' '+gate(j,sj)+')',join('or',poss))
 S.append('(check-sat)');r,_=run('\n'.join(S)+'\n',seconds*1000);assert r in ('sat','unsat','unknown');return r
def main(v):
 d=v.cold.resolve();s=v.screen.resolve();out=v.dest.resolve();out.mkdir(exist_ok=True,parents=True);U=5000000
 meta=json.loads((s/'screen_verified.json').read_text());cases=[(k,m) for k,rows in json.loads((s/'open_matchings.json').read_text()).items() for m in rows]
 assert meta['ordered_masks']==53361 and meta['side_micro']==U and len(cases)==1142 and json.loads((d/'status.json').read_text())['screened_matchings']==1142
 def task(row):
  k,m=row;name=stamp(k,m);pr=json.loads((d/'matchings'/(name+'.json')).read_text())
  assert pr['mask_pair']==k and pr['matching']==m and pr['target_micro']==U
  if not pr['open_leaves']:return 'unrestricted'
  fp=out/(name+'.json')
  if fp.is_file():
   vs=json.loads(fp.read_text())
   if vs['closed'] or not v.retry:return 'restricted' if vs['closed'] else 'open'
  def tryowner(o):
   with TemporaryDirectory() as td:
    dom=Path(td)/'domains';native=export(d,k,m,o,[0,1,5,14,16,64,1],dom)
    if native[0]!='EXPORTED_SHARED':return [[str(v.low),'5/12',native]]
    data=read(dom)
   rec=[]
   def go(a,b,depth):
    res=solve(data,a,b,v.seconds)
    if res in ('empty','unsat'):rec.append([str(a),str(b),res]);return True
    if depth>=v.depth:return False
    c=(a+b)/2
    return go(a,c,depth+1) and go(c,b,depth+1)
   return rec if go(v.low,F(5,12),0) else None
  # A root proof is sufficient for every ownership alternative.
  r=tryowner([-2]*4);receipts=[]
  if r is not None:receipts.append([[-2]*4,r]);ok=True
  elif v.owned:
   ok=True
   for o in pr['open_leaves']:
    r=tryowner(o)
    if r is None:ok=False;break
    receipts.append([o,r])
  else:ok=False
  atomic(fp,{'key':k,'matching':m,'closed':ok,'lower':str(v.low),'upper':'5/12','receipts':receipts});return 'restricted' if ok else 'open'
 if v.key:cases=[q for q in cases if v.key in stamp(*q)]
 st=time.monotonic();ct=Counter();bad=[]
 with ThreadPoolExecutor(v.jobs) as ex:
  fs={ex.submit(task,row):row for row in cases}
  for f in as_completed(fs):
   result=f.result();ct[result]+=1
   if result=='open':bad.append(fs[f])
   if result!='unrestricted' or sum(ct.values())%250==0:print(dict(ct),fs[f][0],int(time.monotonic()-st),flush=True)
 if len(cases)==1142:
  result={'threshold':str(v.low),'all_matchings':len(cases),'counts':ct,'unresolved':bad};atomic(out/'summary',result)
  if not bad:atomic(out/'verified.json',result)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('cold',type=Path);p.add_argument('screen',type=Path);p.add_argument('dest',type=Path);p.add_argument('--low',type=F,default=F(1,24));p.add_argument('--jobs',type=int,default=2);p.add_argument('--depth',type=int,default=8);p.add_argument('--seconds',type=int,default=4);p.add_argument('--owned',action='store_true');p.add_argument('--retry',action='store_true');p.add_argument('--key');main(p.parse_args())
