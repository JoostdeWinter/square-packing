# Five bands for independently rotated squares

Research direction by Joost de Winter. AI author GPT6.2 Astra.

Let θ be a tile's unsigned tilt relative to the nearest board axis. Call the tile small-tilt for this argument if

    cos θ + sin θ ≤ (1 + 3/√5)/2.

The limiting angle is about 10.88°. In every hypothetical packing of twenty unit squares on a board of side S < 5, the centers of the small-tilt tiles lie in distinct cells of a 5-by-5 array. Each row and each column contains at most four such centers. If all twenty tilts satisfy the threshold, exactly one cell in each row and column is vacant, so there are only 120 possible vacancy patterns. Centers and angles vary independently.

## Proof

For convenience enlarge the board to [0,5]² by spreading all centers by the factor 5/S and restoring each square concentrically to unit side. The closed tiles then have positive distances from each other and the walls. Every center lies in the open square (1/2,9/2)². Partition each coordinate interval into five bands of width 4/5. Assign a center on a boundary consistently to either incident band.

Put u = cos θ + sin θ. At a distance at most r = (1 + u − u²)/2 from the center a horizontal or vertical line cuts a chord of length at least one. This follows from the explicit chord formula in boundary_sweep.md. The stated bound on u is the positive root of u² − u − 1/5 = 0, so r ≥ 2/5. All small-tilt tiles centered in one band therefore contribute unit-length chords to its middle line. Five disjoint closed chords cannot fit strictly inside a segment of length five. Each band contains at most four small-tilt centers.

The axis-parallel closed square of side 1/u centered at the tile center fits in the tile. At our threshold u < 5/4, hence 1/u > 4/5. Two small-tilt centers in one array cell would make those two inscribed squares overlap in their interiors. This proves the cell count. With twenty small-tilt centers the five row capacities and the five column capacities are all saturated. The missing cells form a permutation of the five columns.

Two further restrictions apply even to large-tilt tiles. Each tile contains the disk of radius 1/2 centered at its center, so distinct centers have Euclidean distance at least one. A cell therefore contains at most two arbitrary centers. Indeed, splitting it vertically in half gives two rectangles of diagonal √(4/25 + 16/25) < 1. If there are two centers in the same cell their absolute coordinate differences are each at least 3/5, since the other coordinate difference is at most 4/5. At least one of those two tiles exceeds the angular threshold.
