"""Standard-library verifier of the small equal-absolute-tilt theorem."""
from pathlib import Path
from itertools import product,permutations
from collections import Counter
from fractions import Fraction as F
from signed_angle_graphs import pattern,constraints,models
from equal_tilt_signs import assignments
from signed_linear import canon,rules
from check_signed_duals import verify_cert
import json,gzip,argparse,time
def loadbank(src):
 if src.is_dir():
  bank=[]
  for p in src.glob('support_*.json'):
   v=json.loads(p.read_text())
   if v.get('verified'):bank.append(v)
  return bank
 with gzip.open(src,'rt') as f:return json.load(f)
def classify(certfiles,want=None,Q=64,exact_paths=False):
 from equal_path_polynomial import bridge,exact_clauses
 if exact_paths:assert Q>=20 and not bridge(Q)[1]
 else:assert Q>=64
 assert (20*(1+F(1,32))+F(24,5)+F(2,3*32))/32<1
 assert 1-5*F(33,1024)>F(4,5) and (1+3*F(33,1024))/32+4*F(33,1024)<1
 atoms={};masks=[];records=[]
 def code(rs):
  out=0
  for r in rs:
   r=tuple(r)
   if r not in atoms:atoms[r]=len(atoms)
   out|=1<<atoms[r]
  return out
 for src in certfiles:
  for row in loadbank(src):
   assert verify_cert(row,Q);m=code(row['rules'])
   if m not in masks:masks.append(m);records.append({k:row[k] for k in ('rules','multipliers','margin')})
 counts=Counter();reps=set();routes={};uncovered=[];usage=Counter()
 for p in permutations(range(5)):
  for s in assignments(p):
   counts['after_paired_chains']+=1
   if s in (0,1048575):counts['same_sign_delegated_to_parallel_proof']+=1;continue
   P,S=canon(p,s)
   if (P,S) not in routes:
    cr=exact_clauses(P,S,Q) if exact_paths else constraints(P,S);A,E,_=pattern(P);ms=models(cr,len(E),False);routes[P,S]=ms
   if routes[P,S]:counts['signs_with_contact_graph']+=1;reps.add((P,S))
 for p,s in sorted(reps):
  for x in routes[p,s]:
   counts['mixed_contact_graphs']+=1;z=code(rules(p,s,x));idx=next((i for i,m in enumerate(masks) if m&z==m),None)
   if idx is None:uncovered.append((p,s,x))
   else:usage[idx]+=1
 out={'half_tangent_interval':f'0 < t <= 1/{Q}','exact_chain_polynomials':exact_paths,'mixed_dihedral_representatives':len(reps),'counts':counts,'verified_polynomial_certificates':len(records),'certificates_used':len(usage),'uncovered_graphs':len(uncovered)}
 if want:
  with gzip.open(want,'wt',compresslevel=9) as f:json.dump([records[i] for i in sorted(usage)],f,separators=(',',':'))
 return out,uncovered
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('certfiles',type=Path,nargs='+');p.add_argument('--out',type=Path);p.add_argument('--holes',type=Path);p.add_argument('--bundle',type=Path);p.add_argument('--Q',type=int,default=64);p.add_argument('--exact-paths',action='store_true');v=p.parse_args();rec,failed=classify(v.certfiles,v.bundle,v.Q,v.exact_paths);print(json.dumps(rec),flush=True)
 if v.out:v.out.write_text(json.dumps(rec,indent=2)+'\n')
 if v.holes:v.holes.write_text(json.dumps(failed,separators=(',',':'))+'\n')
