from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import json
h=Path(__file__).resolve().parents[1]
def main():
 js=[json.loads(f.read_text()) for f in (h/'trials/grid_jets').glob('*.json')]
 scores=[z for z in js if 'repaired_cap' in z];best=min(scores,key=lambda x:F(x['repaired_cap'])) if scores else None
 receipt={'search_only':True,'patterns_modulo_dihedral':len(set(z['pattern'] for z in js)),'samples':len(js),'negative_numerical_quadratic_coefficients_below_1e-7':len(scores),'rational_reconstructions_per_negative_proposal':7,'reconstructed_below_five':sum(bool(z['below_five']) for z in scores),'best_negative_proposal':best}
 (h/'runs/grid_jet_summary.json').write_text(json.dumps(receipt,indent=2))
 cs=[json.loads(f.read_text()) for f in (h/'trials/contact_lp').glob('*.json')]
 if cs:
  top=min(cs,key=lambda z:F(z['repaired_side']));out={'search_only':True,'rational_reconstructions':len(cs),'pairs_per_reconstruction':190,'certified_below_five':sum(bool(x['below_five']) for x in cs),'best':top}
  (h/'runs/contact_search_summary.json').write_text(json.dumps(out,indent=2))
 print('jet samples',len(js),'contact LP trials',len(cs))
if __name__=='__main__':main()
