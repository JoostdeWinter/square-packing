"""Exact loss along a five-tile chain for equal absolute tilts."""
from itertools import product
from functools import lru_cache
from collections import Counter
from fractions import Fraction as F
from verify_parallel import positive,add,mult,scale
from check_signed_duals import C,S,D,Z,ZD,ZZD,D2,CD2,CDZ
import argparse,json
@lru_cache(maxsize=None)
def nonnegative(A,B,H,K,Q,loss=F(0),rank_extra=F(0)):
 # (u + A/c + B*u - tan(theta)*(H+d*K) - 5) * C D^2.
 p=add(scale(CDZ,B+1),scale(mult(D2,D),A));p=add(p,scale(CD2,-5));p=add(p,scale(mult(S,D2),-H));p=add(p,scale(mult(S,ZZD),-K))
 if loss:
  size=add(scale(CDZ,B+1),scale(mult(D2,D),A));p=add(scale(p,loss.denominator),scale(mult([0,0,1],size),-loss.numerator))
 if rank_extra:
  den=loss.denominator if loss else 1
  p=add(scale(p,rank_extra.denominator),scale(mult([0,0,1],mult(S,D2)),-K*rank_extra.numerator*den))
 return positive(p,Q=Q)
@lru_cache(maxsize=None)
def excluded(rows,signs,Q,loss=F(0),rank_extra=F(0)):
 steps=[v-u for u,v in zip(rows,rows[1:])];assert all(abs(z)<=1 for z in steps)
 opts=[];A=0;B=0
 for z,a,b in zip(steps,signs,signs[1:]):
  if a==b:A+=1;opts.append((a,))
  else:B+=1;opts.append((z,) if z else (-1,1))
 for norm in product(*opts):
  H=sum(d*j for d,j in zip(steps,norm));weights=(-norm[0],*(norm[j-1]-norm[j] for j in range(1,4)),norm[3])
  K=sum(a*((4-k) if a>0 else -k) for a,k in zip(weights,rows))
  assert K>=0
  if not nonnegative(A,B,H,K,Q,loss,rank_extra):return False
 return True
def bridge(Q,loss=F(0),rank_extra=F(0)):
 total=0;unproven=[]
 for k in range(4):
  for a in range(5):
   for b in (a-1,a+1):
    if b not in range(5):continue
    rs=(a,)*(k+1)+(b,)*(4-k)
    for signs in product((-1,1),repeat=5):
     if all(v==b-a for v in signs):continue
     total+=1
     if not excluded(rs,signs,Q,loss,rank_extra):unproven.append([rs,signs])
 return total,unproven
if __name__=='__main__':
 for Q in (64,48,40,36,32,30,28,26,24,22,20):
  n,f=bridge(Q);print(Q,n,len(f),f[:1],flush=True)
@lru_cache(maxsize=12)
def full_paths(p):
 A=sorted((x,y) for x,y in product(range(5),repeat=2) if p[x]!=y)
 diag=[(i,j) for i,(x,y) in enumerate(A) for j,(X,Y) in enumerate(A) if X==x+1 and abs(Y-y)==1];E={q:1<<i for i,q in enumerate(diag)};all_=[]
 for ax in (0,1):
  layers=[[i for i,p in enumerate(A) if p[ax]==k] for k in range(5)]
  for path in product(*layers):
   rows=tuple(A[i][1] if ax==0 else 4-A[i][0] for i in path);ds=[v-u for u,v in zip(rows,rows[1:])]
   if max(map(abs,ds))>1:continue
   mask=sum(E[tuple(sorted((i,j)))] for i,j,dd in zip(path,path[1:],ds) if dd)
   all_.append((ax,mask,rows,path))
 return all_
def exact_clauses(p,s,Q,loss=F(0),rank_extra=F(0)):
 st=set();sg=[1 if s>>i&1 else -1 for i in range(20)]
 for ax,mask,rows,idx in full_paths(p):
  if excluded(rows,tuple(sg[i] for i in idx),Q,loss,rank_extra):st.add((mask,0) if ax else (0,mask))
 out=[]
 for x,y in sorted(st,key=lambda z:(z[0]|z[1]).bit_count()):
  if not any((a&x)==a and (b&y)==b for a,b in out):out.append((x,y))
 return out
