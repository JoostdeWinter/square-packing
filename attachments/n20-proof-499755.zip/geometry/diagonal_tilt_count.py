"""Verify the weighted center count for squares with large tilt."""
from fractions import Fraction as F
from pathlib import Path
import argparse
import json
from diamond_capacity import verify

def check(path, t):
    data = json.loads(path.read_text())
    B, M = data["B"], data["M"]
    assert t >= 0 and t*t + 2*t <= 1
    cosine = (1-t*t)/(1+t*t)
    sine = 2*t/(1+t*t)
    width = (5-cosine-sine)*cosine
    assert B*width < M
    mass = verify(B, M, data["bank"])
    assert mass == F(data["mass"]) and mass < 19
    return {"maximum_side": 5, "half_tangent": str(t), "center_radius_upper": str(width),
            "quantization_factor": B, "integer_diamond_radius": M,
            "weighted_count_bound": str(mass), "maximum_at_or_above_cutoff": int(mass),
            "number_strictly_below_cutoff_among_twenty": 20-int(mass)}

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("certificate", type=Path)
    parser.add_argument("--t", type=F, default=F(19,48))
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    result = check(args.certificate, args.t)
    if args.out:
        args.out.write_text(json.dumps(result, indent=2) + "\n")
    print(result)
