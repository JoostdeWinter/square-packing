"""Exact rational checks for the four-point wall-strip correction."""
from fractions import Fraction as F
from math import gcd
import json
def verify():
 assert F(14142,10000)**2<2
 tested=0
 for q in range(1,180):
  for p in range(q+1):
   if gcd(p,q)!=1:continue
   t=F(p,q);c=(1-t*t)/(1+t*t);s=2*t/(1+t*t);u=c+s;h=u/2;r=h-c*s
   assert c*c+s*s==1
   assert h-r==c*s and h+r==1-(u-1)**2/2
   assert c*s<=F(1,2) and h+r>F(9142,10000)
   for d,tau in [(F(3,10),F(85,100)),(F(15,100),F(76,100)),(F(4,10),F(905,1000)),(F(1,20),F(73,100)),(F(1,5),F(715,1000))]:
    for x in (h,h+d):assert abs(tau-x)<=r
   tested+=1
 return {'wall_bound':'sqrt(2)-1','central_minimum':4,'rational_direction_controls':tested,'transversal_upper':'sqrt(2)-1/2','at_most_per_wall':4}
if __name__=='__main__':print(json.dumps(verify(),indent=2))
