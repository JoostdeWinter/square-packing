"""Independent exhaustive enumeration of all five-hole patterns and turning steps."""
from itertools import combinations, permutations, product
from collections import Counter,deque
from math import comb
import json
def bridges(holes):
 points=set(product(range(5),repeat=2))-set(holes)
 result=[]
 for x in range(4):
  for y in range(5):
   for d in (-1,1):
    z=y+d
    if not 0<=z<5:continue
    h=[(i,y if i<=x else z) for i in range(5)]
    k=min(y,z);left=x if d==1 else x+1;right=x+1 if d==1 else x
    v=[(left if j<=k else right,j) for j in range(5)]
    if set(h+v)<=points:
     assert len(set(h)&set(v))==2
     result.append((x,y,d))
 return result
def max_distance(holes):
 pts=set(product(range(5),repeat=2))-set(holes)
 distance={p:0 for p in pts if p[0] in (0,4) or p[1] in (0,4)};queue=deque(distance)
 while queue:
  x,y=queue.popleft()
  for p in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)]:
   if p in pts and p not in distance:distance[p]=1+distance[x,y];queue.append(p)
 assert len(distance)==20
 return max(distance.values())
if __name__=='__main__':
 allsites=list(product(range(5),repeat=2))
 full=0;perms=[]
 for holes in combinations(allsites,5):
  if len({x for x,y in holes})==5 and len({y for x,y in holes})==5:perms.append(holes)
  else:full+=1
 table=Counter(len(bridges(p)) for p in perms);steps=max(map(max_distance,perms))
 assert full==53010 and comb(25,5)==full+len(perms) and table=={4:92,5:24,6:4} and steps==2
 print(json.dumps({'total_vacancy_patterns':full+len(perms),'full_row_or_column':full,'permutations':len(perms),'turning_steps':dict(table),'graph_distance_to_board_edge':steps},indent=2))
