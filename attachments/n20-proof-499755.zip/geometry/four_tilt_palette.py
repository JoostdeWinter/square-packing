"""Search a finite independently chosen orientation palette exactly.

An exact solution with positive clearances would disprove the unrestricted
equality. Each case uses the 16 lattice owners and four missing cell centers.
"""
from four_tilt_smt import *
import ctypes,ctypes.util,re
sys.path.insert(0,str(h/'advanced'));import z3_lra
def strict_model(C,vals):
 blocks=[[(t,t) for t in vals] for z in C]
 return model(C,len(vals),blocks,details=True,strict_physical=True)
def eval_values(txt):
 tokens=re.findall(r'\(|\)|[^()\s]+',txt);p=0
 def walk():
  nonlocal p
  w=tokens[p];p+=1
  if w!='(':return w
  z=[]
  while tokens[p]!=')':z.append(walk())
  p+=1;return z
 tree=walk()
 def val(z):
  if isinstance(z,str):return z if z in ('true','false') else F(z)
  if z[0]=='/':return val(z[1])/val(z[2])
  if z[0]=='-':return -val(z[1])
  raise ValueError(z)
 return {k:val(v) for k,v in tree}
def certify(C,vals,store):
 poses=[]
 for x,y in product(range(1,5),repeat=2):poses.append((F(x)+store[f'z_{x}_{y}_0'],F(y)+store[f'z_{x}_{y}_1'],F(1),F(0)))
 for i,(x,y) in enumerate(C):
  matches=[t for j,t in enumerate(vals) if store[f'b_{i}_{j}']=='true'];assert matches
  c,s=trig(matches[0]);poses.append((F(2*x+1,2)+store[f't_{i}_0'],F(2*y+1,2)+store[f't_{i}_1'],c,s))
 # Scale each center difference and every wall clearance about (5/2,5/2).
 # Their common contraction yields a rational closed board strictly below 5.
 ratios=[]
 for x,y,c,s in poses:
  assert c*c+s*s==1;r=(abs(c)+abs(s))/2
  for a in (x,y):
   ratios.append(r/a);ratios.append(r/(5-a))
 for (x,y,a,b),(X,Y,c,s) in combinations(poses,2):
  dx,dy=X-x,Y-y;need=(1+abs(a*c+b*s)+abs(a*s-b*c))/2
  used=max(abs(dx*A+dy*B) for A,B in dirs(a,b)+dirs(c,s));ratios.append(need/used)
 scale=max(ratios);return {'scale':str(scale),'side':str(5*scale),'below_five':scale<1,'poses_at_five':[[str(q) for q in p] for p in poses]}
def main(v):
 vals=sorted(set(map(F,v.palette.split(','))));vals=sorted(set(vals+[(1-t)/(1+t) for t in vals]));assert all(0<t<1 for t in vals)
 d=h/f'trials/mesh_palette_{v.tag}';d.mkdir(exist_ok=True);total=Counter();start=time.monotonic()
 def one(item):
  i,C=item;dest=d/f'{i:02}.json'
  if dest.is_file():
   old=json.loads(dest.read_text())
   if old['status']!='unknown' or not v.retry_unknown:return old
  s=strict_model(C,vals);keys=[f'z_{x}_{y}_{k}' for x,y,k in product(range(1,5),range(1,5),range(2))]+[f't_{j}_{k}' for j,k in product(range(4),range(2))]+[f'b_{j}_{k}' for j,k in product(range(4),range(len(vals)))]
  status,details=z3_lra.run(s,v.time*1000,'(get-value ('+' '.join(keys)+'))');assert status in ('sat','unknown','unsat')
  result={'case':i,'cells':C,'palette':list(map(str,vals)),'status':status,'sha256':hashlib.sha256(s.encode()).hexdigest()}
  if status=='sat':result['exact_repair']=certify(C,vals,eval_values(details))
  dest.write_text(json.dumps(result));return result
 with ThreadPoolExecutor(v.jobs) as ex:
  for f in as_completed([ex.submit(one,j) for j in enumerate(sets())]):
   z=f.result();total[z['status']]+=1;print(z['case'],z['status'],z.get('exact_repair',{}).get('side'),dict(total),int(time.monotonic()-start),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('palette');p.add_argument('--retry-unknown',action='store_true');p.add_argument('--tag',required=True);p.add_argument('--jobs',default=2,type=int);p.add_argument('--time',default=20,type=int);main(p.parse_args())
