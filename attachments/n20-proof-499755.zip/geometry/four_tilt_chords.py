"""Exact linear relaxations of grid-line chords for four missed cells.

The pose of each lattice-missing tile uses bounded normalized displacement
v with center q + d v, d=(cos(theta)+sin(theta)-1)/2. All chord coefficients
remain finite as the tilt approaches either lattice direction.
"""
from four_tilt_smt import *
def model_chords(C,bins,blocks=None,full=False,save_model=False):
 base=model(C,bins,blocks,details=full,linked=True);pos=base.rindex('(check-sat)');out=[base[:pos]]
 def emit(z):out.append('(assert '+z+')')
 def real(s):out.append('(declare-fun '+s+' () Real)');return s
 def le(x,y):return '(<= '+x+' '+y+')'
 def lt(x,y):return '(< '+x+' '+y+')'
 def eq(x,y):return '(= '+x+' '+y+')'
 def dis(x):return joint(x,'or')
 def I(x,lo,hi):return [con(x,'>=',lo),con(x,'<=',hi)]
 def mc(A,B,Z,x,y):
  l,u=x;v,w=y
  return [con(sub(add(scale(v,A),scale(l,B)),Z),'<=',l*v),con(sub(add(scale(w,A),scale(u,B)),Z),'<=',u*w),
          con(sub(sub(Z,scale(v,A)),scale(u,B)),'<=',-u*v),con(sub(sub(Z,scale(w,A)),scale(l,B)),'<=',-l*w)]
 def off(p,ax):
  i,j=p
  if i in range(1,5) and j in range(1,5):return f'z_{i}_{j}_{ax}'
  v=p[ax];return number(-F(1,2) if v==0 else F(1,2) if v==5 else 0)
 edges={};margin=F(1414214,10**6);vbox=(-margin,margin)
 for i,(x,y) in enumerate(C):
  T=[f't_{i}_{k}' for k in (0,1)];V=[real(f'v_{i}_{k}') for k in (0,1)]
  for v in V:
   for z in I(v,*vbox):emit(z)
  for a,b in product((-1,1),repeat=2):emit(con(dot((a,b),V),'<',2))
  d=f'd_{i}';c,s,P,Q=[real(f'm_{i}_{v}') for v in ('cos','sin','p','q')];A=scale(F(1,2),sub(c,s));emit(eq(add(c,s),add('1',scale(2,d))))
  vals={'c':c,'s':s,'p':P,'q':Q,'d':d};prodV={}
  for key,Z in vals.items():
   for ax in (0,1):prodV[key,ax]=T[ax] if key=='d' else real(f'w_{i}_{ax}_{key}')
  for f in [add(prodV['c',0],prodV['s',1]),sub(prodV['c',1],prodV['s',0])]:
   emit(con(f,'<',1));emit(con(f,'>',-1))
  # Each list describes one chord in coordinates based at the edge's middle.
  data=[((x,y,0),1,-1,scale(-1,A),'q','p',-1),
        ((x,y+1,0),1,1,A,'p','q',1),
        ((x,y,1),0,-1,A,'p','q',-1),
        ((x+1,y,1),0,1,scale(-1,A),'q','p',1)]
  for edge,ax,sg,displacement,left,right,vsg in data:
   X,Y,kind=edge;u0=V[ax];t=T[1-ax]
   inactive=con(scale(sg,u0),'<=',-1);lrad=add(vals[left],scale(vsg,prodV[left,ax]));rrad=add(vals[right],scale(vsg,prodV[right,ax]))
   l=sub(add(t,displacement),lrad);r=add(t,displacement,rrad)
   aa=off((X,Y),kind);bb=off((X+(kind==0),Y+(kind==1)),kind)
   emit(dis([inactive,joint([lt(aa,l),lt(r,bb)])]))
   if (Y if not kind else X) in (0,5):emit(con(scale(sg,u0),'<',-1))
   edges.setdefault(edge,[]).append((inactive,l,r))
  endpoints=blocks[i] if blocks else [(F(k,bins),F(k+1,bins)) for k in range(bins)]
  for k,(a,b) in enumerate(endpoints):
   key=f'b_{i}_{k}';lo,hi=trig(a),trig(b);u0=min(sum(lo),sum(hi));um=max(sum(lo),sum(hi)) if (lo[0]-lo[1])*(hi[0]-hi[1])>=0 else margin
   limits={'c':(hi[0],lo[0]),'s':(lo[1],hi[1]),'p':(hi[0]**2/(1+um),lo[0]**2/(1+u0)),
           'q':(lo[1]**2/(1+um),hi[1]**2/(1+u0)),'d':((u0-1)/2,(um-1)/2)}
   extra=[]
   for ky,z in vals.items():
    extra+=I(z,*limits[ky])
    for ax in (0,1):extra+=mc(z,V[ax],prodV[ky,ax],limits[ky],vbox)
   for m in (lo,hi,trig((a+b)/2)):extra.append(con(dot(m,[c,s]),'<=',1))
   extra.append(con(dot((lo[0]+hi[0],lo[1]+hi[1]),[c,s]),'>=',1+lo[0]*hi[0]+lo[1]*hi[1]))
   # w=P+Q=1/(2+2d). Convexity gives two tangents and the secant.
   l,r=limits['d'];w=add(P,Q)
   if l<r:
    f=lambda z:1/(2+2*z);slope=(f(r)-f(l))/(r-l)
    extra.append(con(sub(w,scale(slope,d)),'<=',f(l)-slope*l))
    for p in (l,r):
     sl=-1/(2*(1+p)**2);extra.append(con(sub(w,scale(sl,d)),'>=',f(p)-sl*p))
   else:extra.append(con(w,'=',1/(2+2*l)))
   emit('(=> '+key+' '+joint(extra)+')')
 for e,rows in edges.items():
  assert len(rows) in (1,2)
  if len(rows)==2:
   (x,l,r),(y,L,R)=rows;emit(dis([x,y,lt(r,L),lt(R,l)]))
 out.append('(check-sat)')
 if save_model:out.append('(get-model)')
 return '\n'.join(out)+'\n'
def main(z):
 d=h/f'trials/meshchord_{z.bins}_{z.tag}';d.mkdir(exist_ok=True);C=sets();summary=Counter();t=time.monotonic()
 def one(item):
  i,case=item;f=d/f'{i:02}.json'
  if f.is_file():return json.loads(f.read_text())
  s=model_chords(case,z.bins,full=z.full);p=d/f'{i:02}.smt2';p.write_text(s)
  ans=subprocess.check_output([sys.executable,h/'advanced/z3_lra.py',p,str(z.time*1000)],text=True).strip()
  assert ans in ('sat','unsat','unknown')
  rec={'case':i,'cells':case,'status':ans,'bins':z.bins,'full':z.full,'sha256':hashlib.sha256(s.encode()).hexdigest()}
  if ans=='unsat' or z.keep:
   with gzip.open(d/f'{i:02}.smt2.gz','wb') as gz:gz.write(s.encode())
  p.unlink();f.write_text(json.dumps(rec));return rec
 with ThreadPoolExecutor(z.jobs) as ex:
  for f in as_completed([ex.submit(one,c) for c in enumerate(C)]):
   a=f.result();summary[a['status']]+=1;print(a['case'],a['status'],dict(summary),int(time.monotonic()-t),flush=True)
if __name__=='__main__':
 q=argparse.ArgumentParser();q.add_argument('--bins',default=6,type=int);q.add_argument('--tag',default='m');q.add_argument('--full',action='store_true');q.add_argument('--time',default=30,type=int);q.add_argument('--jobs',default=2,type=int);q.add_argument('--keep',action='store_true');main(q.parse_args())
