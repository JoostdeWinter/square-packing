"""Separate Boolean and difference-logic coverage for the one-aligned-tile certificates."""
from pathlib import Path
from itertools import permutations,product,combinations
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor
from collections import Counter
from fractions import Fraction as F
import sys,gzip,json,time,argparse
from one_axis_equal import patterns,canon
from near_grid import bridges
from check_signed_duals import verify_cert
from check_equal_boolean import join
h=Path(__file__).resolve().parents[1];sys.path.insert(0,str(h/'advanced'));from z3_lra import run
@lru_cache(maxsize=120)
def cells(p):
 occ=sorted(set(product(range(5),repeat=2))-set(enumerate(p)));return occ,{q:i for i,q in enumerate(occ)}
def sign_problem(p,z):
 occ,idx=cells(p);v=[f'a{i}' for i in range(20)]
 T=['(set-logic QF_UF)']+[f'(declare-const {q} Bool)' for q in v];T.append(f'(assert (not {v[z]}))')
 for x,y,d in bridges(set(enumerate(p))):
  k=min(y,y+d);lx=x if d>0 else x+1;hx=x+1 if d>0 else x
  arms=[(d,[[(j,y) for j in range(x+1)],[(j,y+d) for j in range(4,x,-1)]]),(-d,[[(lx,j) for j in range(k+1)],[(hx,j) for j in range(4,k,-1)]])]
  choices=[]
  for sg,ps in arms:
   cons=[]
   for arm in ps:
    seen_nonzero=False
    for q in arm:
     i=idx[q]
     if i==z:
      if seen_nonzero:cons.append('false')
     else:cons.append(v[i] if sg>0 else '(not '+v[i]+')');seen_nonzero=True
   choices.append(join('and',cons))
  T.append('(assert '+join('or',choices)+')')
 for s in patterns(p,z):
  T.append('(assert '+join('or',['(not '+q+')' if s>>i&1 else q for i,q in enumerate(v) if i!=z])+')')
 return '\n'.join(T)+'\n(check-sat)\n'
def graph_problem(p,s,z,bank,Q=None):
 occ,idx=cells(p);cell=[5*x+y for x,y in occ];sg={ci:(0 if i==z else (1 if s>>i&1 else -1)) for i,ci in enumerate(cell)}
 tr={};S=['(set-logic QF_IDL)'];emit=lambda t:S.append('(assert '+t+')')
 def X(i,k):return f'x{k}_{i}'
 def integer(k):return str(k) if k>=0 else f'(- {-k})'
 for i in cell:
  for dim,g in enumerate(divmod(i,5)):
   S.append('(declare-const '+X(i,dim)+' Int)')
   if Q is None and g==0:emit('(>= '+X(i,dim)+' '+integer(abs(sg[i]))+')')
   if Q is None and g==4:emit('(<= '+X(i,dim)+' '+integer(-abs(sg[i]))+')')
   for w in (-1,1):
    tr['rank',i,dim,w,g]='';tr['wall' if sg[i] else 'wall0',i,dim,w]=''
 for i,j in combinations(cell,2):
  a,b=divmod(i,5),divmod(j,5);ds=[b[k]-a[k] for k in (0,1)]
  if max(map(abs,ds))!=1:continue
  diag=all(ds);gate=f'h{i}_{j}'
  if diag:S.append('(declare-const '+gate+' Bool)')
  for dim in (0,1):
   if not ds[dim]:continue
   low,hi=(i,j) if ds[dim]>0 else (j,i);u,v=sg[low],sg[hi];t=divmod(hi,5)[1-dim]-divmod(low,5)[1-dim]
   selected=(gate if dim==0 else '(not '+gate+')') if diag else ''
   cost=-(1 if dim==0 else -1)*t*(u+v) if diag else abs(u-v)
   row='(>= (- '+X(hi,dim)+' '+X(low,dim)+') '+integer(cost)+')'
   if Q is None:emit('(=> '+selected+' '+row+')' if selected else row)
   if u==v:key=('same' if u else 'aligned',low,hi,dim,u)
   elif u*v:key=('mixdiag' if diag else 'mixedstraight',low,hi,dim,t)
   elif not diag:key=('zero_straight',low,hi,dim,0)
   elif (u+v)*(1 if dim==0 else -1)*t>0:key=('zero_favored',low,hi,dim,t)
   else:key=('zero_flat',low,hi,dim,0)
   tr[key]=selected
 if Q is not None:
  from one_axis_paths import exclude
  forbidden=set()
  for dim in (0,1):
   levels=[[q for q in cell if divmod(q,5)[dim]==l] for l in range(5)]
   for path in product(*levels):
    trans=tuple((q%5 if dim==0 else 4-q//5) for q in path)
    if any(abs(b-a)>1 for a,b in zip(trans,trans[1:])):continue
    if not exclude(tuple(sg[q] for q in path),trans,Q):continue
    lits=set()
    for i,j,a,b in zip(path,path[1:],trans,trans[1:]):
     if a==b:continue
     low,high=sorted((i,j));gate=f'h{low}_{high}'
     lits.add(gate if dim==0 else '(not '+gate+')')
    forbidden.add(frozenset(lits))
  for c in forbidden:
   if not any(d<c for d in forbidden):emit('(not '+join('and',sorted(c))+')')
 for rule in bank:
  if all(r in tr for r in rule):
   emit('(not '+join('and',sorted({tr[x] for x in rule if tr[x]}))+')')
 return '\n'.join(S)+'\n(check-sat)\n'
def main(v):
 if v.exact_paths:
  from one_axis_paths import bridges_exact
  assert v.Q>=24 and not bridges_exact(v.Q)[1]
 else:assert v.Q>=128 and (20*(1+F(1,64))+F(24,5)+F(2,3*64))/64<F(1,2)
 with gzip.open(v.proof,'rt') as f:b=json.load(f)
 assert all(verify_cert(r,v.Q) for r in b);bank=[set(map(tuple,row['rules'])) for row in b]
 reps=set();req=[]
 for p in permutations(range(5)):
  for z in range(20):
   req.append(('sign',p,z,0));reps.update(canon(p,s,z) for s in patterns(p,z))
 req.extend(('graph',p,s,z) for p,s,z in sorted(reps));counts=Counter();start=time.monotonic()
 def task(row):
  k,p,x,y=row;src=sign_problem(p,x) if k=='sign' else graph_problem(p,x,y,bank,v.Q if v.exact_paths else None)
  out,_=run(src,45000);assert out=='unsat',(k,p,x,y,out);return k
 with ThreadPoolExecutor(v.jobs) as ex:
  for i,k in enumerate(ex.map(task,req),1):
   counts[k]+=1
   if i%500==0:print(i,dict(counts),int(time.monotonic()-start),flush=True)
 assert counts=={'sign':2400,'graph':3671}
 res={'half_tangent_cutoff':f'1/{v.Q}','exact_chain_inequalities':v.exact_paths,'replayed_polynomials':len(bank),'independent_unsatisfiable_formulations':counts,'unresolved':0};print(res,flush=True)
 if v.out:v.out.write_text(json.dumps(res,indent=2)+'\n')
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('proof',type=Path);a.add_argument('--out',type=Path);a.add_argument('--jobs',type=int,default=2);a.add_argument('--Q',type=int,default=128);a.add_argument('--exact-paths',action='store_true');main(a.parse_args())
