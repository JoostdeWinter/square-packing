"""Find sparse numeric supports for one-parameter Farkas identities."""
from signed_linear import h,canon,rules
from signed_angle_graphs import pattern,constraints,models
from collections import Counter
from functools import lru_cache
from pathlib import Path
import argparse,time,json
def coeff(r,v):
 k,i,*rest=r
 if k in ('wall','wall0','rank'):
  a,b=rest[:2];return [(2*i+a,b)]
 j,a,s=rest;l=s*v if k in ('mixdiag','zero_favored') or k=='same' and a==0 else -s*v if k=='same' else 0
 return [(2*i+a,1),(2*j+a,-1),(2*i+1-a,l),(2*j+1-a,-l)]
def rhs(r,t):
 C=1-t*t;S=2*t;D=1+t*t;c=C/D;s=S/D;u=c+s;v=S/C;d=u*(u-1);k=r[0]
 if k in ('wall','wall0'):
  return -(1 if k=='wall0' else u)/2+(5 if r[3]==1 else 0)
 if k=='rank':
  sd,x=r[3:];return sd*(x+.5)+(4-x if sd==1 else x)*d
 if k=='same':return -1/c
 if k=='aligned':return -1
 if k=='zero_favored':return -(1+u)/(2*c)
 if k in ('zero_flat','zero_straight'):return -(1+u)/2+(4*v*d if k=='zero_straight' else 0)
 return -u+(4*v*d if k=='mixedstraight' else 0)
def phase(rs,t):
 import numpy as np
 from scipy.optimize import linprog
 v=2*t/(1-t*t)
 A=np.zeros((len(rs),51));b=[]
 for i,r in enumerate(rs):
  for k,w in coeff(r,v):A[i,k]+=w
  A[i,50]=1;b.append(rhs(r,t))
 z=linprog(np.r_[np.zeros(50),-1],A_ub=A,b_ub=b,bounds=[(None,None)]*51,method='highs',options={'primal_feasibility_tolerance':1e-10,'dual_feasibility_tolerance':1e-10});assert z.success,z.message
 # A nonzero marginal can be extremely small for a high-degree identity.
 weights=z.ineqlin.marginals;idx=[i for i,w in enumerate(weights) if w<0]
 return -z.fun,tuple(sorted(rs[i] for i in idx))
def main(v):
 data=json.loads((h/'trials/signed_graph_kept.json').read_text());cases=set()
 for p,ls in data.items():
  p=tuple(map(int,p.split(',')))
  for s in ls:
   if s not in (0,1048575):cases.add(canon(p,s))
 dest=h/'trials'/('signed_duals_'+v.tag);dest.mkdir(exist_ok=True)
 map_={};supports={};checked={};clock=time.monotonic();ct=Counter();reject=set()
 def enc(rs):
  z=0
  for r in rs:
   if r not in map_:map_[r]=len(map_)
   z|=1<<map_[r]
  return z
 if v.exclude:
  for f in Path(v.exclude).glob('*.json'):
   q=json.loads(f.read_text())
   if not q.get('verified'):reject.add(tuple(sorted(tuple(x) for x in q['rules'])))
 for f in sorted(dest.glob('support_*.json')):
  r=json.loads(f.read_text());ss=tuple(tuple(q) for q in r['rules']);z=enc(ss)
  if ss not in reject:supports[z]=r['index']
 next_id=max([int(f.stem.split('_')[-1]) for f in dest.glob('support_*.json')]+[-1])+1
 for it,(p,s) in enumerate(sorted(cases,key=lambda j:(min(j[1].bit_count(),20-j[1].bit_count()),j))):
  _,edges,_=pattern(p);graphs=models(constraints(p,s),len(edges),False);hits=Counter();open_=0
  for m in graphs:
   rs=rules(p,s,m);z=enc(rs);hit=next((j for need,j in supports.items() if need&z==need),None)
   if hit is not None:hits[hit]+=1;ct['reused']+=1;continue
   gap,ss=phase(rs,v.t)
   if gap< -1e-9 and ss not in reject:
    out={'index':next_id,'rules':ss,'sample_half_tangent':v.t,'sample_max_slack':gap,'first_pattern':p,'first_sign':s,'first_graph':m}
    (dest/f'support_{next_id:05}.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
    supports[enc(ss)]=next_id;hits[next_id]+=1;next_id+=1;ct['new']+=1
   else:
    open_+=1;ct['open']+=1
    if open_<=3:
     (dest/f"open_{''.join(map(str,p))}_{s}_{m}.json").write_text(json.dumps({'p':p,'s':s,'m':m,'gap':gap,'rules':ss}))
  checked[str([p,s])]=[len(graphs),open_]
  if (it+1)%12==0:print(it+1,len(cases),dict(ct),'known',len(supports),int(time.monotonic()-clock),flush=True)
 (dest/'summary.json').write_text(json.dumps({'counts':ct,'representatives':len(cases),'supports':len(supports),'graphs':sum(x[0] for x in checked.values()),'open':sum(x[1] for x in checked.values())},indent=2));print('end',dict(ct),'known',len(supports),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--tag',default='t77');p.add_argument('--t',default=1/77,type=float);p.add_argument('--exclude');main(p.parse_args())
