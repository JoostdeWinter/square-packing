"""Discover symmetric weighted board-point transversals with continuous centers."""
from pathlib import Path
from fractions import Fraction as F
import argparse,itertools,json,sys,subprocess,time
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csr_matrix,vstack
h=Path(__file__).resolve().parents[1]
def orbits(L,q,mixes):
 base={F(i,q) for i in range(1,(5*q)//2+1)}
 for d in mixes:
  base.update(F(i,d) for i in range(1,(5*d)//2+1))
 base.update(F(i,10) for i in (5,9,10,15,17,20,25))
 # Marks very close to a wall cannot dominate their inward counterparts for
 # arbitrary tilts, but keep all grid marks for the finite search.
 raw=sorted(base)
 sites=[];sg=[];n=[]
 for i,x in enumerate(raw):
  for y in raw[i:]:
   pts=sorted({(a if not u else 5-a,b if not v else 5-b) for a,b in [(x,y),(y,x)] for u,v in itertools.product((0,1),repeat=2)})
   sg.extend([len(n)]*len(pts));n.append(len(pts));sites.extend((float(a)*L/5,float(b)*L/5) for a,b in pts)
 return np.array(sites),np.array(sg),n
def masks(xy,o,nn,jobs):
 seen={}
 for p in range(0,len(jobs),150):
  vals=np.asarray(jobs[p:p+150]);xs,ys,Ang=vals.T;c=np.cos(Ang)[:,None];s=np.sin(Ang)[:,None];x=xy[None,:,0]-xs[:,None];y=xy[None,:,1]-ys[:,None]
  hit=(abs(c*x+s*y)<=.5+3e-11)&(abs(-s*x+c*y)<=.5+3e-11)
  for m,j in zip(hit,vals):
   a=np.bincount(o[m],minlength=nn).astype('uint8');seen[a.tobytes()]=j.tolist()
 return seen
def run(U,q,mix,samples,bins,iterations):
 L=U/1e6;xy,o,n=orbits(L,q,mix);nn=len(n);t=time.monotonic();d=h/'trials'/('pierce'+str(U)+'_'+str(q)+'_'+'_'.join(map(str,mix)));d.mkdir(exist_ok=True)
 rng=np.random.default_rng(201126);tasks=[]
 for i in range(samples):
  a=0 if i%11==0 else np.pi/4 if i%13==0 else rng.uniform(0,np.pi/4);hh=.5*(np.cos(a)+np.sin(a));v=rng.uniform(hh,L-hh,2)
  if i%5==0:v[0]=hh+1e-7
  if i%7==0:v[1]=hh+1e-7
  if i%6==0:
   v=rng.choice(np.arange(.5,5,1.),size=2)*L/5+rng.uniform(-.025,.025,2);v=np.clip(v,hh+1e-7,L-hh-1e-7)
  tasks.append([v[0],v[1],a])
 examples=masks(xy,o,nn,tasks);hist=[]
 for it in range(iterations):
  A=csr_matrix(np.frombuffer(b''.join(examples),dtype='uint8').reshape(-1,nn).astype(float));b=-np.ones(len(examples));obj=np.array(n)
  res=linprog(obj,A_ub=-A,b_ub=b,bounds=(0,1),method='highs',options={'time_limit':180})
  if not res.success:print('LP',res.message,flush=True);break
  act=(res.x[o]>1e-8);marked=xy[act];weights=res.x[o[act]];dat=d/'active.txt';dat.write_text(str(len(marked))+'\n'+''.join(f'{x:.15g} {y:.15g} {w:.15g}\n' for (x,y),w in zip(marked,weights)))
  raw=subprocess.check_output([h/'geometry/piercing_oracle',str(L),str(bins),str(20),dat],text=True);candidates=[]
  for line in raw.splitlines():
   k,w,x,y,a=map(float,line.split())
   if w<.999999:
    b0=(np.cos(a)+np.sin(a))/2;assert b0-1e-7<=min(x,y) and max(x,y)<=L-b0+1e-7
    candidates.append([x,y,a])
  new=masks(xy,o,nn,candidates) if candidates else {};old=len(examples);examples.update(new)
  step=dict(iteration=it,mass=res.fun,constraints=old,active_points=int(act.sum()),violating_witnesses=len(examples)-old,elapsed=round(time.monotonic()-t,1))
  hist.append(step);print(step,flush=True);(d/'status.json').write_text(json.dumps({'U':U,'q':q,'mix':mix,'status':'discovery_only','history':hist}))
  if res.fun>20.02 or not len(examples)-old:
   data={'U':U,'q':q,'mix':mix,'history':hist,'weights':[[float(xx),float(yy),float(wt)] for (xx,yy),wt in zip(marked,weights)]}
   (d/'weights.json').write_text(json.dumps(data));break
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('U',type=int);a.add_argument('--q',default=6,type=int);a.add_argument('--mix',nargs='*',type=int,default=[]);a.add_argument('--samples',type=int,default=6500);a.add_argument('--bins',type=int,default=24);a.add_argument('--iterations',type=int,default=80);v=a.parse_args();run(v.U,v.q,v.mix,v.samples,v.bins,v.iterations)
