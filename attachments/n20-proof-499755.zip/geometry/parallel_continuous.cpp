// Certified continuous common-angle center packing in an outward rational
// polygon. Each native coordinate is an integer in user-specified units.
#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>
using namespace std;using I=int64_t;using W=__int128_t;
struct P{I x,y;bool operator<(P a)const{return x==a.x?y<a.y:x<a.x;}bool operator==(P a)const{return x==a.x&&y==a.y;}};
using Poly=vector<P>;using Mask=uint64_t;
I cross(P a,P b,P c){return (b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);}
Poly hull(Poly p){sort(p.begin(),p.end());p.erase(unique(p.begin(),p.end()),p.end());if(p.size()<3)return p;
 Poly q(p.size()*2);int k=0;for(auto x:p){while(k>=2&&cross(q[k-2],q[k-1],x)<=0)--k;q[k++]=x;}
 int m=k+1;for(int j=p.size()-2;j>=0;j--){auto x=p[j];while(k>=m&&cross(q[k-2],q[k-1],x)<=0)--k;q[k++]=x;}q.resize(k-1);return q;}
I flo(W n,W d){if(d<0)n=-n,d=-d;return n/d-(n<0&&n%d);}
struct F{int axis,sign;I k;};
I val(P p,F n){return n.sign*(n.axis?p.y:p.x)-n.k;}
Poly cut(const Poly&p,F n){
 if(p.empty())return {};Poly out;auto a=p.back();I u=val(a,n);
 for(auto b:p){I v=val(b,n);if((u<0&&v>0)||(u>0&&v<0)){
  I den=u-v;W X=(W)b.x*u-(W)a.x*v,Y=(W)b.y*u-(W)a.y*v;
  for(I x:{flo(X,den),-flo(-X,den)})for(I y:{flo(Y,den),-flo(-Y,den)})out.push_back({x,y});
 }if(v<=0)out.push_back(b);a=b;u=v;}return hull(move(out));
}
struct Box{I lo[2],hi[2];};
Box bb(const Poly&p){Box b{{p[0].x,p[0].y},{p[0].x,p[0].y}};for(auto z:p){b.lo[0]=min(b.lo[0],z.x);b.lo[1]=min(b.lo[1],z.y);b.hi[0]=max(b.hi[0],z.x);b.hi[1]=max(b.hi[1],z.y);}return b;}
struct Edge{int a,b,k;}; // z_b - z_a >= unit in coordinate k
using State=vector<Poly>;
ofstream open_masks;
struct Solver{
 I D;int budget;long nodes=0,closed=0,unknown=0,skipped=0,leaves=0;vector<Mask> bad;int peak=0;vector<Poly> all;
 bool trim(Poly& p,const Box& b,F n){
  I hi=n.sign==1?b.hi[n.axis]:-b.lo[n.axis];if(hi<=n.k)return false;
  I lo=n.sign==1?b.lo[n.axis]:-b.hi[n.axis];if(lo>n.k){p.clear();return true;}
  auto q=cut(p,n);if(q==p)return false;p=move(q);return true;
 }
 bool contract(State& p,const vector<Edge>& fixed,vector<Edge>& choices){
  int n=p.size();vector<Edge>best;long bestscore=-1;
  for(int iter=0;iter<80;iter++){
   // Waiving further contraction after the limit only enlarges the search.
   bool changed=false;vector<Box> boxes;for(auto& q:p){if(q.empty())return false;boxes.push_back(bb(q));}
   vector<Edge> forced=fixed;best.clear();bestscore=-1;
   for(int i=0;i<n;i++)for(int j=i+1;j<n;j++){
    auto a=boxes[i],b=boxes[j];vector<Edge>opts;I penalty=0;bool separated=false;
    for(int k:{0,1})for(int sign:{1,-1}){int u=sign==1?i:j,v=sign==1?j:i;
     I minDiff=boxes[v].lo[k]-boxes[u].hi[k],maxDiff=boxes[v].hi[k]-boxes[u].lo[k];
     if(minDiff>=D)separated=true;
     if(maxDiff>=D){opts.push_back({u,v,k});penalty+=max<I>(0,D-minDiff);}
    }
    if(separated)continue;if(opts.empty())return false;
    if(opts.size()==1)forced.push_back(opts[0]);
    else{
     bool done=any_of(fixed.begin(),fixed.end(),[&](Edge e){return (e.a==i&&e.b==j)||(e.a==j&&e.b==i);});
     long score=10000000/(long)opts.size()+penalty/(long)opts.size();
     if(!done&&score>bestscore){bestscore=score;best=opts;}
    }
   }
   for(auto e:forced){
    if(trim(p[e.a],boxes[e.a],{e.k,1,boxes[e.b].hi[e.k]-D})){changed=true;if(p[e.a].empty())return false;boxes[e.a]=bb(p[e.a]);}
    if(trim(p[e.b],boxes[e.b],{e.k,-1,-boxes[e.a].lo[e.k]-D})){changed=true;if(p[e.b].empty())return false;boxes[e.b]=bb(p[e.b]);}
   }
   // Exclude the interior of the rectangle in which a neighbor cannot
   // be a unit apart along either coordinate, then take an outward hull.
   if(iter%3==0)for(int j=0;j<n;j++)for(int i=0;i<n;i++)if(i!=j){
    auto b=boxes[j],a=boxes[i];I xl=b.hi[0]-D,xh=b.lo[0]+D,yl=b.hi[1]-D,yh=b.lo[1]+D;
    if(a.hi[0]<=xl||a.lo[0]>=xh||a.hi[1]<=yl||a.lo[1]>=yh)continue;
    if(a.lo[0]>xl&&a.hi[0]<xh&&a.lo[1]>yl&&a.hi[1]<yh)return false;
    // If every vertex already escapes, taking the hull cannot improve it.
    if(none_of(p[i].begin(),p[i].end(),[&](P x){return xl<x.x&&x.x<xh&&yl<x.y&&x.y<yh;}))continue;
    Poly pts;
    for(F side:vector<F>{{0,1,xl},{0,-1,-xh},{1,1,yl},{1,-1,-yh}}){
     auto u=cut(p[i],side);pts.insert(pts.end(),u.begin(),u.end());
    }
    auto q=hull(move(pts));if(q.empty())return false;
    if(q!=p[i]){ // Intersecting outward pieces can round out by one. Retain
                  // only a change when a bounding extent or a vertex improves.
     if(q.size()==p[i].size()&&equal(q.begin(),q.end(),p[i].begin()))continue;
     changed=true;p[i]=move(q);boxes[i]=bb(p[i]);}
   }
   if(!changed)break;
  }
  choices=move(best);return true;
 }
 bool solve(State p,vector<Edge> fixed,int& used,int depth){
  ++nodes;peak=max(peak,depth);
  if(++used>budget)return false;vector<Edge> opt;if(!contract(p,fixed,opt))return true;
  if(opt.empty()){leaves++;return false;}
  for(auto e:opt){auto next=fixed;next.push_back(e);if(!solve(p,move(next),used,depth+1))return false;}
  return true;
 }
 State state(Mask m){State p;for(int j=0;j<(int)all.size();j++)if(m>>j&1)p.push_back(all[j]);return p;}
 void examine(Mask m){
  for(Mask v:bad)if((m&v)==v){skipped++;return;}
  auto p=state(m);vector<Edge>opts;
  if(!contract(p,{},opts)){
   auto v=m;for(int i=0;i<(int)all.size();i++)if(v>>i&1){auto t=state(v^(Mask(1)<<i));if(!contract(t,{},opts))v^=Mask(1)<<i;}
   bad.push_back(v);closed++;return;
  }
  int used=0;
  if(solve(move(p),{},used,0))closed++;else{unknown++;if(open_masks.is_open())open_masks<<m<<"\n";if(unknown<8)cout<<"OPEN "<<m<<" "<<used<<"\n";}
 }
 void masks(int i,int left,Mask m){
  if(left==0){examine(m);return;}if((int)all.size()-i<left)return;
  masks(i+1,left-1,m|(Mask(1)<<i));masks(i+1,left,m);
 }
};
int main(int argc,char**argv){try{
 if(argc!=3)throw runtime_error("continuous-input node-limit");ifstream in(argv[1]);if(const char* masks=getenv("N20_MASK_FILE"))open_masks.open(masks);int n;I d;in>>n>>d;if(!in||n<0||n>30||d<1000||d>10000000)throw runtime_error("header");Solver s{d,stoi(argv[2])};
 for(int i=0;i<n;i++){int N;in>>N;if(N<1||N>30)throw runtime_error("cell domain");Poly p(N);for(auto& z:p){in>>z.x>>z.y;if(!in||abs(z.x)>10*d||abs(z.y)>10*d)throw runtime_error("point bounds");}
  auto q=hull(p);auto b=bb(q);if(b.hi[0]-b.lo[0]>=d||b.hi[1]-b.lo[1]>=d)throw runtime_error("cell can hold two");s.all.push_back(q);}
 s.masks(0,20,0);cout<<"RESULT "<<n<<" "<<s.closed<<" "<<s.skipped<<" "<<s.unknown<<" "<<s.nodes<<" "<<s.bad.size()<<" "<<s.peak<<" "<<s.leaves<<endl;
}catch(exception& e){cerr<<e.what()<<endl;return 2;}}
