"""Enumerate first-order signed angle orders forced by paired turning chains."""
from itertools import permutations,product,combinations
from collections import Counter
from pathlib import Path
from near_grid import bridges
import json,argparse
def arms(q,vertical):
 x,y,d=q;z=y+d
 if not vertical:return d,[(i,y) for i in range(x+1)],[(i,z) for i in range(4,x,-1)]
 k=min(y,z);u=x if d==1 else x+1;v=x+1 if d==1 else x
 return -d,[(u,j) for j in range(k+1)],[(v,j) for j in range(4,k,-1)]
def summarize():
 rows=Counter();zone=Counter();tally=Counter();ext={}
 for p in permutations(range(5)):
  vacant=set(enumerate(p));pts=sorted(set(product(range(5),repeat=2))-vacant);ids={j:i for i,j in enumerate(pts)};E=bridges(vacant)
  local=Counter()
  for mask in range(1<<len(E)):
   graph=[1<<i for i in range(21)];old=20
   for i,e in enumerate(E):
    sign,A,B=arms(e,mask>>i&1)
    for a in (A,B):
     chain=[20]+[ids[q] for q in a]
     for x,y in zip(chain,chain[1:]):
      if sign<0:x,y=y,x
      graph[x]|=1<<y
   for j in range(21):
    for i in range(21):
     if graph[i]>>j&1:graph[i]|=graph[j]
   blocks={tuple(j for j in range(21) if graph[i]>>j&1 and graph[j]>>i&1) for i in range(21)}
   zero=next(g for g in blocks if 20 in g);equal=sum((sum(j<20 for j in g)*(sum(j<20 for j in g)-1))//2 for g in blocks)
   order=sum(1 for i,j in combinations(range(20),2) if graph[i]>>j&1 or graph[j]>>i&1)
   rooted=sum(1 for i in range(20) if graph[i]>>20&1 or graph[20]>>i&1)
   biggest=max(sum(q<20 for q in g) for g in blocks)
   key=(len(zero)-1,equal,order,rooted,biggest);rows[key]+=1;local[key]+=1
  for i,name in enumerate(('leading_zero_centers','equal_angle_pairs','comparable_pairs','sign_constrained_tiles','largest_equal_group')):
   lo=min(k[i] for k in local);hi=max(k[i] for k in local);ext.setdefault(name,[lo,hi]);ext[name][0]=min(ext[name][0],lo);ext[name][1]=max(ext[name][1],hi)
   if name=='largest_equal_group':zone[lo]+=1
  tally[len(E)]+=1
 return {'vacancy_permutations':sum(tally.values()),'routing_count':sum(rows.values()),'bridges_per_permutation':dict(tally),'range_over_all_routings':ext,'least_equal_group_by_permutation':dict(zone),'all_routings_have_at_least_one_forced_tie':min(k[1] for k in rows)>0}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path);v=p.parse_args();r=summarize();print(json.dumps(r))
 if v.output:v.output.write_text(json.dumps(r,indent=2)+'\n')
