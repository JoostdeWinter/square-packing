"""Convert a midpoint-angle spread certificate to a bound at the largest tilt."""
from fractions import Fraction as F
import json,argparse
from pathlib import Path
def prove(source,large,coef,signed=False):
 z=json.loads(source.read_text());assert z['reference']=='midpoint' and z['uncovered']==0
 assert z['large_range_concavity_checked'] and z['large_angle_threshold_half_tangent']=='1/24' and z['all_signed_tilts_independent']
 assert z['counts']['graphs']==z['counts']['covered']
 q=json.loads(large.read_text());assert q['terminal_refinements']['parent_matchings']==1142 and not q['terminal_refinements']['pending'] and q['terminal_refinements']['half_tangent']==['1/24','23/25']
 m=2*F(z['angle_spread_radians_over_t_squared']);C=F(coef)
 if signed:
  from signed_near_axis import check
  a=F(check(large)['some_absolute_half_tangent_at_most']);T=F(16,375)
 else:a=F(1,24);T=F(1,22)
 for t in [T,F(5,12)]:assert 2*(t-a)>C*t*t*(1+t*t)
 # For t <= T and Delta <= Ct^2, the mean value theorem bounds the change of tan.
 factor=1-(1+T*T)*C*T/4
 assert factor>0 and m*factor*factor>=C
 return {'midpoint_spread_coefficient':str(m),'maximum_tilt_spread_coefficient':str(C),'breakpoint':str(T),'minimum_ratio_of_half_tangents_in_small_range':str(factor),'exact_geometry_replayed_graphs':z['counts']['covered']}
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('proof',type=Path);a.add_argument('far',type=Path);a.add_argument('coefficient');a.add_argument('--signed',action='store_true');a.add_argument('--out',type=Path);v=a.parse_args();z=prove(v.proof,v.far,v.coefficient,v.signed);print(z)
 if v.out:v.out.write_text(json.dumps(z,indent=2)+'\n')
