"""Enclose every pose of a common-angle center set and exhaust finite lattice placements."""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
from math import ceil
from subprocess import run
import argparse,sys,json
from parallel_cover import trig
from parallel_cover import pixel_intervals
import parallel_cover
h=Path(__file__).resolve().parent
def pixels(a,b,q,cap,align):
 def outer(a,b):
  c,s=trig((a+b)/2);ends=[trig(t) for t in (a,b)]
  half=max(cap-x-y for x,y in ends)*max(c*x+s*y+abs(c*y-s*x) for x,y in ends)/2
  return [(c*x+s*y,-s*x+c*y) for x,y in [(-half,-half),(half,-half),(half,half),(-half,half)]]
 parallel_cover.boundary=outer
 rows=pixel_intervals(a,b,q,(F(1,3),F(1,3)))
 points=[(x,y) for y,(lo,hi) in rows.items() for x in range(lo,hi)]
 low=[min(p[i] for p in points) for i in (0,1)];high=[max(p[i] for p in points) for i in (0,1)]
 # Balanced integer strips of width at most q, covering the full pixel domain.
 n=[ceil((v-u+1)/q) for u,v in zip(low,high)]
 cell=defaultdict(list)
 for p in points:
  if align==0:key=tuple((x-lo)*count//(hi-lo+1) for x,lo,hi,count in zip(p,low,high,n))
  else:key=tuple((x-lo+(count*q-(hi-lo+1))//2)//q for x,lo,hi,count in zip(p,low,high,n))
  cell[key].append(p)
 return [cell[i] for i in sorted(cell)]
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--ranges',nargs='+',required=True);ap.add_argument('--q',type=int,default=20);ap.add_argument('--cap',default='5');ap.add_argument('--limit',type=int,default=150);ap.add_argument('--align',type=int,default=0);v=ap.parse_args()
 folder=h.parent/'trials/parallel_discrete';folder.mkdir(exist_ok=True)
 for limits in v.ranges:
  a,b=map(F,limits.split(','));cells=pixels(a,b,v.q,F(v.cap),v.align)
  name=f'{a.numerator}_{a.denominator}_{b.numerator}_{b.denominator}_q{v.q}_s{v.cap.replace("/","_")}_a{v.align}'
  target=folder/(name+'.in');target.write_text(f'{v.q} {len(cells)}\n'+'\n'.join(' '.join(map(str,[len(cell),*[x for z in cell for x in z]])) for cell in cells)+'\n')
  print('start',name,len(cells),flush=True)
  r=run([h/'parallel_discrete',target,str(v.limit)],capture_output=True,text=True,check=True)
  last=r.stdout.splitlines()[-1].split();assert last[0]=='RESULT' and len(last)==6
  print(name,' '.join(last),flush=True);z={'interval':[str(a),str(b)],'q':v.q,'side':v.cap,'alignment':v.align,'limit':v.limit,'counts':list(map(int,last[1:]))}
  (folder/(name+'.json')).write_text(json.dumps(z,indent=2))
if __name__=='__main__':main()
