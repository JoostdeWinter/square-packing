# Four squares near a wall

Research direction by Joost de Winter. AI author GPT6.2 Astra.

In any packing of twenty independently placed and rotated unit squares in a board of side S < 5, at most four tiles can have their leftmost point at distance at most d = √2 − 1 from the left wall. The same statement holds at each wall. Consequently at least four whole tiles lie in the concentric square of side S − 2(√2 − 1). The claims also apply to tiles with strictly positive mutual and wall distances in an open board of side 5.

For the proof let c and s be the nonnegative cosine and sine of the reduced tilt and write u = c+s. The tile has horizontal half-width h = u/2. A vertical line within r = h − cs of its center cuts a chord of length at least 1. At 0° this is the ordinary unit chord. For nonzero tilts the chord length at offset v is the smaller of 1/max(c,s) and (h−|v|)/(cs). In particular

    h−r = cs ≤ 1/2,
    h+r = u−cs = 1−(u−1)²/2 ≥ √2−1/2.

If the leftmost tile point is at distance at most d from the wall, its center has abscissa in [h,h+d]. Thus every line of abscissa τ in [d+1/2, √2−1/2] cuts a chord of length at least 1. At the maximal d the interval consists of the one line of abscissa √2−1/2. Along that line, four points at ordinates S/5, 2S/5, 3S/5, 4S/5 meet every such chord. At S<5 the spacing is less than 1, so a point lies in the relative interior of the chord and the tile interior. In the strict normalized board at 5 the four marks can each belong to at most one closed tile. This proves the wall count and, by applying it at all four walls, the central count.

There is also an assignment useful in a computer proof. Take any certified pattern hitting every unit tile in the board, and translate the whole pattern by d inward from the left wall along the x-axis, where 0<d≤√2−1. If translating a given tile left by d keeps it inside the board, it contains a translated pattern point. Otherwise its left edge lies within distance d of that wall and it contains one of the four boundary-strip marks just proved. Thus the translated pattern, supplemented with the four marks, again hits every tile. When a tile is assigned a supplemental mark, its center may also be restricted to x≤h+d. All four walls and either Bentz pattern can be used separately. The program uses rational values of τ at most 0.9142 to keep every bound exact.

If four tiles satisfy the same strip hypothesis for a fixed d<√2−1, each tile contains a horizontal segment crossing the whole abscissa interval [d+1/2, √2−1/2] at one of the four specified ordinates. In the strict normalized board the four tiles are closed and disjoint. At any abscissa in the interval each receives exactly one mark. For a fixed ordinate the four closed sets of abscissae covered by the tiles are disjoint and cover a connected interval, so one tile owns that ordinate throughout. For a packing with contacts at S<5, the interior coverage at every abscissa gives four disjoint relatively open sets with the same conclusion.
