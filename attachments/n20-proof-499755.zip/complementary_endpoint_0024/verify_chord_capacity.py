#!/usr/bin/env python3
"""Independent rational checker for chord_capacity_receipt.json."""

from __future__ import annotations

import json
import sys
from fractions import Fraction
from pathlib import Path


def fraction(text: str) -> Fraction:
    a, b = text.split("/")
    return Fraction(int(a), int(b))


def main() -> None:
    data = json.loads(Path(sys.argv[1]).read_text())
    rows = data["rows"]
    assert len(rows) == 5
    previous = Fraction(0)
    for row in rows:
        side = fraction(row["side"])
        deficit = fraction(row["side_deficit"])
        energy = fraction(row["sum_u_times_u_minus_1_at_least"])
        sine = fraction(row["sum_sin_twice_tilt_at_least"])
        angle = fraction(row["sum_tilt_radians_at_least"])
        assert Fraction(1 + 2, 1) < side < 5
        assert deficit == 5 - side > 0
        assert energy == sine == 4 * deficit
        assert angle == 2 * deficit
        assert side > previous
        previous = side

    # Exact algebra behind the chord formula.  For u in [1,sqrt(2)],
    # h=(1+u-u^2)/2 is positive, h<=u/2, and
    # 1-2h=u(u-1).  Rational samples include both endpoints by squared tests.
    samples = [Fraction(1), Fraction(1001, 1000), Fraction(7, 5)]
    for u in samples:
        assert 1 <= u and u * u <= 2
        h = (1 + u - u * u) / 2
        assert h > 0 and h <= u / 2
        assert 1 - 2 * h == u * (u - 1)

    print("PASS: 5 exact sides; chord identity and unrestricted aggregate consequences verified")


if __name__ == "__main__":
    main()

