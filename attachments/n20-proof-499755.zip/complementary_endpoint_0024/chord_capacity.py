#!/usr/bin/env python3
"""Exact receipt for the unrestricted directional chord-capacity theorem.

Research direction: Joost de Winter.
AI author: GPT6.2 Astra.
"""

from __future__ import annotations

import argparse
import json
from decimal import Decimal, getcontext
from fractions import Fraction
from pathlib import Path


SIDES = (
    Fraction(99, 20),
    Fraction(124, 25),
    Fraction(497, 100),
    Fraction(249, 50),
    Fraction(499, 100),
)


def ftext(x: Fraction) -> str:
    return f"{x.numerator}/{x.denominator}"


def row(side: Fraction) -> dict[str, object]:
    deficit = 5 - side
    energy = 4 * deficit
    angle_sum = 2 * deficit
    getcontext().prec = 60
    pi = Decimal("3.141592653589793238462643383279502884197169399375105820974944")
    degrees = Decimal(angle_sum.numerator) / Decimal(angle_sum.denominator) * Decimal(180) / pi
    return {
        "side": ftext(side),
        "side_deficit": ftext(deficit),
        "sum_u_times_u_minus_1_at_least": ftext(energy),
        "sum_sin_twice_tilt_at_least": ftext(energy),
        "sum_tilt_radians_at_least": ftext(angle_sum),
        "sum_tilt_degrees_at_least_display": format(degrees, ".30f"),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("chord_capacity_receipt.json"))
    args = parser.parse_args()
    result = {
        "theorem": (
            "For N interior-disjoint unit squares in a square of strict side S<5, "
            "sum u_i(u_i-1) >= N-4S, where u_i=cos(phi_i)+sin(phi_i)."
        ),
        "specialization": "N=20; all certified quantities except displayed degrees are exact fractions",
        "rows": [row(side) for side in SIDES],
        "attribution": {
            "research_direction": "Joost de Winter",
            "ai_author": "GPT6.2 Astra",
        },
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

