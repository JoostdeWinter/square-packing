# Directional chord capacity at the endpoint

Research direction by Joost de Winter. AI author GPT6.2 Astra.

## Checked unrestricted theorem

Let `N` independently translated and rotated unit squares have pairwise disjoint
interiors in a square board of side `S<5`.  Reduce each tile angle modulo 90
degrees to `phi_i` in `[0,45 degrees]`, and put

    u_i = cos(phi_i) + sin(phi_i).

Then

    sum_i u_i (u_i - 1) >= N - 4S.

For `N=20`, this is

    sum_i u_i (u_i - 1) >= 4(5-S).

Since `sin(2 phi_i) = u_i^2-1 >= u_i(u_i-1)` and
`sin(2 phi_i) <= 2 phi_i`, every hypothetical sub-5 packing also satisfies

    sum_i sin(2 phi_i) >= 4(5-S),
    sum_i phi_i >= 2(5-S) radians.

These statements are fully unrestricted.  They allow independent rotations,
non-lattice centers, tile contacts, wall contacts, and all line/tile
degeneracies.  They are necessary conditions, not a proof of `s(20)=5`.

## Proof

For a tile at reduced angle `phi`, write `c=cos(phi)`, `s=sin(phi)` and
`u=c+s`.  A horizontal line at signed distance `v` from its center cuts the
tile in a segment of length

    min(1/max(c,s), (u/2-|v|)/(cs)).

Consequently that chord has length at least one whenever

    |v| <= h(u) = (1+u-u^2)/2.

The formula includes `phi=0` by continuity, when `h=1/2`.  Also
`0<h<=u/2`; containment of the tile in the board therefore places the whole
closed interval `[y_i-h_i,y_i+h_i]` inside `[0,S]`.

Outside the finitely many tile-edge supporting lines and interval endpoints,
no horizontal line can belong to five of these intervals.  Otherwise that
generic line would pass through the interiors of five tiles and contain five
chords, each of length at least one, whose relative interiors are pairwise
disjoint.  Their total length is at least five, which cannot fit in a board
section of length `S<5`.  Thus the interval depth is at most four almost
everywhere.  Integrating it over `[0,S]` gives

    sum_i 2h_i <= 4S.

Substitute `2h_i=1+u_i-u_i^2` and rearrange.  Because only an
almost-everywhere depth bound is used, coincident boundary edges, equality
chords, centers on interval endpoints and wall contacts cause no gap.

## Directional strengthening

The same proof works for lines at angle `alpha` whenever

    S/max(|cos(alpha)|,|sin(alpha)|) < 5.

Writing `psi_i` for the reduced angle between tile `i` and those lines, it
gives the family

    sum_i h(cos(psi_i)+sin(psi_i))
      <= 2S (|cos(alpha)|+|sin(alpha)|).

The axial member `alpha=0` yields the exact aggregate theorem above.  The
nonzero members are a complementary pruning condition for endpoint angle
cells; this checkpoint does not claim that they close every marked case.

## Reproduction

Run from this directory:

    python3 chord_capacity.py --output chord_capacity_receipt.json
    python3 verify_chord_capacity.py chord_capacity_receipt.json

The receipt contains exact rational side deficits and exact consequences.  Its
decimal degree totals are display values only.  The independent checker uses
only integer and rational arithmetic for every certified equality and
inequality.

## Relation to the earlier near-axis count

The earlier strip theorem forces at least four tiles above a side-dependent
individual angle.  This result is different: it forces aggregate angular mass.
For example, at side `4.99` it requires the sum of the twenty reduced tile
angles to be at least `0.02` radians, or about `1.1459 degrees`; at side `4.98`
the minimum is `0.04` radians, or about `2.2918 degrees`.  The two constraints
can be enforced simultaneously in a marked-pattern search.

