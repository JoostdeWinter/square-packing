#!/usr/bin/env python3
"""Replay an unrestricted square-packing lower bound from the pinned upstream source."""
import argparse
import hashlib
import itertools
import json
import os
import subprocess
import sys
import tempfile
from collections import Counter,defaultdict
from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction as F
from pathlib import Path

H=Path(__file__).resolve().parent
sys.path[:0]=[str(H/'base496'),str(H/'enumerator')]
from central_replay import verify_movements,replay_final
from coverage import sweep
from deepbuild import build as build_pair
from strongbuild import build as build_strong
from prereqs import checked_sources, marks, SPEC

def batches(items,size):
    return [items[i:i+size] for i in range(0,len(items),size)]

def all_markings(pts,side,cert):
    """Independently enumerate every ordered pair of two-hole patterns in physical coordinates."""
    red=list(pts);blue=[(side-y,x) for x,y in pts];z=len(pts)
    transforms=[[],[]]
    for swap,h,v in itertools.product(range(2),repeat=3):
        def image(p):
            x,y=p[swap],p[1-swap]
            return side-x if h else x,side-y if v else y
        rt=[image(p) for p in red];bt=[image(p) for p in blue]
        if set(rt)==set(red) and set(bt)==set(blue):
            transforms[0].append(([red.index(p) for p in rt],[blue.index(p) for p in bt]))
        elif set(rt)==set(blue) and set(bt)==set(red):
            transforms[1].append(([blue.index(p) for p in rt],[red.index(p) for p in bt]))
        else:raise ValueError('A board isometry does not preserve this pair of mark patterns')
    assert list(map(len,transforms))==[4,4]
    holes=list(itertools.combinations(range(z),2))
    def mask(h):
        return (1<<z)-1-sum(1<<i for i in h)
    h_by_mask={mask(h):h for h in holes}
    singles={int(k) for k in cert['one_pattern']};assert singles<=set(h_by_mask)
    def act(h,g):return tuple(sorted(g[i] for i in h))
    closed=set()
    for m in singles:
        orb={act(h_by_mask[m],a) for a,b in transforms[0]}
        assert closed.isdisjoint(orb);closed|=orb
    jobs={tuple(map(int,k.split('_'))) for k in cert['pairs']}
    assert len(jobs)==len(cert['pairs'])
    seen=set()
    for a,b in jobs:
        assert a in h_by_mask and b in h_by_mask
        x=h_by_mask[a];y=h_by_mask[b]
        assert x not in closed and y not in closed
        orb={(act(x,g),act(y,h)) for g,h in transforms[0]}|{(act(y,h),act(x,g)) for g,h in transforms[1]}
        assert seen.isdisjoint(orb)
        seen|=orb
    expected={(a,b) for a in holes for b in holes if a not in closed and b not in closed}
    assert seen==expected and len(holes)==231
    return len(closed),len(holes)**2-len(seen),len(seen)

def require_mask(m,z,n):
    assert type(m)is int and 0<=m<1<<z and m.bit_count()==n
    return [i for i in range(z) if m>>i&1]

def independent_control(pts,u):
    red=pts;blue=[(u-y,x) for x,y in pts]
    centers=[(700000+i*1050000,730000+j*1050000) for i,j in itertools.product(range(4),repeat=2)]
    assert all(500000<=min(x,y) and max(x,y)+500000<=u for x,y in centers)
    for a,b in itertools.combinations(centers,2):assert max(abs(a[k]-b[k]) for k in range(2))>=1000000
    masks=[]
    for sites in (red,blue):
        own=[]
        for x,y in centers:
            d=[max(abs(x-a),abs(y-b)) for a,b in sites];assert min(d)<499995
            own.append(d.index(min(d)))
        assert len(set(own))==16
        masks.append(sum(1<<i for i in own))
    return tuple(masks)

def verify(cert,offline,d,workers):
    assert cert['n']==20
    s=cert['side_hundredths'];assert type(s)is int and 495<s<500
    side=F(s,100);u=s*10000
    spec=dict(SPEC,cap=str(side))
    pts=[(int(x*10**6),int(y*10**6)) for x,y in marks(spec)]
    assert all((F(a,10**6),F(b,10**6))==z for (a,b),z in zip(pts,marks(spec),strict=True))
    one_fixed,paired_by_one,ordered=all_markings(pts,u,cert)
    intervals=sweep(pts,u);assert intervals>0
    upstream=d/'upstream';upstream.mkdir();checked_sources(upstream,offline)
    os.chdir(upstream);sys.path.insert(0,str(upstream))
    import check_stabs,nearest_rack,rack_lattice_input
    from verify_arc_lower import build
    from verify_nearest_lower import certified_init
    for mod in (check_stabs,nearest_rack,rack_lattice_input):mod.marks=marks
    public=check_stabs if hasattr(check_stabs,'check_rack') else __import__('verify_rack_angle')
    cover=public.check_rack(spec)
    assert cover['status']=='STRICT_STABBING'
    native=d/'native';native.mkdir();build(native)
    build_pair(native/'r.cc',native/'pair')
    grouped=defaultdict(list);one=defaultdict(list);settings_by_grid=defaultdict(set)
    for m,v in cert['one_pattern'].items():
        b,args,mode,expected=v
        assert b in (32,48,64,96) and mode in (0,1) and len(args)==4
        ids=require_mask(int(m),22,20)
        one[b,mode].append((' '.join(map(str,[*args,20,*ids])),expected))
    use_strong=False; extra=[]
    for pair,job in cert['pairs'].items():
        a,c=map(int,pair.split('_'));require_mask(a,22,20);require_mask(c,22,20)
        if len(job)==3 and job[2]=='central-owners':
            b,r,_=job
            assert b==64 and r==60
            settings_by_grid[b,r].update((a,c));extra.append((a,c,b,r));use_strong=True
            continue
        b,r,mode,*pars,rc,ii=job
        assert b in (32,48,64,96,128) and 1<=r<=1000 and mode in ('pairs','deep','strong') and rc in range(1,7)
        assert ((mode=='pairs' and len(pars)==2) or (mode in ('deep','strong') and len(pars)==7))
        assert all(type(i)is int for i in pars) and type(ii)is int
        use_strong|=mode=='strong'
        settings_by_grid[b,r].update((a,c))
        grouped[b,r,mode,tuple(pars)].append((a,c,rc,ii))
    if use_strong:build_strong(native/'pair.cpp',native/'strong')
    grids=sorted(set(b for b,m in one)|set(b for b,r in settings_by_grid))
    for b in grids:
        certified_init(spec,b,d/f'i{b}')
    def dispatch(fn,args):
        with ThreadPoolExecutor(workers) as pool:return list(pool.map(fn,args))
    def single_job(work):
        b,mode,chunk=work
        out=subprocess.check_output([native/f'verify{mode}',d/f'i{b}'],input=''.join(row+'\n' for row,old in chunk),text=True).splitlines()
        for result,(row,expected) in zip(out,chunk,strict=True):
            assert result==expected and result.split()[0] in ('C','F') and result.split()[1] in ('1','2')
        return len(out)
    one_pass=sum(dispatch(single_job,[(b,mode,ch) for (b,mode),rows in one.items() for ch in batches(rows,2)]))
    print('One-pattern exclusions:',one_pass,'representatives,',one_fixed,'individual assignments.',flush=True)
    positive=independent_control(pts,u)
    control_key=min(settings_by_grid);settings_by_grid[control_key].update(positive)
    def prof(work):
        b,r,ch=work
        folder=d/f'profiles{b}-{r}'
        result=subprocess.check_output([native/'pair','profile',d/f'i{b}',str(r),folder],input=''.join(f'{m}\n' for m in ch),text=True).splitlines()
        for row,m in zip(result,ch,strict=True):assert int(row.split()[0])==m
    for b,r in settings_by_grid:(d/f'profiles{b}-{r}').mkdir()
    dispatch(prof,[(b,r,ch) for (b,r),ms in settings_by_grid.items() for ch in batches(sorted(ms),6)])
    def replay_batch(work):
        (b,r,mode,params),rows=work
        exe=native/('strong' if mode=='strong' else 'pair')
        ans=subprocess.check_output([exe,'deep' if mode=='strong' else mode,d/f'i{b}',d/f'profiles{b}-{r}',*map(str,params)],input=''.join(f'{a} {c}\n' for a,c,rc,ii in rows),text=True).splitlines()
        counts=Counter()
        for out,expected in zip(ans,rows,strict=True):
            actual=tuple(map(int,out.split()))
            assert tuple(expected)==actual and actual[2]>0,(expected,actual)
            counts[actual[2]]+=1
        return counts
    pairs=Counter()
    for result in dispatch(replay_batch,[(key,ch) for key,rows in grouped.items() for ch in batches(rows,12 if key[2]=='pairs' else 2)]):pairs+=result
    b,r=control_key;folder=d/f'profiles{b}-{r}'
    for exe in [native/'pair']+([native/'strong'] if use_strong else []):
        out=subprocess.check_output([exe,'deep',d/f'i{b}',folder,'2','12','3','80','0','2','144'],input='%d %d\n'%positive,text=True).strip().split()
        assert list(map(int,out[:3]))==[*positive,0]
    assert sum(pairs.values())+len(extra)==len(cert['pairs'])
    assert len(extra)==1
    import shutil
    ext=d/'terminal';ext.mkdir()
    for f in ['search.inc','slices.inc','build.py']:
        shutil.copy(H/'enumerator'/f,ext/f)
    shutil.copy(native/'strong.cpp',ext/'kernel.cpp')
    subprocess.run([sys.executable,ext/'build.py'],check=True)
    move_file=H/'enumerator'/f'marks{s}.txt'
    movement_verdict=verify_movements(move_file,pts,u,workers)
    joint=[]
    for a,c,b,r in extra:
        joint.append(replay_final(d,d/f'i{b}',d/f'profiles{b}-{r}',move_file,a,c,ext/'enumerate',workers))
    assert len(joint[0]['assignments'])==1
    assert joint[0]['assignments'][0]['ownership_levels']==[[1,0,4],[4,3,4],[4,4,0]]
    assert sum(sum(x['closed_by_reason'].values()) for v in joint for x in v['assignments'])==7
    return {'n':20,'strict_side':str(side),'full_angle_cover_intervals':intervals,'upstream_coverage':cover,
        'single_representatives':one_pass,'single_assignments':one_fixed,'ordered_pairs_total':231**2,
        'ordered_pairs_excluded_by_singles':paired_by_one,'ordered_pairs_excluded_by_joint_proof':ordered,
        'joint_symmetry_representatives':sum(pairs.values())+len(extra),'regular_joint_cases':sum(pairs.values()),'additional_coverings':movement_verdict,'special_case':joint,'joint_reasons':dict(pairs),'feasible_16_square_control':'survived'}
if __name__=='__main__':
    if not __debug__:raise ValueError('The replay requires Python assertions.')
    parser=argparse.ArgumentParser(__doc__);parser.add_argument('--offline',type=Path)
    parser.add_argument('--jobs',type=int,default=4);parser.add_argument('--certificate',type=Path,default=H/'certificate497.json')
    parser.add_argument('--receipt',type=Path)
    opt=parser.parse_args();assert 1<=opt.jobs<=64
    cert=json.loads(opt.certificate.read_text());local=opt.offline.resolve() if opt.offline else None
    receipt=opt.receipt.resolve() if opt.receipt else None
    with tempfile.TemporaryDirectory() as tmp:result=verify(cert,local,Path(tmp),opt.jobs)
    text=json.dumps(result,indent=2,sort_keys=True)+'\n';print(text,end='')
    if receipt:receipt.write_text(text)
