from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'separators.cpp').read_text();key='    int reason=0;\n    if(!propagate(x,data,owners,cycles,rounds,reason))';assert s.count(key)==1
s=s.replace(key,'''    if(const char* band=getenv("N20_BAND")){
        istringstream input(band);I p,q,a,b;input>>p>>q>>a>>b;
        if(!input||q<=0||b<=0||p<0||a<0||p*b>a*q||a>b||max(q,b)>1000000)throw runtime_error("mirror-band bounds");
        for(int k=0;k<x.B;k++){auto& row=x.rows[k];auto intersects=[&](I x,I y,I z,I w){return (I)(row.ki+1)*y>=x*row.gi && (I)row.ki*w<=z*row.gi;};
            if(!intersects(p,q,a,b)&&!intersects(b-a,b+a,q-p,q+p))for(int id:data.A)x.init[k][id].clear();
        }
    }
'''+key)
p=h/'mirror_band.cpp';p.write_text(s);o=h/'mirror_band.partial';subprocess.run(['g++','-O3','-std=c++17',p,'-o',o],check=True);o.replace(h/'mirror_band')
