struct AuxiliarySite {Point p;bool avoider=false;};
using Rack=vector<AuxiliarySite>;
vector<Rack> aux_racks;
void read_extra(I U){
    aux_racks.clear();
    const char* path=getenv("N20_EXTRA_RACKS");
    if(path && *path){
        ifstream in(path);int count;I u;in>>u>>count;
        if(!in||u!=U||count<0||count>100)throw runtime_error("auxiliary rack header");
        for(int i=0;i<count;i++){int n;in>>n;if(!in||n<20||n>60)throw runtime_error("auxiliary rack size");
           Rack r;for(int j=0;j<n;j++){Point p;in>>p.x>>p.y;if(!in||min(p.x,p.y)<0||max(p.x,p.y)>U)throw runtime_error("auxiliary point");r.push_back({p,false});}
           aux_racks.push_back(move(r));}
        string more;if(in>>more)throw runtime_error("trailing auxiliary input");
    }
    if(U%10)throw runtime_error("nonintegral auxiliary grid sites");
    Rack lattice;
    for(int i=1;i<=4;++i)for(int j=1;j<=4;++j)lattice.push_back({{i*(U/5),j*(U/5)},false});
    for(int i=0;i<5;++i)for(int j=0;j<5;++j){
        if((i==0||i==4)&&(j==0||j==4))continue;
        lattice.push_back({{(2*i+1)*(U/10),(2*j+1)*(U/10)},true});
    }
    aux_racks.insert(aux_racks.begin(),move(lattice));
}
bool rectangular_perfect(const vector<Mask>&graph,int sites,int skip=-1,int fixed=-1){
    vector<int> owner(sites,-1);
    for(int i=0;i<(int)graph.size();i++)if(i!=skip){
        Mask seen=fixed<0?0:(Mask(1)<<fixed);
        if(!aug(i,graph,owner,seen))return false;
    }
    return true;
}
I u_upper(const Row& row,I D){
    auto l=cs(row.ki,row.gi),r=cs(row.ki+1,row.gi);
    if(l.c>=l.s && r.c<=r.s)return 1414214;
    return max(-fl(-(W)D*(l.c+l.s),l.d),-fl(-(W)D*(r.c+r.s),r.d));
}
// An endpoint packing is normalized from a side strictly below 5. At any
// quantitative side S < 5 the same argument applies by spreading the centers
// by 5/S. Track each center back in the original chart; its possible capture
// square is smaller by the factor S/5. The 21 open lattice holes are bounded
// using their exact rotated width cos(theta)+sin(theta)-1.
P resource_domain(P p,const Row& row,const AuxiliarySite& site,bool grid,I U,I D){
    I u=site.avoider ? u_upper(row,D)-D : D;
    for(auto f:row.axes){
        W offset=f.k;
        if(grid)offset=-fl(-offset*u*U,(W)5*D*D);
        f.k=(I)offset+dot(f,site.p);
        if(p.empty()||mn(p,f)>f.k)return {};
        if(mx(p,f)>f.k)p=cut(p,f);
    }
    return p;
}
bool apply_resource(Engine& e,const vector<int>& ids,const Rack& rack,bool grid){
    int n=ids.size(),m=rack.size();vector<Mask> graph(n);
    vector<vector<vector<P>>> opts(n,vector<vector<P>>(m));
    vector<vector<P>> shapes(n,vector<P>(m));
    for(int i=0;i<n;i++){
        int id=ids[i];
        for(int j=0;j<m;j++){
            P req=convex_union(e.seed[id],{rack[j].p});
            bool forbidden=false;
            for(int q:ids)if(q!=id&&intersect_closed(req,e.seed[q])){forbidden=true;break;}
            if(forbidden)continue;
            vector<P> bins(e.B);vector<HP> common;
            for(int k=0;k<e.B;k++)if(!e.init[k][id].empty()){
                P p=resource_domain(e.init[k][id],e.rows[k],rack[j],grid,e.U,e.D);
                if(p.empty())continue;
                for(auto f:e.rows[k].fac){f.k+=mn(p,f);common.push_back(f);}
                bins[k]=move(p);
            }
            if(common.empty())continue;
            req=convex_union(req,safe(common,e.U));
            for(int q:ids)if(q!=id&&intersect_closed(req,e.seed[q])){forbidden=true;break;}
            if(forbidden)continue;
            graph[i]|=Mask(1)<<j;opts[i][j]=move(bins);shapes[i][j]=move(req);
        }
        if(!graph[i])return false;
    }
    if(!rectangular_perfect(graph,m))return false;
    for(int i=0;i<n;i++){
        vector<P> merged(e.B);vector<const P*> hulls;auto links=graph[i];
        while(links){
            int j=__builtin_ctzll(links);links&=links-1;
            if(!rectangular_perfect(graph,m,i,j))continue;
            hulls.push_back(&shapes[i][j]);
            for(int k=0;k<e.B;k++)merge_vertices(merged[k],opts[i][j][k]);
        }
        if(hulls.empty())return false;
        guaranteed_intersection(e.seed[ids[i]],hulls,e.U);
        for(int k=0;k<e.B;k++)e.init[k][ids[i]]=hull(move(merged[k]));
    }
    return true;
}
bool apply_resources(Engine& e,const vector<int>& ids){
    for(size_t i=0;i<aux_racks.size();i++)if(!apply_resource(e,ids,aux_racks[i],i==0))return false;
    return true;
}
