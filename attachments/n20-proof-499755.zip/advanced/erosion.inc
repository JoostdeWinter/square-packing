// A conditional tile has a center in P and a guaranteed centered body B.
// Every placement overlaps an inner probe A if the probe center lies in the
// interior of the intersection over p in P of p + (B - A). Its halfplanes
// have support h_(B-A)(n) + min_(p in P) n.p. Both this polygon and the
// translated mandatory-point polygon belong to the same physical obstacle.
struct RFamily{P center,body,mandatory;vector<HP> edges;};
P rigid_obstacle(const P& reversed,const vector<HP>& edges,const RFamily& q,I U){
    auto z=add(reversed,edges,q.body,q.edges);for(auto& n:z.p)n.k+=mn(q.center,n);
    P r=safe(z.p,U);
    return convex_union(move(r),mink(q.mandatory,reversed,false));
}
bool rigid_erosion(Engine& e,const Choices& c,const vector<int>& owners,int angles,int div){
    vector<vector<RFamily>> all(e.Z);
    for(int id:c.A){
        for(auto& p:families(e,id,angles,div)){
            auto fs=facets(p.body);if(fs.empty())throw runtime_error("empty conditional body");
            all[id].push_back({move(p.center),move(p.body),move(p.mandatory),move(fs)});
        }
        if(all[id].empty())return false;
    }
    for(int k=0;k<e.B;k++){
        vector<int> ids;for(int id:c.A)if(!e.init[k][id].empty())ids.push_back(id);if(ids.empty())continue;
        P neg;for(auto z:e.rows[k].core)neg.push_back({-z.x,-z.y});neg=hull(move(neg));auto fs=facets(neg);
        vector<UObstacle> obs(e.Z);
        for(int id:c.A){
            vector<HP> planes;
            for(const auto& q:all[id]){
                auto r=rigid_obstacle(neg,fs,q,e.U);auto g=facets(r);
                if(g.empty()){planes.clear();break;}
                planes.insert(planes.end(),g.begin(),g.end());
            }
            P r=mink(e.seed[id],neg,false);
            if(!planes.empty())r=convex_union(move(r),safe(planes,e.U));
            if(r.size()>=3)obs[id]={r,facets(r),bbox(r)};
        }
        for(int i=0;i<N;i++){
            int id=c.A[i];auto& p=e.init[k][id];if(p.empty())continue;auto bb=bbox(p);vector<UObstacle> bans;
            for(int j:c.A)if(j!=id&&!obs[j].vertices.empty()&&bmatch(bb,obs[j].box))bans.push_back(obs[j]);
            for(int s=0;s<4;s++)if(owners[s]!=-2&&owners[s]!=i){
                auto& rack=s>=2?c.blue:c.red;Point pt=rack.mark[c.hole[s/2][s%2]];
                append_uob(bans,mink({pt},neg,false));
            }
            p=union_complement(p,bans);
        }
    }
    for(int id:c.A)if(none_of(e.init.begin(),e.init.end(),[&](const vector<P>& p){return !p[id].empty();}))return false;
    return true;
}
