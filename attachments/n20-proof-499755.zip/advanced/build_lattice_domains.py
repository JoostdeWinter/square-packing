from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'separators.cpp').read_text();key='string sym(int axis,int i)';assert s.count(key)==1;s=s.replace(key,(h/'lattice_domains.inc').read_text()+'\n'+key)
key='if(mode=="sep"){';assert s.count(key)==1
s=s.replace(key,'''if(mode=="lattice"){
        int f=stoi(getenv("N20_FINE"));if(f>1)fine(x,data.A,f,base.B*f);
        LSearch st(x,stoi(getenv("N20_UNION_PASSES")),stoi(getenv("N20_FRAME_SUB")),stoi(getenv("N20_LATTICE_DEPTH")),stoi(getenv("N20_LATTICE_BUDGET")));
        array<Sites,N> opts;opts.fill((Sites(1)<<37)-1);bool closed=st.search(x,data,owners,opts,0);
        cout<<(closed?"CLOSED_LATTICE ":"OPEN_LATTICE ")<<st.nodes<<" "<<st.checks<<" "<<st.pruned<<endl;return 0;
    }
    '''+key)
p=h/'lattice_domains.cpp';p.write_text(s);t=h/'lattice_domains.partial';subprocess.run(['g++','-O3','-std=c++17',p,'-o',t],check=True);t.replace(h/'lattice_domains')
