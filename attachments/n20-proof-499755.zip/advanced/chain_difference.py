"""A difference-logic enclosure of shared tile angles and all pair separations."""
from dataclasses import dataclass
from fractions import Fraction as F
from functools import lru_cache
from itertools import product,combinations
from math import floor,ceil
from collections import Counter
from pathlib import Path
import sys,argparse
D=10**6;W=10**6
def smt(a):return str(a) if a>=0 else '(- '+str(-a)+')'
def combine(op,items):
 unit='true' if op=='and' else 'false';other='false' if op=='and' else 'true';q=list(dict.fromkeys(items))
 if other in q:return other
 q=[x for x in q if x!=unit]
 return unit if not q else q[0] if len(q)==1 else '('+op+' '+' '.join(q)+')'
def imp(a,b):return 'true' if b=='true' or a=='false' else b if a=='true' else '(=> '+a+' '+b+')'
@lru_cache(maxsize=None)
def cs(t):
 return (1-t*t)/(1+t*t),2*t/(1+t*t)
@lru_cache(maxsize=None)
def sepwidth(low,high,l,h):
 if max(low,l)<=min(high,h):return D
 v=[]
 for a,b in product((low,high),(l,h)):
  c,s=cs(a);C,S=cs(b);v.append(c*C+s*S+abs(c*S-s*C))
 return floor(F(D,2)*(1+min(v)))
@lru_cache(maxsize=None)
def modes(lo,hi):
 c,s=cs(lo);C,S=cs(hi);cs0,ss0=cs((lo+hi)/2);A=(floor(W*C),ceil(W*c));B=(floor(W*s),ceil(W*S));ans=[]
 for rotation in range(4):
  if rotation==0:x,y,xc,yc=A,B,cs0,ss0
  elif rotation==1:x,y,xc,yc=(-B[1],-B[0]),A,-ss0,cs0
  elif rotation==2:x,y,xc,yc=(-A[1],-A[0]),(-B[1],-B[0]),-cs0,-ss0
  else:x,y,xc,yc=B,(-A[1],-A[0]),ss0,-cs0
  dim=0 if abs(xc)>=abs(yc) else 1;primary,perp=(x,y) if not dim else (y,x)
  phys=(xc,yc)[dim];sgn=1 if phys>=0 else -1
  if sgn<0:primary=-primary[1],-primary[0]
  assert primary[0]>0
  ans.append((dim,sgn,primary,perp))
 return ans
@dataclass
class Pose:
 lo:F
 hi:F
 bb:tuple
 poly:list
 gate:str
def load_domains(source,groups):
 sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'global'))
 from scale_coupled import load_state,hull
 st=load_state(source);poses=[]
 for i,(_,rows) in enumerate(st):
  seg={}
  for k,p in enumerate(rows):
   if p:seg.setdefault(k*groups//64,[]).append((k,p))
  opts=[]
  for j,els in seg.items():
   p=hull(v for _,q in els for v in q);bounds=tuple((min(z[a] for z in p),max(z[a] for z in p)) for a in (0,1))
   opts.append(Pose(F(els[0][0],64),F(els[-1][0]+1,64),bounds,p,'true' if len(seg)==1 else f'g{i}_{j}'))
  assert opts;poses.append(opts)
 return poses
def diff(i,j,dim,sgn=1):
 if sgn<0:i,j=j,i
 a='xy'[dim];return f'(- {a}{j} {a}{i})'
def rel(v,op,n):return '('+op+' '+v+' '+smt(n)+')'
def inner(i,j,a,b,mode,H,bins):
 dim,sgn,(l,h),(u,v)=mode;k=1-dim
 dx=(b.bb[dim][0]-a.bb[dim][1],b.bb[dim][1]-a.bb[dim][0]);dx=dx if sgn>0 else (-dx[1],-dx[0])
 y0,y1=b.bb[k][0]-a.bb[k][1],b.bb[k][1]-a.bb[k][0]
 xname=diff(i,j,dim,sgn);yname=diff(i,j,k)
 def threshold(y,z):
  n=H*W-max(u*y,u*z,v*y,v*z)
  return n//(h if n>=0 else l)
 base=threshold(y0,y1)
 if base>dx[1]:return 'false'
 def barrier(y,z):
  n=threshold(y,z)
  return 'false' if n>dx[1] else 'true' if n<=dx[0] else rel(xname,'>=',n)
 rows=[barrier(y0,y1)]
 for t in sorted({y0+(y1-y0)*j//bins for j in range(1,bins)}|{0}):
  if not y0<t<y1:continue
  for left,end,op in [(y0,t,'<='),(t,y1,'>=')]:
   if threshold(left,end)==base:continue
   rows.append(imp(rel(yname,op,t),barrier(left,end)))
 return combine('and',rows)
def generate(path,groups,steps):
 from scale_coupled import cut
 poses=load_domains(path,groups);U=int(path.open().readline().split()[2]);S=['(set-logic QF_RDL)'];stat=Counter()
 def emit(x):
  if x!='true':S.append('(assert '+x+')')
 for i,opts in enumerate(poses):
  x=f'x{i}';y=f'y{i}';S.extend([f'(declare-const {x} Real)',f'(declare-const {y} Real)'])
  for p in opts:
   if p.gate!='true':S.append('(declare-const '+p.gate+' Bool)')
   lt=[]
   for n,(lo,hi) in zip((x,y),p.bb):lt.extend([rel(n,'>=',lo),rel(n,'<=',hi)])
   for dim in range(2):
    a,b=(1,0) if dim==0 else (0,1);V,other=(x,y) if dim==0 else (y,x);L,H=p.bb[dim]
    for z in range(1,4):
     t=L+(H-L)*z//4
     for aa,bb,c,op in [(a,b,t,'<='),(-a,-b,-t,'>=')]:
      q=cut(p.poly,aa,bb,c)
      if q:
       low=min(w[1-dim] for w in q);high=max(w[1-dim] for w in q)
       cond=combine('and',[rel(other,'>=',low) if low>p.bb[1-dim][0] else 'true',rel(other,'<=',high) if high<p.bb[1-dim][1] else 'true'])
       lt.append(imp(rel(V,op,t),cond))
   emit(imp(p.gate,combine('and',lt)));stat['angle_groups']+=1
  emit(combine('or',[p.gate for p in opts]))
  for a,b in combinations(opts,2):emit('(not (and '+a.gate+' '+b.gate+'))')
 for i,j in combinations(range(20),2):
  for a,b in product(poses[i],poses[j]):
   if any(max(a.bb[k][0]-b.bb[k][1],b.bb[k][0]-a.bb[k][1])>1414214 for k in range(2)):continue
   H=sepwidth(a.lo,a.hi,b.lo,b.hi);opts=[]
   for mode in dict.fromkeys(modes(a.lo,a.hi)+modes(b.lo,b.hi)):
    z=inner(i,j,a,b,mode,H,steps);opts.append(z)
    if z=='true':break
   rhs=combine('or',opts)
   if rhs=='true':continue
   stat['blocked_group_pairs' if rhs=='false' else 'geometric_clauses']+=1;emit(imp(combine('and',[a.gate,b.gate]),rhs))
 S.append('(check-sat)');src='\n'.join(S)+'\n';stat['bytes']=len(src);return src,dict(stat)
if __name__=='__main__':
 import json,time
 sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'global'))
 from z3_lra import run
 p=argparse.ArgumentParser();p.add_argument('state',type=Path);p.add_argument('--groups',type=int,default=12);p.add_argument('--steps',type=int,default=3);p.add_argument('--seconds',type=int,default=90);p.add_argument('--save',type=Path);v=p.parse_args();s,stats=generate(v.state,v.groups,v.steps);print('compiled',stats,flush=True)
 if v.save:v.save.write_text(s)
 t=time.monotonic();r=run(s,v.seconds*1000)[0];print('result',r,stats,int(time.monotonic()-t),flush=True)
