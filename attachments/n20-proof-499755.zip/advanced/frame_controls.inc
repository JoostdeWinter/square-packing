struct ControlPose {Point p;Dir a;};
bool good_poses(const Engine& e,const vector<int>& ids,const vector<ControlPose>& m){
    for(int i:ids){auto p=m[i].p;auto a=m[i].a;bool covered=false;
        for(auto v:e.seed[i]){
            W x=v.x-p.x,y=v.y-p.y;W u=x*a.c+y*a.s,b=-x*a.s+y*a.c;
            if(2*max(u<0?-u:u,b<0?-b:b)>(W)e.D*a.d){cerr<<"bad control seed "<<i<<endl;return false;}}
        for(int k=0;k<e.B;k++){auto r=e.rows[k];W q=(W)a.s*r.gi;
            if(q>=(W)r.ki*(a.c+a.d)&&q<=(W)(r.ki+1)*(a.c+a.d)&&inside_closed(p,e.init[k][i]))covered=true;}
        if(!covered){cerr<<"lost control pose "<<i<<endl;return false;}
    }return true;
}
int main(int argc,char** argv){try{
 if(argc>1&&string(argv[1])=="union"){
    int n;cin>>n;for(int trial=0;trial<n;trial++){
        auto polygon=[](){int nn;cin>>nn;P p(nn);for(auto& a:p)cin>>a.x>>a.y;return hull(move(p));};
        P original=polygon();int z;cin>>z;vector<UObstacle> obs;for(int i=0;i<z;i++)append_uob(obs,polygon());
        P out=union_complement(original,obs);cout<<out.size();for(auto v:out)cout<<" "<<v.x<<" "<<v.y;cout<<"\n";
    }return 0;
 }
 if(argc!=3)throw runtime_error("table and temporary movement path");
 for(int style=0;style<5;style++)for(int fun:{1,2}){
    string path=argv[1];if(style>2&&fun==2){auto a=path.rfind("i32");if(a==string::npos)throw runtime_error("i32 control table");path.replace(a,3,"i64");}
    Engine e(path);I pitch=style==0?1000000:style==1?1005000:style==2?1150000:1470000;
    I off=style==0?500000:style==1?510000:style==2?600000:750000;
    e.U=style==0?5000000:style==1?5040000:style==2?5800000:7500000;e.Z=N;
    vector<int> ids(N);iota(ids.begin(),ids.end(),0);e.seed.assign(N,P{});e.init.assign(e.B,vector<P>(N));
    vector<ControlPose> m;vector<Point> points;
    for(int i:ids){
        Point p{off+(i%5)*pitch,off+(i/5)*pitch};
        I z=style<=1?0:style==2?(i*11)%15:(i*29)%251;auto a=cs(z,256);
        if(style>1&&(i+style)%2){I r=a.c;a.c=a.s;a.s=r;}
        if(style==4){p.x+=(i%3-1)*6000;p.y+=(i%5-2)*3000;}
        I rad=-fl(-(W)e.D*(a.c+a.s),2*a.d);if(min({p.x,p.y,e.U-p.x,e.U-p.y})<rad)throw runtime_error("bad wall control");
        m.push_back({p,a});points.push_back(p);p.x+=20000;e.seed[i].push_back(p);p.x-=40000;e.seed[i].push_back(p);p.x+=20000;p.y+=20000;e.seed[i].push_back(p);p.y-=40000;e.seed[i].push_back(p);e.seed[i]=hull(move(e.seed[i]));
        int nearest=(int)((W)a.s*e.B/(a.c+a.d));for(int k=0;k<e.B;k++){
            if(abs(k-nearest)>2 && abs(k-(e.B-nearest-1))>1)continue;
            Point c=m.back().p;I wx=123000+(i%4)*11000,wy=101000+(i%3)*8000;
            e.init[k][i]={{c.x-wx,c.y-wy},{c.x+wx,c.y-wy},{c.x+wx,c.y+wy},{c.x-wx,c.y+wy}};
        }
    }
    for(int i:ids)for(int j:ids)if(i<j){
        auto a=m[i].a,b=m[j].a;I x=m[j].p.x-m[i].p.x,y=m[j].p.y-m[i].p.y;
        W dot=(W)a.c*b.c+(W)a.s*b.s,cross=(W)a.s*b.c-(W)a.c*b.s;if(cross<0)cross=-cross;
        W demand=(W)e.D*((W)a.d*b.d+dot+cross);
        auto support=[&](Dir u){W X=(W)u.c*x+(W)u.s*y,Y=-(W)u.s*x+(W)u.c*y;return max(X<0?-X:X,Y<0?-Y:Y);};
        if(2*max(support(a)*b.d,support(b)*a.d)<demand)throw runtime_error("overlap control");
    }
    {ofstream out(argv[2]);out<<22<<" "<<e.U<<"\n";for(auto p:points)out<<p.x<<" "<<p.y<<" 0\n";out<<"0 0 0\n"<<e.U<<" "<<e.U<<" 0\n";}
    Movement mk(argv[2],e.U);Choices data(mk,mk,ids,ids,e.U);vector<int> own(4,-1);
    if(style<=2&&fun>1&&!fine(e,ids,fun,e.B*fun))throw runtime_error("invalid control refinement");
    if(!good_poses(e,ids,m)||!union_prune(e,data,own,false)||!good_poses(e,ids,m))throw runtime_error("union positive control");
    if(!local_frame(e,data,own,5)||!good_poses(e,ids,m))throw runtime_error("frame positive control");
    SPre pre(e.rows);SRules rules{};SChoose choice;
    if(!angular_separators(e,ids,pre,rules,choice)||!good_poses(e,ids,m))throw runtime_error("separating normal control");
    cout<<style<<" "<<fun<<" "<<N<<" preserved"<<endl;
 }
 }catch(exception& e){cerr<<e.what()<<endl;return 2;}}
