"""Disaggregated two-tile relaxation and exact integer dual verification.

Every variable is in [0,1]. Coordinates are normalized by U. A negative
right side after adding nonnegative inequalities and signed equalities,
compared with the minimum of the left side on the known box, is conclusive.
"""
from collections import defaultdict
from pathlib import Path
from itertools import combinations
import argparse,hashlib,json,math,time
from fractions import Fraction
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix,hstack,csr_matrix

def faces(it):
 return [tuple(next(it) for k in range(3)) for _ in range(next(it))]

class Lift:
 def __init__(self,path):
  self.path=path;self.digest=hashlib.sha256(path.read_bytes()).hexdigest();self.eq=[];self.le=[];self.n=0;self.gates=[]
  with path.open() as f:
   header,u,n,lines=f.readline().split();assert header=='LIFT1' and int(n)==20
   self.U=int(u);self.lanes=int(lines);self.tiles=[];self.geo=[];chords=defaultdict(list)
   for i in range(20):
    tag,tile,num=f.readline().split();assert tag=='T' and int(tile)==i
    boxes=[];opts=[]
    for g in range(int(num)):
     tag,who,which,rs=f.readline().split(maxsplit=3);assert tag=='G' and (int(who),int(which))==(i,g)
     v=self.variables(3);opts.append(v);it=iter(map(int,rs.split()));rows=faces(it);assert next(it,None) is None
     boxes.append(rows);self.polygon(v,rows)
     tag,*coeff=f.readline().split();assert tag=='C' and len(coeff)==2*(self.lanes-1)
     for k,a in enumerate(map(int,coeff)):
      if a:chords[k].append((v[0],a))
    self.tiles.append(opts);self.geo.append(boxes);self.choose([v[0] for v in opts])
   for terms in chords.values():
    if sum(a for _,a in terms)>self.U:self.le.append((terms,self.U))
   self.pairs=0;self.sectors=0
   for row in f:
    if row.strip()=='END':break
    tag,i,j,num=row.split();i,j,num=map(int,(i,j,num));assert tag=='B' and i<j and num==len(self.tiles[i])*len(self.tiles[j])
    self.pairs+=1;slices=[[[] for _ in self.tiles[i]],[[] for _ in self.tiles[j]]];gates=[]
    for a in range(len(self.tiles[i])):
     for b in range(len(self.tiles[j])):
      tag,*data=f.readline().split();it=iter(map(int,data));assert tag=='A' and (next(it),next(it))==(a,b)
      for _ in range(next(it)):
       ds=faces(it);v=self.variables(5);w,x,y,X,Y=v;gates.append(w);self.sectors+=1
       self.polygon((w,x,y),self.geo[i][a]);self.polygon((w,X,Y),self.geo[j][b])
       for p,q,c in ds:self.le.append(([(X,p*self.U),(Y,q*self.U),(x,-p*self.U),(y,-q*self.U),(w,-c)],0))
       slices[0][a].append((w,x,y));slices[1][b].append((w,X,Y))
      assert next(it,None) is None
    for side,t in enumerate((i,j)):
     for g,sg in enumerate(slices[side]):
      for k in range(3):self.eq.append(([(self.tiles[t][g][k],-1)]+[(v[k],1) for v in sg],0))
    self.gates.append(gates)
  self.A,self.b,self.ascl=self.matrix(self.le)
  self.E,self.d,self.escl=self.matrix(self.eq)
 def variables(self,n):
  i=self.n;self.n+=n;return tuple(range(i,self.n))
 def choose(self,ids):
  self.gates.append(ids);self.eq.append(([(i,1) for i in ids],1))
 def polygon(self,vs,fs):
  w,x,y=vs
  for a,b,k in fs:self.le.append(([(x,a*self.U),(y,b*self.U),(w,-k)],0))
 def matrix(self,rows):
  i=[];j=[];data=[];rhs=[];norms=[]
  for idx,(terms,b) in enumerate(rows):
   scale=max([1,abs(b)]+[abs(v) for k,v in terms]);norms.append(scale);rhs.append(b/scale)
   for k,v in terms:
    if v:i.append(idx);j.append(k);data.append(v/scale)
  return coo_matrix((data,(i,j)),shape=(len(rows),self.n)).tocsr(),np.array(rhs),norms
 def certify(self,z,excluded):
  for quant in (10**15,10**22,10**32):
   coeff=[0]*self.n;rhs=0;witness=[]
   for name,values,norms,rows in [('le',z.ineqlin.marginals,self.ascl,self.le),('eq',z.eqlin.marginals,self.escl,self.eq)]:
    weights=[]
    for i,x in enumerate(values):
     if abs(x)<1e-13 or (name=='le' and x>0):continue
     w=round(Fraction.from_float(-float(x))*quant/norms[i])
     if w==0:continue
     assert w>=0 or name=='eq';weights.append([i,w]);terms,b=rows[i];rhs+=w*b
     for k,v in terms:coeff[k]+=w*v
    witness.append(weights)
   floor=sum(min(0,v) for k,v in enumerate(coeff) if k not in excluded)
   if floor>rhs:
    ans={'le':witness[0],'eq':witness[1],'margin':str(floor-rhs)};assert self.audit(ans,excluded)
    return ans
  return None
 def audit(self,cert,excluded):
  c=[0]*self.n;right=0
  for category,rows in [('le',self.le),('eq',self.eq)]:
   for k,v in cert[category]:
    if type(k)!=int or type(v)!=int or not 0<=k<len(rows) or category=='le' and v<0:return False
    terms,b=rows[k];right+=v*b
    for j,a in terms:c[j]+=v*a
  gap=sum(min(0,x) for i,x in enumerate(c) if i not in excluded)-right
  return gap>0 and str(gap)==cert['margin']
 def explore(self,nodes=20,seconds=100):
  total_time=time.monotonic();stats={'nodes':0,'certified_infeasible':0,'feasible_relaxations':0};eps=np.ones(len(self.le))
  Aphase=hstack([self.A,-csr_matrix(eps[:,None])],format='csr');Ephase=hstack([self.E,csr_matrix((len(self.eq),1))],format='csr')
  def visit(excluded):
   if stats['nodes']>=nodes or time.monotonic()-total_time>seconds:return {'status':'budget'}
   stats['nodes']+=1;box=np.empty((self.n,2));box[:,0]=0;box[:,1]=1
   if excluded:box[list(excluded),1]=0
   opts={'time_limit':max(1,min(30,seconds-(time.monotonic()-total_time))),'primal_feasibility_tolerance':1e-8,'dual_feasibility_tolerance':1e-8}
   z=linprog(np.zeros(self.n),A_ub=self.A,b_ub=self.b,A_eq=self.E,b_eq=self.d,bounds=box,method='highs',options=opts)
   if z.status==2:
    v=linprog(np.r_[np.zeros(self.n),1.],A_ub=Aphase,b_ub=self.b,A_eq=Ephase,b_eq=self.d,bounds=np.vstack([box,[0,1e6]]),method='highs',options=opts)
    if v.success:
     proof=self.certify(v,excluded)
     if proof:
      stats['certified_infeasible']+=1;return {'status':'closed','dual':proof}
    # Equalities might already be infeasible under the selected zero gates.
    return {'status':'uncertified','optimizer':v.message}
   if not z.success:return {'status':'timeout','optimizer':z.message}
   stats['feasible_relaxations']+=1;x=z.x;best=None
   for idx,ids in enumerate(self.gates):
    vs=[k for k in ids if k not in excluded]
    if len(vs)<2:continue
    xs=sorted(vs,key=lambda k:-x[k]);s=0;left=[]
    for k in xs:
     if s<.5:left.append(k);s+=x[k]
    if min(s,1-s)<1e-6:continue
    score=min(s,1-s)+.055*(idx<20)-.003*math.log1p(len(vs))
    if best is None or score>best[0]:best=score,idx,left,[k for k in vs if k not in left]
   if best is None:return {'status':'integral_relaxation'}
   _,idx,a,b=best;left=visit(excluded|set(a))
   if left['status']!='closed':return {'status':'open','gate':idx,'zeros':a,'child':left}
   right=visit(excluded|set(b))
   if right['status']!='closed':return {'status':'open','gate':idx,'zeros':b,'child':right,'closed_sibling':True}
   return {'status':'closed','gate':idx,'partition':[a,b],'children':[left,right]}
  answer=visit(set());result={'model_sha256':self.digest,'variables':self.n,'inequalities':len(self.le),'equalities':len(self.eq),'neighbor_pairs':self.pairs,'sectors':self.sectors,'elapsed':round(time.monotonic()-total_time,2),'statistics':stats,'tree':answer}
  if answer['status']=='closed':assert self.verify_tree(answer,set())
  return result
 def verify_tree(self,tree,excluded):
  if tree.get('status')!='closed':return False
  if 'dual' in tree:return self.audit(tree['dual'],excluded)
  a,b=map(set,tree['partition']);ids=set(self.gates[tree['gate']])-excluded
  if a&b or a|b!=ids or not a or not b:return False
  return all(self.verify_tree(t,excluded|s) for t,s in zip(tree['children'],(a,b),strict=True))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('model',type=Path);p.add_argument('--nodes',type=int,default=24);p.add_argument('--seconds',type=int,default=100);p.add_argument('--receipt',type=Path);a=p.parse_args();m=Lift(a.model);v=m.explore(a.nodes,a.seconds)
 if a.receipt:a.receipt.write_text(json.dumps(v,separators=(',',':')))
 print({k:z for k,z in v.items() if k!='tree'},v['tree']['status'])
