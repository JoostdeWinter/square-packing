from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'poses.cpp').read_text();key='string sym(int axis,int i)';assert s.count(key)==1;s=s.replace(key,(h/'third.inc').read_text()+'\n'+key)
key='if(mode=="families"){';assert s.count(key)==1;s=s.replace(key,'''if(mode=="third"){
        int f=stoi(getenv("N20_FINE"));if(f>1)fine(x,data.A,f,base.B*f);
        RBudget bgt;bgt.limit=stoi(getenv("N20_THIRD_LIMIT"));bgt.depth=stoi(getenv("N20_THIRD_DEPTH"));bgt.passes=stoi(getenv("N20_THIRD_PASSES"));
        istringstream list(getenv("N20_THIRD_RACKS"));int id;char ch;
        while(list>>id){if(id<0||id>=(int)aux_racks.size())throw runtime_error("third rack index");bgt.selected.push_back(id);list>>ch;}
        if(bgt.selected.empty())throw runtime_error("no third rack");
        vector<vector<int>> forced(aux_racks.size(),vector<int>(N,-1));
        bool status=third_tree(move(x),data,owners,move(forced),0,bgt);
        cout<<(status?"CLOSED_THIRD":"OPEN_THIRD")<<" "<<bgt.nodes<<" "<<bgt.tests<<endl;return 0;
    }
    '''+key)
p=h/'third.cpp';p.write_text(s);tmp=h/'third.partial';subprocess.run(['g++','-std=c++17','-O3',p,'-o',tmp],check=True);tmp.replace(h/'third')
