"""Export the surviving center polygons and their exact rational orientation arcs."""
from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent
s=(h/'frame.cpp').read_text();entry='if(mode=="frame"){';assert s.count(entry)==1
mode=r'''if(mode=="shared"){
        int f=stoi(getenv("N20_FINE"));if(f>1)fine(x,data.A,f,base.B*f);
        int rounds=stoi(getenv("N20_UNION_PASSES")),sub=stoi(getenv("N20_FRAME_SUB"));
        if(sub<1||sub*x.rows[0].gi>4096)throw runtime_error("frame subdivision");
        for(int pass=0;pass<rounds;pass++){
            if(!local_frame(x,data,owners,sub)||!cluster_filter(x,data.A)||!propagate(x,data,owners,1,12,reason)){
                cout<<"CLOSED_SHARED"<<endl;return 0;
            }
        }
        int lanes=stoi(getenv("N20_SMT_GROUPS"));if(lanes<8||lanes>128)throw runtime_error("angular strip count");
        ofstream dst(argv[11]);if(!dst||argc<12)throw runtime_error("missing shared angle output");
        dst<<x.U<<" "<<x.D<<" "<<lanes<<" "<<data.A.size()<<"\n";
        auto printpoly=[&](const P& p){dst<<p.size();for(auto v:p)dst<<" "<<v.x<<" "<<v.y;dst<<"\n";};
        for(int id:data.A){
            printpoly(x.seed[id]);
            vector<P> ps(lanes);vector<int> lo(lanes,1000000),hi(lanes,-1);int grid=x.rows[0].gi;
            for(int k=0;k<x.B;k++){
                const Row& r=x.rows[k];if(r.gi!=grid)throw runtime_error("inconsistent angular grid");
                if(x.init[k][id].empty())continue;
                int group=min(lanes-1,r.ki*lanes/r.gi);lo[group]=min(lo[group],r.ki);hi[group]=max(hi[group],r.ki+1);
                merge_vertices(ps[group],x.init[k][id]);
            }
            int count=0;for(auto& p:ps)if(!p.empty())++count;
            if(!count){cout<<"CLOSED_SHARED"<<endl;return 0;}dst<<count<<"\n";
            for(int j=0;j<lanes;j++)if(!ps[j].empty()){dst<<lo[j]<<" "<<hi[j]<<" "<<grid<<" ";printpoly(hull(move(ps[j])));}
        }
        cout<<"EXPORTED_SHARED"<<endl;return 0;
    }
    '''
s=s.replace(entry,mode+entry)
tmp=h/'shared_angles.partial';p=h/'shared_angles.cpp';p.write_text(s);subprocess.run(['g++','-O0','-g0','--param=ggc-min-expand=3','--param=ggc-min-heapsize=4096','-std=c++17',p,'-o',tmp],check=True);tmp.replace(h/'shared_angles')
