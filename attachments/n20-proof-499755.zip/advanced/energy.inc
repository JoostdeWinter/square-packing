// Integrate the depth bound on long-chord center intervals over all tested
// windows. An interval of radius r and a center in [l,h] has overlap at
// least max(0,min(width,2r,l+r-a,b-h+r)) with the window [a,b].
struct EnergyShape{I least=INT64_MAX,early=INT64_MAX,late=INT64_MIN;};
I mandatory_length(const EnergyShape& z,I a,I b){
    if(z.least<=0)return 0;
    return max((I)0,min({b-a,z.least,z.early-a,b-z.late}));
}
struct EnergyCut {I lo,hi;};
bool apply_energy(Engine& e,const vector<int>& ids,int cap,bool trim){
    I length=(e.U+cap)/(cap+1);
    if(e.U<5000000&&length*(cap+1)<=e.U)length++;
    vector<I> radius(e.B);
    for(int k=0;k<e.B;k++){
        auto z=chord_constants(e.rows[k],e.D);
        radius[k]=z.plateau<length?0:max((I)0,z.height+fl(-(W)length*z.product,e.D)-1);
    }
    for(int ax=0;ax<2;ax++){
        vector<EnergyShape> s(N);vector<vector<Bound>> boxes(N,vector<Bound>(e.B));vector<I> at={0,e.U};
        for(int i=0;i<N;i++){
            for(int k=0;k<e.B;k++)if(!e.init[k][ids[i]].empty()){
                auto b=bbox(e.init[k][ids[i]]);boxes[i][k]=b;
                I l=ax?b.b:b.l,h=ax?b.t:b.r,r=radius[k];
                s[i].least=min(s[i].least,2*r);s[i].early=min(s[i].early,l+r);s[i].late=max(s[i].late,h-r);
            }
            if(s[i].least==INT64_MAX)return false;
            for(I p:{s[i].early,s[i].late,s[i].early-s[i].least,s[i].late+s[i].least})if(p>0&&p<e.U)at.push_back(p);
        }
        sort(at.begin(),at.end());at.erase(unique(at.begin(),at.end()),at.end());
        vector<vector<vector<EnergyCut>>> cuts(N,vector<vector<EnergyCut>>(e.B));
        for(int left=0;left<(int)at.size();left++)for(int right=left+1;right<(int)at.size();right++){
            I a=at[left],b=at[right],w=b-a;array<I,N> val{};I spare=cap*w;
            for(int i=0;i<N;i++){val[i]=mandatory_length(s[i],a,b);spare-=val[i];}
            if(spare<0)return false;
            if(!trim)continue;
            for(int i=0;i<N;i++){
                I room=spare+val[i];if(room>=w||room>=2*e.D)continue;
                for(int k=0;k<e.B;k++)if(!e.init[k][ids[i]].empty()&&room<2*radius[k]){
                    auto z=boxes[i][k];I l=ax?z.b:z.l,h=ax?z.t:z.r,lo=a-radius[k]+room,hi=b+radius[k]-room;
                    if(l>lo&&h<hi){e.init[k][ids[i]].clear();continue;}
                    if(l>=hi||h<=lo)continue;
                    cuts[i][k].push_back({lo,hi});
                }
            }
        }
        for(int i=0;i<N;i++)for(int k=0;k<e.B;k++)if(!e.init[k][ids[i]].empty()&&!cuts[i][k].empty()){
            auto cv=move(cuts[i][k]);sort(cv.begin(),cv.end(),[](const EnergyCut& x,const EnergyCut& y){return x.lo<y.lo||(x.lo==y.lo&&x.hi<y.hi);});
            vector<EnergyCut> dis;for(auto v:cv){
                if(!dis.empty()&&v.lo<dis.back().hi)dis.back().hi=max(dis.back().hi,v.hi);else dis.push_back(v);}
            auto p=e.init[k][ids[i]];P retained;bool first=true;I last=0;
            for(auto v:dis){auto q=p;if(!first)q=half(move(q),ax,-1,last);q=half(move(q),ax,1,v.lo);merge_vertices(retained,q);last=v.hi;first=false;}
            merge_vertices(retained,half(p,ax,-1,last));e.init[k][ids[i]]=hull(move(retained));
        }
    }
    return true;
}
