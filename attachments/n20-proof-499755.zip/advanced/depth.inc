#include <tuple>
struct DepthTables{
    int grid=0;I board=0;vector<I> base;
    map<tuple<int,I,I>,vector<I>> per_move;
    void load(const char* file,I side){
        if(!file||!*file)return;
        ifstream f(file);int sub;f>>board>>grid>>sub;
        if(!f||board!=side||grid<4||grid>512||sub<1)throw runtime_error("depth table header");
        int i;I x,y;
        while(f>>i>>x>>y){
            vector<I> v(grid);for(auto& a:v){f>>a;if(!f||a<500000||a>1000000)throw runtime_error("depth table entry");}
            if(i==-1)base=move(v);else{auto ret=per_move.emplace(make_tuple(i,x,y),move(v));if(!ret.second)throw runtime_error("duplicate depths");}
        }
        if(base.empty())throw runtime_error("no primary depth grid");
    }
    I bound(const vector<I>* v,const Row& r,bool primary) const {
        I out=1000000;
        if(v&&grid){
            int lo=r.ki*grid/r.gi,hi=((r.ki+1)*grid+r.gi-1)/r.gi;
            out=*max_element(v->begin()+lo,v->begin()+hi);
        }
        // Bentz's primary closed endpoint covering, transferred from 5.
        if(primary&&board>0&&board<=5000000)out=min(out,(board+4)/5);
        return out;
    }
} depth_table;
struct DeepPoint{Point p;const vector<I>* depth;bool primary;};
vector<DeepPoint> needed_depths(const Choices& v,int i,const P& red_alt,const P& blue_alt,const vector<int>& owners){
    vector<DeepPoint> out;
    for(int c=0;c<2;c++){
        const auto& rack=c?v.blue:v.red;int id=(c?v.B:v.A)[i];
        out.push_back({rack.mark[id],depth_table.grid?&depth_table.base:nullptr,true});
        bool has=false;for(int j=0;j<2;j++)if(owners[c*2+j]==i)has=true;
        if(has)continue;
        P full=rack.moves[id];full.push_back(rack.mark[id]);full=hull(move(full));
        if(full!=(c?blue_alt:red_alt))continue;
        for(auto p:rack.moves[id]){
            auto lookup=(c && &v.red!=&v.blue)?Point{p.y,v.side-p.x}:p;
            auto it=depth_table.per_move.find(make_tuple(id,lookup.x,lookup.y));
            if(it!=depth_table.per_move.end())out.push_back({p,&it->second,false});
        }
    }
    return out;
}
P depth_clip(P p,const Row& row,Point z,I width){
    for(auto n:row.axes){
        n.k=-fl(-(W)n.k*width,1000000)+dot(n,z);
        if(p.empty()||mn(p,n)>n.k)return {};
        if(mx(p,n)>n.k)p=cut(p,n);
    }
    return p;
}
void pad(P& p,Point site,I width){
    I r=(1000000-width)/2;
    if(r<2)return;
    for(auto z:vector<Point>{{r,0},{-r,0},{0,r},{0,-r}})p.push_back({site.x+z.x,site.y+z.y});
    I a=r*7071/10000;
    for(int i:{-1,1})for(int j:{-1,1})p.push_back({site.x+i*a,site.y+j*a});
}
