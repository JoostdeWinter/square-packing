"""Certify additional unavoidable point patterns before using them in the search."""
from fractions import Fraction as F
from pathlib import Path
from itertools import product
import sys,json
h=Path(__file__).resolve().parent
sys.path.insert(0,str(h.parent/'base496'));from coverage import sweep
def candidates(U):
 coord=lambda a:int(F(a)*U/50)
 row_y=[9,17,25,33,41]
 for parity in [0,1]:
  pts=sorted((coord(5*x),coord(y)) for j,y in enumerate(row_y) for x in range(1,10) if (x+j)%2==parity)
  if len(pts)==23:yield 'complement',pts
  for setup in ['edge','edge_both','translate']:
   for amount in ([2,4] if setup!='translate' else [1]):
    s=[]
    for x,y in pts:
     if x==coord(5) and setup!='translate':x+=coord(amount)
     if x==coord(45) and setup=='edge_both':x-=coord(amount)
     if y in [coord(17),coord(33)] and setup=='translate':x+=coord(amount)
     s.append((x,y))
    yield f'{parity}_{setup}_{amount}',sorted(s)
def run(side):
 U=side*10000;recs=[];data=[];unique=set()
 for name,pts in candidates(U):
  if tuple(pts) in unique:continue
  unique.add(tuple(pts));proof=sweep(pts,U)
  print(name,len(pts),proof,flush=True)
  if not proof:continue
  recs.append({'name':name,'points':pts,'intervals':proof})
  for f in (lambda x,y:(x,y),lambda x,y:(U-y,x)):
   q=sorted(f(*z) for z in pts)
   if q not in data:data.append(q)
 (h/f'proofs{side}.json').write_text(json.dumps(recs,separators=(',',':')))
 for n in [1,3,5,len(data)]:
  racks=data[:n];out=[f'{U} {len(racks)}']
  for rack in racks:out.append(' '.join(map(str,[len(rack),*[v for z in rack for v in z]])))
  (h/f'racks{side}_{n}.txt').write_text('\n'.join(out)+'\n')
if __name__=='__main__':run(int(sys.argv[1]))
