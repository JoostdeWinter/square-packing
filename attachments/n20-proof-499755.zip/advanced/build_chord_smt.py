from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'shift.cpp').read_text()
key='void export_disj(';assert s.count(key)==1;s=s.replace(key,(h/'smt_chords.inc').read_text()+'\n'+key)
key='out<<"; pair constraints "';assert s.count(key)==1;s=s.replace(key,'''if(const char* cs=getenv("N20_SMT_CHORDS")){
        int count=stoi(cs);if(count>=5)export_chord_capacity(out,e,ids,groups,all,5,strict);
        if(count>=6)export_chord_capacity(out,e,ids,groups,all,6,strict);
    }
    '''+key)
p=h/'chordsmt.cpp';p.write_text(s);tmp=h/'chordsmt.partial';subprocess.run(['g++','-std=c++17','-O3',p,'-o',tmp],check=True);tmp.replace(h/'chordsmt')
