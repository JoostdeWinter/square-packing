from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'separators.cpp').read_text()
key='if(e.U==5000000 && outer.size()<3)continue;';assert s.count(key)==1;s=s.replace(key,'')
key='string sym(int axis,int i)';assert s.count(key)==1;s=s.replace(key,(h/'erosion.inc').read_text()+'\n'+key)
key='if(mode=="sep"){';assert s.count(key)==1
s=s.replace(key,'''if(mode=="erosion"){
        int f=stoi(getenv("N20_FINE"));if(f>1)fine(x,data.A,f,base.B*f);
        int passes=stoi(getenv("N20_UNION_PASSES")),sub=stoi(getenv("N20_FRAME_SUB")),an=stoi(getenv("N20_ERO_ANGLES")),div=stoi(getenv("N20_ERO_DIV"));
        for(int pass=0;pass<passes;pass++){
            if(!local_frame(x,data,owners,sub)||!rigid_erosion(x,data,owners,an,div)||!cluster_filter(x,data.A)||!propagate(x,data,owners,1,12,reason)){cout<<"CLOSED_EROSION "<<pass+1<<endl;return 0;}
        }cout<<"OPEN_EROSION "<<passes<<endl;return 0;
    }
    '''+key)
p=h/'erosion.cpp';p.write_text(s);t=h/'erosion.partial';subprocess.run(['g++','-O3','-std=c++17',p,'-o',t],check=True);t.replace(h/'erosion')
