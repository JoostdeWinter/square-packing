"""Compile the rotated-lattice refinement from the existing exact kernel."""
from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent
s=(h/'separators.cpp').read_text();key='string sym(int axis,int i)';assert s.count(key)==1
base=(h/'lattice_domains.inc').read_text()
old='int cycles,int parts,int maxdepth,int limit):';new='int cycles,int parts,int maxdepth,int limit,I C=1,I S=0,I D=1,int tx=0,int ty=0):';assert base.count(old)==1;base=base.replace(old,new)
a=base.index('        for(int type=0;');b=base.index('            body=hull(move(body))',a)
base=base[:a]+'''        if(C*C+S*S!=D*D||e.U%(20*D))throw runtime_error("inexact lattice basis");
        bool plain=(C==1 && S==0 && !tx && !ty);
        for(int type=0;type<2;type++)for(int i=-4;i<=9;i++)for(int j=-4;j<=9;j++){
            I X=2*i+type-5,Y=2*j+type-5;
            Point p{e.U/2+e.U*(C*X-S*Y)/(10*D)+e.U*tx/20,
                    e.U/2+e.U*(S*X+C*Y)/(10*D)+e.U*ty/20};
            if(min({p.x,p.y,e.U-p.x,e.U-p.y})<=0)continue;
            if(plain&&type&&(i==0||i==4)&&(j==0||j==4))continue;
            P body{p};
            if(type){
                for(I x=0;x<=370000;x+=10000){
                    I lo=0,hi=370001;if((W)(x+500000)*(x+500000)+(W)500000*500000>=(W)e.D*e.D)continue;
                    while(hi-lo>1){I y=(lo+hi)/2;if((W)(x+500000)*(x+500000)+(W)(y+500000)*(y+500000)<(W)e.D*e.D)lo=y;else hi=y;}
                    I xx=x/D*D,yy=lo/D*D;
                    for(I a:{-1,1})for(I b:{-1,1})body.push_back({p.x+(C*a*xx-S*b*yy)/D,p.y+(S*a*xx+C*b*yy)/D});
                }
            }
'''+base[b:]
base=base.replace('if(site.size()!=37)throw runtime_error("lattice site count");','if(site.size()>=64||site.size()<20||(plain&&site.size()!=37))throw runtime_error("rotated lattice site count");')
base=base.replace('            LChart ch;','''            I relative=upper;
            if(C!=1||S!=0){
                auto mid=cs(2*row.ki+1,2*row.gi);
                I cd=mid.c*C+mid.s*S,sd=mid.s*C-mid.c*S;
                relative=min(I(1414214),-fl(-(W)e.D*(abs(cd)+abs(sd)),(W)mid.d*D)-fl(-e.D,row.gi));
            }
            LChart ch;''').replace('I side=t?upper-e.D:e.D;','I side=t?relative-e.D:e.D;')
base=base.replace('array<int,37> owner','array<int,64> owner')
s=s.replace(key,base+'\n'+(h/'multilattice.inc').read_text()+'\n'+key)
k='if(mode=="sep"){';assert s.count(k)==1
s=s.replace(k,'''if(mode=="multilattice"){
        int f=stoi(getenv("N20_FINE"));if(f>1)fine(x,data.A,f,base.B*f);
        MLSearch st(x,stoi(getenv("N20_UNION_PASSES")),stoi(getenv("N20_FRAME_SUB")),stoi(getenv("N20_LATTICE_DEPTH")),stoi(getenv("N20_LATTICE_BUDGET")),stoi(getenv("N20_LATTICES")));
        bool closed=st.solve(x,data,owners,st.initial(),0);
        cout<<(closed?"CLOSED_MULTILATTICE ":"OPEN_MULTILATTICE ")<<st.nodes<<" "<<st.passes_used<<endl;return 0;
    }
    '''+k)
p=h/'multilattice.cpp';p.write_text(s);t=h/'multilattice.partial';subprocess.run(['g++','-O3','-std=c++17',p,'-o',t],check=True);t.replace(h/'multilattice')
