from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'chordsmt.cpp').read_text();key='string sym(int axis,int i)';assert s.count(key)==1;s=s.replace(key,(h/'direct.inc').read_text()+'\n'+key)
key='if(mode=="smt"){';assert s.count(key)==1;s=s.replace(key,'''if(mode=="direct"){
        int groups=stoi(getenv("N20_DIRECT_GROUPS"));if(groups<1||groups>64)throw runtime_error("direct groups");
        int f=stoi(getenv("N20_FINE"));if(f>1)fine(x,data.A,f,base.B*f);
        int passes=stoi(getenv("N20_DIRECT_PASSES"));if(passes<1||passes>30)throw runtime_error("direct passes");
        for(int z=0;z<passes;z++){
            if(!direct_centers(x,data.A,groups)){cout<<"DIRECT "<<z+1<<" 11"<<endl;return 0;}
            if(!cluster_filter(x,data.A)){cout<<"DIRECT "<<z+1<<" 10"<<endl;return 0;}
            if(!propagate(x,data,owners,1,10,reason)){cout<<"DIRECT "<<z+1<<" "<<reason<<endl;return 0;}
        }
        if(argc>11 && string(argv[11])!="-"){
            int groups=getenv("N20_SMT_GROUPS")?stoi(getenv("N20_SMT_GROUPS")):3;
            export_disj(x,data.A,groups,argv[11],x.U==5000000);
        }
        cout<<"OPEN_DIRECT "<<passes<<endl;return 0;
    }
    '''+key)
p=h/'direct.cpp';p.write_text(s);tmp=h/'direct.partial';subprocess.run(['g++','-std=c++17','-O3',p,'-o',tmp],check=True);tmp.replace(h/'direct')
