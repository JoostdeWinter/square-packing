struct FrameGroup {P centers;P inner;};
P centered_core(const vector<int>& bins,const Engine& e){
    I t=e.U/2;vector<HP> all;
    for(int k:bins)for(auto f:e.rows[k].fac){f.k+=(f.a+f.b)*t;all.push_back(f);}
    P p=safe(all,e.U);for(auto& z:p){z.x-=t;z.y-=t;}
    // The inscribed disk is independent of orientation. Add rational points
    // strictly inside a radius-half disk before taking the convex hull.
    static P circ;
    if(circ.empty()){
        for(int j=0;j<40;j++){double v=j*2*acos(-1)/40;
            I x=llround(499990*cos(v)),y=llround(499990*sin(v));
            if((W)x*x+(W)y*y<(W)500000*500000)circ.push_back({x,y});}
    }
    return convex_union(move(p),circ);
}
P mink(const P& a,const P& b,bool diff){
    if(a.empty()||b.empty())return {};
    P sum;sum.reserve(a.size()*b.size());
    for(auto x:a)for(auto y:b)sum.push_back({x.x+(diff?-y.x:y.x),x.y+(diff?-y.y:y.y)});
    return hull(move(sum));
}
vector<FrameGroup> ep_groups(const Engine& e,int id,int lanes){
    vector<vector<int>> bins(lanes);vector<FrameGroup> out;
    for(int k=0;k<e.B;k++)if(!e.init[k][id].empty())bins[min(lanes-1,lanes*e.rows[k].ki/e.rows[k].gi)].push_back(k);
    for(auto& use:bins)if(!use.empty()){
        P p;for(int k:use)merge_vertices(p,e.init[k][id]);p=hull(move(p));
        out.push_back({move(p),centered_core(use,e)});
    }
    return out;
}
void unique_normal(HP& h){
    I g=gcd(abs(h.a),abs(h.b));if(g<1)throw runtime_error("zero normal");
    if(h.k%g)throw runtime_error("nonlattice facet normalization");
    h.a/=g;h.b/=g;h.k/=g;
}
void export_lp(const Engine& e,const vector<int>& ids,int lanes,const string& name){
    ofstream out(name);if(!out)throw runtime_error("LP output");
    out<<ids.size()<<" "<<e.U<<"\n";
    vector<vector<FrameGroup>> gs;vector<P> centers;
    for(int i=0;i<(int)ids.size();i++){
        gs.push_back(ep_groups(e,ids[i],lanes));P pts;
        for(const auto& g:gs.back())merge_vertices(pts,g.centers);
        pts=hull(move(pts));if(pts.empty())throw runtime_error("empty pose chart");
        centers.push_back(pts);
        auto b=bbox(pts);
        auto fs=pts.size()>=3?facets(pts):vector<HP>{{1,0,b.r},{-1,0,-b.l},{0,1,b.t},{0,-1,-b.b}};
        for(auto f:fs){unique_normal(f);out<<-1<<" "<<i<<" "<<f.a<<" "<<f.b<<" "<<f.k<<"\n";}
    }
    for(int i=0;i<(int)ids.size();i++)for(int j=i+1;j<(int)ids.size();j++){
        Bound x=bbox(centers[i]),y=bbox(centers[j]);
        if(max(x.l-y.r,y.l-x.r)>1414214 || max(x.b-y.t,y.b-x.t)>1414214)continue;
        P combined;
        for(const auto& g:gs[i])for(const auto& k:gs[j]){
            P outer=mink(k.centers,g.centers,true);
            auto f=add(g.inner,facets(g.inner),k.inner,facets(k.inner));
            P allowed=remove_forbidden(outer,f);
            merge_vertices(combined,allowed);
        }
        auto allowed=hull(move(combined));
        if(allowed.empty()){out<<"-2 -2 0 0 -1\n";continue;}
        P raw=mink(centers[j],centers[i],true);auto b=bbox(allowed);
        auto fs=allowed.size()>=3?facets(allowed):vector<HP>{{1,0,b.r},{-1,0,-b.l},{0,1,b.t},{0,-1,-b.b}};
        for(auto f:fs){if(mx(raw,f)<=f.k)continue;unique_normal(f);out<<i<<" "<<j<<" "<<f.a<<" "<<f.b<<" "<<f.k<<"\n";}
    }
}
