from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import os,subprocess,sys,json
h=Path(__file__).resolve().parents[1]
def one(f):
 z=json.loads(f.read_text());a,b=z['key'].split('_');env=dict(os.environ,N20_FINE='4',N20_EXTRA_RACKS=str(h/'advanced/racks498_20.txt'),N20_TREE_DEPTH='19',N20_TREE_LIMIT='1800',N20_TREE_CHECKS='6')
 cmd=[h/'advanced/diagnostic','tree',h/'cold498/i64',h/'cold498/strongprofiles',h/'enumerator/marks498.txt',a,b,'40','4',','.join(map(str,z['owners']))]
 r=subprocess.run(cmd,text=True,input=' '.join(map(str,z['match']))+'\n',env=env,capture_output=True)
 return f.name,r.returncode,r.stdout.strip(),r.stderr.strip()
if __name__=='__main__':
 with ThreadPoolExecutor(2) as pool:
  for v in pool.map(one,sorted((h/'trials/tree498_fine').glob('*.json'))):print(json.dumps(v),flush=True)
