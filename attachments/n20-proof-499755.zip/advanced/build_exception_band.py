"""Build a frame checker with an individual set of possible tilt exceptions."""
from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent
src=(h/'separators.cpp').read_text()
anchor='string sym(int axis,int i)'
assert src.count(anchor)==1
method=r'''void filter_exceptions(Engine& x,const Choices& data){
        int lo,ld,hi,hd,ex,axis;
        istringstream in(getenv("N20_EXCEPTION_BAND"));
        if(!(in>>lo>>ld>>hi>>hd>>ex>>axis)||lo<=0||ld>1000000||hd>1000000||ld<=0||hd<=0||
           (I)lo*hd>(I)hi*ld||hi>hd||ex<0||ex>=(1<<N)||(axis!=0&&axis!=1))throw runtime_error("exception band");
        for(int k=0;k<x.B;k++){
          const auto& r=x.rows[k];
          bool inside=(I)(r.ki+1)*ld>=(I)lo*r.gi && (I)r.ki*hd<=(I)hi*r.gi;
          if(inside)continue;
          bool aligned=r.ki==0 || r.ki+1==r.gi;
          for(int i=0;i<N;i++)if(!(ex&(1<<i)) || (axis&&!aligned))x.init[k][data.A[i]].clear();
        }
}
'''
src=src.replace(anchor,method+anchor)
start='    int reason=0;\n    if(!propagate(x,data,owners,cycles,rounds,reason))'
assert src.count(start)==1
src=src.replace(start,'    filter_exceptions(x,data);\n'+start)
a=src.index('if(mode=="frame")');idx=src.index('fine(x,',a);idx=src.index(';',idx)+1
src=src[:idx]+'filter_exceptions(x,data);'+src[idx:]
p=h/'exception_band.cpp';p.write_text(src)
o=h/'exception_band.partial';subprocess.run(['g++','-std=c++17','-O1','-g0','-fno-var-tracking','--param','ggc-min-expand=8','--param','ggc-min-heapsize=8192',p,'-o',o],check=True);o.replace(h/'exception_band')
