// Physical chord lengths on oblique board lines. For the two 45-degree
// families use x+y or x-y as the normal coordinate, and horizontal chord
// extent as the length. No approximation to sqrt(2) is needed in a line.
struct OLine{I a,b,e;bool diag;};
struct OConst{I h,p,z;};
OConst ochart(const Row& r,I D,OLine n){
    auto v=cs(r.ki,r.gi),w=cs(r.ki+1,r.gi);
    I height=2*D,plateau=2*D,prod=0;
    if(n.diag){
        for(auto t:{v,w}){
            height=min(height,fl((W)D*max(t.c,t.s),t.d));
            plateau=min(plateau,fl((W)D*t.d,t.c+t.s));
            W diff=(W)t.c*t.c-(W)t.s*t.s;if(diff<0)diff=-diff;
            prod=max(prod,-fl(-(W)D*diff,(W)t.d*t.d));
        }
        if(v.c>=v.s&&w.c<=w.s){height=min(height,(I)707106);plateau=min(plateau,(I)707106);}
    }else{
        vector<array<I,2>> cs0;
        for(auto t:{v,w}){
            I c=n.a*t.c+n.b*t.s,s=n.a*t.s-n.b*t.c,d=n.e*t.d;
            cs0.push_back({c,s});
            height=min(height,fl((W)D*(abs(c)+abs(s)),2*d));
            plateau=min(plateau,fl((W)D*d,max(abs(c),abs(s))));
            prod=max(prod,-fl(-(W)D*abs(c)*abs(s),(W)d*d));
        }
        auto crosses=[](I a,I b){return (a<=0&&b>=0)||(b<=0&&a>=0);};
        auto l=cs0[0],u=cs0[1];
        if(crosses(l[0],u[0])||crosses(l[1],u[1])){height=min(height,D/2);plateau=min(plateau,D);}
        if(crosses(l[0]-l[1],u[0]-u[1])||crosses(l[0]+l[1],u[0]+u[1]))prod=(D+1)/2;
    }
    return {height-1,plateau,max((I)1,prod)};
}
I board_oline(I U,I t,OLine n){
    if(n.diag){I center=(n.a+n.b)*U/2;return max((I)0,U-abs(t-center));}
    W avail=(W)U*(abs(n.a)+abs(n.b));
    W shift=(W)2*n.e*t-(W)U*(n.a+n.b);if(shift<0)shift=-shift;avail-=shift;
    if(avail<=0)return 0;
    I cap=-fl(-(W)U*n.e,max(abs(n.a),abs(n.b)));
    if(n.a&&n.b)cap=min(cap,-fl(-avail*n.e,2*(W)abs(n.a)*abs(n.b)));
    return cap;
}
bool oblique_cut(Engine& e,const vector<int>& ids,OLine n,int density){
    vector<OConst> cc;for(auto& r:e.rows)cc.push_back(ochart(r,e.D,n));
    HP norm{n.a,n.b,0};
    vector<vector<pair<I,I>>> bounds(N,vector<pair<I,I>>(e.B));vector<vector<int>> live(N);
    vector<I> levels;I lo=fl((W)(min((I)0,n.a)+min((I)0,n.b))*e.U,n.e);
    I hi=-fl(-(W)(max((I)0,n.a)+max((I)0,n.b))*e.U,n.e);
    for(I t=lo;t<=hi;t+=max((I)1,e.D/density))levels.push_back(t);
    if(n.diag)for(int i=-5;i<=10;i++)levels.push_back(i*e.U/5);
    for(int i=0;i<N;i++){
        auto& sh=e.seed[ids[i]];I s=mn(sh,norm),t=mx(sh,norm);levels.push_back(fl((W)s+t,2*n.e));
        for(auto z:sh){I p=fl(dot(norm,z),n.e);if(n.diag&&density>=20)levels.push_back(p);}
        for(int k=0;k<e.B;k++){
            auto& p=e.init[k][ids[i]];if(p.empty())continue;
            I l=fl(mn(p,norm),n.e),u=-fl(-mx(p,norm),n.e);bounds[i][k]={l,u};live[i].push_back(k);}
        if(live[i].empty())return false;
    }
    sort(levels.begin(),levels.end());levels.erase(unique(levels.begin(),levels.end()),levels.end());
    vector<vector<vector<EnergyCut>>> cuts(N,vector<vector<EnergyCut>>(e.B));
    for(auto t:levels){
        if(t<=lo||t>=hi)continue;I cap=board_oline(e.U,t,n);array<I,N> need{};I spare=cap;
        for(int i=0;i<N;i++){
            I least=2*e.D;
            for(int k:live[i]){auto [l,u]=bounds[i][k];auto z=cc[k];I m=max(abs(l-t),abs(u-t));
                I len=m>=z.h?0:min(z.p,fl((W)e.D*(z.h-m),z.z));least=min(least,len);
                if(!least)break;}
            need[i]=least;spare-=least;
        }
        if(spare<0)return false;
        for(int i=0;i<N;i++){
            I room=spare+need[i];if(room>=2*e.D)continue;
            for(int k:live[i]){auto z=cc[k];if(room>=z.p)continue;
                I r=z.h+fl(-(W)room*z.z,e.D);if(r<=0)continue;
                auto [l,u]=bounds[i][k];if(t+r<=l||u<=t-r)continue;
                cuts[i][k].push_back({(t-r)*n.e,(t+r)*n.e});
            }
        }
    }
    for(int i=0;i<N;i++)for(int k:live[i])if(!cuts[i][k].empty()){
        auto& v=cuts[i][k];sort(v.begin(),v.end(),[](const EnergyCut& x,const EnergyCut& y){return x.lo<y.lo||(x.lo==y.lo&&x.hi<y.hi);});
        vector<EnergyCut> sep;for(auto q:v){if(!sep.empty()&&q.lo<sep.back().hi)sep.back().hi=max(sep.back().hi,q.hi);else sep.push_back(q);}
        auto& p=e.init[k][ids[i]];P out;bool first=true;I last=0;
        for(auto q:sep){auto part=p;if(!first)part=one_half(part,{-n.a,-n.b,-last});if(!part.empty())part=one_half(part,{n.a,n.b,q.lo});merge_vertices(out,part);last=q.hi;first=false;}
        merge_vertices(out,one_half(p,{-n.a,-n.b,-last}));p=hull(move(out));
    }
    for(int id:ids)if(none_of(e.init.begin(),e.init.end(),[&](const vector<P>& r){return !r[id].empty();}))return false;
    return true;
}
vector<OLine> olines(int level){
    vector<OLine> dirs={{1,1,1,true},{1,-1,1,true}};
    vector<pair<int,int>> slopes={{1,5},{1,10},{1,3},{2,7},{1,14},{4,11},{2,17},{3,20}};
    for(int j=0;j<min((int)slopes.size(),level);j++){auto [m,k]=slopes[j];auto d=cs(m,k);
        for(auto [a,b]:vector<pair<I,I>>{{d.c,d.s},{d.c,-d.s},{d.s,d.c},{d.s,-d.c}})dirs.push_back({a,b,d.d,false});}
    return dirs;
}
