from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'frame.cpp').read_text();key='string sym(int axis,int i)';assert s.count(key)==1;s=s.replace(key,(h/'local_hall.inc').read_text()+'\n'+key)
key='if(mode=="frame"){';assert s.count(key)==1;s=s.replace(key,'''if(mode=="hall"){
        int f=stoi(getenv("N20_FINE"));if(f>1)fine(x,data.A,f,base.B*f);
        int passes=stoi(getenv("N20_UNION_PASSES")),sub=stoi(getenv("N20_FRAME_SUB")),groups=stoi(getenv("N20_HALL_GROUPS")),div=stoi(getenv("N20_HALL_DIV"));
        istringstream in(getenv("N20_HALL_RACKS"));vector<int> racks;int nr;char sep;
        while(in>>nr){if(nr<0||nr>=(int)aux_racks.size())throw runtime_error("invalid Hall rack");racks.push_back(nr);in>>sep;}
        for(int pass=0;pass<passes;pass++){
            if(!local_frame(x,data,owners,sub)){cout<<"CLOSED_HALL "<<pass+1<<" frame"<<endl;return 0;}
            for(int slot:racks)if(!local_hall(x,data.A,slot,groups,div)){cout<<"CLOSED_HALL "<<pass+1<<" hall "<<slot<<endl;return 0;}
            if(!cluster_filter(x,data.A)||!propagate(x,data,owners,1,12,reason)){cout<<"CLOSED_HALL "<<pass+1<<" propagation "<<reason<<endl;return 0;}
        }cout<<"OPEN_HALL "<<passes<<endl;return 0;
    }
    '''+key)
p=h/'hall.cpp';p.write_text(s);t=h/'hall.partial';subprocess.run(['g++','-O3','-std=c++17',p,'-o',t],check=True);t.replace(h/'hall')
