"""Recheck every endpoint pattern used in the finite searches, including its symmetries."""
from concurrent.futures import ProcessPoolExecutor
from itertools import product
from pathlib import Path
import argparse,collections,json
from endpoint_cover import prove,U
h=Path(__file__).resolve().parents[1]
def grp(points,swap):
 for sw in range(2 if swap else 1):
  for a,b in product(range(2),repeat=2):
   def f(p):return U-p[sw] if a else p[sw],U-p[1-sw] if b else p[1-sw]
   yield tuple(sorted(f(p) for p in points))
def main(jobs):
 raw=(h/'advanced/endpoint_moves.txt').read_text().splitlines();n,u=map(int,raw[0].split());assert n==22 and u==U and len(raw)==23
 p=[];moves=[]
 for i,l in enumerate(raw[1:]):
  x,y,m,*zs=map(int,l.split());assert len(zs)==2*m
  p.append((x,y));moves.extend((i,X,Y) for X,Y in zip(zs[::2],zs[1::2]))
 coords=((10,9),(20,9),(5,17),(15,17),(25,17),(10,25),(20,25))
 expected=sorted({(X*U//50,Y*U//50) for x,y in coords for X in (x,50-x) for Y in (y,50-y)})
 assert p==expected and len(set(moves))==len(moves)
 sets=set([min(grp(p,True))])
 for i,x,y in moves:
  a=p.copy();a[i]=(x,y);sets.add(min(grp(a,True)))
 full=set()
 for f in sorted((h/'advanced').glob('endpoint_racks_*.txt')):
  lines=f.read_text().splitlines();u,count=map(int,lines[0].split());assert u==U and count==len(lines)-1
  for line in lines[1:]:
   k,*zs=map(int,line.split());pts=tuple(sorted(zip(zs[::2],zs[1::2])));assert len(zs)==2*k and len(set(pts))==k
   full.add(pts);sets.add(min(grp(pts,True)))
 with ProcessPoolExecutor(jobs) as pool:
  proofs=list(pool.map(prove,sorted(sets)))
 assert all(proofs),[p for p,res in zip(sorted(sets),proofs) if not res]
 r={'side':5,'primary_count':len(p),'single_moved_sites':len(moves),'auxiliary_patterns':len(full),'distinct_patterns_up_to_square_symmetry':len(sets),'exact_chart_counts':[z['interval_count'] for z in proofs],'event_polynomial_counts':[z['event_polynomials'] for z in proofs]}
 print(json.dumps(r,indent=2));return r
if __name__=='__main__':ap=argparse.ArgumentParser();ap.add_argument('--jobs',type=int,default=2);v=ap.parse_args();main(v.jobs)
