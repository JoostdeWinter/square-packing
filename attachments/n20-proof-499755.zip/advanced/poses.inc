// Pose families exhaust the contracted angular strips and center polygon.
// A full packing gives a 20-partite clique in their necessary pairwise
// compatibility graph. The graph can be replayed with a finite SAT checker.
struct PoseFamily {P center,body,mandatory;Bound b;vector<HP> edges;int halfangle_lo,halfangle_hi;};
struct PosePart{vector<int> bins;vector<P> centers;};
vector<PoseFamily> families(const Engine& e,int id,int angle_slices,int div){
    P all;vector<int> active;
    for(int k=0;k<e.B;k++)if(!e.init[k][id].empty()){merge_vertices(all,e.init[k][id]);active.push_back(k);}
    if(active.empty())return {};auto box=bbox(all);vector<PoseFamily> out;
    vector<I> xx(div+1),yy(div+1);for(int i=0;i<=div;i++){
        xx[i]=box.l+(box.r-box.l)*i/div;yy[i]=box.b+(box.t-box.b)*i/div;}
    vector<PosePart> groups(angle_slices*div*div);
    for(int k:active){
        int ang=min(angle_slices-1,e.rows[k].ki*angle_slices/e.rows[k].gi);
        const auto& p=e.init[k][id];auto b=bbox(p);
        for(int ix=0;ix<div;ix++){if(xx[ix]>b.r||xx[ix+1]<b.l)continue;
            P px=half(half(p,0,-1,xx[ix]),0,1,xx[ix+1]);if(px.empty())continue;
            for(int iy=0;iy<div;iy++){if(yy[iy]>b.t||yy[iy+1]<b.b)continue;
                P q=half(half(px,1,-1,yy[iy]),1,1,yy[iy+1]);if(q.empty())continue;
                auto& g=groups[(ang*div+ix)*div+iy];g.bins.push_back(k);g.centers.push_back(move(q));
            }
        }
    }
    for(auto& group:groups)if(!group.bins.empty()){
        P outer;vector<HP> support;
        for(int j=0;j<(int)group.bins.size();j++){
            int k=group.bins[j];auto& p=group.centers[j];merge_vertices(outer,p);
            for(auto f:e.rows[k].fac){f.k+=mn(p,f);support.push_back(f);}
        }
        outer=hull(move(outer));auto mandatory=convex_union(e.seed[id],safe(support,e.U));
        if(e.U==5000000 && outer.size()<3)continue; // normalized feasible packings form an open set
        auto body=centered_core(group.bins,e);
        P neg;for(auto z:body)neg.push_back({-z.x,-z.y});body=convex_union(move(body),neg);
        out.push_back({outer,body,mandatory,bbox(outer),facets(body),e.rows[group.bins.front()].ki,e.rows[group.bins.back()].ki+1});
    }
    return out;
}
bool incompatible(const PoseFamily& a,const PoseFamily& b,bool strict){
    if(max({a.b.l-b.b.r,b.b.l-a.b.r,a.b.b-b.b.t,b.b.b-a.b.t})>1414214)return false;
    if(intersect_closed(a.mandatory,b.mandatory))return true;
    // A direction of either inner polygon must separate the two to avoid
    // interior overlap. Compare the largest possible signed center gap.
    for(auto& o:vector<pair<const PoseFamily*,const PoseFamily*>>{{&a,&b},{&b,&a}}){
        for(auto f:o.first->edges){
            I required=f.k+mx(o.second->body,f);
            I possible=mx(b.center,f)-mn(a.center,f);
            if(strict?possible>required:possible>=required)return false;
        }
    }
    return true;
}
void export_families(const Engine& e,const vector<int>& ids,int ag,int divisions,const string& filename){
    vector<vector<PoseFamily>> gs;for(int i:ids)gs.push_back(families(e,i,ag,divisions));
    ofstream out(filename);if(!out)throw runtime_error("pose output");
    out<<"FAMILIES1 "<<ids.size()<<" "<<e.U<<"\n";
    for(const auto& opts:gs)out<<opts.size()<<" ";out<<"\n";
    for(int i=0;i<(int)gs.size();i++)for(int j=i+1;j<(int)gs.size();j++){
        vector<pair<int,int>> bad;
        for(int a=0;a<(int)gs[i].size();a++)for(int b=0;b<(int)gs[j].size();b++){
            if(incompatible(gs[i][a],gs[j][b],e.U==5000000))bad.push_back({a,b});
        }
        out<<i<<" "<<j<<" "<<bad.size()<<"\n";for(auto [a,b]:bad)out<<a<<" "<<b<<" ";out<<"\n";
    }
}
