from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'separators.cpp').read_text()
key='    int reason=0;\n    if(!propagate(x,data,owners,cycles,rounds,reason))';assert s.count(key)==1
s=s.replace(key,'''    if(const char* band=getenv("N20_BAND")){
        istringstream input(band);I p,q,a,b;
        if(!(input>>p>>q>>a>>b)||min(q,b)<=0||p<0||a<0||p*b>a*q||a>b)throw runtime_error("half-angle band");
        for(int k=0;k<x.B;k++){auto& row=x.rows[k];
            if((I)(row.ki+1)*q<p*row.gi||(I)row.ki*b>a*row.gi)for(int id:data.A)x.init[k][id].clear();
        }
    }
'''+key)
p=h/'bands.cpp';p.write_text(s);out=h/'bands.partial';subprocess.run(['g++','-O3','-std=c++17',p,'-o',out],check=True);out.replace(h/'bands')
