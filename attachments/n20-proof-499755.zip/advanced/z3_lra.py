"""Evaluate exact SMT-LIB over linear real arithmetic through the system Z3."""
import ctypes as C,ctypes.util,os,sys
from pathlib import Path
def run(src,timeout_ms=5000,more=''):
 lib=C.CDLL(ctypes.util.find_library('z3') or 'libz3.so.4');ptr=C.c_void_p
 for f,a,r in [('Z3_mk_config',[],ptr),('Z3_mk_context_rc',[ptr],ptr),('Z3_eval_smtlib2_string',[ptr,C.c_char_p],C.c_char_p),('Z3_del_context',[ptr],None),('Z3_del_config',[ptr],None)]:
  v=getattr(lib,f);v.argtypes=a;v.restype=r
 cfg=lib.Z3_mk_config();ctx=lib.Z3_mk_context_rc(cfg)
 try:
  ans=lib.Z3_eval_smtlib2_string(ctx,(f'(set-option :timeout {int(timeout_ms)})\n'+src).encode()).decode().strip()
  if more and ans=='sat':return ans,lib.Z3_eval_smtlib2_string(ctx,more.encode()).decode().strip()
  return ans,None
 finally:lib.Z3_del_context(ctx);lib.Z3_del_config(cfg)
if __name__=='__main__':print(run(Path(sys.argv[1]).read_text(),int(sys.argv[2]) if len(sys.argv)>2 else 5000)[0])
