"""Closed-mark charts at side 5, applicable to a strict normalized packing."""
from pathlib import Path
from fractions import Fraction as F
import sys,json,subprocess,os,shutil,itertools,tempfile
h=Path(__file__).resolve().parents[1];up=h/'base496/upstream';sys.path[:0]=[str(up),str(h/'base496')]
from prereqs import SPEC,marks
from export_lattice import uv,hull,clip,rect,dot,to_inner,gcd,ceil,floor
import nearest_rack
from nearest_init import source
D=10**6
def closed_init(pts,B,L,dest):
 with tempfile.TemporaryDirectory() as td:
  tmp=Path(td);geom=tmp/'geometry'
  with geom.open('w') as out:
   def polygon(v):print(len(v),*(x for p in v for x in p),file=out)
   print(int(L*D),D,B,len(pts),file=out)
   for x,y in pts:
    assert (x*D).denominator==(y*D).denominator==1;polygon([(int(x*D),int(y*D))])
   for k in range(B):
    c,s=uv(F(2*k+1,2*B));axes=[(c,s),(-s,c),(-c,-s),(s,-c)];ends=list(map(uv,[F(k,B),F(k+1,B)]))
    rm=max(c*C+s*T+abs(s*C-c*T) for C,T in ends);lo=min(C+T for C,T in ends)/2;rr=(1-F(1,10**7))/2
    for x,y in axes:
     v=x.denominator*y.denominator//gcd(x.denominator,y.denominator);print(int(v*x),int(v*y),ceil(v*rm*D/2),file=out)
    body=hull([(rr*(i*c-j*s)/rm,rr*(i*s+j*c)/rm) for i,j in itertools.product((-1,1),repeat=2)]+[(rr*a,rr*b) for a,b in axes])
    polygon(to_inner(body,D,True))
    for point in pts:
     P=rect(lo,L-lo)
     for n in axes:P=clip(P,n,rm/2+dot(n,point))
     polygon(hull((x,y) for X,Y in P for x in (floor(X*D),ceil(X*D)) for y in (floor(Y*D),ceil(Y*D))))
  nearest_rack.marks=lambda unused:pts
  with (tmp/'nearest').open('w') as f:nearest_rack.emit({'erosion':'0'},B,f)
  source(up/'lattice_kernel.cpp',tmp/'nearest.cpp')
  subprocess.run(['g++','-O3','-std=c++17',tmp/'nearest.cpp','-o',tmp/'filter'],check=True)
  with dest.open('w') as f:subprocess.run([tmp/'filter',geom,tmp/'nearest'],stdout=f,check=True)
def write_rack(pts,path,L):
 u=int(L*D);lines=[f'{len(pts)} {u}']+[f'{int(x*D)} {int(y*D)} 0' for x,y in pts];path.write_text('\n'.join(lines)+'\n')
def main():
 L=F(5);d=h/'trials/b500';d.mkdir(exist_ok=True)
 pts=marks(dict(SPEC,cap='5'));write_rack(pts,h/'enumerator/marks500.txt',L)
 # Bentz's complementary 23 marks, Theorem 11 and Figure 3.
 complement=sorted((F(x,2),F(y,10)) for x in range(1,10) for y in (9,17,25,33,41) if (F(x,2),F(y,10)) not in pts)
 assert len(complement)==23
 qr=sorted((L-y,x) for x,y in complement)
 (h/'advanced/racks500.txt').write_text('5000000 2\n'+'\n'.join(' '.join(map(str,[len(z),*[int(v*D) for p in z for v in p]])) for z in (complement,qr))+'\n')
 for b in map(int,sys.argv[1:]):
  path=d/f'i{b}'
  if not path.exists():closed_init(pts,b,L,path)
  print('closed endpoint table',b,flush=True)
if __name__=='__main__':main()
