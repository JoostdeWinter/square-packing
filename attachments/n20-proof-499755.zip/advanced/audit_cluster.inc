// Audit support for a single refined root. Emit the rational-polytope
// witnesses for an independently implemented arbitrary-precision checker.
void audit_cluster(Engine e,const vector<int>& A,ostream& out){
    auto poly=[&](const P& p){out<<p.size();for(auto pt:p)out<<" "<<pt.x<<" "<<pt.y;out<<"\n";};
    out<<"AUDIT1 "<<e.B<<" "<<A.size()<<" "<<e.U<<"\n";
    for(const auto& r:e.rows){out<<"ROW "<<r.ki<<" "<<r.gi<<" ";poly(r.core);}
    for(int id:A){out<<"TILE "<<id<<" ";poly(e.seed[id]);for(const auto& q:e.init){out<<"P ";poly(q[id]);}}
    for(int id:A){
        auto shapes=conditional_cores(e,id);out<<"SOURCE "<<id<<" "<<shapes.size()<<"\n";
        for(auto& q:shapes){out<<"SHAPE ";poly(q);}
        if(shapes.empty()){out<<"IMPOSSIBLE "<<id<<"\n";return;}
        if(shapes.size()==1 && shapes[0].size()<3)continue;
        for(int k=0;k<e.B;k++){
            vector<HP> all;Bound shared={INT64_MIN,INT64_MAX,INT64_MIN,INT64_MAX};
            for(auto& shape:shapes){
                auto b=add(shape,facets(shape),e.rows[k].core,e.rows[k].fac);
                shared.l=max(shared.l,b.b.l);shared.r=min(shared.r,b.b.r);shared.b=max(shared.b,b.b.b);shared.t=min(shared.t,b.b.t);
                all.insert(all.end(),b.p.begin(),b.p.end());
            }
            if(shared.l>=shared.r||shared.b>=shared.t)continue;
            for(int i:A)if(i!=id){
                auto& p=e.init[k][i];if(p.empty()||!bmatch(bbox(p),shared))continue;
                auto q=noninterior_hull(p,all);if(q!=p){out<<"UPDATE "<<i<<" "<<k<<" ";poly(q);p=move(q);}
            }
        }
    }
    for(int i:A){bool alive=false;for(const auto& q:e.init)if(!q[i].empty())alive=true;if(!alive){out<<"IMPOSSIBLE "<<i<<"\n";return;}}
    out<<"LIVE\n";
}
