// Assign a further unavoidable pattern. Geometrically incompatible pairs of
// candidate marks are removed before checking whether a complete assignment
// exists. Every bounded search returns "possible" on budget exhaustion.
struct ThirdData{
    int n,m;vector<Mask> edges;
    vector<vector<P>> shape;vector<vector<vector<P>>> poses;
    vector<vector<vector<Mask>>> compat;
    ThirdData(int nn,int mm,int bins):n(nn),m(mm),edges(n),shape(n,vector<P>(m)),
       poses(n,vector<vector<P>>(m)),compat(n,vector<vector<Mask>>(m,vector<Mask>(n))){}
};
bool restrict_third(ThirdData& sc,const Engine& e,const vector<int>& ids,const Rack& rack,bool lattice,const vector<int>& forced){
    for(int i=0;i<sc.n;i++){
        int id=ids[i];
        for(int j=0;j<sc.m;j++){
            if(forced[i]>=0&&forced[i]!=j)continue;
            P req=convex_union(e.seed[id],{rack[j].p});bool clash=false;
            for(int q:ids)if(q!=id&&intersect_closed(req,e.seed[q])){clash=true;break;}if(clash)continue;
            vector<HP> all;vector<P> xs(e.B);
            for(int k=0;k<e.B;k++)if(!e.init[k][id].empty()){
                P c=resource_domain(e.init[k][id],e.rows[k],rack[j],lattice,e.U,e.D);
                if(c.empty())continue;xs[k]=move(c);
                for(auto a:e.rows[k].fac){a.k+=mn(xs[k],a);all.push_back(a);}
            }
            if(all.empty())continue;
            req=convex_union(move(req),safe(all,e.U));
            for(int q:ids)if(q!=id&&intersect_closed(req,e.seed[q])){clash=true;break;}if(clash)continue;
            sc.edges[i]|=Mask(1)<<j;sc.poses[i][j]=move(xs);sc.shape[i][j]=move(req);
        }
        if(!sc.edges[i])return false;
    }
    if(!rectangular_perfect(sc.edges,sc.m))return false;
    for(int i=0;i<sc.n;i++)for(int j=0;j<sc.m;j++)if(sc.edges[i]>>j&1){
        for(int v=0;v<sc.n;v++)if(v!=i){
            Mask candidates=sc.edges[v]&~(Mask(1)<<j),ans=candidates;
            while(candidates){int k=__builtin_ctzll(candidates);candidates&=candidates-1;
                if(intersect_closed(sc.shape[i][j],sc.shape[v][k]))ans&=~(Mask(1)<<k);}
            sc.compat[i][j][v]=ans;
        }
    }
    return true;
}
int third_complete(const ThirdData& data,vector<Mask> state,Mask done,int& visited,int lim){
    if(++visited>lim)return 2;
    if(__builtin_popcountll(done)==data.n)return 1;
    int i=-1,low=data.m+1;
    for(int a=0;a<data.n;a++)if(!(done>>a&1)){
        int c=__builtin_popcountll(state[a]);if(!c)return 0;if(c<low){low=c;i=a;}}
    if(low>=2&&!rectangular_perfect(state,data.m))return 0;
    Mask choices=state[i];while(choices){
        int j=__builtin_ctzll(choices);choices&=choices-1;auto next=state;next[i]=Mask(1)<<j;bool ok=true;
        for(int a=0;a<data.n;a++)if(a!=i && !(done>>a&1)){
            next[a]&=data.compat[i][j][a];if(!next[a]){ok=false;break;}
        }
        if(ok){int r=third_complete(data,move(next),done|(Mask(1)<<i),visited,lim);if(r)return r;}
    }
    return 0;
}
struct ThirdBranch{int rack=-1,tile=-1;Mask choices=0;double score=-1e50;};
bool third_apply(Engine& e,const vector<int>& ids,int rid,const vector<int>& forced,ThirdBranch& branch,int look){
    const auto& rack=aux_racks[rid];ThirdData g(ids.size(),rack.size(),e.B);
    if(!restrict_third(g,e,ids,rack,rid==0,forced))return false;
    for(int i=0;i<g.n;i++){
        Mask links=g.edges[i];vector<P> unionP(e.B);vector<const P*> shapes;
        while(links){
            int j=__builtin_ctzll(links);links&=links-1;auto state=g.edges;state[i]=Mask(1)<<j;
            int visit=0;if(!third_complete(g,move(state),0,visit,look)){g.edges[i]&=~(Mask(1)<<j);continue;}
            shapes.push_back(&g.shape[i][j]);
            for(int k=0;k<e.B;k++)merge_vertices(unionP[k],g.poses[i][j][k]);
        }
        if(shapes.empty())return false;
        if(forced[i]<0&&shapes.size()>=2){
            P points;Mask t=g.edges[i];int not_hit=0;
            while(t){int j=__builtin_ctzll(t);t&=t-1;points.push_back(rack[j].p);not_hit+=!inside_closed(rack[j].p,e.seed[ids[i]]);}
            auto b=bbox(points);double spread=(b.r-b.l+b.t-b.b)/1e6;
            double rank=15.0/shapes.size()+spread+.9*(not_hit==(int)shapes.size())+.45*(rid==0);
            if(rank>branch.score)branch={rid,i,g.edges[i],rank};
        }
        guaranteed_intersection(e.seed[ids[i]],shapes,e.U);
        for(int k=0;k<e.B;k++)e.init[k][ids[i]]=hull(move(unionP[k]));
    }
    return true;
}
struct RBudget{int limit=100,depth=6,look=2000,nodes=0,passes=1;long tests=0;vector<int> selected;};
bool third_tree(Engine e,const Choices& c,const vector<int>& own,vector<vector<int>> forced,int depth,RBudget& b){
    if(++b.nodes>b.limit)return false;ThirdBranch chosen;int r;
    for(int pass=0;pass<b.passes;pass++){
        chosen=ThirdBranch{};
        for(int rid:b.selected){++b.tests;if(!third_apply(e,c.A,rid,forced[rid],chosen,b.look))return true;}
        if(!cluster_filter(e,c.A)||!propagate(e,c,own,1,8,r))return true;
    }
    if(depth>=b.depth||chosen.rack<0)return false;
    Mask links=chosen.choices;
    while(links){
        int pos=__builtin_ctzll(links);links&=links-1;
        auto f=forced;f[chosen.rack][chosen.tile]=pos;
        if(!third_tree(e,c,own,move(f),depth+1,b))return false;
    }
    return true;
}
