from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'frame.cpp').read_text()
key='if(mode=="frame"){';assert s.count(key)==1;s=s.replace(key,'''if(mode=="orient"){
        int f=stoi(getenv("N20_FINE"));if(f>1)fine(x,data.A,f,base.B*f);
        int pre=stoi(getenv("N20_UNION_PASSES")),sub=stoi(getenv("N20_FRAME_SUB"));
        for(int z=0;z<pre;z++)if(!local_frame(x,data,owners,sub)||!propagate(x,data,owners,1,10,reason)){cout<<"CLOSED "<<(reason?reason:13)<<endl;return 0;}
        int groups=stoi(getenv("N20_FAMILY_ANGLES"));ofstream fo(argv[11]);if(!fo)throw runtime_error("orientation file");fo<<"ORIENT1 "<<x.U<<" "<<x.rows[0].gi<<"\\n";
        auto put=[&](const P& p){fo<<p.size();for(auto z:p)fo<<" "<<z.x<<" "<<z.y;fo<<"\\n";};
        for(int id:data.A){put(x.seed[id]);auto sets=families(x,id,groups,1);fo<<sets.size()<<"\\n";
            for(auto& p:sets){fo<<p.halfangle_lo<<" "<<p.halfangle_hi<<" ";put(p.center);}}
        cout<<"ORIENT"<<endl;return 0;
    }
    '''+key)
p=h/'orient.cpp';p.write_text(s);o=h/'orient.partial';subprocess.run(['g++','-std=c++17','-O3',p,'-o',o],check=True);o.replace(h/'orient')
