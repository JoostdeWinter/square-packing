// In a narrow angle interval use rational coordinates in its midpoint frame.
// Required anchors give an outer center rectangle. The open obstacles from
// every other tile's certified points are removed simultaneously.
struct LocalF{
    I C,S,E,H,outer,edge;
    LocalF(int p,int g,I D){
        auto m=cs(2*p+1,2*g);C=m.c;S=m.s;E=m.d;
        H=D;outer=0;edge=D;
        for(auto l:{cs(p,g),cs(p+1,g)}){
            W dot=(W)C*l.c+(W)S*l.s,cr=abs((I)((W)C*l.s-(W)S*l.c));
            H=min(H,fl((W)D*E*l.d,2*(dot+cr))-2);
            outer=max(outer,-fl(-(W)D*(dot+cr),2*(W)E*l.d));
            edge=min(edge,fl((W)D*(l.c+l.s),2*l.d));
        }if(H<490000||outer>515000)throw runtime_error("local chart too wide");
    }
    Point project(Point p,bool inv=false)const{I s=inv?-S:S;
        return {fl((W)C*p.x+(W)s*p.y,E),fl(-(W)s*p.x+(W)C*p.y,E)};}
    P outer_project(const P& v,bool inv=false)const{
        P out;for(auto p:v){auto t=project(p,inv);for(int i:{0,1})for(int j:{0,1})out.push_back({t.x+i,t.y+j});}return hull(move(out));
    }
    P obstacle(const P& v)const{
        P out;for(auto p:v){auto t=project(p);for(int i:{-1,1})for(int j:{-1,1})out.push_back({t.x+i*H,t.y+j*H});}return hull(move(out));
    }
    P restrict_req(P p,const P& req)const{
        auto b=bbox(outer_project(req));
        for(auto f:vector<HP>{{1,0,b.l+outer+2},{-1,0,-b.r+outer+2},{0,1,b.b+outer+2},{0,-1,-b.t+outer+2}}){
            if(p.empty())return {};if(mx(p,f)>f.k)p=cut(p,f);}
        return p;
    }
    vector<HP> common(const Bound& b)const{
        return {{C,S,(b.l+H)*E},{-C,-S,(-b.r+H)*E},{-S,C,(b.b+H)*E},{S,-C,(-b.t+H)*E}};
    }
};
bool local_frame(Engine& e,const Choices& set,const vector<int>& owners,int sub){
    vector<vector<HP>> normals(e.Z);bool live_chart=false;
    for(int k=0;k<e.B;k++){
        bool any=false;for(int id:set.A)any|=!e.init[k][id].empty();if(!any)continue;
        vector<P> merged(e.Z);
        for(int a=0;a<sub;a++){
            LocalF f(e.rows[k].ki*sub+a,e.rows[k].gi*sub,e.D);vector<UObstacle> ob(e.Z);
            for(int j:set.A){auto p=f.obstacle(e.seed[j]);ob[j]={p,facets(p),bbox(p)};}
            for(int i=0;i<(int)set.A.size();i++){
                int id=set.A[i];if(e.init[k][id].empty())continue;P region=e.init[k][id];
                for(auto t:vector<HP>{{1,0,e.U-f.edge},{0,1,e.U-f.edge},{-1,0,-f.edge},{0,-1,-f.edge}}){
                    if(!region.empty()&&mx(region,t)>t.k)region=cut(region,t);}
                if(region.empty())continue;auto p=f.restrict_req(f.outer_project(region),e.seed[id]);
                if(p.empty())continue;auto bb=bbox(p);vector<UObstacle> ban;
                for(int j:set.A)if(j!=id&&bmatch(ob[j].box,bb))ban.push_back(ob[j]);
                for(int l=0;l<4;l++)if(owners[l]!=i&&owners[l]!=-2){
                    const auto& rack=l>=2?set.blue:set.red;auto q=rack.mark[set.hole[l/2][l%2]];
                    auto obstacle=f.obstacle({q});if(bmatch(bb,bbox(obstacle)))append_uob(ban,move(obstacle));}
                p=union_complement(p,ban);if(p.empty())continue;
                auto nb=f.common(bbox(p));normals[id].insert(normals[id].end(),nb.begin(),nb.end());
                merge_vertices(merged[id],f.outer_project(p,true));live_chart=true;
            }
        }
        for(int id:set.A)if(!e.init[k][id].empty())e.init[k][id]=intersect_outer(e.init[k][id],hull(move(merged[id])));
    }
    if(!live_chart)return false;
    for(int id:set.A){if(normals[id].empty()||none_of(e.init.begin(),e.init.end(),[&](const vector<P>& r){return !r[id].empty();}))return false;
        e.seed[id]=convex_union(e.seed[id],safe(normals[id],e.U));}
    return true;
}
