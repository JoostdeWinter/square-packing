from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'frame.cpp').read_text()
key='vector<vector<HP>> normals(e.Z);bool live_chart=false;';assert s.count(key)==1
s=s.replace(key,'''Engine before=e;
    auto audit=[&](int id){
        const char* name=getenv("N20_FRAME_TRACE");if(!name)return;
        ofstream w(name);if(!w)throw runtime_error("frame audit path");
        int idx=find(set.A.begin(),set.A.end(),id)-set.A.begin();
        w<<"FRAME1 "<<e.U<<" "<<sub<<" "<<e.B<<" "<<idx<<" "<<N<<"\\n";
        auto poly=[&](const P& v){w<<v.size();for(auto p:v)w<<" "<<p.x<<" "<<p.y;w<<"\\n";};
        for(int i:set.A)poly(before.seed[i]);
        vector<Point> miss;for(int l=0;l<4;l++)if(owners[l]!=idx&&owners[l]!=-2){const auto& rack=l>=2?set.blue:set.red;miss.push_back(rack.mark[set.hole[l/2][l%2]]);}
        poly(miss);
        for(int k=0;k<e.B;k++){w<<e.rows[k].ki<<" "<<e.rows[k].gi<<" ";poly(before.init[k][id]);}
    };
    '''+key)
key='if(!live_chart)return false;';assert s.count(key)==1;s=s.replace(key,'if(!live_chart){audit(set.A[0]);return false;}')
key='[&](const vector<P>& r){return !r[id].empty();}))return false;';assert s.count(key)==1;s=s.replace(key,'[&](const vector<P>& r){return !r[id].empty();})){audit(id);return false;}')
p=h/'frame_audit.cpp';p.write_text(s);t=h/'frame_audit.partial';subprocess.run(['g++','-O3','-std=c++17',p,'-o',t],check=True);t.replace(h/'frame_audit')
