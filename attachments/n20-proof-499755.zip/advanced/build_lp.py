from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'tree.cpp').read_text()
k='void save_state(';s=s.replace(k,(h/'lp.inc').read_text()+'\n'+k)
k='if(mode=="tree"){'
s=s.replace(k,'''if(mode=="lp"){
        if(argc<12)throw runtime_error("LP output missing");
        int groups=8;if(const char* setting=getenv("N20_LP_GROUPS"))groups=stoi(setting);
        if(groups<1||groups>128)throw runtime_error("bad linear group count");
        if(const char* f=getenv("N20_FINE")){int fact=stoi(f);if(fact>1)fine(x,data.A,fact,base.B*fact);}
        if(const char* cuts=getenv("N20_EXTRA_CENTER_CUTS")){
            ifstream f(cuts);int i;HP ax;
            while(f>>i>>ax.a>>ax.b>>ax.k){if(i<0||i>=N||abs(ax.a)>100000||abs(ax.b)>100000)throw runtime_error("LP cut range");
                for(int k=0;k<x.B;k++){P& p=x.init[k][data.A[i]];if(!p.empty()&&mx(p,ax)>ax.k)p=cut(p,ax);}}
        }
        if(!cluster_filter(x,data.A)||!propagate(x,data,owners,1,12,reason)){cout<<"CLOSED "<<(reason?reason:10)<<endl;return 0;}
        export_lp(x,data.A,groups,argv[11]);cout<<"MODEL"<<endl;return 0;
    }
    '''+k)
p=h/'linear.cpp';p.write_text(s);subprocess.run(['g++','-O3','-std=c++17',p,'-o',h/'linear'],check=True)
