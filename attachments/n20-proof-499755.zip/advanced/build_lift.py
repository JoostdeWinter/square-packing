from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent
s=(h/'poses.cpp').read_text()
key='void bool_list(ostream&';assert s.count(key)==1
s=s.replace(key,(h/'lift.inc').read_text()+'\n'+key)
key='if(mode=="families"){';assert s.count(key)==1
s=s.replace(key,'''if(mode=="lift"){
        int f=stoi(getenv("N20_FINE"));if(f>1)fine(x,data.A,f,base.B*f);
        int pre=stoi(getenv("N20_LIFT_PRE"));
        for(int n=0;n<pre;n++)if(!direct_centers(x,data.A,8)||!cluster_filter(x,data.A)||!propagate(x,data,owners,1,10,reason)){
            cout<<"CLOSED "<<(reason?reason:11)<<endl;return 0;}
        if(argc<12)throw runtime_error("missing lift file");
        lift_export(x,data.A,stoi(getenv("N20_FAMILY_ANGLES")),stoi(getenv("N20_FAMILY_DIV")),stoi(getenv("N20_LIFT_SECTORS")),argv[11]);
        cout<<"LIFT"<<endl;return 0;
    }
    '''+key)
p=h/'lift.cpp';p.write_text(s);tmp=h/'lift.partial';subprocess.run(['g++','-std=c++17','-O3',p,'-o',tmp],check=True);tmp.replace(h/'lift')
