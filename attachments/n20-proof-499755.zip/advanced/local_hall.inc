// A tile inside a pose family which meets a slot's guaranteed core is the
// only tile that could own that slot. Remove all such foreign edges together
// and re-test the global matching before retaining that pose family.
P lattice_slot(I U,const AuxiliarySite& s,bool grid){
    if(!grid)return {s.p};
    P core={s.p};I D=1000000;
    if(!s.avoider){
        I r=(5*D-U)/10;if(r>0)for(auto p:vector<Point>{{r,0},{0,r},{-r,0},{0,-r}})core.push_back({s.p.x+p.x,s.p.y+p.y});
        return hull(move(core));
    }
    I endpoint=5*D+U;
    auto good=[&](I x,I y){return (W)(10*x+U)*(10*x+U)+(W)(10*y+U)*(10*y+U)<(W)endpoint*endpoint;};
    for(int k=0;k<=32;k++){
        I x=D*k/80;if(!good(x,0))continue;
        I l=0,r=D;while(r-l>1){I mid=(l+r)/2;if(good(x,mid))l=mid;else r=mid;}
        for(int a:{-1,1})for(int b:{-1,1})for(int flip:{0,1}){
            I hx=flip?l:x,hy=flip?x:l;core.push_back({s.p.x+a*hx,s.p.y+b*hy});}
    }
    return hull(move(core));
}
bool local_hall(Engine& e,const vector<int>& ids,int rid,int groups,int div){
    auto& rack=aux_racks[rid];int slots=rack.size();if(slots>63)throw runtime_error("Hall rack width");
    vector<P> body;for(auto& s:rack)body.push_back(lattice_slot(e.U,s,rid==0));
    vector<Mask> graph(N);
    for(int i=0;i<N;i++){
        int id=ids[i];
        for(int s=0;s<slots;s++){
            auto req=convex_union(e.seed[id],body[s]);bool bad=false;
            for(int o:ids)if(o!=id&&intersect_closed(req,e.seed[o])){bad=true;break;}
            if(bad)continue;
            for(int k=0;k<e.B;k++)if(!e.init[k][id].empty()&&!resource_domain(e.init[k][id],e.rows[k],rack[s],rid==0,e.U,e.D).empty()){
                graph[i]|=Mask(1)<<s;break;}
        }
    }
    if(!rectangular_perfect(graph,slots))return false;
    for(int i=0;i<N;i++){
        int id=ids[i];auto all=families(e,id,groups,div);vector<PoseFamily*> live;vector<const P*> cores;
        for(auto& f:all){
            Mask hit=0;for(int s=0;s<slots;s++)if(intersect_closed(f.mandatory,body[s]))hit|=Mask(1)<<s;
            auto g=graph;for(int j=0;j<N;j++)if(i!=j)g[j]&=~hit;
            if(!rectangular_perfect(g,slots))continue;
            // The assigned slot core must also belong to this particular tile.
            Mask opts=g[i];while(opts){
                int j=__builtin_ctzll(opts);opts&=opts-1;
                P req=convex_union(f.mandatory,body[j]);
                bool forbidden=false;for(int v:ids)if(v!=id&&intersect_closed(req,e.seed[v])){forbidden=true;break;}
                if(forbidden){g[i]&=~(Mask(1)<<j);continue;}
                bool possible=false;
                for(int k=0;k<e.B;k++)if(e.rows[k].ki>=f.halfangle_lo&&e.rows[k].ki<f.halfangle_hi&&!e.init[k][id].empty()){
                    P w=intersect_outer(f.center,e.init[k][id]);if(w.empty())continue;
                    if(!resource_domain(move(w),e.rows[k],rack[j],rid==0,e.U,e.D).empty()){possible=true;break;}
                }
                if(!possible)g[i]&=~(Mask(1)<<j);
            }
            if(!rectangular_perfect(g,slots))continue;
            live.push_back(&f);cores.push_back(&f.mandatory);
        }
        if(live.empty())return false;
        guaranteed_intersection(e.seed[id],cores,e.U);
        for(int k=0;k<e.B;k++)if(!e.init[k][id].empty()){
            P p;for(auto f:live)if(f->halfangle_lo<=e.rows[k].ki&&e.rows[k].ki<f->halfangle_hi)merge_vertices(p,intersect_outer(e.init[k][id],f->center));
            e.init[k][id]=hull(move(p));
        }
    }
    return true;
}
