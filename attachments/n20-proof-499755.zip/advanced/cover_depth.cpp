// Certified depths of marked points over entire orientation intervals.
// All geometry and comparisons use integers. h is rounded inward; the
// possible board center polygon and its section ranges are rounded outward.
#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <utility>
#include <vector>
using namespace std;using I=int64_t;using W=__int128_t;using P=pair<I,I>;
I flo(W n,W d){if(d<0){d=-d;n=-n;}return I(n/d-(n<0&&n%d!=0));}
I cei(W n,W d){return -flo(-n,d);}
struct V{I c,s,d;};V dir(I p,I q){return {q*q-p*p,2*p*q,q*q+p*p};}
struct Frame {
    I C,S,E,lo,hi;V l,r;array<P,4> board;I U;
    Frame(int k,int G,I cap):l(dir(k,G)),r(dir(k+1,G)),U(cap){
        const I D=1000000;auto m=dir(2*k+1,2*G);C=m.c;S=m.s;E=m.d;
        lo=min(flo((W)D*(l.c+l.s),2*l.d),flo((W)D*(r.c+r.s),2*r.d));hi=U-lo;
        board={proj({lo,lo}),proj({hi,lo}),proj({hi,hi}),proj({lo,hi})};
    }
    P proj(P p)const{return {C*p.first+S*p.second,C*p.second-S*p.first};}
    I rad(I K)const{
        I h=INT64_MAX;
        for(auto v:{l,r}){
            I dot=C*v.c+S*v.s,cr=abs(C*v.s-S*v.c);
            if(dot<=cr)throw runtime_error("coarse chart");
            h=min(h,flo((W)K*E*E*v.d,2*(W)(dot+cr)));
        }
        return h;
    }
    P xminmax(I b,I t)const{
        I a=INT64_MAX,z=INT64_MIN;
        for(int i=0;i<4;i++){
            auto x=board[i],y=board[(i+1)%4];
            if(b<=x.second&&x.second<=t){a=min(a,x.first);z=max(z,x.first);}
            if(x.second>y.second)swap(x,y);
            if(x.second==y.second)continue;
            for(I Y:{b,t})if(x.second<Y&&Y<y.second){
                I den=y.second-x.second;W num=(W)x.first*den+(W)(y.first-x.first)*(Y-x.second);
                a=min(a,flo(num,den));z=max(z,cei(num,den));}
        }
        if(a>z)throw runtime_error("empty polygon slab");return {a,z};
    }
    bool covered(const vector<P>& pp,I K)const{
        I h=rad(K),loY=INT64_MAX,hiY=INT64_MIN;
        for(auto b:board){loY=min(loY,b.second);hiY=max(hiY,b.second);}
        vector<I> events={loY,hiY};for(auto p:pp)for(I y:{p.second-h,p.second+h})if(loY<y&&y<hiY)events.push_back(y);
        sort(events.begin(),events.end());events.erase(unique(events.begin(),events.end()),events.end());
        for(size_t j=1;j<events.size();j++){
            I bottom=events[j-1],top=events[j];auto [x,z]=xminmax(bottom,top);
            for(auto mark:pp)if(mark.second-h<=bottom&&top<=mark.second+h){
                if(mark.first-h>x)break;
                x=max(x,mark.first+h);if(x>=z)break;
            }
            if(x<z)return false;
        }
        return true;
    }
};
int main(int argc,char**argv){try{
 if(argc!=4)throw runtime_error("moves bins subcharts");
 ifstream f(argv[1]);int N,B=stoi(argv[2]),sub=stoi(argv[3]);I U;f>>N>>U;
 if(!f||N!=22||B<4||B>512||sub<1||B*sub>2048)throw runtime_error("input grid");
 vector<P> sites(N);vector<vector<P>> moves(N);
 for(int i=0;i<N;i++){int m;f>>sites[i].first>>sites[i].second>>m;if(!f||m<0||m>200)throw runtime_error("moves");moves[i].resize(m);
    for(auto& p:moves[i])f>>p.first>>p.second;}
 vector<Frame> frames;for(int k=0;k<B*sub;k++)frames.emplace_back(k,B*sub,U);
 cout<<U<<" "<<B<<" "<<sub<<"\n";
 auto solve=[&](int index,P change){
    auto pts=sites;if(index>=0)pts[index]=change;
    cout<<index<<" "<<change.first<<" "<<change.second;
    for(int i=0;i<B;i++){
      I hi_all=0;
      for(int j=0;j<sub;j++){auto& frame=frames[i*sub+j];vector<P> pp;for(auto p:pts)pp.push_back(frame.proj(p));sort(pp.begin(),pp.end());
         // The full-side cap is supplied by a separate closed or eroded rack proof.
         // Returned full-side entries express no additional reduction.
         int lo=650,hi=1000;while(hi-lo>1){int m=(lo+hi)/2;if(frame.covered(pp,I(m)*1000))hi=m;else lo=m;}
         hi_all=max(hi_all,I(hi)*1000);
      }
      cout<<" "<<hi_all;
    }
    cout<<endl;
 };
 solve(-1,{0,0});for(int i=0;i<N;i++)for(auto p:moves[i])solve(i,p);
}catch(exception&e){cerr<<e.what()<<endl;return 2;}}
