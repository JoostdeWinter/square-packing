struct Split {int index,axis;I at;double rank;};
double state_size(const Engine& e,const vector<int>& ids){
    double s=0;
    for(int id:ids){
        double sum=0;
        for(int k=0;k<e.B;k++)if(!e.init[k][id].empty()){
            auto b=bbox(e.init[k][id]);sum+=((b.r-b.l)/1e6+.025)*((b.t-b.b)/1e6+.025);
        }
        s+=log1p(sum);
    }
    return s;
}
vector<Split> split_choices(const Engine& e,const vector<int>& ids){
    vector<Split> out;
    for(int i=0;i<(int)ids.size();i++){
        int id=ids[i];P all;vector<int> bins;
        for(int k=0;k<e.B;k++)if(!e.init[k][id].empty()){merge_vertices(all,e.init[k][id]);bins.push_back(e.rows[k].ki);}
        if(all.empty())continue;
        auto b=bbox(all);for(int ax:{0,1,3,4}){
            HP n=ax==0?HP{1,0,0}:ax==1?HP{0,1,0}:ax==3?HP{1,1,0}:HP{1,-1,0};
            I lo=mn(all,n),hi=mx(all,n);
            double width=(hi-lo)/1e6*(ax>=3?.62:1);
            if(width>.00001)out.push_back({i,ax,(lo+hi)/2,width});
        }
        if(bins.size()>1){
            int k=bins[bins.size()/2];double size=(double)(bins.back()-bins.front()+1)/e.rows[0].gi;
            out.push_back({i,2,k,size*.49});
        }
    }
    stable_sort(out.begin(),out.end(),[](const Split&a,const Split&b){return a.rank>b.rank;});
    return out;
}
void apply_split(Engine& e,const vector<int>& ids,const Split& s,int sign){
    int id=ids[s.index];for(int k=0;k<e.B;k++){
        auto& p=e.init[k][id];if(p.empty())continue;
        if(s.axis==2){if(sign==1?e.rows[k].ki>=s.at:e.rows[k].ki<s.at)p.clear();}
        else p=half(move(p),s.axis,sign,s.at);
    }
}
struct TreeBudget {int nodes=0,limit=600,depth=11,checks=4,rounds=8;};
bool search_space(Engine x,const Choices& c,const vector<int>& owners,int depth,TreeBudget& budget){
    ++budget.nodes;if(budget.nodes>budget.limit)return false;
    int r=0,w,it;
    if(!cluster_filter(x,c.A))return true;
    if(!propagate(x,c,owners,1,budget.rounds,r))return true;
    if(depth>=budget.depth)return false;
    auto opts=split_choices(x,c.A);vector<Engine> best;double bestscore=1e100;
    vector<int> used;int count=0;
    for(const auto& sp:opts){
        if(find(used.begin(),used.end(),sp.index)!=used.end())continue;
        used.push_back(sp.index);
        vector<Engine> children;double score=0;
        for(int s:{-1,1}){
            auto child=x;apply_split(child,c.A,sp,s);
            if(child.run(c.A,5,w,it))continue;
            score+=state_size(child,c.A);children.push_back(move(child));
        }
        if(children.empty())return true;
        score+=children.size()*1000;
        if(score<bestscore){bestscore=score;best=move(children);}
        if(++count>=budget.checks)break;
    }
    if(best.empty())return false;
    // A single unexcluded child is sufficient to keep this node unresolved.
    for(auto& child:best)if(!search_space(move(child),c,owners,depth+1,budget))return false;
    return true;
}
