from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'tree.cpp').read_text()
s=s.replace('if(!cluster_filter(x,c.A))return true;','if(!cluster_filter(x,c.A)){if(depth==0)cerr<<"root: clusters\\n";return true;}')
s=s.replace('if(!propagate(x,c,owners,1,budget.rounds,r))return true;','if(!propagate(x,c,owners,1,budget.rounds,r)){if(depth==0)cerr<<"root: propagation reason "<<r<<" bins "<<x.B<<"\\n";return true;}')
s=s.replace('if(children.empty())return true;','if(children.empty()){if(depth==0)cerr<<"root: split "<<sp.index<<" "<<sp.axis<<" "<<sp.at<<"\\n";return true;}')
p=h/'diagnostic.cpp';p.write_text(s)
subprocess.run(['g++','-O2','-g0','-std=c++17','-fsanitize=undefined','-fno-sanitize-recover=all',p,'-o',h/'diagnostic'],check=True)
