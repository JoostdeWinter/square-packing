from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'lattice_domains.cpp').read_text()
p='int main(int argc,char** argv)'
if p not in s:p='int main(int argc,char**argv)'
assert s.count(p)==1;s=s.replace(p,'int packing_main(int argc,char** argv)')
a=(h/'frame_controls.inc').read_text();k='SPre pre(e.rows);';assert a.count(k)==1
a=a.replace(k,'if(e.U==5000000){LSearch lattice(e,1,2,1,4);array<Sites,N> labels;labels.fill((Sites(1)<<37)-1);if(!lattice.filter(e,data,labels)||!good_poses(e,ids,m))throw runtime_error("lattice positive control");}\n    '+k)
f=h/'lattice_control.cpp';f.write_text(s+'\n'+a);t=h/'lattice_control.partial';subprocess.run(['g++','-std=c++17','-O2',f,'-o',t],check=True);t.replace(h/'lattice_control')
