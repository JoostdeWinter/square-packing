from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'separators.cpp').read_text();q='int main(int argc,char** argv)';alt='int main(int argc,char**argv)'
if q not in s:q=alt
assert s.count(q)==1;s=s.replace(q,'int geometry_main(int argc,char** argv)')
p=h/'frame_controls.cpp';p.write_text(s+'\n'+(h/'frame_controls.inc').read_text());subprocess.run(['g++','-O2','-std=c++17',p,'-o',h/'frame_controls'],check=True)
