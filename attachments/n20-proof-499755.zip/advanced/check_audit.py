"""Independent arbitrary-precision verifier for a refined angular-cluster exclusion.

Inputs start with the coarse kernel's certified seed and outward center domains.
All subsequent cluster implications are checked as rational polygon inclusions.
"""
from pathlib import Path
from collections import defaultdict,Counter
from itertools import product
from fractions import Fraction as F
from math import floor,ceil
import json,sys,gzip
def det(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def hull(a):
 pts=sorted(set(a))
 if len(pts)<3:return pts
 def chain(points):
  c=[]
  for p in points:
   while len(c)>1 and det(c[-2],c[-1],p)<=0:c.pop()
   c.append(p)
  return c
 return chain(pts)[:-1]+chain(pts[::-1])[:-1]
def facets(p):
 for a,b in zip(p,p[1:]+p[:1]):
  x=b[1]-a[1];y=a[0]-b[0]
  yield x,y,x*a[0]+y*a[1]
def ev(n,p):return n[0]*p[0]+n[1]*p[1]-n[2]
def incl(a,p):
 if not p:return False
 if len(p)==1:return a==p[0]
 if len(p)==2:return det(*p,a)==0 and all(min(x,y)<=u<=max(x,y) for u,x,y in zip(a,p[0],p[1]))
 return all(ev(n,a)<=0 for n in facets(p))
def outer_cut(p,n):
 if not p:return []
 out=[]
 for a,b in zip(p,p[1:]+p[:1]):
  va=ev(n,a);vb=ev(n,b)
  if va<=0:out.append(a)
  if va*vb<0:
   xy=[F(y*va-x*vb,va-vb) for x,y in zip(a,b)]
   out.extend(product(*(set((floor(v),ceil(v))) for v in xy)))
 return hull(out)
def rational_inclusion(p,out,n):
 # Show P intersect the closed exterior of one facet is contained in out,
 # by checking all its rational vertices (no rounding on a cut).
 vals=[ev(n,z) for z in p]
 if max(vals)<0:return True
 f=list(facets(out)) if len(out)>2 else None
 def scaled_inside(X,Y,d):
  if d<0:X,Y,d=-X,-Y,-d
  if f is not None:return all(a*X+b*Y<=d*c for a,b,c in f)
  return incl((F(X,d),F(Y,d)),out)
 for i,z in enumerate(p):
  u=vals[i];j=(i+1)%len(p);w=p[j];v=vals[j]
  if u>=0 and not scaled_inside(*z,1):return False
  if u*v<0 and not scaled_inside(w[0]*u-z[0]*v,w[1]*u-z[1]*v,u-v):return False
 return True
def read_poly(words):
 n=int(words[0]);v=list(map(int,words[1:]));assert len(v)==2*n
 p=list(zip(v[::2],v[1::2]));assert hull(p)==p;return p
def sumfacets(p,q):
 # Build exact Minkowski sums by their grid of vertex sums, independently of
 # the support-function implementation that produced the proposed updates.
 return list(facets(hull((x+X,y+Y) for x,y in p for X,Y in q)))
def verify(path):
 with (gzip.open(path,'rt') if path.suffix=='.gz' else path.open()) as f:
  l=iter(f);words=next(l).split();assert words[0]=='AUDIT1';B,N,U=map(int,words[1:])
  rows=[];indices=[];grids=[]
  for _ in range(B):
   a=next(l).split();assert a[0]=='ROW';indices.append(int(a[1]));grids.append(int(a[2]));rows.append(read_poly(a[3:]))
  assert len(set(grids))==1 and len(set(indices))==B and 0<max(indices)+1<=grids[0]
  seeds={};cells={};count=Counter();raw=Counter()
  for _ in range(N):
   a=next(l).split();assert a[0]=='TILE';i=int(a[1]);seeds[i]=read_poly(a[2:])
   for k in range(B):
    a=next(l).split();assert a[0]=='P';cells[i,k]=read_poly(a[1:]);raw[i]+=bool(cells[i,k])
  bans={};status=None
  for row in l:
   s=row.split()
   if s[0]=='SOURCE':
    src,num=map(int,s[1:]);assert src in seeds
    shapes=[]
    for j in range(num):
     a=next(l).split();assert a[0]=='SHAPE';shapes.append(read_poly(a[1:]))
    used=[k for k in range(B) if cells[src,k]]
    if not used:assert not shapes;continue
    assert shapes;count['sources']+=1
    if len(shapes)==1 and shapes[0]==seeds[src]:pass
    else:
     sites=[p for k in used for p in cells[src,k]]
     X=(min(p[0] for p in sites)+max(p[0] for p in sites))//2;Y=(min(p[1] for p in sites)+max(p[1] for p in sites))//2
     A=(min(indices[k] for k in used)+max(indices[k] for k in used)+1)//2
     groups=defaultdict(list)
     for k in used:
      for xi,yi in product(range(2),repeat=2):
       u=1 if xi else -1;v=1 if yi else -1
       reg=outer_cut(outer_cut(cells[src,k],(u,0,u*X)),(0,v,v*Y))
       if reg:groups[xi+2*yi+4*(indices[k]>=A)].append((k,reg))
     assert len(groups)==len(shapes)
     for shape,g in zip(shapes,sorted(groups),strict=True):
      for z in shape:
       if incl(z,seeds[src]):continue
       for k,reg in groups[g]:
        for a,b,c in facets(rows[k]):
         assert a*z[0]+b*z[1]<=c+min(a*x+b*y for x,y in reg),('bad conditional core',src,k,z)
         count['conditional_inequalities']+=1
    bans={};continue
   if s[0]=='UPDATE':
    i,k=map(int,s[1:3]);out=read_poly(s[3:]);p=cells[i,k];assert p and i!=src
    if k not in bans:bans[k]=set(w for shape in shapes for w in sumfacets(shape,rows[k]))
    for n in bans[k]:
     assert rational_inclusion(p,out,n),('unsafe outside cut',src,i,k,n)
     count['rational_halfplane_inclusions']+=1
    cells[i,k]=out;count['contracted_polygons']+=1
    continue
   assert s[0] in ('IMPOSSIBLE','LIVE');status=s[0]
   if status=='IMPOSSIBLE':
    lost=int(s[1]);assert not any(cells[lost,k] for k in range(B))
   else:lost=None
   break
  assert status and next(l,None) is None
  return {'outcome':status,'empty_tile':lost,'refined_angle_grid':grids[0],'rows':B,'initial_domains':sum(raw.values()),'checks':dict(count)}
if __name__=='__main__':print(json.dumps(verify(Path(sys.argv[1])),indent=2))
