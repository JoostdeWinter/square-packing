from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'poses.cpp').read_text()
key='string sym(int axis,int i)';assert s.count(key)==1;s=s.replace(key,(h/'union.inc').read_text()+'\n'+key)
key='if(mode=="families"){';assert s.count(key)==1
s=s.replace(key,'''if(mode=="union"){
        int f=stoi(getenv("N20_FINE"));if(f>1)fine(x,data.A,f,base.B*f);
        int rounds=stoi(getenv("N20_UNION_PASSES")),conditional=stoi(getenv("N20_UNION_CONDITIONAL"));
        for(int pass=0;pass<rounds;pass++){
            if(!union_prune(x,data,owners,conditional)){cout<<"CLOSED_UNION "<<pass+1<<endl;return 0;}
            if(!cluster_filter(x,data.A)||!propagate(x,data,owners,1,10,reason)){
                cout<<"CLOSED_UNION "<<pass+1<<" "<<reason<<endl;return 0;}
        }cout<<"OPEN_UNION "<<rounds<<endl;return 0;
    }
    '''+key)
p=h/'union.cpp';p.write_text(s);tmp=h/'union.partial';subprocess.run(['g++','-std=c++17','-O3',p,'-o',tmp],check=True);tmp.replace(h/'union')
