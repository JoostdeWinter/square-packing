// Exactly sixteen axis-parallel tiles hit the sixteen integer sites.
// The other four must be lattice misses in four different noncorner cells.
// Seventeen dummy rows may use any of the twenty-one half-integer sites.
// A 37-by-37 perfect matching therefore enforces the exact quota.
bool quota_match(const vector<Mask>& graph,int skip=-1,int reserved=-1){
    vector<Mask> g=graph;Mask holes=((Mask(1)<<37)-1)^((Mask(1)<<16)-1);
    for(int k=0;k<17;k++)g.push_back(holes);
    return rectangular_perfect(g,37,skip,reserved);
}
struct AOption{P core,centers;vector<P> bins;};
struct AQPick{int tile=-1;Mask opts=0;double score=-1e100;};
struct AQTable{vector<Mask> graph;vector<vector<AOption>> opts;vector<vector<array<Mask,N>>> compat;
    AQTable():graph(N),opts(N,vector<AOption>(37)),compat(N,vector<array<Mask,N>>(37)){}};
bool qcompat(const AOption& a,int ia,const AOption& b,int ib){
    if(intersect_closed(a.core,b.core))return false;
    if(ia>=16||ib>=16)return true;
    auto u=bbox(a.centers),v=bbox(b.centers);
    bool xplus=v.r-u.l>1000000,xminus=u.r-v.l>1000000,yplus=v.t-u.b>1000000,yminus=u.t-v.b>1000000;
    // Integer sites are stored with column outermost, row innermost.
    if(ia%4==ib%4)return ia<ib?xplus:xminus;
    if(ia/4==ib/4)return ia<ib?yplus:yminus;
    return xplus||xminus||yplus||yminus;
}
int qsearch(const AQTable& t,vector<Mask> edges,Mask done,int used,int& count,int limit){
    if(++count>limit)return 2;
    int kdone=__builtin_popcountll(done);if(used>4||kdone-used>16)return 0;if(kdone==N)return used==4;
    if(!quota_match(edges))return 0;int i=-1,small=100;
    for(int k=0;k<N;k++)if(!(done>>k&1)){int n=__builtin_popcountll(edges[k]);if(!n)return 0;if(n<small){small=n;i=k;}}
    auto cand=edges[i];while(cand){int s=__builtin_ctzll(cand);cand&=cand-1;auto ch=edges;ch[i]=Mask(1)<<s;bool ok=true;
        for(int v=0;v<N;v++)if(v!=i&&!(done>>v&1)){ch[v]&=t.compat[i][s][v];if(!ch[v]){ok=false;break;}}
        if(ok){int q=qsearch(t,move(ch),done|(Mask(1)<<i),used+(s>=16),count,limit);if(q)return q;}}
    return 0;
}
bool axis_quota(Engine& e,const vector<int>& ids,const array<int,N>& forced,AQPick& pick,bool compat){
    if(e.U!=5000000)throw runtime_error("axis quota normalized side");auto& sites=aux_racks[0];if(sites.size()!=37)throw runtime_error("lattice slots");
    AQTable data;vector<P> slot;for(auto s:sites)slot.push_back(lattice_slot(e.U,s,true));
    for(int i=0;i<N;i++){
        int id=ids[i];for(int j=0;j<37;j++){
            if(forced[i]>=0&&forced[i]!=j)continue;P anchors=convex_union(e.seed[id],slot[j]);bool bad=false;
            for(int v:ids)if(v!=id&&intersect_closed(anchors,e.seed[v])){bad=true;break;}if(bad)continue;
            auto& q=data.opts[i][j];q.bins.resize(e.B);vector<HP> common;auto ab=bbox(anchors);
            for(int k=0;k<e.B;k++)if(!e.init[k][id].empty()){
                const Row& row=e.rows[k];P p=e.init[k][id];
                if(j<16){
                    if(row.ki!=0&&row.ki+1!=row.gi)continue;
                    for(auto n:vector<HP>{{1,0,ab.l+500000},{-1,0,-ab.r+500000},{0,1,ab.b+500000},{0,-1,-ab.t+500000}})if(!p.empty()&&mx(p,n)>n.k)p=cut(p,n);
                }else p=resource_domain(move(p),row,sites[j],true,e.U,e.D);
                if(p.empty())continue;q.bins[k]=p;merge_vertices(q.centers,p);
                if(j>=16)for(auto f:row.fac){f.k+=mn(p,f);common.push_back(f);}
            }
            if(q.centers.empty())continue;q.centers=hull(move(q.centers));
            if(j<16){
                auto b=bbox(q.centers);I l=b.r-500000,r=b.l+500000,bot=b.t-500000,top=b.b+500000;
                if(l<=r&&bot<=top)for(I x:{l,r})for(I y:{bot,top})anchors.push_back({x,y});q.core=hull(move(anchors));
            }else q.core=convex_union(move(anchors),safe(common,e.U));
            for(int v:ids)if(v!=id&&intersect_closed(q.core,e.seed[v])){bad=true;break;}
            if(!bad)data.graph[i]|=Mask(1)<<j;
        }
        if(!data.graph[i])return false;
    }
    if(!quota_match(data.graph))return false;
    for(int i=0;i<N;i++)for(int j=0;j<37;j++)if(data.graph[i]>>j&1){
        if(!quota_match(data.graph,i,j)){data.graph[i]&=~(Mask(1)<<j);continue;}
        for(int v=0;v<N;v++)if(v!=i){
            auto a=data.graph[v]&~(Mask(1)<<j),b=a;while(a){int s=__builtin_ctzll(a);a&=a-1;
                if(!qcompat(data.opts[i][j],j,data.opts[v][s],s))b&=~(Mask(1)<<s);}
            data.compat[i][j][v]=b;
        }
    }
    for(int i=0;i<N;i++){
        vector<P> merged(e.B);vector<const P*> cores;Mask choices=data.graph[i],survive=0;
        while(choices){int j=__builtin_ctzll(choices);choices&=choices-1;
            if(compat){auto g=data.graph;g[i]=Mask(1)<<j;int count=0;if(!qsearch(data,move(g),0,0,count,2500))continue;}
            auto& q=data.opts[i][j];survive|=Mask(1)<<j;cores.push_back(&q.core);
            for(int k=0;k<e.B;k++)merge_vertices(merged[k],q.bins[k]);
        }
        if(!survive)return false;data.graph[i]=survive;guaranteed_intersection(e.seed[ids[i]],cores,e.U);
        for(int k=0;k<e.B;k++)e.init[k][ids[i]]=hull(move(merged[k]));
        int m=__builtin_popcountll(survive);if(m>1){
            bool both=(survive&65535)&&(survive>>16);double rank=15./m+.8*both;
            if(rank>pick.score)pick={i,survive,rank};
        }
    }
    return true;
}
struct AQLimit{int depth=3,budget=25,nodes=0,passes=2;};
bool quota_tree(Engine e,const Choices& c,const vector<int>& o,array<int,N> forced,int dep,AQLimit& lim){
    if(++lim.nodes>lim.budget)return false;AQPick pick;int r;
    for(int p=0;p<lim.passes;p++){pick=AQPick{};
        if(!axis_quota(e,c.A,forced,pick,true)||!local_frame(e,c,o,3)||!cluster_filter(e,c.A)||!propagate(e,c,o,1,10,r))return true;}
    if(dep>=lim.depth||pick.tile<0)return false;Mask options=pick.opts;
    while(options){int j=__builtin_ctzll(options);options&=options-1;auto f=forced;f[pick.tile]=j;
        if(!quota_tree(e,c,o,f,dep+1,lim))return false;}
    return true;
}
