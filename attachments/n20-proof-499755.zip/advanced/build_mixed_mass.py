from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'separators.cpp').read_text()
k='if(e.U==5000000 && outer.size()<3)continue;';assert s.count(k)==1;s=s.replace(k,'')
k='string sym(int axis,int i)';assert s.count(k)==1;s=s.replace(k,(h/'mixed_mass.inc').read_text()+'\n'+k)
k='if(mode=="sep"){';assert s.count(k)==1
s=s.replace(k,'''if(mode=="mixed"){
        int f=stoi(getenv("N20_FINE"));if(f>1)fine(x,data.A,f,base.B*f);
        int passes=stoi(getenv("N20_UNION_PASSES")),sub=stoi(getenv("N20_FRAME_SUB")),an=stoi(getenv("N20_MASS_ANGLES")),div=stoi(getenv("N20_MASS_DIV"));
        MixedMeasure mass(x.U,getenv("N20_MASS_FILE"),stoi(getenv("N20_MASS_PIECES")));
        MResult r;
        for(int pass=0;pass<passes;pass++){
            if(!local_frame(x,data,owners,sub)||!cluster_filter(x,data.A)||!propagate(x,data,owners,1,12,reason)){cout<<"CLOSED_MIXED "<<pass+1<<" geometry"<<endl;return 0;}
            if(pass+1==passes||pass==1){r=mixed_test(x,data,mass,an,div,getenv("N20_MASS_TRACE"));
                if(r.flow<r.required){cout<<"CLOSED_MIXED "<<pass+1<<" measure "<<r.required<<" "<<r.flow<<" "<<r.unavailable<<" "<<r.witness<<endl;return 0;}}
        }cout<<"OPEN_MIXED "<<r.required<<" "<<r.flow<<" "<<r.unavailable<<" "<<mass.unit<<endl;return 0;
    }
    '''+k)
p=h/'mixed_mass.cpp';p.write_text(s);t=h/'mixed_mass.partial';subprocess.run(['g++','-std=c++17','-O3',p,'-o',t],check=True);t.replace(h/'mixed_mass')
