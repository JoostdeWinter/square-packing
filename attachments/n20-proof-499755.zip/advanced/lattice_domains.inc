// Normalize the board to side five while keeping tiles unit size. A tile
// contains a grid point, or its center lies in a rotated square of side
// u-1 about a noncorner cell center (u=cos+sin). Scale center offsets back.
using Sites=uint64_t;
struct LSite{Point pt;bool missed;P body;Bound box;};
struct LChart{vector<HP> normals[2];I reach[2];};
struct LSearch{
    vector<LSite> site;vector<LChart> chart;
    int passes,sub,depth,budget,nodes=0,checks=0,pruned=0;
    LSearch(const Engine& e,int cycles,int parts,int maxdepth,int limit):passes(cycles),sub(parts),depth(maxdepth),budget(limit){
        if(e.D!=1000000 || e.U>5*e.D || e.U%10)throw runtime_error("unavailable normalized grid");
        for(int type=0;type<2;type++)for(int i=type?0:1;i<=4;i++)for(int j=type?0:1;j<=4;j++){
            if(type && (i==0||i==4)&&(j==0||j==4))continue;
            Point p{e.U*(2*i+type)/10,e.U*(2*j+type)/10};P body{p};
            if(type){
                for(I x=0;x<=370000;x+=10000){
                    // K_mu is at least K_1 for mu<=1. The chosen points lie
                    // strictly inside (|x|+.5)^2 + (|y|+.5)^2 < 1.
                    I lo=0,hi=370001;if((W)(x+500000)*(x+500000)+(W)500000*500000>=(W)e.D*e.D)continue;
                    while(hi-lo>1){I y=(lo+hi)/2;if((W)(x+500000)*(x+500000)+(W)(y+500000)*(y+500000)<(W)e.D*e.D)lo=y;else hi=y;}
                    for(I a:{-1,1})for(I b:{-1,1})body.push_back({p.x+a*x,p.y+b*lo});
                }
            }
            body=hull(move(body));site.push_back({p,(bool)type,body,bbox(body)});
        }
        if(site.size()!=37)throw runtime_error("lattice site count");
        for(auto& row:e.rows){
            auto a=cs(row.ki,row.gi),b=cs(row.ki+1,row.gi);
            I upper=max(-fl(-(W)e.D*(a.c+a.s),a.d),-fl(-(W)e.D*(b.c+b.s),b.d));
            if(a.c>a.s && b.c<b.s)upper=1414214;
            LChart ch;
            for(int t=0;t<2;t++){
                I side=t?upper-e.D:e.D;W num=(W)e.U*side,den=(W)5*e.D*e.D;
                ch.reach[t]=-fl(-num*upper,2*den);
                for(auto n:row.axes){n.k=-fl(-num*n.k,den);ch.normals[t].push_back(n);}
            }
            chart.push_back(move(ch));
        }
    }
    P cut_site(P p,int k,int q)const{
        if(p.empty())return {};
        auto& st=site[q];const auto& ch=chart[k];I r=ch.reach[st.missed];auto b=bbox(p);
        if(b.r<st.pt.x-r||b.l>st.pt.x+r||b.t<st.pt.y-r||b.b>st.pt.y+r)return {};
        for(auto n:ch.normals[st.missed]){
            n.k+=dot(n,st.pt);if(mn(p,n)>n.k)return {};if(mx(p,n)>n.k)p=cut(p,n);
            if(p.empty())return {};
        }
        return p;
    }
    bool matching(const array<Sites,N>& masks,int fixed=-1,int chosen=-1){
        array<int,37> owner;owner.fill(-1);
        if(fixed>=0)owner[chosen]=fixed;
        auto aug=[&](auto&& self,int id,Sites& seen)->bool{
            Sites m=masks[id]&~seen;
            while(m){int q=__builtin_ctzll(m);m&=m-1;Sites b=Sites(1)<<q;if(seen&b)continue;seen|=b;
                int other=owner[q];if(other<0||(other!=fixed&&self(self,other,seen))){owner[q]=id;return true;}}
            return false;
        };
        for(int i=0;i<N;i++)if(i!=fixed){Sites seen=0;if(!aug(aug,i,seen))return false;}return true;
    }
    bool filter(Engine& e,const Choices& choice,array<Sites,N>& masks){
        array<Bound,N> bounds;vector<vector<P>> core(N,vector<P>(site.size()));
        vector<vector<Bound>> cb(N,vector<Bound>(site.size()));
        for(int i=0;i<N;i++)bounds[i]=bbox(e.seed[choice.A[i]]);
        for(int i=0;i<N;i++){
            int id=choice.A[i];Sites alive=0,opts=masks[i];while(opts){int q=__builtin_ctzll(opts);opts&=opts-1;
                bool possible=false;for(int k=0;k<e.B&&!possible;k++)possible=!cut_site(e.init[k][id],k,q).empty();
                if(!possible)continue;
                auto& sq=site[q];P anchored=convex_union(e.seed[id],sq.body);auto span=bbox(anchored);
                for(int j=0;j<N&&possible;j++)if(j!=i&&bmatch(span,bounds[j])&&intersect_closed(anchored,e.seed[choice.A[j]]))possible=false;
                if(possible){core[i][q]=move(anchored);cb[i][q]=span;alive|=Sites(1)<<q;}
            }
            if(!alive)return false;masks[i]=alive;
        }
        if(!matching(masks))return false;
        vector<vector<array<Sites,N>>> compatible(N,vector<array<Sites,N>>(site.size()));
        for(int i=0;i<N;i++){
            Sites qi=masks[i];while(qi){int q=__builtin_ctzll(qi);qi&=qi-1;
                auto& allow=compatible[i][q];allow=masks;
                for(int j=0;j<N;j++)if(j!=i){
                    Sites choices=masks[j]&~(Sites(1)<<q),ok=0;
                    while(choices){int s=__builtin_ctzll(choices);choices&=choices-1;
                        if(!bmatch(cb[i][q],cb[j][s])||!intersect_closed(core[i][q],core[j][s]))ok|=Sites(1)<<s;
                    }allow[j]=ok;
                }
            }
        }
        bool changed=true;while(changed){
            changed=false;
            for(int i=0;i<N;i++){
                Sites qset=masks[i];while(qset){int q=__builtin_ctzll(qset);qset&=qset-1;
                    auto allowed=compatible[i][q];for(int j=0;j<N;j++)allowed[j]&=masks[j];
                    if(!matching(allowed,i,q)){masks[i]&=~(Sites(1)<<q);pruned++;changed=true;}}
                if(!masks[i])return false;
            }
        }
        for(int i=0;i<N;i++){
            int id=choice.A[i];Sites opts=masks[i];vector<const P*> possible;
            Sites qs=opts;while(qs){int q=__builtin_ctzll(qs);qs&=qs-1;possible.push_back(&core[i][q]);}
            guaranteed_intersection(e.seed[id],possible,e.U);
            for(int k=0;k<e.B;k++){
                P& p=e.init[k][id];if(p.empty())continue;P keep;Sites a=opts;
                while(a){int q=__builtin_ctzll(a);a&=a-1;auto z=cut_site(p,k,q);
                    merge_vertices(keep,z);if(p==z){keep=p;break;}}
                p=hull(move(keep));
            }
        }
        return true;
    }
    bool search(Engine e,const Choices& c,const vector<int>& own,array<Sites,N> opts,int level){
        if(++nodes>budget)return false;int reason=0;
        for(int p=0;p<passes;p++){
            if(!filter(e,c,opts)||!local_frame(e,c,own,sub)||!cluster_filter(e,c.A)||!propagate(e,c,own,1,12,reason))return true;
            checks++;
        }
        if(level==depth || nodes>=budget)return false;
        int j=-1,least=38;for(int i=0;i<N;i++){int n=__builtin_popcountll(opts[i]);if(n>1&&n<least){least=n;j=i;}}
        if(j<0)return false;Sites a=opts[j];
        while(a){int q=__builtin_ctzll(a);a&=a-1;auto child=opts;child[j]=Sites(1)<<q;
            if(!search(e,c,own,child,level+1))return false;}
        return true;
    }
};
