from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
import os,sys,itertools,json
import subprocess
h=Path(__file__).resolve().parents[1];root=h.parent
def main(side,b,r,cycles,workers,tag):
 extra=h/'advanced'/('racks500.txt' if side==500 else f'racks{side}_3.txt')
 extra=Path(os.environ.get('N20_EXTRA_RACKS',extra));moves=Path(os.environ.get('N20_MOVE_FILE',h/'enumerator'/f'marks{side}.txt'));exe=Path(os.environ.get('N20_BINARY',h/'advanced/advanced'))
 if not extra.is_file():raise ValueError('uncertified extra racks')
 env=dict(os.environ,N20_EXTRA_RACKS=str(extra))
 d=h/'trials'/f'profiles{side}_{tag}';d.mkdir(exist_ok=True)
 table=h/'trials'/f'b{side}'/f'i{b}'
 if not table.is_file():table=root/'important_20261120'/f'b{side}'/f'i{b}'
 points=[tuple(map(int,s.split()[:2])) for s in moves.read_text().splitlines()[1:]]
 U=side*10000
 maps=[[points.index((U-x if i else x,U-y if j else y)) for x,y in points]for i,j in itertools.product(range(2),repeat=2)]
 act=lambda m,g:sum(1<<g[i] for i in range(22) if m>>i&1)
 masks=sorted((1<<22)-1-(1<<i)-(1<<j) for i,j in itertools.combinations(range(22),2))
 # Compute all 231 profiles because their orientation limits are in physical coordinates.
 # Put one representative of each orbit first for early feedback.
 masks.sort(key=lambda m:(m!=3932151,m!=min(act(m,g) for g in maps),m))
 def one(m):
  path=d/str(m);tmp=d/('partial_'+str(m));tmp.mkdir(exist_ok=True)
  if not path.exists():
   cmd=[exe,'profile',table,tmp,moves,str(m),str(m),str(r),str(cycles)]
   ans=subprocess.check_output(cmd,text=True,env=env).split();assert len(ans)==2 and int(ans[0])==m
   (tmp/str(m)).replace(path)
  tmp.rmdir()
  u,n,z,x,rc=map(int,path.open().readline().split());assert u==U and n==b and z==22 and x==m
  return m,rc
 status={}
 with ThreadPoolExecutor(workers) as ex:
  for fu in as_completed([ex.submit(one,m) for m in masks]):
   m,rc=fu.result();status[m]=rc
   if len(status)%12==0 or len(status)==len(masks):print(len(status),'of',len(masks),'closed',sum(v>0 for v in status.values()),flush=True)
 (d/'summary.json').write_text(json.dumps(status))
if __name__=='__main__':main(*[int(x) for x in sys.argv[1:6]],sys.argv[6])
