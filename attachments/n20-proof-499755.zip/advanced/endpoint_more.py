"""Construct and certify single- and multiple-point variants of Bentz's endpoint racks."""
from concurrent.futures import ProcessPoolExecutor,as_completed
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import argparse,json,sys
from endpoint_cover import prove,U
h=Path(__file__).resolve().parents[1];folder=h/'trials/endpoint_marks'
def get(r):
 a=list(map(int,r.split()));return tuple(zip(a[1::2],a[2::2]))
def base():
 return [tuple(map(int,x.split()[:2])) for x in (h/'enumerator/marks500.txt').read_text().splitlines()[1:]]
def reflection(points):
 for sw,rx,ry in product(range(2),repeat=3):
  yield tuple(sorted((U-p[sw] if rx else p[sw],U-p[1-sw] if ry else p[1-sw]) for p in points))
def candidates():
 p=base();left=p.index((500000,1700000))
 for x,y in [(1000000,1700000),(975000,1700000),(950000,1700000),(925000,1700000),(800000,2000000),(800000,1400000),(850000,1900000),(850000,1500000),(900000,1800000),(900000,1600000),(950000,1750000),(950000,1650000)]:
  row=p.copy();row[left]=(x,y);yield f'{left}_{x}_{y}',row,(left,x,y)
 # Move only boundary marks from the five-point rows or replace several rows
 # of either parity simultaneously. Every returned pattern is checked separately.
 q=list(get((h/'advanced/racks500.txt').read_text().splitlines()[1]))
 for color,pts in enumerate((p,q)):
  for amt in (100000,200000,300000,390000,450000,500000):
   for style in ('left','inward','outward_y','rows_plus','zig','both_zig','three_rows'):
    new=[]
    for x,y in pts:
     if style in ('left','inward') and x==500000:x+=amt
     elif style=='inward' and x==4500000:x-=amt
     elif style=='outward_y' and x in (500000,4500000):
      x+=amt if x<2500000 else -amt;y+=amt//2 if y>2500000 else -amt//2
     elif style in ('rows_plus','zig','both_zig') and y in (1700000,3300000):x+=amt if style=='rows_plus' or y<2500000 else -amt
     elif style=='both_zig' and y in (900000,4100000):x+=-amt if y<2500000 else amt
     elif style=='three_rows' and y in (900000,2500000,4100000):x+=amt
     new.append((x,y))
    if set(new)!=set(pts):yield f'whole_{color}_{style}_{amt}',new,(-2,color,amt)
def assemble():
 p=base();moves=[set() for z in p];extra=set();checked={}
 for f in sorted(folder.glob('*.json')):
  z=json.loads(f.read_text())
  if not z['proof']:continue
  i,x,y=z['change'];new=z['points'];checked[z['key']]=z['proof']['interval_count']
  if i>=0:
   for a,b in product(range(2),repeat=2):
    t=lambda a0,b0:(U-a0 if a else a0,U-b0 if b else b0)
    moves[p.index(t(*p[i]))].add(t(x,y))
  elif i==-2:extra.update(reflection(new))
 other=list(get((h/'advanced/racks500.txt').read_text().splitlines()[1]))
 main=[tuple(sorted(other)),tuple(sorted((U-y,x) for x,y in other))]
 extra-=set(reflection(p));extra-=set(main)
 racks=main+sorted(extra)
 # Select some geometrically different variants before using the remainder.
 def distance(a,b):
  return sum(min(abs(x-X)+abs(y-Y) for X,Y in b) for x,y in a)+sum(min(abs(x-X)+abs(y-Y) for X,Y in a) for x,y in b)
 chosen=racks[:2];rem=racks[2:]
 while rem and len(chosen)<50:
  r=max(rem,key=lambda a:min(distance(a,b) for b in chosen));rem.remove(r);chosen.append(r)
 for n in sorted({2,min(6,len(chosen)),min(14,len(chosen)),len(chosen)}):
  (h/'advanced'/f'endpoint_racks_{n}.txt').write_text(f'{U} {n}\n'+'\n'.join(' '.join(map(str,[len(r),*[v for z in r for v in z]])) for r in chosen[:n])+'\n')
 (h/'advanced/endpoint_moves.txt').write_text(f'22 {U}\n'+'\n'.join(' '.join(map(str,[*z,len(r),*[v for w in sorted(r) for v in w]])) for z,r in zip(p,moves))+'\n')
 print('certified patterns',len(checked),'moved sites',sum(map(len,moves)),'full available',len(racks),'selected',len(chosen))
 (h/'runs/endpoint_movements.json').write_text(json.dumps({'sides':U,'certified':checked,'moved_sites':sum(map(len,moves)),'available_full':len(racks),'selected':len(chosen)},indent=2))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=2);ap.add_argument('--assemble',action='store_true');v=ap.parse_args()
 if v.assemble:return assemble()
 with ProcessPoolExecutor(v.workers) as pool:
  work={pool.submit(prove,p):(k,p,c) for k,p,c in candidates() if not (folder/(k+'.json')).exists()}
  for fu in as_completed(work):
   k,p,c=work[fu];q=fu.result();(folder/(k+'.json')).write_text(json.dumps({'key':k,'points':p,'change':c,'proof':q},separators=(',',':')))
   print(k,'covered' if q else 'unproved',flush=True)
 assemble()
if __name__=='__main__':main()
