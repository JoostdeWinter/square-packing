from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'smt.cpp').read_text()
def once(a,b):
 global s
 assert s.count(a)==1,a;s=s.replace(a,b)
once('struct AuxiliarySite {Point p;bool avoider=false;};','struct AuxiliarySite {Point p;bool avoider=false;int wall=-1;I shift=0;};')
once('void read_extra(I U){',(h/'shifted.inc').read_text()+'\nvoid read_extra(I U){')
once('if(U%10)throw runtime_error','load_shifted(U);\n    if(U%10)throw runtime_error')
key='I u=site.avoider ? u_upper(row,D)-D : D;'
once(key,'''if(site.wall>=0 && !p.empty()){
        I extent=site.shift+(u_upper(row,D)+1)/2;
        int axis=site.wall/2,far=site.wall%2;
        I pos=far?U-extent:extent,sign=far?-1:1;
        HP wall{axis?0:sign,axis?sign:0,sign*pos};
        if(mn(p,wall)>wall.k)return {};
        if(mx(p,wall)>wall.k)p=cut(p,wall);
    }
    '''+key)
p=h/'shift.cpp';p.write_text(s);tmp=h/'shift.partial';subprocess.run(['g++','-O3','-std=c++17',p,'-o',tmp],check=True);tmp.replace(h/'shift')
