from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'union.cpp').read_text()
key='string sym(int axis,int i)';assert s.count(key)==1;s=s.replace(key,(h/'localframe.inc').read_text()+'\n'+key)
key='if(mode=="union"){';assert s.count(key)==1
s=s.replace(key,'''if(mode=="frame"){
        int f=stoi(getenv("N20_FINE"));if(f>1)fine(x,data.A,f,base.B*f);
        int rounds=stoi(getenv("N20_UNION_PASSES")),sub=stoi(getenv("N20_FRAME_SUB"));
        if(sub<1||sub*x.rows[0].gi>4096)throw runtime_error("frame subdivision");
        for(int pass=0;pass<rounds;pass++){
            if(!local_frame(x,data,owners,sub)){cout<<"CLOSED_FRAME "<<pass+1<<endl;return 0;}
            if(!cluster_filter(x,data.A)||!propagate(x,data,owners,1,12,reason)){
                cout<<"CLOSED_FRAME "<<pass+1<<" "<<reason<<endl;return 0;}
        }cout<<"OPEN_FRAME "<<rounds<<endl;return 0;
    }
    '''+key)
p=h/'frame.cpp';p.write_text(s);tmp=h/'frame.partial';subprocess.run(['g++','-std=c++17','-O3',p,'-o',tmp],check=True);tmp.replace(h/'frame')
