"""Generate an exact-axis plus continuous-angle interval endpoint verifier."""
from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'separators.cpp').read_text()
k='struct FrameGroup {P centers;P inner;};';assert s.count(k)==1
s=s.replace(k,'''I menu_p=0,menu_q=1;
bool pure_menu_axis(const Row& r){return menu_p && r.ki==0 && (I)(r.ki+1)*menu_q<menu_p*r.gi;}
void enforce_menu(Engine& e,const vector<int>& ids){
    if(!menu_p||e.U!=5000000)throw runtime_error("invalid use of angle menu");
    for(int k=0;k<e.B;k++){
        auto& r=e.rows[k];bool interval=(I)(r.ki+1)*menu_q>=menu_p*r.gi && (I)r.ki*(menu_q+menu_p)<=(menu_q-menu_p)*r.gi;
        if(r.ki==0&&!interval){
            I h=e.D/2;r.axes={HP{1,0,h},HP{-1,0,h},HP{0,1,h},HP{0,-1,h}};
            r.core={{-h,-h},{h,-h},{h,h},{-h,h}};r.fac=facets(r.core);
            for(int i:ids)if(!e.init[k][i].empty())for(auto z:r.axes){
                z.k+=mn(e.seed[i],z);if(!e.init[k][i].empty()&&mx(e.init[k][i],z)>z.k)e.init[k][i]=cut(e.init[k][i],z);
            }
        }else if(!interval){for(int i:ids)e.init[k][i].clear();}
    }
}
'''+k)
k='vector<vector<int>> bins(lanes);vector<FrameGroup> out;';assert s.count(k)==1;s=s.replace(k,'vector<vector<int>> bins(lanes+1);vector<FrameGroup> out;')
k='bins[min(lanes-1,lanes*e.rows[k].ki/e.rows[k].gi)].push_back(k);';assert s.count(k)==1;s=s.replace(k,'bins[pure_menu_axis(e.rows[k])?0:1+min(lanes-1,lanes*e.rows[k].ki/e.rows[k].gi)].push_back(k);')
k='out.push_back({move(p),centered_core(use,e)});';assert s.count(k)==1;s=s.replace(k,'out.push_back({move(p),pure_menu_axis(e.rows[use.front()])?e.rows[use.front()].core:centered_core(use,e)});')
k='    long blockers=0,orcl=0,terms=0;';assert s.count(k)==1;s=s.replace(k,k+'\n    map<pair<int,int>,vector<string>> menu_sites;')
k='if(sel!="true")out<<"(declare-const "<<sel<<" Bool)\\n";';assert s.count(k)==1
s=s.replace(k,k+'''
            bool axis_group=g==0 && menu_p && any_of(e.rows.begin(),e.rows.end(),[&](const Row& row){size_t l=&row-e.rows.data();return pure_menu_axis(row)&&!e.init[l][ids[i]].empty();});
            if(axis_group){
                auto bounds=bbox(gs[g].centers);vector<string> local;auto X=sym(0,i),Y=sym(1,i);
                for(int a=1;a<=4;a++)for(int b=1;b<=4;b++){
                    I xl=e.D*a-e.D/2,xh=xl+e.D,yl=e.D*b-e.D/2,yh=yl+e.D;
                    if(bounds.r<=xl||bounds.l>=xh||bounds.t<=yl||bounds.b>=yh)continue;
                    string name="site_"+to_string(i)+"_"+to_string(a)+"_"+to_string(b);local.push_back(name);menu_sites[{a,b}].push_back(name);
                    out<<"(declare-const "<<name<<" Bool) (assert (=> "<<name<<" (and "<<sel<<" (< "<<xl<<" "<<X<<" "<<xh<<") (< "<<yl<<" "<<Y<<" "<<yh<<"))))\\n";
                }
                out<<"(assert (=> "<<sel<<" ";bool_list(out,local);out<<"))\\n";
                out<<"(assert (=> "<<sel<<" (and (< 500000 "<<X<<" 4500000) (< 500000 "<<Y<<" 4500000))))\\n";
            }''')
k='    out<<"; pair constraints "';assert s.count(k)==1;s=s.replace(k,'''    for(auto& item:menu_sites){auto& v=item.second;for(size_t a=0;a<v.size();a++)for(size_t b=0;b<a;b++)out<<"(assert (or (not "<<v[a]<<") (not "<<v[b]<<")))\\n";}
'''+k)
k='if(mode=="sep"){';assert s.count(k)==1
s=s.replace(k,'''if(mode=="anglemenu"){
        if(argc<12||!getenv("N20_MENU"))throw runtime_error("angle menu requires output file");
        istringstream spec(getenv("N20_MENU"));int lanes;spec>>menu_p>>menu_q>>lanes;
        if(!spec||menu_p<=0||menu_q<=0||menu_p>=menu_q||menu_q>1000000||lanes<2||lanes>128)throw runtime_error("invalid menu parameters");
        int f=stoi(getenv("N20_FINE"));if(f>1)fine(x,data.A,f,base.B*f);
        enforce_menu(x,data.A);
        for(int pass=0;pass<stoi(getenv("N20_UNION_PASSES"));pass++){
            if(!propagate(x,data,owners,1,10,reason)||!local_frame(x,data,owners,stoi(getenv("N20_FRAME_SUB")))||!cluster_filter(x,data.A)){cout<<"CLOSED_MENU "<<pass+1<<endl;return 0;}
        }
        export_disj(x,data.A,lanes,argv[11],true);cout<<"EXPORTED_MENU"<<endl;return 0;
    }
    '''+k)
p=h/'angle_menu.cpp';p.write_text(s);t=h/'angle_menu.partial';subprocess.run(['g++','-O3','-std=c++17',p,'-o',t],check=True);t.replace(h/'angle_menu')
