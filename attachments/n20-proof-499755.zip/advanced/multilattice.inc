// Independent square lattices share the very same physical pose domains.
// Rotations use Pythagorean rational directions. Translations are in
// quarter lattice units and are applied after rotation.
struct MLSearch{
    vector<LSearch> grids;int passes,sub,depth,budget,nodes=0,passes_used=0;
    MLSearch(const Engine& e,int p,int s,int d,int n,int count):passes(p),sub(s),depth(d),budget(n){
        vector<array<int,5>> cfg={{1,0,1,0,0},{4,3,5,0,0},{4,-3,5,0,0},{24,7,25,0,0},{24,-7,25,0,0},{1,0,1,1,0},{1,0,1,0,1},{1,0,1,-1,0},{1,0,1,0,-1},{4,3,5,1,1},{4,-3,5,-1,1},{7,24,25,1,-1},{24,-7,25,1,1},{1,0,1,2,2},{1,0,1,1,1}};
        if(count<1||count>(int)cfg.size())throw runtime_error("lattice count");
        for(int i=0;i<count;i++){
            auto a=cfg[i];if(e.U%(20*a[2]))continue;
            grids.emplace_back(e,1,1,0,1,a[0],a[1],a[2],a[3],a[4]);
        }
        if(grids.empty())throw runtime_error("no exact lattice");
    }
    using Domains=vector<array<Sites,N>>;
    Domains initial()const{Domains d(grids.size());for(int f=0;f<(int)grids.size();f++)d[f].fill((Sites(1)<<grids[f].site.size())-1);return d;}
    bool solve(Engine e,const Choices& c,const vector<int>& own,Domains opts,int level){
        if(++nodes>budget)return false;int reason=0;
        for(int n=0;n<passes;n++){
            for(int f=0;f<(int)grids.size();f++)if(!grids[f].filter(e,c,opts[f]))return true;
            if(!local_frame(e,c,own,sub)||!cluster_filter(e,c.A)||!propagate(e,c,own,1,12,reason))return true;passes_used++;
        }
        if(level>=depth||nodes>=budget)return false;
        int fbest=-1,ibest=-1,least=65;for(int f=0;f<(int)grids.size();f++)for(int i=0;i<N;i++){
            int k=__builtin_popcountll(opts[f][i]);if(k>1&&k<least){least=k;fbest=f;ibest=i;}}
        if(ibest<0)return false;
        Sites a=opts[fbest][ibest];while(a){
            int q=__builtin_ctzll(a);a&=a-1;auto copy=opts;copy[fbest][ibest]=Sites(1)<<q;
            if(!solve(e,c,own,move(copy),level+1))return false;
        }
        return true;
    }
};
