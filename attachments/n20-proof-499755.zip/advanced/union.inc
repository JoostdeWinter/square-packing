// Complete complement of a union of open convex obstacles on a center chart.
// Every extreme point is on an edge of the outer chart or of an obstacle.
// We clip each such edge against the chart and remove all open forbidden
// intervals jointly. Rational endpoint tests precede outward rounding.
struct RatU{I n,d;};
RatU urat(I n,I d){if(d<0){n=-n;d=-d;}if(!d)throw runtime_error("infinite fraction");return {n,d};}
bool ult(RatU a,RatU b){return (W)a.n*b.d<(W)b.n*a.d;}
RatU umax(RatU a,RatU b){return ult(a,b)?b:a;}
RatU umin(RatU a,RatU b){return ult(a,b)?a:b;}
struct USegment{RatU a,b;};
struct UObstacle{P vertices;vector<HP> fs;Bound box;};
bool closed_interval(Point a,Point b,const vector<HP>& fs,USegment& z,bool open){
    for(auto f:fs){I s=eval(f,a),t=eval(f,b);
        if(s==t){if(open?s>=0:s>0)return false;continue;}
        if(s<t)z.b=umin(z.b,urat(-s,t-s));
        else z.a=umax(z.a,urat(-s,t-s));
        if(open?!ult(z.a,z.b):ult(z.b,z.a))return false;
    }
    return true;
}
void uadd(P& out,Point p,Point q,RatU t){
    W x=(W)p.x*t.d+(W)(q.x-p.x)*t.n,y=(W)p.y*t.d+(W)(q.y-p.y)*t.n;
    I l=fl(x,t.d),r=-fl(-x,t.d),b=fl(y,t.d),u=-fl(-y,t.d);
    out.push_back({l,b});out.push_back({r,b});out.push_back({l,u});out.push_back({r,u});
}
bool uinside(const UObstacle& o,Point p){
    if(p.x<=o.box.l||p.x>=o.box.r||p.y<=o.box.b||p.y>=o.box.t)return false;
    for(auto h:o.fs)if(eval(h,p)>=0)return false;return true;
}
P union_complement(const P& domain,const vector<UObstacle>& all){
    if(domain.size()<3)return domain;auto box=bbox(domain);vector<const UObstacle*> obs;
    for(auto& o:all){
        if(o.box.l>=box.r||o.box.r<=box.l||o.box.t<=box.b||o.box.b>=box.t)continue;
        bool apart=false;for(auto f:o.fs)if(mn(domain,f)>=f.k){apart=true;break;}
        if(!apart)obs.push_back(&o);
    }
    if(obs.empty())return domain;
    bool all_ok=true;for(auto p:domain){for(auto o:obs)if(uinside(*o,p)){all_ok=false;break;}if(!all_ok)break;}
    if(all_ok)return domain;
    auto cap=facets(domain);P keep;
    auto edge=[&](Point a,Point b,int origin){
        USegment part{{0,1},{1,1}};
        if(origin>=0&&!closed_interval(a,b,cap,part,false))return;
        vector<USegment> removed;vector<RatU> locations={part.a,part.b};
        for(int i=0;i<(int)obs.size();i++)if(i!=origin){
            auto& o=*obs[i];if(max(a.x,b.x)<=o.box.l||min(a.x,b.x)>=o.box.r||
                max(a.y,b.y)<=o.box.b||min(a.y,b.y)>=o.box.t)continue;
            USegment z{{-1,1},{2,1}};if(!closed_interval(a,b,o.fs,z,true))continue;
            if(!ult(z.a,part.b)||!ult(part.a,z.b)){
                if(ult(part.a,part.b)||!ult(z.a,part.a)||!ult(part.a,z.b))continue;
            }
            if(ult(z.a,part.a)&&ult(part.b,z.b))return;
            removed.push_back(z);
            for(RatU t:{z.a,z.b})if(!ult(t,part.a)&&!ult(part.b,t))locations.push_back(t);
        }
        for(RatU t:locations){bool blocked=false;
            for(auto z:removed)if(ult(z.a,t)&&ult(t,z.b)){blocked=true;break;}
            if(!blocked)uadd(keep,a,b,t);
        }
    };
    for(int i=-1;i<(int)obs.size();i++){
        auto& v=i<0?domain:obs[i]->vertices;
        auto a=v.back();for(auto b:v){edge(a,b,i);a=b;}
    }
    return hull(move(keep));
}
void append_uob(vector<UObstacle>& os,P p){
    p=hull(move(p));if(p.size()<3)return;
    auto b=bbox(p);auto f=facets(p);os.push_back({move(p),move(f),b});
}
bool union_prune(Engine& e,const Choices& c,const vector<int>& owners,bool conditional){
    vector<vector<P>> opts(e.Z);if(conditional)for(int j:c.A)opts[j]=conditional_cores(e,j);
    for(int k=0;k<e.B;k++){
        bool live=false;for(int j:c.A)live|=!e.init[k][j].empty();if(!live)continue;
        vector<vector<UObstacle>> blockers(e.Z);
        for(int j:c.A){
            if(e.seed[j].empty())continue;auto plain=mink(e.seed[j],e.rows[k].core,false);
            append_uob(blockers[j],plain);
            if(conditional && opts[j].size()>1){
                vector<HP> plane;for(auto& z:opts[j]){
                    auto p=mink(z,e.rows[k].core,false);auto fs=facets(p);plane.insert(plane.end(),fs.begin(),fs.end());}
                auto stronger=safe(plane,e.U);if(stronger.size()>=3)append_uob(blockers[j],convex_union(plain,stronger));
            }
        }
        for(int i=0;i<(int)c.A.size();i++){
            int id=c.A[i];auto& poly=e.init[k][id];if(poly.empty())continue;
            vector<UObstacle> forbidden;
            auto box=bbox(poly);
            for(int j:c.A)if(j!=id)for(auto& q:blockers[j])if(bmatch(q.box,box))forbidden.push_back(q);
            for(int l=0;l<4;l++)if(owners[l]!=-2&&owners[l]!=i){
                const auto& rack=l>=2?c.blue:c.red;auto v=rack.mark[c.hole[l/2][l%2]];
                P p;for(auto u:e.rows[k].core)p.push_back({u.x+v.x,u.y+v.y});append_uob(forbidden,move(p));
            }
            poly=union_complement(poly,forbidden);
        }
    }
    for(int id:c.A)if(none_of(e.init.begin(),e.init.end(),[&](const vector<P>& v){return !v[id].empty();}))return false;
    return true;
}
