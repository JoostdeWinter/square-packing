"""A linear mixed-integer outer relaxation which shares every physical tilt.

A true pose assigns the actual sine, cosine and every product used below.
Four McCormick planes bound each product on a rational box. At an integer
candidate, tighter planes from its selected pose boxes are added lazily.
Floating optimization is discovery only.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations,product
from collections import defaultdict,Counter
import hashlib,json,math,time,argparse
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix
D=10**6;Q=10000
def uv(k,g):return F(g*g-k*k,g*g+k*k),F(2*k*g,g*g+k*k)
def widen(a,b):return F(math.floor(a*Q),Q),F(math.ceil(b*Q),Q)
def interval(A,B):
 v=[x*y for x,y in product(A,B)];return min(v),max(v)
def plus(*ls):
 q=defaultdict(int)
 for s,arr in ls:
  for i,a in arr.items():q[i]+=s*a
 return {i:w for i,w in q.items() if w}
def vert(it):
 n,*v=map(int,it);assert len(v)==2*n;return [(F(x,D),F(y,D)) for x,y in zip(v[::2],v[1::2])]
def bounds(points):x,y=zip(*points);return widen(min(x),max(x)),widen(min(y),max(y))
class Model:
 def __init__(self,file):
  self.file=file;self.rows=[];self.lo=[];self.hi=[];self.integer=[];self.conds=[];self.by_tile=[];self.cache=set();self.poses=[];self.z=[];self.solved=[]
  with file.open() as f:
   z,U,g=f.readline().split();assert z=='ORIENT1';self.U=F(int(U),D);self.den=int(g);self.eps=self.new((F(0),F(1,10)))
   self.coords=[];self.pers=[];self.seeds=[]
   for i in range(20):
    self.seeds.append(vert(f.readline().split()));opts=[]
    for k in range(int(f.readline())):
     r=f.readline().split();l,u=map(int,r[:2]);pts=vert(r[2:]);A,B=uv(l,self.den),uv(u,self.den)
     opts.append((l,u,pts,[*bounds(pts),widen(B[0],A[0]),widen(A[1],B[1])]))
    assert opts;self.poses.append(opts);ranges=[(min(o[3][j][0] for o in opts),max(o[3][j][1] for o in opts)) for j in range(4)]
    self.coords.append([self.new(x) for x in ranges]);self.pers.append(ranges);self.by_tile.append(self.gates(len(opts)))
  for i in range(20):self.single(i)
  self.pair_modes={}
  for i,j in combinations(range(20),2):self.pair(i,j)
 def new(self,b,flag=False):
  self.lo.append(b[0]);self.hi.append(b[1]);self.integer.append(int(flag));return len(self.lo)-1
 def gates(self,n):
  if n==1:return [None]
  assert n>1;z=[self.new((0,1),True) for j in range(n)];self.le({j:1 for j in z},1);self.le({j:-1 for j in z},-1);return z
 def le(self,coeff,rhs,gates=()):
  v={i:a for i,a in coeff.items() if a};gs=set(x for x in gates if x is not None)
  if gs:
   M=max(0,sum(a*(self.hi[i] if a>0 else self.lo[i]) for i,a in v.items())-rhs)
   if not M:return
   for i in gs:v[i]=v.get(i,0)+M
   rhs+=M*len(gs)
  self.rows.append((v,rhs))
 def limits(self,form):
  return tuple(sum(a*((self.hi if upper==(a>0) else self.lo)[i]) for i,a in form.items()) for upper in (False,True))
 def mc(self,xx,yy,z,bx,by):
  l,u=bx;v,w=by;zz={z:1}
  return [(plus((v,xx),(l,yy),(-1,zz)),l*v),(plus((w,xx),(u,yy),(-1,zz)),u*w),(plus((1,zz),(-v,xx),(-u,yy)),-u*v),(plus((1,zz),(-w,xx),(-l,yy)),-l*w)]
 def prod(self,X,Y,selector):
  bx=self.limits(X);by=self.limits(Y);z=self.new(interval(bx,by))
  for row,rhs in self.mc(X,Y,z,bx,by):self.le(row,rhs)
  self.conds.append((X,Y,z,selector));return z
 def single(self,i):
  x,y,c,s=self.coords[i];side=self.U
  for k in (x,y):
   self.le({k:-2,c:1,s:1,self.eps:2},0);self.le({k:2,c:1,s:1,self.eps:2},2*side)
  for g,(a,b,p,r) in enumerate(self.poses[i]):
   gate=[self.by_tile[i][g]];lo=uv(a,self.den);hi=uv(b,self.den);mid=uv(a+b,2*self.den)
   for k,(l,u) in zip((x,y,c,s),r):self.le({k:1},u,gate);self.le({k:-1},-l,gate)
   for k,l in (lo,hi,mid):self.le({c:k,s:l},1,gate)
   self.le({c:-(lo[0]+hi[0]),s:-(lo[1]+hi[1])},-1-lo[0]*hi[0]-lo[1]*hi[1],gate)
   if len(p)>=3:
    for A,B in zip(p,p[1:]+p[:1]):
     a,b=B[1]-A[1],A[0]-B[0];self.le({x:a,y:b},a*A[0]+b*A[1],gate)
  w={}
  for k,coord in enumerate((x,y)):
   for n,trig in enumerate((c,s)):w[k,n]=self.prod({coord:1},{trig:1},('self',i,k,n+2))
  seed=self.seeds[i];inds=set()
  for a,b in [(1,0),(0,1),(1,1),(1,-1),(2,1),(-1,2),(1,2),(-2,1)]:
   for d in (-1,1):inds.add(max(range(len(seed)),key=lambda j:d*(a*seed[j][0]+b*seed[j][1])))
  for ind in inds:
   px,py=seed[ind];A={w[0,0]:1,w[1,1]:1,c:-px,s:-py};B={w[0,1]:-1,w[1,0]:1,s:px,c:-py}
   for row in (A,B):self.le(row,F(1,2));self.le({k:-z for k,z in row.items()},F(1,2))
 def pair(self,i,j):
  pos=self.pers;ii,jj=self.coords[i],self.coords[j]
  ds=[(pos[j][k][0]-pos[i][k][1],pos[j][k][1]-pos[i][k][0]) for k in (0,1)]
  sep=[max(0,l,-u) for l,u in ds]
  if sum(z*z for z in sep)>=F(2):return
  vx=[{jj[k]:1,ii[k]:-1} for k in range(2)];modes=[]
  for k in (i,j):
   for rot in (0,1):
    v=interval(ds[0],pos[k][3 if rot else 2]);w=interval(ds[1],pos[k][2 if rot else 3])
    if rot:v=(-v[1],-v[0])
    for sign in (1,-1):
     l,u=v[0]+w[0],v[1]+w[1];l,u=(l,u) if sign==1 else (-u,-l)
     if l>F(131,100):return
     if u>=1:modes.append((k,rot,sign))
  if not modes:self.le({},-1);return
  gates=self.gates(len(modes));self.pair_modes[i,j]=len(modes);WW={}
  for k in set(q[0] for q in modes):
   for a,b in product(range(2),range(2,4)):
    WW[k,a,b]=self.prod(vx[a],{self.coords[k][b]:1},('delta',i,j,k,a,b))
  TT={}
  for a,b in product(range(2,4),repeat=2):TT[a,b]=self.prod({ii[a]:1},{jj[b]:1},('trig',i,j,a,b))
  for gate,(k,rot,sgn) in zip(gates,modes):
   for v in (-1,1):
    r={self.eps:2,TT[2,2]:1,TT[3,3]:1,TT[3,2]:v,TT[2,3]:-v}
    if rot:r[WW[k,0,3]]=2*sgn;r[WW[k,1,2]]=-2*sgn
    else:r[WW[k,0,2]]=-2*sgn;r[WW[k,1,3]]=-2*sgn
    self.le(r,-1,(gate,))
 def tighter(self,point,selections):
  count=0
  for X,Y,z,sel in self.conds:
   typ=sel[0]
   if typ=='self':
    _,i,a,b=sel;g=selections[i];r=self.poses[i][g][3];bx,by=r[a],r[b];gate=[self.by_tile[i][g]]
   else:
    i,j=sel[1:3];gi,gj=selections[i],selections[j];ri,rj=self.poses[i][gi][3],self.poses[j][gj][3];gate=[self.by_tile[i][gi],self.by_tile[j][gj]]
    if typ=='delta':
     k,a,b=sel[3:];bx=(rj[a][0]-ri[a][1],rj[a][1]-ri[a][0]);by=(ri if k==i else rj)[b]
    else:
     a,b=sel[3:];bx,by=ri[a],rj[b]
   for m,(q,rhs) in enumerate(self.mc(X,Y,z,bx,by)):
    key=(z,tuple(gate),m)
    if key in self.cache:continue
    if sum(float(a)*point[i] for i,a in q.items())>float(rhs)+1e-7:
     self.le(q,rhs,gate);self.cache.add(key);count+=1
  return count
 def optimize(self,seconds,iterations):
  count=0;trace=[];t=time.monotonic();answer=None
  for k in range(iterations):
   ii=[];jj=[];vv=[];rhs=[]
   for r,(co,b) in enumerate(self.rows):
    scale=max([.0001,abs(float(b))]+[abs(float(z)) for z in co.values()]);rhs.append(float(b)/scale)
    for j,z in co.items():ii.append(r);jj.append(j);vv.append(float(z)/scale)
   A=coo_matrix((vv,(ii,jj)),shape=(len(rhs),len(self.lo))).tocsr();objective=np.zeros(len(self.lo));objective[self.eps]=-1
   opts={'time_limit':seconds,'mip_rel_gap':.001}
   z=milp(objective,integrality=self.integer,bounds=Bounds(list(map(float,self.lo)),list(map(float,self.hi))),constraints=LinearConstraint(A,-np.inf,rhs),options=opts)
   row={'iteration':k,'status':int(z.status),'rows':len(rhs),'message':z.message}
   if z.x is None:trace.append(row);break
   v=z.x;groups=[max(range(len(g)),key=lambda i:1 if g[i] is None else v[g[i]]) for g in self.by_tile]
   new=self.tighter(v,groups);row.update(margin=float(v[self.eps]),cuts=new);trace.append(row)
   if not new:
    answer={'epsilon':float(v[self.eps]),'centers_and_directions':[[float(v[j]) for j in r] for r in self.coords],'groups':groups};break
  return {'discovery_only':True,'input_sha256':hashlib.sha256(self.file.read_bytes()).hexdigest(),'variables':len(self.lo),'binary_variables':sum(self.integer),'interacting_pairs':len(self.pair_modes),'trace':trace,'relaxation_candidate':answer,'elapsed':round(time.monotonic()-t,2)}
if __name__=='__main__':
 q=argparse.ArgumentParser();q.add_argument('file',type=Path);q.add_argument('--seconds',type=int,default=10);q.add_argument('--iterations',type=int,default=8);p=q.parse_args();z=Model(p.file).optimize(p.seconds,p.iterations);print(json.dumps(z))
