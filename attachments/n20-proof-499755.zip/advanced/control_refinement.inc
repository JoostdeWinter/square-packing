struct TruePose{Point z;I c,s,d;};
bool containsPose(const Engine& e,const vector<int>& ids,const vector<TruePose>& w){
    for(int i:ids){
        auto p=w[i];for(auto z:e.seed[i]){
            I x=z.x-p.z.x,y=z.y-p.z.y;
            if(2*max(abs(p.c*x+p.s*y),abs(-p.s*x+p.c*y))>e.D*p.d){cerr<<"invalid seed "<<i<<endl;return false;}
        }
        bool ok=false;
        for(int k=0;k<e.B;k++){
            const Row& r=e.rows[k];
            // t=s/(d+c). Chart boundaries may both cover a chosen pose.
            W value=(W)p.s*r.gi;
            if(value>=(W)r.ki*(p.d+p.c)&&value<=(W)(r.ki+1)*(p.d+p.c)&&inside_closed(p.z,e.init[k][i]))ok=true;
        }
        if(!ok){cerr<<"lost true pose "<<i<<" of "<<ids.size()<<" grid "<<e.rows[0].gi<<"\n";return false;}
    }
    return true;
}
int main(int argc,char** argv){try{
 if(argc!=2)throw runtime_error("table path");
 for(int style=0;style<3;style++){
     Engine base(argv[1]);int cols=style==2?4:5;int rows=4;int n=cols*rows;
     base.U=style==0?5040000:(style==1?5800000:4980000);base.Z=n;
     base.seed.assign(n,P{});base.init.assign(base.B,vector<P>(n));
     vector<int> ids(n);iota(ids.begin(),ids.end(),0);vector<TruePose>w;
     I pitch=style==0?1005000:(style==1?1150000:1220000),off=style==0?510000:600000;
     for(int i:ids){
         Point p{off+(i%cols)*pitch,off+(i/cols)*pitch};
         int a=style==0?0:((i*11)%15);I dt=256;
         auto dir=cs(a,dt);if(style&&i%2==1){I t=dir.c;dir.c=dir.s;dir.s=t;}
         TruePose m{p,dir.c,dir.s,dir.d};w.push_back(m);base.seed[i]={p};
         I rad=-fl(-(W)base.D*(dir.c+dir.s),2*dir.d);
         if(min({p.x,p.y,base.U-p.x,base.U-p.y})<rad||2*rad>=pitch)throw runtime_error("bad positive placement");
         I wx=style==0?180000:110000,wy=style==0?170000:90000;P box={{p.x-wx,p.y-wy},{p.x+wx,p.y-wy},{p.x+wx,p.y+wy},{p.x-wx,p.y+wy}};
         for(int k=0;k<base.B;k++)base.init[k][i]=box;
     }
     for(int factor:{1,2,3,4,5,6}){
         auto e=base;
         if(factor>1&&!fine(e,ids,factor,base.B*factor))throw runtime_error("failed angular refinement");
         if(!containsPose(e,ids,w))throw runtime_error("after refinement");
         if(!cluster_filter(e,ids)||!containsPose(e,ids,w))throw runtime_error("after conditional-core filtering");
         int idx,it;
         if(e.run(ids,5,idx,it)||!containsPose(e,ids,w))throw runtime_error("after integer relaxation");
         cout<<style<<" "<<factor<<" "<<e.rows[0].gi<<" OK"<<endl;
     }
 }
}catch(exception&e){cerr<<e.what()<<endl;return 2;}}
