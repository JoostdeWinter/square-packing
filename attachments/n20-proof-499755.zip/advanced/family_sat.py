"""Finite exact existential choice of one pose family per tile."""
from pathlib import Path
from collections import deque
from itertools import combinations
import argparse,json
def bits(x):
 while x:
  z=x&-x;yield z.bit_length()-1;x-=z
def load(path):
 with path.open() as f:
  name,n,U=f.readline().split();assert name=='FAMILIES1' and int(n)==20
  sizes=list(map(int,f.readline().split()));assert len(sizes)==20
  full=[(1<<w)-1 for w in sizes];allowed={};neighbors=[set() for v in sizes]
  for i,j in combinations(range(20),2):
   a,b,n=map(int,f.readline().split());assert (a,b)==(i,j)
   v=list(map(int,f.readline().split()));assert len(v)==2*n
   if n:
    neighbors[i].add(j);neighbors[j].add(i)
    ab=[full[j]]*sizes[i];ba=[full[i]]*sizes[j]
    for x,y in zip(v[::2],v[1::2]):
     assert 0<=x<sizes[i] and 0<=y<sizes[j];ab[x]&=~(1<<y);ba[y]&=~(1<<x)
    allowed[i,j]=ab;allowed[j,i]=ba
  assert not f.read().strip()
 return sizes,full,allowed,neighbors
def solve(path,limit=10000,singletons=False):
 sizes,initial,E,adj=load(path);stats={'families':sum(sizes),'initial_widths':sizes,'nodes':0,'singleton_tests':0,'edges_with_exclusions':len(E)//2}
 def ac(d,dirty):
  if not all(d):return None
  stack=deque(dirty);queued=set(dirty)
  while stack:
   j=stack.pop();queued.discard(j)
   for i in adj[j]:
    r=d[i];good=r;arc=E[i,j];t=d[j]
    for a in bits(r):
     if arc[a]&t==0:good^=1<<a
    if not good:return None
    if good!=r:
     d[i]=good
     if i not in queued:stack.append(i);queued.add(i)
  return d
 def dfs(d,dirty):
  if stats['nodes']>=limit:return 'unknown',None
  stats['nodes']+=1;d=ac(d,dirty)
  if d is None:return 'unsat',None
  if all(r.bit_count()==1 for r in d):return 'sat',[v.bit_length()-1 for v in d]
  j=min((i for i,x in enumerate(d) if x.bit_count()>1),key=lambda i:(d[i].bit_count(),-sum(d[k].bit_count()>1 for k in adj[i])))
  vals=list(bits(d[j]));vals.sort(key=lambda v:-sum((E[j,k][v]&d[k]).bit_count() for k in adj[j]))
  missing=False
  for v in vals:
   child=d.copy();child[j]=1<<v;status,solution=dfs(child,[j])
   if status=='sat':return status,solution
   if status=='unknown':return status,None
  return 'unsat',None
 d=ac(initial.copy(),list(range(20)))
 if d is not None and singletons:
  for _ in range(4):
   edits=0
   for i in sorted(range(20),key=lambda j:d[j].bit_count()):
    for a in list(bits(d[i])):
     if d[i].bit_count()==1:break
     b=d.copy();b[i]=1<<a;stats['singleton_tests']+=1
     if ac(b,[i]) is None:
      d[i]^=1<<a;edits+=1;d=ac(d,[i])
      if d is None:break
    if d is None:break
   if d is None or not edits:break
 stats['arc_widths']=[] if d is None else [r.bit_count() for r in d]
 status,solution=('unsat',None) if d is None else dfs(d,list(range(20)))
 if solution is not None:
  assert len(solution)==20
  for (i,j),arc in E.items():assert arc[solution[i]]>>solution[j]&1
 return dict(stats,status=status,witness=solution)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('graph',type=Path);ap.add_argument('--nodes',type=int,default=10000);ap.add_argument('--singletons',action='store_true');v=ap.parse_args();print(json.dumps(solve(v.graph,v.nodes,v.singletons)))
