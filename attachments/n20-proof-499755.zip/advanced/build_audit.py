from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'tree.cpp').read_text()
pattern='struct TreeBudget {';assert s.count(pattern)==1
s=s.replace(pattern,(h/'audit_cluster.inc').read_text()+'\n'+pattern)
pattern='if(mode=="tree"){';assert s.count(pattern)==1
s=s.replace(pattern,'''if(mode=="audit"){
        if(argc<12)throw runtime_error("missing trace");
        int f=stoi(getenv("N20_FINE"));if(f>1)fine(x,data.A,f,base.B*f);
        ofstream out(argv[11]);audit_cluster(move(x),data.A,out);cout<<"AUDIT"<<endl;return 0;
    }
    '''+pattern)
p=h/'audit.cpp';p.write_text(s);subprocess.run(['g++','-std=c++17','-O3',p,'-o',h/'audit'],check=True)
