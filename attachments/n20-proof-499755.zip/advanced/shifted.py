"""Construct shifts with a four-point boundary correction on any target cap <=5."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import sys,math,json
h=Path(__file__).resolve().parents[1];sys.path.insert(0,str(h/'base496'));from prereqs import SPEC,marks
def make(U):
 assert U%50==0 and U<=5000000
 p=[(int(x*10**6),int(y*10**6)) for x,y in marks(dict(SPEC,cap=str(F(U,10**6))))]
 q=[(U-y,x) for x,y in p]
 # The complementary 23-point Bentz rack at five, homothetically scaled.
 comp=[(U*i//10,U*j//50) for i in range(1,10) for j in (9,17,25,33,41) if (U*i//10,U*j//50) not in p]
 assert len(p)==len(q)==22 and len(comp)==23
 pairs=[p,q,comp,[(U-y,x) for x,y in comp]]
 records=[]
 for shift,tau,which in [(300000,850000,[0,1]),(150000,760000,[0,1]),(400000,905000,[0,1]),(225000,860000,[2,3]),(350000,900000,[2,3]),(50000,730000,[0,1]),(200000,715000,[0,1]),(200000,910000,[0,1])]:
  assert shift+500000<=tau and (2*tau+1000000)**2<=8*10**12
  for g in which:
   for ax,sign in product((0,1),(1,-1)):records.append((ax,sign,shift,tau,pairs[g]))
 where=h/f'trials/shifts{U}';where.mkdir(exist_ok=True)
 for n in (4,8,16,24,32,48,64):
  data=records[:n];out=[f'{U} {len(data)}']
  for axis,sgn,d,t,r in data:out.append(' '.join(map(str,[axis,sgn,d,t,len(r),*(x for z in r for x in z)])))
  (where/f's{n}.txt').write_text('\n'.join(out)+'\n')
 return len(records)
if __name__=='__main__':
 for v in sys.argv[1:]:print(v,make(int(v)))
