"""Build the angular-frame checker with exact disk support along its local axes."""
from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent
src=(h/'separators.cpp').read_text()
key='t.y+j*H});}return hull(move(out));'
assert src.count(key)==1
src=src.replace(key,'''t.y+j*H});
            // The projected center was rounded down by less than one unit in each coordinate.
            // (R+1)^2+1 < (D/2)^2, so all four added points belong to the true inscribed disk.
            const I R=499997;
            for(auto r:vector<Point>{{R,0},{-R,0},{0,R},{0,-R}})out.push_back({t.x+r.x,t.y+r.y});
        }return hull(move(out));''')
key='if(circ.empty()){';assert src.count(key)==1
src=src.replace(key,'''if(circ.empty()){
        for(auto v:vector<Point>{{500000,0},{-500000,0},{0,500000},{0,-500000}})circ.push_back(v);''')
key='LocalF(int p,int g,I D){';assert src.count(key)==1;src=src.replace(key,key+' if(D!=1000000)throw runtime_error("unit length");')
p=h/'octframe.cpp';p.write_text(src);out=h/'octframe.partial'
subprocess.run(['g++','-O1','-g0','--param=ggc-min-expand=4','--param=ggc-min-heapsize=4096','-std=c++17',p,'-o',out],check=True);out.replace(h/'octframe')
