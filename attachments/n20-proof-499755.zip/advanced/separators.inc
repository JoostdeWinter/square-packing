// Projection on a physical edge normal. If the normal lies on a rational
// angular arc of width w, at least one endpoint projects the center gap by
// at least the physical separation times cos(w/2). The support of the
// independently rotated neighbor is bounded from its relative angle.
struct StabDir{I x,y,d;int bucket;};
struct SRow{array<Dir,2> ends;array<StabDir,8> endpoints;};
struct SChoose{int i=-1,j=-1;unsigned mask=0;double score=-1e100;};
using SRules=array<array<unsigned char,N>,N>;
struct SPre{const vector<Row>& rows;vector<SRow> bins;vector<vector<I>> rhs;
    SPre(const vector<Row>& r):rows(r),bins(r.size()),rhs(r.size(),vector<I>(r.size())){
        for(int k=0;k<(int)r.size();k++){
            auto& b=bins[k];b.ends={cs(r[k].ki,r[k].gi),cs(r[k].ki+1,r[k].gi)};
            auto p=cs(2*r[k].ki+1,2*r[k].gi);
            for(int turn=0;turn<4;turn++){
                int bucket=abs(p.c)>=abs(p.s)?(p.c>0?0:1):(p.s>0?2:3);
                for(int j=0;j<2;j++){auto q=b.ends[j];for(int u=0;u<turn;u++){I t=q.c;q.c=-q.s;q.s=t;}
                    I den=gcd(q.c,q.s);if(q.d%den)throw runtime_error("rational direction reduction");
                    b.endpoints[2*turn+j]={q.c/den,q.s/den,q.d/den,bucket};}
                I t=p.c;p.c=-p.s;p.s=t;
            }
        }
        for(int k=0;k<(int)r.size();k++)for(int l=0;l<(int)r.size();l++){
            I R=1000000;
            if(abs(r[k].ki-r[l].ki)>1){
                R=2000000;
                for(auto p:bins[k].ends)for(auto q:bins[l].ends){
                    W d=(W)p.d*q.d,dot=(W)p.c*q.c+(W)p.s*q.s;
                    W cr=(W)p.s*q.c-(W)p.c*q.s;if(cr<0)cr=-cr;
                    R=min(R,fl((W)1000000*(d+dot+cr),2*d));
                }
            }
            I g=r[k].gi;rhs[k][l]=fl((W)R*(2*g*g-1),2*g*g);
        }
    }
};
P one_half(const P& a,HP n){
    if(mn(a,n)>n.k)return {};
    if(mx(a,n)<=n.k)return a;
    return cut(a,n);
}
bool angular_separators(Engine& e,const vector<int>& ids,const SPre& pre,const SRules& rules,SChoose& best){
    vector<vector<int>> alive(N);vector<Bound> boxes(N);
    for(int i=0;i<N;i++){
        P all;for(int k=0;k<e.B;k++)if(!e.init[k][ids[i]].empty()){
            alive[i].push_back(k);merge_vertices(all,e.init[k][ids[i]]);}
        if(all.empty())return false;boxes[i]=bbox(all);
    }
    for(int i=0;i<N;i++)for(int j=i+1;j<N;j++){
        unsigned mask=rules[i][j]?rules[i][j]:15;
        auto a=boxes[i],b=boxes[j];
        if(mask==15&&max({a.l-b.r,b.l-a.r,a.b-b.t,b.b-a.t})>1414214)continue;
        vector<P> left(e.B),right(e.B);vector<char> wholel(e.B),wholer(e.B);array<long,4> hits{};bool exists=false;
        for(int k:alive[i])for(int l:alive[j]){
            const P& A=e.init[k][ids[i]];const P& B=e.init[l][ids[j]];
            if(A.empty()||B.empty())continue;
            I R=pre.rhs[k][l];unsigned usable=0;bool auto_lax=false;
            struct Way{HP n;I upper,lower,level;};vector<Way> ways;
            for(int who:{k,l}){
                for(auto d:pre.bins[who].endpoints){unsigned bit=1u<<d.bucket;if(!(mask&bit))continue;
                    HP n{d.x,d.y,0};I loA=mn(A,n),hiB=mx(B,n),lim=R*d.d;
                    if(hiB-loA<lim)continue;usable|=bit;
                    if(mn(B,n)-mx(A,n)>=lim){auto_lax=true;continue;}
                    ways.push_back({n,hiB,loA,lim});
                }
                if(k==l)break;
            }
            if(!usable)continue;exists=true;for(int w=0;w<4;w++)if(usable>>w&1)hits[w]++;
            if(auto_lax){
                if(!wholel[k]){left[k]=A;wholel[k]=1;}
                if(!wholer[l]){right[l]=B;wholer[l]=1;}
            }else for(auto w:ways){
                HP f=w.n;
                if(!wholel[k]){f.k=w.upper-w.level;merge_vertices(left[k],one_half(A,f));}
                if(!wholer[l]){f={-w.n.a,-w.n.b,-w.lower-w.level};merge_vertices(right[l],one_half(B,f));}
            }
        }
        if(!exists)return false;
        for(int k:alive[i])if(!wholel[k])e.init[k][ids[i]]=hull(move(left[k]));
        for(int k:alive[j])if(!wholer[k])e.init[k][ids[j]]=hull(move(right[k]));
        if(mask==15){
            unsigned possible=0;long lo=INT64_MAX,hi=0;
            for(int m=0;m<4;m++)if(hits[m]){possible|=1u<<m;lo=min(lo,hits[m]);hi=max(hi,hits[m]);}
            int cnt=__builtin_popcount(possible);
            if(cnt>1){
                double dx=((double)b.l+b.r-a.l-a.r)/2e6,dy=((double)b.b+b.t-a.b-a.t)/2e6;
                double rating=9./cnt+1.7*min(abs(dx),abs(dy))+.7*lo/hi-.2*abs(hypot(dx,dy)-1.3);
                if(rating>best.score)best={i,j,possible,rating};
            }
        }
    }
    return true;
}
struct SLimit{int nodes=0,limit=100,depth=8,sub=3,passes=2,split=1;};
bool separator_tree(Engine x,const Choices& c,const vector<int>& owners,const SPre& pre,SRules rules,SLimit& lim,int dep){
    if(++lim.nodes>lim.limit)return false;SChoose best;int reason=0;
    for(int it=0;it<lim.passes;it++){
        if(!local_frame(x,c,owners,lim.sub))return true;
        best=SChoose{};
        if(!angular_separators(x,c.A,pre,rules,best)||!cluster_filter(x,c.A)||!propagate(x,c,owners,1,10,reason))return true;
    }
    if(dep>=lim.depth)return false;
    if(best.i>=0 && lim.split){
        unsigned choices=best.mask;while(choices){int m=__builtin_ctz(choices);choices&=choices-1;
            auto r=rules;r[best.i][best.j]=1<<m;
            if(!separator_tree(x,c,owners,pre,r,lim,dep+1))return false;}
        return true;
    }
    auto splits=split_choices(x,c.A);if(splits.empty())return false;auto sp=splits.front();
    for(int sg:{-1,1}){auto ch=x;apply_split(ch,c.A,sp,sg);if(!separator_tree(move(ch),c,owners,pre,rules,lim,dep+1))return false;}
    return true;
}
