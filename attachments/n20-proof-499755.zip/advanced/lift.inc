// Pair-dependent distributions preserve each tile's angle/position marginals.
// Split possible separating facets into convex sectors and enclose each
// sector's feasible center differences. All emitted bounds are necessary.
int lift_octant(HP f,int parts){
    if(parts<=1)return 0;
    if(parts==2)return abs(f.a)>=abs(f.b)?0:1;
    if(parts==4)return abs(f.a)>=abs(f.b)?(f.a>=0?0:1):(f.b>=0?2:3);
    return (f.a<0?4:0)+(f.b<0?2:0)+(abs(f.a)<abs(f.b)?1:0);
}
vector<HP> lift_faces(const P& p){
    if(p.empty())throw runtime_error("empty lift face");
    return outer_faces(p);
}
void print_faces(ostream& out,vector<HP> fs){
    out<<" "<<fs.size();for(auto f:fs){unique_normal(f);out<<" "<<f.a<<" "<<f.b<<" "<<f.k;}
}
void lift_export(const Engine& e,const vector<int>& ids,int angles,int divisions,int parts,const string& filename){
    ofstream out(filename);if(!out)throw runtime_error("lift output");
    vector<vector<PoseFamily>> opts;for(int id:ids)opts.push_back(families(e,id,angles,divisions));
    int lanes=80;out<<"LIFT1 "<<e.U<<" "<<ids.size()<<" "<<lanes<<"\n";
    for(int i=0;i<(int)opts.size();i++){
        out<<"T "<<i<<" "<<opts[i].size()<<"\n";
        for(int p=0;p<(int)opts[i].size();p++){
            const auto& z=opts[i][p];out<<"G "<<i<<" "<<p;print_faces(out,lift_faces(z.center));out<<"\n";
            I h=e.D,plateau=2*e.D,product_hi=0;
            for(const auto& row:e.rows)if(z.halfangle_lo<=row.ki&&row.ki<z.halfangle_hi){
                auto cc=chord_constants(row,e.D);h=min(h,cc.height);plateau=min(plateau,cc.plateau);product_hi=max(product_hi,cc.product);
            }
            out<<"C";for(int ax=0;ax<2;ax++)for(int k=1;k<lanes;k++){
                I level=e.U*k/lanes;
                I lo=ax?z.b.l:z.b.b,hi=ax?z.b.r:z.b.t;
                I away=max(abs(level-lo),abs(hi-level));I len=0;
                if(away<h && product_hi)len=min(plateau,fl((W)e.D*(h-away),product_hi));
                len=max(len,inner_chord(z.mandatory,ax==1,level));out<<" "<<len;
            }
            out<<"\n";
        }
    }
    for(int i=0;i<(int)ids.size();i++)for(int j=i+1;j<(int)ids.size();j++){
        vector<string> lines;bool any_cut=false;
        for(int ga=0;ga<(int)opts[i].size();ga++)for(int gb=0;gb<(int)opts[j].size();gb++){
            const auto& a=opts[i][ga];const auto& b=opts[j][gb];ostringstream rec;rec<<"A "<<ga<<" "<<gb;
            if(intersect_closed(a.mandatory,b.mandatory)){rec<<" 0";any_cut=true;lines.push_back(rec.str());continue;}
            auto raw=mink(b.center,a.center,true);P forbidden=mink(a.body,b.body,true);auto fs=facets(forbidden);
            bool automatic=false;
            for(auto f:fs)if(mn(raw,f)>=f.k){automatic=true;break;}
            if(automatic){rec<<" 1 0";lines.push_back(rec.str());continue;}
            vector<P> unioned(parts);
            for(auto f:fs){if(mx(raw,f)<f.k)continue;f={-f.a,-f.b,-f.k};
                auto region=cut(raw,f);if(region.empty())continue;merge_vertices(unioned[lift_octant(f,parts)],region);}
            vector<vector<HP>> sectors;
            for(auto& points:unioned)if(!points.empty()){
                auto shell=hull(move(points));vector<HP> keep;
                for(auto f:lift_faces(shell))if(mx(raw,f)>f.k)keep.push_back(f);
                if(keep.empty()){sectors={keep};break;}
                sectors.push_back(move(keep));
            }
            rec<<" "<<sectors.size();for(auto& s:sectors)print_faces(rec,s);
            if(sectors.size()!=1||!sectors[0].empty())any_cut=true;
            lines.push_back(rec.str());
        }
        if(any_cut){out<<"B "<<i<<" "<<j<<" "<<lines.size()<<"\n";for(auto& l:lines)out<<l<<"\n";}
    }
    out<<"END\n";
}
