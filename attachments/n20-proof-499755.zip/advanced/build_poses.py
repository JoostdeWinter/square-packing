from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'direct.cpp').read_text();key='string sym(int axis,int i)';assert s.count(key)==1;s=s.replace(key,(h/'poses.inc').read_text()+'\n'+key)
key='if(mode=="direct"){';assert s.count(key)==1;s=s.replace(key,'''if(mode=="families"){
        int f=stoi(getenv("N20_FINE"));if(f>1)fine(x,data.A,f,base.B*f);
        int passes=stoi(getenv("N20_DIRECT_PASSES"));
        for(int z=0;z<passes;z++){
            if(!direct_centers(x,data.A,8)||!cluster_filter(x,data.A)||!propagate(x,data,owners,1,10,reason)){
                cout<<"CLOSED "<<(reason?reason:11)<<endl;return 0;
            }
        }
        int groups=stoi(getenv("N20_FAMILY_ANGLES")),positions=stoi(getenv("N20_FAMILY_DIV"));
        if(argc<12||groups<1||groups>64||positions<1||positions>12)throw runtime_error("pose family settings");
        export_families(x,data.A,groups,positions,argv[11]);cout<<"GRAPH"<<endl;return 0;
    }
    '''+key)
p=h/'poses.cpp';p.write_text(s);tmp=h/'poses.partial';subprocess.run(['g++','-std=c++17','-O3',p,'-o',tmp],check=True);tmp.replace(h/'poses')
