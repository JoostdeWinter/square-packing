from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'advanced.cpp').read_text()
n='bool propagate(Engine& x,'
assert s.count(n)==1;s=s.replace(n,(h/'cluster.inc').read_text()+'\n'+n)
n='void save_state('
assert s.count(n)==1;s=s.replace(n,(h/'tree.inc').read_text()+'\n'+n)
n='if(mode!="check")throw runtime_error("unsupported mode");'
s=s.replace(n,'''if(mode=="tree"){
       TreeBudget bgt;
       if(const char* budget=getenv("N20_TREE_LIMIT"))bgt.limit=stoi(budget);
       if(const char* depth=getenv("N20_TREE_DEPTH"))bgt.depth=stoi(depth);
       if(const char* checks=getenv("N20_TREE_CHECKS"))bgt.checks=stoi(checks);
       if(const char* f=getenv("N20_FINE")){int fact=stoi(f);if(fact>1)fine(x,data.A,fact,base.B*fact);}
       bool closed=search_space(move(x),data,owners,0,bgt);
       cout<<(closed?"CLOSED_TREE":"OPEN_TREE")<<" "<<bgt.nodes<<endl;return 0;
    }
    '''+n)
p=h/'tree.cpp';p.write_text(s);subprocess.run(['g++','-O3','-std=c++17',p,'-o',h/'tree'],check=True)
