"""Exact outward linearization of physical edge-normal separation with shared tile angles."""
from dataclasses import dataclass
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations
from math import floor,ceil,gcd
from pathlib import Path
from collections import Counter
import argparse
D=1000000;Q=1<<23
def dot(a,b):return a[0]*b[0]+a[1]*b[1]
def turn(n):return (-n[1],n[0])
def neg(n):return (-n[0],-n[1])
@lru_cache(maxsize=None)
def cs(t):return (1-t*t)/(1+t*t),2*t/(1+t*t)
def prodcross(a,b):return a[0]*b[1]-a[1]*b[0]
def geometry(t0,t1,g):
 a,b=F(t0,g),F(t1,g);mid=cs((a+b)/2);left,right=cs(a),cs(b)
 lo,hi=prodcross(mid,left),prodcross(mid,right);A=1-min(dot(mid,left),dot(mid,right));B=max(-lo,hi)
 assert -F(1,7)<lo<=0<=hi<F(1,7) and A>=0 and 50*B*B<1
 return mid,lo,hi,A,B
@dataclass
class Pose:
 poly:tuple
 nom:tuple
 lo:F
 hi:F
 error:F
 bound:F
 gate:str
 def __post_init__(self):
  self.box=(min(x for x,y in self.poly),max(x for x,y in self.poly),min(y for x,y in self.poly),max(y for x,y in self.poly));self.cache={}
 def support(self,n):
  if n not in self.cache:
   vals=[dot(n,p) for p in self.poly];self.cache[n]=(min(vals),max(vals))
  return self.cache[n]
def read(path):
 ls=iter(path.read_text().splitlines());U,D0,G,N=map(int,next(ls).split());assert 0<U<=5*D and D0==D and N==20
 def points(z):
  count,*v=map(int,z);assert len(v)==2*count
  return tuple(zip(v[::2],v[1::2]))
 all_=[];bodies=[]
 for i in range(N):
  bodies.append(points(next(ls).split()));count=int(next(ls));q=[]
  for j in range(count):
   k,l,g,*coords=next(ls).split();poly=points(coords);q.append(Pose(poly,*geometry(int(k),int(l),int(g)),f'g{i}_{j}' if count>1 else 'true'))
  all_.append(q)
 assert next(ls,None) is None
 return U,all_,bodies
def combine(op,args):
 ls=list(dict.fromkeys(args));unit='true' if op=='and' else 'false';end='false' if op=='and' else 'true'
 if end in ls:return end
 ls=[x for x in ls if x!=unit]
 if not ls:return unit
 return ls[0] if len(ls)==1 else '('+op+' '+' '.join(ls)+')'
def ac(v):return str(v) if v>=0 else '(- '+str(-v)+')'
def lin(terms,b):
 # Physical centers have magnitudes at most 5D. Angular variables are D sin(delta).
 # Round an entire necessary lower bound outward, including the RHS.
 result={};err=F(0)
 for var,r in terms:
  result[var]=result.get(var,0)+r
 out=[];ints=[]
 for var,r in sorted(result.items()):
  if not r:continue
  v=round(Q*r);err+=abs(Q*r-v)*(D if var.startswith('w') else 5*D)
  if v:ints.append((var,v))
 B=floor(Q*b-err);g=abs(B)
 for _,j in ints:g=gcd(g,abs(j))
 g=max(1,g);B//=g
 for var,v in ints:
  v//=g;out.append(var if v==1 else '(- '+var+')' if v==-1 else '(* '+ac(v)+' '+var+')')
 if not out:return 'true' if B<=0 else 'false'
 return '(>= '+(out[0] if len(out)==1 else '(+ '+' '.join(out)+')')+' '+ac(B)+')'
def terms(i,n):
 return [(f'x{i}',n[0]),(f'y{i}',n[1])]
def faces(p):
 if len(p)<3:return []
 B=[]
 for v,w in zip(p,p[1:]+p[:1]):
  a,b=w[1]-v[1],v[0]-w[0];g=gcd(abs(a),abs(b));a//=g;b//=g;K=a*v[0]+b*v[1]
  if any(a*x+b*y>K for x,y in p):a,b,K=-a,-b,-K
  assert all(a*x+b*y<=K for x,y in p);B.append((a,b,K))
 return B
def sep_inner(i,j,A,B,k,who):
 # For every physically valid separating normal, the nominal component is
 # positive: if it were nonpositive, its projection would be at most
 # 5 sqrt(2) D max |sin(delta)| < D on these strips.
 src=A if who==i else B;n=src.nom
 for _ in range(k):n=turn(n)
 v=turn(n);rl,rh=A.support(n);ql,qh=B.support(n);vl,vh=A.support(v);wl,wh=B.support(v)
 r0,r1=ql-rh,qh-rl;vlo,vhi=wl-vh,wh-vl
 if r1<=0 or r1+src.bound*max(abs(vlo),abs(vhi))<D:return 'false'
 # The largest possible physical projection can only help. If the fixed
 # nominal direction separates all configurations by >sqrt(2), no test is needed.
 if r0*r0>2*D*D and r0>0:return 'true'
 gapcos=A.error+B.error+A.bound*B.bound
 gapsin=B.bound*A.error+A.bound*B.error
 fc=dot(A.nom,B.nom);fs=prodcross(A.nom,B.nom)
 variants=[(0,D)]
 for e in (1,-1):
  v0=fc+e*fs;v1=-fs+e*fc;level=F(D,2)*(1+v0-max(v0,0)*gapcos-abs(v1)*gapsin)
  variants.append((v1/2,level))
 out=[]
 for bound,vx in ((src.hi,vlo),(src.lo,vhi)):
  N=(n[0]+bound*v[0],n[1]+bound*v[1])
  coord=terms(j,N)+terms(i,neg(N))+[(f'w{who}',vx/D)]
  for slope,level in variants:
   co=coord+[(f'w{j}',-slope),(f'w{i}',slope)]
   out.append(lin(co,level+bound*vx))
 return combine('and',out)
def skip_by_box(A,B):
 xl,xh,yl,yh=A.box;Xl,Xh,Yl,Yh=B.box
 return max(xl-Xh,Xl-xh,yl-Yh,Yl-yh)>=1414214
def pose_rows(i,p,U,seed):
 w=f'w{i}';x=f'x{i}';y=f'y{i}';n=p.nom;r=[]
 r.append(lin([(w,1)],D*p.lo));r.append(lin([(w,-1)],-D*p.hi))
 low,high,bottom,top=p.box
 for var,lo,hi in ((x,low,high),(y,bottom,top)):
  r.extend((lin([(var,1)],lo),lin([(var,-1)],-hi)))
  width=D*(n[0]+n[1])*(1-p.error)/2;der=(n[0]-n[1])/2
  r.extend((lin([(var,1),(w,-der)],width),lin([(var,-1),(w,-der)],width-U)))
 for a,b,d in faces(p.poly):r.append(lin([(x,-a),(y,-b)],-d))
 # Each seed vertex lies in the actual square. For each tile axis use
 # the two lower McCormick bounds for the transverse product.
 for uax in (p.nom,turn(p.nom),neg(p.nom),neg(turn(p.nom))):
  v=turn(uax);L,H=p.support(uax);l,h=p.support(v)
  if not seed:continue
  # Four extremal vertices suffice to add necessary constraints efficiently.
  points=set()
  for div in (p.lo,p.hi):
   direct=(uax[0]+div*v[0],uax[1]+div*v[1]);points.add(max(seed,key=lambda z:dot(direct,z)))
  for point in points:
   un=dot(uax,point);vn=dot(v,point);maxr=un-L
   for z,V in ((p.lo,vn-h),(p.hi,vn-l)):
    N=(uax[0]+z*v[0],uax[1]+z*v[1])
    r.append(lin(terms(i,N)+[(w,-V/D)],un+z*vn-z*V-max(0,maxr)*p.error-F(D,2)))
 return combine('and',r)
def generate(path,exchange=True):
 U,poses,anchors=read(path);s=['(set-logic QF_LRA)'];stats=Counter()
 def emit(expr):
  if expr!='true':s.append('(assert '+expr+')')
 def imp(cn,r):
  if cn=='true':return r
  if r=='true':return 'true'
  return '(=> '+cn+' '+r+')'
 for i,opts in enumerate(poses):
  for var in ('x','y','w'):s.append(f'(declare-const {var}{i} Real)')
  for p in opts:
   stats['possible_angle_groups']+=1
   if p.gate!='true':s.append('(declare-const '+p.gate+' Bool)')
   emit(imp(p.gate,pose_rows(i,p,U,anchors[i])))
  emit(combine('or',[p.gate for p in opts]))
 for i,j in combinations(range(len(poses)),2):
  for A in poses[i]:
   for B in poses[j]:
    if skip_by_box(A,B):continue
    if any(B.support(n)[0]-A.support(n)[1]>1414214 for n in ((1,0),(-1,0),(0,1),(0,-1))):continue
    alts=[]
    for owner in (i,j):
     for k in range(4):
      expr=sep_inner(i,j,A,B,k,owner)
      if expr!='false':alts.append(expr)
      if expr=='true':break
     if 'true' in alts:break
    term=combine('or',alts)
    if term!='true':
     stats['conditional_pair_tests']+=1;stats['possible_directions']+=len(alts);emit(imp(combine('and',[A.gate,B.gate]),term))
 if exchange:
  from saturation import export
  rows,extras=export(U,poses);s.extend(rows);stats.update(extras)
 s.append('(check-sat)');text='\n'.join(s)+'\n';stats['bytes']=len(text);return text,dict(stats)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('poses',type=Path);a.add_argument('output',type=Path);v=a.parse_args();s,stats=generate(v.poses);v.output.write_text(s);print(stats)
