from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'deeper.cpp').read_text()
key='void save_state(';assert s.count(key)==1;s=s.replace(key,(h/'smt.inc').read_text()+'\n'+key)
key='if(mode=="lp"){';assert s.count(key)==1
s=s.replace(key,'''if(mode=="smt"){
        if(argc<12)throw runtime_error("need SMT destination");
        int groups=stoi(getenv("N20_SMT_GROUPS"));if(groups<1||groups>32)throw runtime_error("group count");
        int f=getenv("N20_FINE")?stoi(getenv("N20_FINE")):1;if(f>1)fine(x,data.A,f,base.B*f);
        if(!cluster_filter(x,data.A)||!propagate(x,data,owners,1,12,reason)){cout<<"CLOSED "<<(reason?reason:10)<<endl;return 0;}
        export_disj(x,data.A,groups,argv[11],x.U==5000000);cout<<"EXPORTED"<<endl;return 0;
    }
    '''+key)
p=h/'smt.cpp';p.write_text(s);subprocess.run(['g++','-std=c++17','-O3',p,'-o',h/'smt'],check=True)
