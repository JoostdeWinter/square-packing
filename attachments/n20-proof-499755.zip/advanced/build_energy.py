from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'separators.cpp').read_text();key='string sym(int axis,int i)';assert s.count(key)==1;s=s.replace(key,(h/'energy.inc').read_text()+'\n'+key)
key='if(mode=="sep"){';assert s.count(key)==1
s=s.replace(key,'''if(mode=="energy"){
        int f=stoi(getenv("N20_FINE"));if(f>1)fine(x,data.A,f,base.B*f);
        int passes=stoi(getenv("N20_UNION_PASSES")),sub=stoi(getenv("N20_FRAME_SUB")),maxcap=stoi(getenv("N20_ENERGY_CAP"));
        for(int pass=0;pass<passes;pass++){
            for(int c=4;c<=maxcap;c++)if(!apply_energy(x,data.A,c,true)){cout<<"CLOSED_ENERGY "<<pass+1<<" window "<<c<<endl;return 0;}
            if(!local_frame(x,data,owners,sub)){cout<<"CLOSED_ENERGY "<<pass+1<<" frame"<<endl;return 0;}
            if(!cluster_filter(x,data.A)||!propagate(x,data,owners,1,12,reason)){cout<<"CLOSED_ENERGY "<<pass+1<<" propagation "<<reason<<endl;return 0;}
        }cout<<"OPEN_ENERGY "<<passes<<endl;return 0;
    }
    '''+key)
p=h/'energy.cpp';p.write_text(s);t=h/'energy.partial';subprocess.run(['g++','-O3','-std=c++17',p,'-o',t],check=True);t.replace(h/'energy')
