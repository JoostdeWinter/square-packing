// Evan Daniel's closed-tile measure, with fixed integer capacities. A
// maximum flow tests all Hall inequalities on subsets of the twenty tiles.
struct MPiece{Point a,b;I weight;};
struct MixedMeasure{
    I den=0,unit=0,total=0;vector<MPiece> piece;
    MixedMeasure(I U,const string& file,int M){
        if(M<1||M>16)throw runtime_error("mixed subdivision");
        ifstream raw(file);string line,clean;while(getline(raw,line))if(!line.empty()&&line[0]!='#')clean+=line+"\n";
        istringstream in(clean);string fmt;I v,capA,capB,scale,weights;int n,m,tail;
        in>>fmt>>v>>capA>>capB>>scale>>weights>>n;
        if(fmt!="mixed"||v!=1||capA!=5||capB!=1||scale!=1000||weights!=100000000000ll||n!=7536||U>5000000)throw runtime_error("mixed mass header");
        den=5*scale*M;unit=weights*M;
        auto pt=[&](I x,I y){return Point{x*U,y*U};};
        for(int i=0;i<n;i++){I x,y,w;in>>x>>y>>w;auto a=pt(M*x,M*y);piece.push_back({a,a,w*M});total+=w*M;}
        in>>m;if(m!=1872)throw runtime_error("mixed segments");
        for(int i=0;i<m;i++){I x,y,X,Y,w;in>>x>>y>>X>>Y>>w;
            for(int j=0;j<M;j++)piece.push_back({pt((M-j)*x+j*X,(M-j)*y+j*Y),pt((M-j-1)*x+(j+1)*X,(M-j-1)*y+(j+1)*Y),w});
            total+=w*M;
        }
        in>>tail;if(!in||tail||total!=2089474919732ll*M)throw runtime_error("incorrect mixed total");
    }
};
struct MPoly{Bound box;vector<HP> planes;};
bool possibly_hits(const MPiece& p,const MPoly& shape,I den){
    if(max(p.a.x,p.b.x)<den*shape.box.l||min(p.a.x,p.b.x)>den*shape.box.r||max(p.a.y,p.b.y)<den*shape.box.b||min(p.a.y,p.b.y)>den*shape.box.t)return false;
    for(auto n:shape.planes){
        W a=(W)n.a*p.a.x+(W)n.b*p.a.y,b=(W)n.a*p.b.x+(W)n.b*p.b.y;
        if(min(a,b)>(W)den*n.k)return false;
    }
    return true;
}
bool surely_inside(const MPiece& p,const MPoly& shape,I den){
    if(shape.planes.size()<3||min(p.a.x,p.b.x)<=den*shape.box.l||max(p.a.x,p.b.x)>=den*shape.box.r||min(p.a.y,p.b.y)<=den*shape.box.b||max(p.a.y,p.b.y)>=den*shape.box.t)return false;
    for(auto n:shape.planes){
        W a=(W)n.a*p.a.x+(W)n.b*p.a.y,b=(W)n.a*p.b.x+(W)n.b*p.b.y;
        if(max(a,b)>=(W)den*n.k)return false;
    }
    return true;
}
struct MFlow{
    struct Arc{int v,back;I capacity;};vector<vector<Arc>> gr;vector<int> level,iter;
    MFlow(int n):gr(n),level(n),iter(n){}
    void add(int i,int j,I cap){int a=gr[i].size(),b=gr[j].size();gr[i].push_back({j,b,cap});gr[j].push_back({i,a,0});}
    I push(int v,int t,I amount){
        if(v==t)return amount;
        for(int& i=iter[v];i<(int)gr[v].size();i++){
            auto& a=gr[v][i];if(!a.capacity||level[a.v]!=level[v]+1)continue;
            I w=push(a.v,t,min(amount,a.capacity));if(w){a.capacity-=w;gr[a.v][a.back].capacity+=w;return w;}
        }
        return 0;
    }
    I solve(int s,int t){
        I flow=0;while(true){fill(level.begin(),level.end(),-1);vector<int> q={s};level[s]=0;
            for(int v=0;v<(int)q.size();v++)for(auto a:gr[q[v]])if(a.capacity&&level[a.v]<0){level[a.v]=level[q[v]]+1;q.push_back(a.v);}
            if(level[t]<0)break;fill(iter.begin(),iter.end(),0);I w;while((w=push(s,t,INT64_MAX/8)))flow+=w;
        }return flow;
    }
};
struct MResult{I required=0,flow=0,unavailable=0;unsigned witness=0;};
MResult mixed_test(Engine& e,const Choices& choice,const MixedMeasure& mu,int an,int div,const char* trace){
    vector<unsigned> mask(mu.piece.size()),forced(mask.size());array<I,N> demand{};vector<vector<MPoly>> outer(N);
    vector<P> bodies(e.B);
    for(int k=0;k<e.B;k++){
        P q={{-e.D,-e.D},{e.D,-e.D},{e.D,e.D},{-e.D,e.D}};
        for(auto n:e.rows[k].axes)q=one_half(q,n);bodies[k]=move(q);
    }
    for(int i=0;i<N;i++){int id=choice.A[i];
        for(int k=0;k<e.B;k++)if(!e.init[k][id].empty()){
            P p=mink(e.init[k][id],bodies[k],false);outer[i].push_back({bbox(p),facets(p)});
        }
        if(outer[i].empty())return {1,0,0,1u<<i};
        auto opts=families(e,id,an,div);if(opts.empty())return {1,0,0,1u<<i};
        vector<int> relevant;MPoly fixed{bbox(e.seed[id]),facets(e.seed[id])};
        for(int j=0;j<(int)mu.piece.size();j++){
            auto& z=mu.piece[j];if(surely_inside(z,fixed,mu.den))forced[j]|=1u<<i;
            bool possible=false;for(const auto& a:outer[i])if(possibly_hits(z,a,mu.den)){possible=true;break;}
            if(possible){mask[j]|=1u<<i;relevant.push_back(j);}
        }
        I least=mu.total;
        for(auto& o:opts){
            I amount=0;MPoly shape{bbox(o.mandatory),facets(o.mandatory)};
            for(int j:relevant)if(surely_inside(mu.piece[j],shape,mu.den))amount+=mu.piece[j].weight;
            least=min(least,amount);if(least<=mu.unit)break;
        }
        demand[i]=max(mu.unit,least);
    }
    map<unsigned,I> bymask;
    for(int j=0;j<(int)mask.size();j++){
        if(__builtin_popcount(forced[j])>1)return {1,0,0,forced[j]};
        if(forced[j])mask[j]=forced[j];bymask[mask[j]]+=mu.piece[j].weight;
    }
    int n=bymask.size(),src=0,sink=n+N+1;MFlow g(sink+1);int z=0;MResult ret;
    for(auto [bits,w]:bymask){
        z++;g.add(src,z,w);for(int i=0;i<N;i++)if(bits&(1u<<i))g.add(z,n+1+i,mu.total+1);
    }
    for(int i=0;i<N;i++){g.add(n+1+i,sink,demand[i]);ret.required+=demand[i];}
    ret.flow=g.solve(src,sink);ret.unavailable=bymask[0];
    for(int i=0;i<N;i++)if(g.level[n+1+i]<0)ret.witness|=1u<<i;
    if(ret.flow<ret.required){
        I want=0,can=0;for(int i=0;i<N;i++)if(ret.witness&(1u<<i))want+=demand[i];
        for(auto [bits,w]:bymask)if(bits&ret.witness)can+=w;if(can>=want)throw runtime_error("Hall witness failure");
    }
    if(trace&&*trace){ofstream o(trace);o<<mu.den<<" "<<mu.unit<<" "<<mu.total<<" "<<ret.witness<<"\n";for(auto d:demand)o<<d<<" ";o<<"\n";for(auto [m,w]:bymask)o<<m<<" "<<w<<"\n";}
    return ret;
}
