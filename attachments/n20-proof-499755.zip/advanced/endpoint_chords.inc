// Universal interval of transverse lines on which a tile must contribute
// a chord of length at least one. Coordinates are millionths. This uses
// the exact formula d=(cos+sin)/2-cos*sin=(1+u-u*u)/2, u=cos+sin.
I one_chord_radius(const Row& r,I D){
    auto dir=[](I k,I g){return array<I,3>{g*g-k*k,2*k*g,g*g+k*k};};
    auto a=dir(r.ki,r.gi),b=dir(r.ki+1,r.gi);
    if(a[0]>=a[1]&&b[0]<=b[1])return 207106; // floor((sqrt(2)-1)/2 * 1e6)
    I q=D;
    for(auto z:{a,b}){
        I n=z[0]+z[1],d=z[2];
        q=min(q,fl((W)D*((W)d*d+(W)n*d-(W)n*n),2*(W)d*d));
    }
    return q;
}
bool strict_five_chords(const vector<int>& O,const vector<Row>&rows,vector<vector<P>>&C,I U,I D){
    if(U>5*D)return true;
    vector<I> rad;for(const auto& row:rows)rad.push_back(one_chord_radius(row,D)-(U<5*D));
    for(int axis=0;axis<2;axis++){
        vector<pair<I,I>> range(O.size(),{INT64_MIN,INT64_MAX});vector<I> levels;
        for(size_t i=0;i<O.size();i++){
            bool any=false;for(size_t k=0;k<rows.size();k++){
                const auto& p=C[k][O[i]];if(p.empty())continue;
                any=true;auto b=bbox(p);I lo=axis?b.l:b.b,hi=axis?b.r:b.t;
                range[i].first=max(range[i].first,hi-rad[k]);
                range[i].second=min(range[i].second,lo+rad[k]);
            }
            if(!any)return false;
            if(range[i].first<=range[i].second){levels.push_back(range[i].first);levels.push_back(range[i].second);}
        }
        // Five complete chords cannot occur in a strictly interior packing
        // at 5. They also cannot occur on a board strictly below 5.
        for(I level:levels){
            int n=0;for(auto [l,r]:range)n+=l<=level&&level<=r;
            if(n>=5)return false;
            if(n!=4)continue;
            for(size_t i=0;i<O.size();i++){
                if(range[i].first<=level&&level<=range[i].second)continue;
                for(size_t k=0;k<rows.size();k++){
                    auto& p=C[k][O[i]];if(p.empty())continue;auto box=bbox(p);
                    I a=level-rad[k],b=level+rad[k],low=axis?box.l:box.b,high=axis?box.r:box.t;
                    if(low>=a&&high<=b){p.clear();continue;}
                    if(low>=a&&low<b){HP h=axis?HP{-1,0,-b}:HP{0,-1,-b};p=cut(p,h);}
                    else if(high<=b&&high>a){HP h=axis?HP{1,0,a}:HP{0,1,a};p=cut(p,h);}
                }
            }
        }
    }
    return true;
}
