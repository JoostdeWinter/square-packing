"""Closed endpoint coverings, including the exact limiting angles and potential rack-event degeneracies."""
from fractions import Fraction as F
from itertools import combinations,product
from pathlib import Path
from functools import lru_cache
import math,json,sys,argparse
h=Path(__file__).resolve().parents[1];D=10**6;U=5*D
def add(p,q,scale=1):
 r=[(p[i] if i<len(p) else 0)+scale*(q[i] if i<len(q) else 0) for i in range(max(len(p),len(q)))]
 while r and r[-1]==0:r.pop()
 return tuple(r)
def sc(p,a):return tuple(a*v for v in p)
def mul(p,q):
 r=[0]*(len(p)+len(q)-1)
 for i,x in enumerate(p):
  for j,y in enumerate(q):r[i+j]+=x*y
 return add(r,())
def events(points):
 c=(1,0,-1);s=(0,2);d=(1,0,1);u=add(c,s);H=sc(d,D//2)
 X=[];Y=[]
 for x,y in points:
  a=add(sc(c,x),sc(s,y));b=add(sc(c,y),sc(s,-x))
  for sign in (-1,1):X.append(add(a,H,sign));Y.append(add(b,H,sign))
 X=list(set(X));Y=list(set(Y))
 for lines in (X,Y):
  for a,b in combinations(lines,2):yield add(a,b,-1)
 lo=sc(u,D);hi=add(sc(d,2*U),lo,-1)
 for x,y in product((lo,hi),repeat=2):
  for lines,z in [(X,add(mul(c,x),mul(s,y))),(Y,add(mul(c,y),mul(s,x),-1))]:
   for a in lines:yield add(z,sc(mul(d,a),2),-1)
 low=mul(lo,d);high=mul(hi,d)
 for a in X:
  ca=mul(c,a);sa=mul(s,a)
  for b in Y:
   for q in [add(ca,mul(s,b),-1),add(sa,mul(c,b))]:
    q=sc(q,2);yield add(q,low,-1);yield add(q,high,-1)
def at_one(p):return tuple((-1)**j*sum(math.comb(k,j)*p[k] for k in range(j,len(p))) for j in range(len(p)))
def rootfree_den(ps):
 Q=8;n=0
 for p in ps:
  p=list(p)
  while p and not p[0]:p.pop(0)
  if len(p)<=1:continue
  n+=1
  while abs(p[0])*Q**(len(p)-1)<=sum(abs(v)*Q**(len(p)-1-j) for j,v in enumerate(p) if j):Q*=2
 return Q,n
def uv(t):
 p,q=t.numerator,t.denominator
 return q*q-p*p,2*p*q,q*q+p*p
def covers_rect(sites,H,board):
 xmin=lambda a,b: min(a,b)
 ys=[y for _,y in board];lo=min(ys);hi=max(ys)
 Y=sorted({lo,hi}|{e for _,y in sites for e in [y-H,y+H] if lo<e<hi})
 for low,high in zip(Y,Y[1:]):
  xx=[]
  for z,q in zip(board,board[1:]+board[:1]):
   x,y=z;X,y1=q
   if low<=y<=high:xx.append((x,1))
   if y>y1:x,y,X,y1=X,y1,x,y
   if y<y1:
    for line in (low,high):
     if y<line<y1:xx.append((x*(y1-y)+(X-x)*(line-y),y1-y))
  if not xx:raise ValueError('bad coordinate slab')
  # Exact rationals. A floor for the left edge and a ceiling for the right
  # are valid because the endpoints of the intervals used to cover them are integers.
  left=min(n//d for n,d in xx);right=max(-((-n)//d) for n,d in xx)
  for x,y in sites:
   if y-H<=low and high<=y+H:
    if x-H>left:break
    left=max(left,x+H)
    if left>=right:break
  if left<right:return False
 return True
def fixed(points,t):
 C,S,E=uv(t);lo=D*(C+S);hi=2*U*E-lo
 board=[(C*x+S*y,C*y-S*x) for x,y in [(lo,lo),(hi,lo),(hi,hi),(lo,hi)]]
 cells=sorted((2*E*(C*x+S*y),2*E*(C*y-S*x)) for x,y in points)
 return covers_rect(cells,D*E*E,board)
@lru_cache(maxsize=150000)
def envelope(a,b):
 C,S,E=uv((a+b)/2);ends=[uv(a),uv(b)]
 rat=max(F(C*x+S*y+abs(C*y-S*x),E*d) for x,y,d in ends)
 assert all(C*x+S*y>abs(C*y-S*x) for x,y,d in ends)
 r=F(D*E,2)/rat;H=r.numerator//r.denominator
 lo=min(D*(x+y)//(2*d) for x,y,d in ends);hi=U-lo
 board=[(C*x+S*y,C*y-S*x) for x,y in [(lo,lo),(hi,lo),(hi,hi),(lo,hi)]]
 return C,S,H,board
def chart(points,a,b):
 C,S,H,board=envelope(a,b);sites=sorted((C*x+S*y,C*y-S*x) for x,y in points);return covers_rect(sites,H,board)
def prove(points):
 points=tuple(sorted(points))
 # Screen actual failure witnesses before computing an event family.
 for k in range(33):
  if not fixed(points,F(k,32)):return None
 ps=set(events(points));ps.discard(())
 L,n0=rootfree_den(ps);R,n1=rootfree_den(map(at_one,ps));a=F(1,L);b=1-F(1,R)
 if not fixed(points,a/2) or not fixed(points,(1+b)/2):return None
 leaves=[]
 def sub(a,b,depth):
  if chart(points,a,b):leaves.append([str(a),str(b)]);return True
  if depth>=23 or not fixed(points,(a+b)/2):return False
  mid=(a+b)/2;return sub(a,mid,depth+1) and sub(mid,b,depth+1)
 cuts=sorted({a,b}|{F(i,8) for i in range(1,8) if a<F(i,8)<b})
 if any(not sub(x,y,0) for x,y in zip(cuts,cuts[1:])):return None
 return {'event_polynomials':len(ps),'left_denominator':L,'right_denominator':R,'interval_count':len(leaves),'exact_charts':leaves}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--worker',type=int,default=2);ap.add_argument('--single',action='store_true');v=ap.parse_args()
 from concurrent.futures import ProcessPoolExecutor
 sys.path.insert(0,str(h.parent/'important_20261120'));from marks import geometry
 pts,tasks=geometry(500);d=h/'trials/endpoint_marks';d.mkdir(exist_ok=True)
 work=[('primary',pts,(-1,0,0))]
 if not v.single:
  for _,i,x,y in tasks:
   p=pts[i];q=(500*x,500*y)
   for fac in (1,2,4):
    site=tuple(a+(b-a)//fac for a,b in zip(p,q));row=pts.copy();row[i]=site
    if site==p:continue
    work.append((f'{i}_{site[0]}_{site[1]}',row,(i,*site)))
 seen={};work=[t for t in work if not (t[0] in seen or seen.setdefault(t[0],False))]
 with ProcessPoolExecutor(v.worker) as pool:
  tasks={pool.submit(prove,p):[k,p,chg] for k,p,chg in work if not (d/(k+'.json')).exists()}
  from concurrent.futures import as_completed
  for fu in as_completed(tasks):
   key,points,change=tasks[fu];proof=fu.result();res={'key':key,'change':change,'points':points,'proof':proof}
   (d/(key+'.json')).write_text(json.dumps(res,separators=(',',':')));print(key,'PASS' if proof else 'unproved',None if not proof else proof['interval_count'],flush=True)
if __name__=='__main__':main()
