"""Independently prove an exhausted tile chart using rational polygon subtraction.

The native algorithm scans integer-rounded polygon edges. This checker keeps
exact fractions, constructs each inner square in the rational midpoint frame,
and subtracts the open obstacles by successive half-plane splits instead.
"""
from fractions import Fraction as F
from itertools import product
from collections import Counter
from pathlib import Path
import argparse,gzip,json,hashlib,time
from check_union import hull,edges
def direction(k,g):
 return F(g*g-k*k,g*g+k*k),F(2*k*g,g*g+k*k)
def normals(poly):
 return [(b[1]-a[1],a[0]-b[0],(b[1]-a[1])*a[0]+(a[0]-b[0])*a[1]) for a,b in edges(poly)]
def clip(p,h):
 if not p:return []
 nx,ny,k=h;vals=[nx*x+ny*y-k for x,y in p]
 if max(vals)<=0:return p
 if min(vals)>0:return []
 out=[]
 for idx,(a,b) in enumerate(edges(p)):
  u,v=vals[idx],vals[(idx+1)%len(p)]
  if u<=0:out.append(a)
  if (u<0<v) or (v<0<u):
   t=F(u,u-v);out.append((a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t))
 return hull(out)
def subtract(p,obs,stats):
 ns=normals(obs);rs=[]
 for x,y,k in ns:
  vv=[x*a+y*b-k for a,b in p];rs.append((min(vv),max(vv)))
 if any(a>=0 for a,b in rs):return [p]
 if all(b<0 for a,b in rs):return []
 q=p;out=[]
 for (x,y,k),(lo,hi) in zip(ns,rs):
  if not q:break
  if hi>=0:
   ext=clip(q,(-x,-y,-k))
   if ext:out.append(ext)
  if hi>0:q=clip(q,(x,y,k));stats['halfplane_splits']+=1
 return out
def bb(r):
 x,y=zip(*r);return min(x),max(x),min(y),max(y)
def outside(a,b):return a[0]>b[1] or b[0]>a[1] or a[2]>b[3] or b[2]>a[3]
def run(path):
 raw=gzip.decompress(path.read_bytes()) if path.suffix=='.gz' else path.read_bytes();ls=iter(raw.decode().splitlines());tag,U,sub,B,i,n=next(ls).split();assert tag=='FRAME1';U,sub,B,i,n=map(int,(U,sub,B,i,n));assert n==20
 def poly(v):
  n,*vals=map(int,v);assert len(vals)==2*n;return list(zip(vals[::2],vals[1::2]))
 seeds=[poly(next(ls).split()) for j in range(n)];holes=poly(next(ls).split());stats=Counter();t0=time.monotonic()
 for k in range(B):
  r=next(ls).split();ki,gi=map(int,r[:2]);P=poly(r[2:])
  if not P:continue
  stats['nonempty_input_bins']+=1
  for v in range(sub):
   stats['angular_subcharts']+=1;p=ki*sub+v;g=gi*sub
   c,s=direction(2*p+1,2*g);ends=[direction(p,g),direction(p+1,g)];half=F(500000)
   h=half*min(x+y for x,y in ends);factor=max((c*x+s*y+abs(c*y-s*x)) for x,y in ends)
   inside=half/factor;out=half*factor;q=P
   for z in ((-1,0,-h),(0,-1,-h),(1,0,U-h),(0,1,U-h)):q=clip(q,z)
   if not q:stats['walls']+=1;continue
   def rotate(a):return [(c*x+s*y,-s*x+c*y) for x,y in a]
   q=hull(rotate(q));own=bb(rotate(seeds[i]));bounds=[(1,0,own[0]+out),(-1,0,-own[1]+out),(0,1,own[2]+out),(0,-1,-own[3]+out)]
   for z in bounds:q=clip(q,z)
   if not q:stats['anchors']+=1;continue
   # Obstacle vertices are exact. Every point in its interior would make
   # this tile's interior meet the other tile's required convex seed.
   objs=[];bbox=bb(q)
   for pts in [z for j,z in enumerate(seeds) if j!=i]+[[z] for z in holes]:
    w=rotate(pts);x,X,y,Y=bb(w)
    if outside(bbox,(x-inside,X+inside,y-inside,Y+inside)):continue
    oba=hull([(a+ax*inside,b+ay*inside) for a,b in w for ax,ay in product((-1,1),repeat=2)])
    objs.append(oba)
   pieces=[q]
   for o in objs:
    pieces=[a for z in pieces for a in subtract(z,o,stats)];stats['obstacles_visited']+=1
    if not pieces:break
   assert not pieces,(ki,gi,v,sub,'exact complement nonempty',len(pieces))
   stats['union_covers']+=1
 assert next(ls,None) is None and stats['angular_subcharts']>0
 return {'trace':path.name,'trace_sha256_uncompressed':hashlib.sha256(raw).hexdigest(),'side_micro':U,'exhausted_tile':i,'statistics':dict(stats),'seconds':round(time.monotonic()-t0,2)}
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('traces',nargs='+',type=Path);ap.add_argument('--out',type=Path);a=ap.parse_args();z=[]
 for path in a.traces:
  r=run(path);z.append(r);print(r,flush=True)
 if a.out:a.out.write_text(json.dumps(z,indent=2)+'\n')
