from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'linear.cpp').read_text()
def once(a,b):
 global s
 assert s.count(a)==1,a
 s=s.replace(a,b)
n='bool contract_disjunction(';once(n,(h/'depth.inc').read_text()+'\n'+n)
n='P req=convex_union(convex_union(x.seed[id],r),b);'
once(n,n+' auto demands=needed_depths(records,i,r,b,owners);vector<I> worst(demands.size());')
n='p=restrict_to_anchors(move(p),x.rows[k],req);'
once(n,n+'''for(const auto& dm:demands)if(!p.empty()){
                    I width=depth_table.bound(dm.depth,x.rows[k],dm.primary);
                    if(width<1000000)p=depth_clip(move(p),x.rows[k],dm.p,width);
                }''')
n='for(auto h:x.rows[k].fac){h.k+=mn(p,h);all.push_back(h);}'
once(n,'''for(size_t dd=0;dd<demands.size();dd++)worst[dd]=max(worst[dd],depth_table.bound(demands[dd].depth,x.rows[k],demands[dd].primary));
                '''+n)
n='if(!all.empty())core_choices.push_back(convex_union(req,safe(all,x.U)));'
once(n,'''if(!all.empty()){for(size_t dd=0;dd<demands.size();dd++)pad(req,demands[dd].p,worst[dd]);
            core_choices.push_back(convex_union(req,safe(all,x.U)));}''')
n='read_extra(base.U);';once(n,n+'depth_table.load(getenv("N20_DEPTH_TABLE"),base.U);')
p=h/'deeper.cpp';p.write_text(s);subprocess.run(['g++','-O3','-std=c++17',p,'-o',h/'deeper'],check=True)
