// A simultaneous disjunction of exact rational separating half-planes.
// Distinct groups are exhaustive orientation intervals. Each centered body
// lies inside every allowed physical tile in the corresponding group.
string sym(int axis,int i){return string(axis?"y":"x")+to_string(i);}
string gate(int i,int g,int count){return count==1?"true":("a"+to_string(i)+"_"+to_string(g));}
string lin(I a,string x,I b,string y){
    auto term=[](I v,string s){return v==1?s:"(* "+to_string(v)+" "+s+")";};
    if(a==0)return term(b,y);if(b==0)return term(a,x);
    return "(+ "+term(a,x)+" "+term(b,y)+")";
}
vector<HP> outer_faces(const P& p){
    if(p.size()>=3)return facets(p);
    auto b=bbox(p);return {{1,0,b.r},{-1,0,-b.l},{0,1,b.t},{0,-1,-b.b}};
}
void bool_list(ostream& f,const vector<string>& terms){
    if(terms.empty()){f<<"false";return;}if(terms.size()==1){f<<terms[0];return;}
    f<<"(or";for(auto& s:terms)f<<" "<<s;f<<")";
}
void export_disj(const Engine& e,const vector<int>& ids,int groups,const string& name,bool strict){
    ofstream out(name);if(!out)throw runtime_error("disjunction output");
    out<<"(set-logic QF_LRA)\n";
    vector<vector<FrameGroup>> all;
    long blockers=0,orcl=0,terms=0;
    for(int i=0;i<(int)ids.size();i++){
        out<<"(declare-const x"<<i<<" Real) (declare-const y"<<i<<" Real)\n";
        auto gs=ep_groups(e,ids[i],groups);vector<string> gates;
        for(int g=0;g<(int)gs.size();g++){
            string sel=gate(i,g,gs.size());gates.push_back(sel);
            if(sel!="true")out<<"(declare-const "<<sel<<" Bool)\n";
            auto &p=gs[g].centers;
            if(strict && p.size()<3){out<<"(assert (not "<<sel<<"))\n";continue;}
            for(auto n:outer_faces(p)){
                unique_normal(n);
                out<<"(assert (=> "<<sel<<" ("<<(strict?"<":"<=")<<" "<<lin(n.a,sym(0,i),n.b,sym(1,i))<<" "<<n.k<<")))\n";
            }
        }
        out<<"(assert ";bool_list(out,gates);out<<")\n";all.push_back(move(gs));
    }
    for(int i=0;i<(int)ids.size();i++)for(int j=i+1;j<(int)ids.size();j++){
        string X="(- "+sym(0,j)+" "+sym(0,i)+")",Y="(- "+sym(1,j)+" "+sym(1,i)+")";
        for(int f=0;f<(int)all[i].size();f++)for(int g=0;g<(int)all[j].size();g++){
            auto& a=all[i][f];auto& b=all[j][g];auto A=bbox(a.centers),B=bbox(b.centers);
            if(max({A.l-B.r,B.l-A.r,A.b-B.t,B.b-A.t})>1414214)continue;
            // Explicit vertex sums give the true Minkowski difference of the two inner shapes.
            P forbidden=mink(a.inner,b.inner,true);vector<string> branches;bool automatic=false;
            for(auto n:facets(forbidden)){
                unique_normal(n);
                I largest=mx(b.centers,n)-mn(a.centers,n),smallest=mn(b.centers,n)-mx(a.centers,n);
                if(strict?smallest>n.k:smallest>=n.k){automatic=true;break;}
                if(strict?largest<=n.k:largest<n.k)continue;
                branches.push_back(string("(")+(strict?">":">=")+" "+lin(n.a,X,n.b,Y)+" "+to_string(n.k)+")");
            }
            if(automatic)continue;
            out<<"(assert (=> (and "<<gate(i,f,all[i].size())<<" "<<gate(j,g,all[j].size())<<") ";
            bool_list(out,branches);out<<"))\n";orcl++;terms+=branches.size();blockers+=branches.empty();
        }
    }
    out<<"; pair constraints "<<orcl<<" separating alternatives "<<terms<<" incompatible group pairs "<<blockers<<"\n";
    out<<"(check-sat)\n";
}
