from pathlib import Path
import sys,subprocess,json,os,gzip
h=Path(__file__).resolve().parents[1]
def test():
 selected=next(x[0] for line in (h/'runs/refined28_ubsan.log').read_text().splitlines() if (x:=json.loads(line))[3]=='root: clusters')
 z=json.loads((h/'trials/tree498_fine'/selected).read_text())
 a,b=z['key'].split('_');env=dict(os.environ,N20_FINE='4',N20_EXTRA_RACKS=str(h/'advanced/racks498_20.txt'))
 out=h/'trials/hard498.trace'
 cmd=[h/'advanced/audit','audit',h/'cold498/i64',h/'cold498/strongprofiles',h/'enumerator/marks498.txt',a,b,'40','4',','.join(map(str,z['owners'])),'-',out]
 r=subprocess.check_output(cmd,text=True,input=' '.join(map(str,z['match']))+'\n',env=env);assert r.split()==['AUDIT']
 from check_audit import verify
 proof=verify(out);assert proof['outcome']=='IMPOSSIBLE';proof.update(mask_pair=z['key'],matching=z['match'],owners=z['owners']);(h/'runs/rational_cluster_audit.json').write_text(json.dumps(proof,indent=2));print(proof)
 with gzip.open(h/'proof498/cluster_trace.txt.gz','wb',compresslevel=9) as f:f.write(out.read_bytes())
if __name__=='__main__':test()
