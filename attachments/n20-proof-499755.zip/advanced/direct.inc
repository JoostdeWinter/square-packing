// For each possible angle group of tile j compute the overlap region of
// its centered inner body with tile i's centered inner body. A center of i
// is forbidden if every center and angle option of j causes an overlap.
// Taking the intersection after summing the two bodies preserves information
// that can disappear when a world-coordinate core is intersected first.
bool direct_centers(Engine& e,const vector<int>& ids,int groups){
    vector<P> bodies(e.B);vector<vector<HP>> face(e.B);
    for(int k=0;k<e.B;k++){
        bodies[k]=centered_core({k},e);P neg;for(auto p:bodies[k])neg.push_back({-p.x,-p.y});
        bodies[k]=convex_union(move(bodies[k]),neg);face[k]=facets(bodies[k]);
    }
    for(int j:ids){
        auto g=ep_groups(e,j,groups);if(g.empty())return false;
        vector<vector<HP>> gf;for(auto& a:g){P neg;for(auto p:a.inner)neg.push_back({-p.x,-p.y});
            a.inner=convex_union(move(a.inner),neg);gf.push_back(facets(a.inner));}
        for(int k=0;k<e.B;k++){
            bool live=false;for(int i:ids)if(i!=j&&!e.init[k][i].empty())live=true;if(!live)continue;
            map<pair<I,I>,I> bound;
            for(size_t l=0;l<g.size();l++){
                const auto& a=g[l];auto ha=add(bodies[k],face[k],a.inner,gf[l]);
                for(auto f:ha.p){
                    f.k+=mn(a.centers,f);unique_normal(f);
                    auto r=bound.emplace(make_pair(f.a,f.b),f.k);if(!r.second)r.first->second=min(r.first->second,f.k);
                }
            }
            vector<HP> common;for(auto [n,z]:bound)common.push_back({n.first,n.second,z});
            for(int i:ids)if(i!=j&&!e.init[k][i].empty()){
                auto& p=e.init[k][i];p=noninterior_hull(p,common);
            }
        }
    }
    for(int i:ids)if(none_of(e.init.begin(),e.init.end(),[&](const vector<P>& v){return !v[i].empty();}))return false;
    return true;
}
