// All tiles except at most K use the specified closed tangent-half-angle
// interval. The capacities of disjoint groups sum to K. Splitting a group
// tries every division of its remaining capacity between its two children.
struct TBand{I a,b,p,q;int passes,sub,nodes=0,limit;};
struct TGroup{unsigned mask;int cap;};
bool overlaps_T(const Row& row,const TBand& t){
    return (I)(row.ki+1)*t.b>=t.a*row.gi && (I)row.ki*t.q<=t.p*row.gi;
}
bool all_T(const Row& row,const TBand& t){
    return (I)row.ki*t.b>=t.a*row.gi && (I)(row.ki+1)*t.q<=t.p*row.gi;
}
bool tighten_T(Engine& x,const vector<int>& ids,vector<TGroup>& groups,const TBand& t){
    vector<TGroup> next;
    for(auto g:groups){
        unsigned live=0;int forced=0;
        for(int i=0;i<N;i++)if(g.mask&(1u<<i)){
            bool yes=false,no=false;for(int k=0;k<x.B;k++)if(!x.init[k][ids[i]].empty()){
                yes|=overlaps_T(x.rows[k],t);no|=!all_T(x.rows[k],t);}
            if(!yes&&!no)return false;if(!yes)++forced;else if(no)live|=1u<<i;
        }
        if(forced>g.cap)return false;int cap=g.cap-forced;
        if(cap==0){
            for(int i=0;i<N;i++)if(live&(1u<<i))for(int k=0;k<x.B;k++)if(!overlaps_T(x.rows[k],t))x.init[k][ids[i]].clear();
        }else if(__builtin_popcount(live)>cap)next.push_back({live,cap});
    }
    groups=move(next);return true;
}
bool search_T(Engine x,const Choices& c,const vector<int>& own,vector<TGroup> groups,TBand& t){
    if(++t.nodes>t.limit)return false;int reason=0;
    // Do not drop zero-capacity groups before fine has created its final rows.
    if(!tighten_T(x,c.A,groups,t))return true;
    for(int j=0;j<t.passes;j++){
        if(!local_frame(x,c,own,t.sub)||!cluster_filter(x,c.A)||!propagate(x,c,own,1,11,reason))return true;
        if(!tighten_T(x,c.A,groups,t))return true;
    }
    if(groups.empty())return false;
    auto g=groups.back();groups.pop_back();unsigned l=0,r=0;int count=0;
    for(int i=0;i<N;i++)if(g.mask&(1u<<i)){(count++%2?l:r)|=1u<<i;}
    if(!l||!r)throw runtime_error("unsplittable angular quota");
    for(int a=0;a<=g.cap;a++){
        auto gs=groups;gs.push_back({l,a});gs.push_back({r,g.cap-a});
        if(!search_T(x,c,own,move(gs),t))return false;
    }
    return true;
}
