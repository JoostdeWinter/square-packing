from pathlib import Path
import json,os,subprocess,sys,gzip,argparse
h=Path(__file__).resolve().parents[1];sys.path.insert(0,str(h/'global'));from branches import paths
def run(U,tag,num):
 src=h/f'trials/frame{U}_{tag}';dest=h/'runs/frame_traces';dest.mkdir(exist_ok=True);count=0
 for fp in sorted(src.glob('*.json')):
  row=json.loads(fp.read_text());res=row['result']
  if len(res)!=2 or res[0]!='CLOSED_FRAME':continue
  b,r,s,f,sub,passes=row['settings'];p=paths(U,b);a,bb=row['mask_pair'].split('_');key=f'{U}_'+fp.stem
  out=dest/(key+'.txt');comp=dest/(key+'.txt.gz')
  if not comp.exists():
   env=dict(os.environ,N20_EXTRA_RACKS=str(p['racks'](r)),N20_DEPTH_TABLE=str(p['dep']),N20_FINE=str(f),N20_FRAME_SUB=str(sub),N20_UNION_PASSES=str(passes),N20_FRAME_TRACE=str(out))
   if s:env['N20_SHIFT_FILE']=str(h/f'trials/shifts{U}/s{s}.txt')
   z=subprocess.check_output([h/'advanced/frame_audit','frame',p['tab'],p['profiles'],p['moves'],a,bb,'30','3',','.join(map(str,row['owners']))],input=' '.join(map(str,row['matching']))+'\n',text=True,env=env).split()
   assert z==res and out.exists();comp.write_bytes(gzip.compress(out.read_bytes(),mtime=0));out.unlink()
  print(comp,flush=True);count+=1
  if count>=num:break
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('U',type=int);a.add_argument('tag');a.add_argument('--count',type=int,default=2);v=a.parse_args();run(v.U,v.tag,v.count)
