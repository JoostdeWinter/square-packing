// Extend a translated certified pattern by four marked points on one line.
// If translating the tile back would cross a wall, its chord on that line
// contains an interior fifth-grid ordinate. The angle-specific escape band
// is an additional necessary condition for using any of those four points.
void load_shifted(I U){
    auto path=getenv("N20_SHIFT_FILE");if(!path||!*path)return;
    ifstream in(path);int n;I side;in>>side>>n;if(!in||side!=U||side>5000000||side%5||n<1||n>150)throw runtime_error("shift data");
    for(int j=0;j<n;j++){
        int axis,sign,npts;I delta,tau;in>>axis>>sign>>delta>>tau>>npts;
        if(!in||axis<0||axis>1||abs(sign)!=1||delta<=0||delta+500000>tau||tau>914200||npts<20||npts>40)throw runtime_error("uncertified shift");
        Rack rack;
        for(int i=0;i<npts;i++){
            Point p;in>>p.x>>p.y;if(!in||min(p.x,p.y)<0||max(p.x,p.y)>U)throw runtime_error("shift point");
            if(axis)p.y+=sign*delta;else p.x+=sign*delta;
            if(min(p.x,p.y)>=0&&max(p.x,p.y)<=U)rack.push_back({p,false,-1,0});
        }
        for(int i=1;i<=4;i++){
            I level=sign==1?tau:U-tau;Point p=axis?Point{i*(U/5),level}:Point{level,i*(U/5)};
            rack.push_back({p,false,2*axis+(sign<0),delta});
        }
        aux_racks.push_back(move(rack));
    }
    string more;if(in>>more)throw runtime_error("trailing shift data");
}
