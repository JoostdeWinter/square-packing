from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'separators.cpp').read_text()
key='string sym(int axis,int i)';assert s.count(key)==1;s=s.replace(key,(h/'tilt_quota.inc').read_text()+'\n'+key)
key='if(mode=="sep"){';assert s.count(key)==1
s=s.replace(key,'''if(mode=="tiltquota"){
        int f=stoi(getenv("N20_FINE"));if(f>1)fine(x,data.A,f,base.B*f);
        TBand t;int quota;istringstream input(getenv("N20_TILT_SPEC"));
        input>>t.a>>t.b>>t.p>>t.q>>quota;
        if(!input||t.a<0||t.b<1||t.q<1||t.a*t.q>t.p*t.b||t.p>t.q||quota<0||quota>N)throw runtime_error("invalid angular quota");
        t.passes=stoi(getenv("N20_UNION_PASSES"));t.sub=stoi(getenv("N20_FRAME_SUB"));t.limit=stoi(getenv("N20_TILT_LIMIT"));
        bool closed=search_T(x,data,owners,{{(1u<<N)-1,quota}},t);
        cout<<(closed?"CLOSED_TILT ":"OPEN_TILT ")<<t.nodes<<endl;return 0;
    }
    '''+key)
p=h/'tilt_quota.cpp';p.write_text(s);t=h/'tilt_quota.partial';subprocess.run(['g++','-O3','-std=c++17',p,'-o',t],check=True);t.replace(h/'tilt_quota')
