"""Add literal axis-aligned support to all pure endpoint rows of the exception filter."""
from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'exception_band.cpp').read_text()
q='(axis!=0&&axis!=1)';assert s.count(q)==1;s=s.replace(q,'(axis<0||axis>2)')
q='''const auto& r=x.rows[k];
          bool inside=(I)(r.ki+1)*ld>=(I)lo*r.gi && (I)r.ki*hd<=(I)hi*r.gi;
          if(inside)continue;
          bool aligned=r.ki==0 || r.ki+1==r.gi;
          for(int i=0;i<N;i++)if(!(ex&(1<<i)) || (axis&&!aligned))x.init[k][data.A[i]].clear();'''
assert s.count(q)==1
s=s.replace(q,'''auto& r=x.rows[k];
          bool inside=(I)(r.ki+1)*ld>=(I)lo*r.gi && (I)r.ki*hd<=(I)hi*r.gi;
          bool aligned=r.ki==0 || r.ki+1==r.gi;
          if(inside){
              if(axis==2 && !aligned)for(int i=0;i<N;i++)if(ex&(1<<i))x.init[k][data.A[i]].clear();
              continue;
          }
          for(int i=0;i<N;i++)if(!(ex&(1<<i)) || (axis&&!aligned))x.init[k][data.A[i]].clear();
          if(axis&&aligned){
             I h=x.D/2;r.axes={HP{1,0,h},HP{-1,0,h},HP{0,1,h},HP{0,-1,h}};
             r.core={{-h,-h},{h,-h},{h,h},{-h,h}};r.fac=facets(r.core);
             for(int id:data.A)for(auto z:r.axes){
                 z.k+=mn(x.seed[id],z);
                 if(!x.init[k][id].empty()&&mx(x.init[k][id],z)>z.k)x.init[k][id]=cut(x.init[k][id],z);
             }
          }''')
p=h/'exact_axis_exception.cpp';p.write_text(s);o=h/'exact_axis_exception.partial';subprocess.run(['g++','-O1','-g0','--param=ggc-min-expand=4','--param=ggc-min-heapsize=4096','-std=c++17',p,'-o',o],check=True);o.replace(h/'exact_axis_exception')
