// Split another tile's continuous center-angle domain into a finite cover.
// Its required inner polygons give separate necessary nonoverlap conditions.
// For a fixed candidate tile a center is impossible if it is forbidden for
// every part of that cover. Intersecting translated Minkowski sums may be
// strictly stronger than translating the common inner polygon.
P half(P p,int axis,int sign,I threshold){
    if(p.empty())return p;
    HP n=axis==0?HP{sign,0,sign*threshold}:axis==1?HP{0,sign,sign*threshold}:axis==3?HP{sign,sign,sign*threshold}:HP{sign,-sign,sign*threshold};
    if(mx(p,n)>n.k)p=cut(p,n);
    return p;
}
vector<P> conditional_cores(const Engine& e,int id){
    P all;for(int k=0;k<e.B;++k)merge_vertices(all,e.init[k][id]);if(all.empty())return {};
    auto bb=bbox(all);I midx=(bb.r+bb.l)/2,midy=(bb.t+bb.b)/2;
    int lo=e.rows[0].gi,hi=0;for(int k=0;k<e.B;k++)if(!e.init[k][id].empty()){lo=min(lo,e.rows[k].ki);hi=max(hi,e.rows[k].ki);}
    int amid=(lo+hi+1)/2;
    vector<vector<HP>> normals(8);
    for(int k=0;k<e.B;k++)for(int a=0;a<2;a++)for(int b=0;b<2;b++){
        P p=half(e.init[k][id],0,a?1:-1,midx);
        p=half(move(p),1,b?1:-1,midy);if(p.empty())continue;
        auto& dst=normals[a+2*b+4*(e.rows[k].ki>=amid)];
        for(auto f:e.rows[k].fac){f.k+=mn(p,f);dst.push_back(f);}
    }
    vector<P> cores;
    for(auto& v:normals)if(!v.empty()){
        P p=convex_union(e.seed[id],safe(v,e.U));
        if(p.size()<3)return {e.seed[id]}; // This coarse fallback only weakens the test.
        cores.push_back(move(p));
    }
    return cores;
}
bool cluster_filter(Engine& e,const vector<int>& ids){
    for(int j:ids){
        auto shapes=conditional_cores(e,j);
        if(shapes.empty())return false;
        if(shapes.size()==1 && shapes[0].size()<3)continue;
        for(int k=0;k<e.B;k++){
            vector<vector<HP>> parts;vector<HP> all;Bound shared={INT64_MIN,INT64_MAX,INT64_MIN,INT64_MAX};
            for(auto& shape:shapes){
                Ban b=add(shape,facets(shape),e.rows[k].core,e.rows[k].fac);
                shared.l=max(shared.l,b.b.l);shared.r=min(shared.r,b.b.r);shared.b=max(shared.b,b.b.b);shared.t=min(shared.t,b.b.t);
                all.insert(all.end(),b.p.begin(),b.p.end());
            }
            if(shared.l>=shared.r||shared.b>=shared.t)continue;
            for(int i:ids)if(i!=j){
                auto& p=e.init[k][i];if(p.empty())continue;
                if(!bmatch(bbox(p),shared))continue;
                p=noninterior_hull(p,all);
            }
        }
    }
    return true;
}
