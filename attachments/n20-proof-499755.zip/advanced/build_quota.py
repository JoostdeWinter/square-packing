from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'hall.cpp').read_text();key='string sym(int axis,int i)';assert s.count(key)==1;s=s.replace(key,(h/'axis_quota.inc').read_text()+'\n'+key)
key='if(mode=="hall"){';assert s.count(key)==1;s=s.replace(key,'''if(mode=="quota"){
        int f=stoi(getenv("N20_FINE"));if(f>1)fine(x,data.A,f,base.B*f);
        AQLimit lim;lim.depth=stoi(getenv("N20_QUOTA_DEPTH"));lim.budget=stoi(getenv("N20_QUOTA_BUDGET"));lim.passes=stoi(getenv("N20_UNION_PASSES"));
        array<int,N> forced;forced.fill(-1);bool ok=quota_tree(move(x),data,owners,forced,0,lim);
        cout<<(ok?"CLOSED_QUOTA":"OPEN_QUOTA")<<" "<<lim.nodes<<endl;return 0;
    }
    '''+key)
p=h/'quota.cpp';p.write_text(s);t=h/'quota.partial';subprocess.run(['g++','-O3','-std=c++17',p,'-o',t],check=True);t.replace(h/'quota')
