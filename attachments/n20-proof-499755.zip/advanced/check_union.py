"""Compare the native edge-interval sweep against an exact planar arrangement."""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import argparse,random,subprocess,json
def area(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def hull(points):
 pts=sorted(set(points))
 if len(pts)<3:return pts
 def half(s):
  t=[]
  for p in s:
   while len(t)>1 and area(t[-2],t[-1],p)<=0:t.pop()
   t.append(p)
  return t
 return half(pts)[:-1]+half(reversed(pts))[:-1]
def edges(poly):return list(zip(poly,poly[1:]+poly[:1]))
def contains(p,v,strict=False):
 if not p:return False
 if len(p)==1:return not strict and v==p[0]
 if len(p)==2:return not strict and area(p[0],p[1],v)==0 and all(min(a,b)<=z<=max(a,b) for a,b,z in zip(*p,v))
 s=[area(a,b,v) for a,b in edges(p)]
 return min(s)>0 if strict else min(s)>=0
def meet(a,b,c,d):
 dx,dy=b[0]-a[0],b[1]-a[1];ex,ey=d[0]-c[0],d[1]-c[1];det=dx*ey-dy*ex
 if det==0:return []
 t=F((c[0]-a[0])*ey-(c[1]-a[1])*ex,det);u=F((c[0]-a[0])*dy-(c[1]-a[1])*dx,det)
 return [(a[0]+t*dx,a[1]+t*dy)] if 0<=t<=1 and 0<=u<=1 else []
def rect(a,b,c,d):return [(a,b),(c,b),(c,d),(a,d)]
def check(exe,trials):
 R=random.Random(20261121);cases=[];domain=rect(0,0,10,10)
 for bands in [[rect(-1,-1,5,11),rect(5,-1,11,11)],[rect(-1,-1,6,11),rect(5,-1,11,11)],[rect(-1,-1,5,11),rect(5,-1,11,11),rect(-1,-1,11,5),rect(-1,5,11,11)], [rect(-1,-1,11,11)],[rect(0,0,10,10)],[]]:cases.append((domain,bands))
 for k in range(trials):
  dom=rect(-12,-12,12,12) if k%2==0 else hull([(R.randint(-17,17),R.randint(-17,17)) for _ in range(8)])
  obs=[]
  for j in range(R.randint(1,8)):
   x,y=R.randint(-18,18),R.randint(-18,18);rad=R.randint(4,25)
   p=hull([(x+R.randint(-rad,rad),y+R.randint(-rad,rad)) for _ in range(R.randint(4,9))])
   if len(p)>2:obs.append(p)
  if len(dom)>2:cases.append((dom,obs))
 def poly(p):return ' '.join(map(str,[len(p),*(n for q in p for n in q)]))
 data=[str(len(cases))]
 for dom,obs in cases:data.extend([poly(dom),str(len(obs)),*[poly(z) for z in obs]])
 raw=subprocess.check_output([exe,'union'],text=True,input='\n'.join(data)+'\n').splitlines();assert len(raw)==len(cases)
 vertices=0;empty=0;removed=0;degenerate=0
 for (dom,obs),line in zip(cases,raw):
  n,*v=map(int,line.split());assert len(v)==2*n;out=list(zip(v[::2],v[1::2]));allp=[dom,*obs];points=set(x for p in allp for x in p)
  for p,q in combinations(allp,2):
   for a,b in edges(p):
    for c,d in edges(q):points.update(meet(a,b,c,d))
  allowed=[x for x in points if contains(dom,x) and all(not contains(o,x,True) for o in obs)]
  assert all(contains(out,z) for z in allowed),(dom,obs,out,[x for x in allowed if not contains(out,x)])
  if not allowed:
   empty+=1;assert not out
  degenerate+=0<len(hull(allowed))<3;removed+=out!=dom;vertices+=len(allowed)
 return {'cases':len(cases),'true_admissible_vertices_checked':vertices,'completely_excluded':empty,'contracted':removed,'point_or_segment_complements':degenerate}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('binary');p.add_argument('--trials',type=int,default=700);v=p.parse_args();print(json.dumps(check(v.binary,v.trials),indent=2))
