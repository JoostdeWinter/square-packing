from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;s=(h/'energy.cpp').read_text();key='string sym(int axis,int i)';assert s.count(key)==1;s=s.replace(key,(h/'oblique.inc').read_text()+'\n'+key)
key='if(mode=="energy"){';assert s.count(key)==1
s=s.replace(key,'''if(mode=="oblique"){
        int f=stoi(getenv("N20_FINE"));if(f>1)fine(x,data.A,f,base.B*f);
        int passes=stoi(getenv("N20_UNION_PASSES")),sub=stoi(getenv("N20_FRAME_SUB")),slopes=stoi(getenv("N20_SLOPES")),density=stoi(getenv("N20_LINES"));
        auto dirs=olines(slopes);
        for(int pass=0;pass<passes;pass++){
            for(auto d:dirs)if(!oblique_cut(x,data.A,d,density)){cout<<"CLOSED_OBLIQUE "<<pass+1<<" line "<<d.a<<" "<<d.b<<endl;return 0;}
            if(!local_frame(x,data,owners,sub)){cout<<"CLOSED_OBLIQUE "<<pass+1<<" frame"<<endl;return 0;}
            if(!cluster_filter(x,data.A)||!propagate(x,data,owners,1,12,reason)){cout<<"CLOSED_OBLIQUE "<<pass+1<<" propagation "<<reason<<endl;return 0;}
        }cout<<"OPEN_OBLIQUE "<<passes<<endl;return 0;
    }
    '''+key)
p=h/'oblique.cpp';p.write_text(s);t=h/'oblique.partial';subprocess.run(['g++','-std=c++17','-O3',p,'-o',t],check=True);t.replace(h/'oblique')
