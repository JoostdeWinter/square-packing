from pathlib import Path
import subprocess
h=Path(__file__).resolve().parent;old=h.parent/'enumerator'
s=(old/'kernel.cpp').read_text()
def once(s,a,b):
 assert s.count(a)==1,a
 return s.replace(a,b)
n='vector<array<I,3>> restr;';s=once(s,n,(old/'slices.inc').read_text()+'\n'+(h/'endpoint_chords.inc').read_text()+'\n'+n)
n='for(it=0;it<rounds;it++){';s=once(s,n,n+'if ((it==0 || it%5==4) && (!strict_five_chords(O,rows,C,U,D) || !slice_filter(O,rows,C,H,U,D,where))) return 7;')
s=s[:s.index('struct Budget{')]+(old/'search.inc').read_text()
n='bool propagate(Engine& x,';s=once(s,n,(h/'extra.inc').read_text()+'\n'+n)
n='if(!contract_disjunction(x,data,owners,removed))';s=once(s,n,'if(!apply_resources(x,data.A)){reason=9;return false;}\n        '+n)
n='if(pair_filter(x,y,A,B,&allowed,&live)){';s=once(s,n,'if(!apply_resources(x,A)||!apply_resources(y,B)){cerr<<"auxiliary resources impossible\\n";return;}\n        '+n)
n='Movement p(argv[4],base.U),q=p;';s=once(s,n,n+'read_extra(base.U);')
n='Profile r(dir+"/"+to_string(ma),false),b(dir+"/"+to_string(mb),true);'
s=once(s,n,'''if(mode=="profile"){
        auto A=ids(ma,base.Z);Choices c(p,p,A,A,base.U);vector<int> owners(4,-2);int rc=0;
        bool ok=propagate(base,c,owners,cycles,rounds,rc);
        ofstream out(dir+"/"+to_string(ma));out<<base.U<<" "<<base.B<<" "<<base.Z<<" "<<ma<<" "<<(ok?0:rc)<<"\\n";
        if(ok){for(int i:A)write_poly(out,base.seed[i]);for(int i:A)for(int k=0;k<base.B;k++)write_poly(out,base.init[k][i]);}
        cout<<ma<<" "<<(ok?0:rc)<<endl;return 0;
    }
    '''+n)
s=once(s,'if(r.m!=ma||b.m!=mb||','if((r.shut||b.shut)&&mode=="match"){cerr<<"single profile closed\\n";return 0;}\n    if(r.m!=ma||b.m!=mb||')
(src:=h/'advanced.cpp').write_text(s)
subprocess.run(['g++','-O3','-std=c++17',str(src),'-o',str(h/'advanced')],check=True)
