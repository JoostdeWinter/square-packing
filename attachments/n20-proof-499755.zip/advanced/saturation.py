"""Necessary replacement constraints using the established theorem s(21)=5."""
from itertools import product
from fractions import Fraction as F
from functools import lru_cache
from collections import Counter
D=1000000
def lines(U,margin,space):
 out=[]
 for omit in range(5):
  R=[(D//2+margin+j*(D+space)) if j<omit else (U-D//2-margin-(4-j)*(D+space)) for j in range(5) if j!=omit]
  assert min(R)>=D//2 and max(R)<=U-D//2 and all(b-a>=D for a,b in zip(R,R[1:]))
  if U==5*D:assert margin>0 and all(b-a>D for a,b in zip(R,R[1:]))
  out.append(tuple(R))
 return out
def probe_packings(U):
 out=set()
 for margin,space in ([(1,1),(6000,2000)] if U==5*D else [(0,0),(6000,2000)]):
  grid=lines(U,margin,space)
  for xs,ys in product(grid,repeat=2):out.add(tuple(product(xs,ys)))
 return sorted(out)
def export(U,poses,reduced=True):
 from shared_angle_lp import combine,lin,terms,turn,dot
 emit=[];stats=Counter();templates=probe_packings(U)
 if reduced:templates=templates[:25]
 probes=sorted(set(q for t in templates for q in t))
 def clause(body):
  if body!='true':emit.append('(assert '+body+')')
 def var(name):emit.append('(declare-const '+name+' Bool)');return name
 def implies(a,b):return b if a=='true' else 'true' if b=='true' else '(=> '+a+' '+b+')'
 graph={}
 for pi,q in enumerate(probes):
  opts={}
  for i,ls in enumerate(poses):
   ways=[]
   for A in ls:
    # Positive overlap requires projection overlap along both probe and mean tile axes.
    # The true tile is contained in the mean frame dilated by 1+max|sin(delta)|.
    directions=((1,0),(0,1),A.nom,turn(A.nom));necessary=[];rejected=False
    for k,n in enumerate(directions):
     l,h=A.support(n);g=dot(q,n)
     pw=F(D,2)*(abs(n[0])+abs(n[1]))
     if k<2:
      u,v=A.nom;b=u-v;half=D*(u+v)/2
      top=half+max(D*A.lo*b/2,D*A.hi*b/2)
     else:half=F(D,2)*(1+A.bound);top=half;b=0
     R=pw+top
     if l>g+R or h<g-R:rejected=True;break
     if h>g-R and l<g+R:
      if h>g+pw+half+min(D*A.lo*b/2,D*A.hi*b/2):
       necessary.append(lin(terms(i,(-n[0],-n[1]))+[(f'w{i}',b/2)],-g-pw-half))
      if l<g-pw-half-min(D*A.lo*b/2,D*A.hi*b/2):
       necessary.append(lin(terms(i,n)+[(f'w{i}',b/2)],g-pw-half))
    if not rejected:ways.append(combine('and',[A.gate,*necessary]))
   desc=combine('or',ways)
   if desc=='false':continue
   v=var(f'hit_{pi}_{i}');clause(implies(v,desc));opts[i]=v
  graph[q]=opts;stats['blocker_options']+=len(opts)
  clause(combine('or',opts.values()))
 # Enforce Hall on all singletons already, plus pairs/triples of probes likely
 # to compete for the same tiles. Each clause has an explicit combinatorial meaning.
 subsets=set()
 for T in templates:
  for p,point in enumerate(T):
   a=graph[point]
   if len(a)>5:continue
   for other in T[p+1:]:
    b=graph[other]
    if len(b)>5 or not (set(a)&set(b)):continue
    pair=tuple(sorted((point,other)))
    if pair in subsets:continue
    subsets.add(pair)
    # Each selected probe really overlaps a tile. For two disjoint probes,
    # some two different original tiles must lie in their overlap neighborhoods.
    for i in a.keys()&b.keys():
     clause(combine('or',[v for j,v in a.items() if j!=i]+[v for j,v in b.items() if j!=i]))
 stats['probe_points']=len(probes);stats['known_packings']=len(templates);stats['pair_hall']=len(subsets)
 return emit,stats
