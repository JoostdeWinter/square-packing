// Interval Helly in one dimension: whenever k of the mandatory chord
// intervals overlap, one transverse line must carry at least k long chords.
void export_chord_capacity(ostream& out,const Engine& e,const vector<int>& ids,int group_count,const vector<vector<FrameGroup>>& gs,int kcount,bool strict){
    int n=ids.size();I target=(e.U+kcount-1)/kcount;
    if(!strict && kcount*target<=e.U)++target;
    vector<vector<I>> widths(n);vector<I> minw(n),maxw(n);vector<Bound> boxes;
    for(int i=0;i<n;i++){
        vector<I> wg(group_count,INT64_MAX);P area;
        for(int k=0;k<e.B;k++)if(!e.init[k][ids[i]].empty()){
            auto& r=e.rows[k];int g=min(group_count-1,group_count*r.ki/r.gi);
            auto c=chord_constants(r,e.D);
            if(c.plateau<target)throw runtime_error("unsupported chord target");
            I radius=c.height+fl(-(W)target*c.product,e.D)-(!strict);
            wg[g]=min(wg[g],radius);merge_vertices(area,e.init[k][ids[i]]);
        }
        if(area.empty())throw runtime_error("empty chord pose");
        boxes.push_back(bbox(area));for(I w:wg)if(w!=INT64_MAX)widths[i].push_back(w);
        if(widths[i].size()!=gs[i].size())throw runtime_error("different group ordering");
        minw[i]=*min_element(widths[i].begin(),widths[i].end());
        maxw[i]=*max_element(widths[i].begin(),widths[i].end());
        if(minw[i]<=0)throw runtime_error("invalid mandatory radius");
        out<<"(declare-const h"<<kcount<<"_"<<i<<" Real)\n";
        for(int g=0;g<(int)widths[i].size();g++)out<<"(assert (=> "<<gate(i,g,widths[i].size())<<" (= h"<<kcount<<"_"<<i<<" "<<widths[i][g]<<")))\n";
    }
    long count=0;
    for(int axis=0;axis<2;axis++){
        vector<I> lo(n),hi(n);for(int i=0;i<n;i++){lo[i]=axis?boxes[i].b:boxes[i].l;hi[i]=axis?boxes[i].t:boxes[i].r;}
        vector<int> chosen;
        function<void(int,I,I)> extend=[&](int start,I left,I right){
            if((int)chosen.size()==kcount){
                vector<string> ways;
                for(int i:chosen)for(int j:chosen)if(i!=j){
                    if(lo[j]-hi[i]>maxw[i]+maxw[j])return;
                    if(hi[j]-lo[i]<=minw[i]+minw[j])continue;
                    ways.push_back("(> (- "+sym(axis,j)+" "+sym(axis,i)+") (+ h"+to_string(kcount)+"_"+to_string(i)+" h"+to_string(kcount)+"_"+to_string(j)+"))");
                }
                out<<"(assert ";bool_list(out,ways);out<<")\n";++count;return;
            }
            for(int j=start;j<n;j++){
                if(n-j<kcount-(int)chosen.size())break;
                I l=max(left,lo[j]-maxw[j]),r=min(right,hi[j]+maxw[j]);if(l>r)continue;
                chosen.push_back(j);extend(j+1,l,r);chosen.pop_back();
            }
        };
        extend(0,INT64_MIN,INT64_MAX);
    }
    out<<"; mandatory chord constraints "<<kcount<<" "<<count<<"\n";
}
