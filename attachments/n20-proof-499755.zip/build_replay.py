"""Compose the 4.97 replay from the earlier verifier and the terminal-case extension."""
from pathlib import Path
h=Path(__file__).resolve().parent
s=(h/'base496/verify.py').read_text()
def rep(old,new):
 global s
 assert s.count(old)==1,old
 s=s.replace(old,new)
rep('from coverage import sweep',"""sys.path[:0]=[str(H/'base496'),str(H/'enumerator')]
from central_replay import verify_movements,replay_final
from coverage import sweep""")
rep('use_strong=False','use_strong=False; extra=[]')
rep("b,r,mode,*pars,rc,ii=job","""if len(job)==3 and job[2]=='central-owners':
            b,r,_=job
            assert b==64 and r==60
            settings_by_grid[b,r].update((a,c));extra.append((a,c,b,r));use_strong=True
            continue
        b,r,mode,*pars,rc,ii=job""")
rep("assert sum(pairs.values())==len(cert['pairs'])","""assert sum(pairs.values())+len(extra)==len(cert['pairs'])
    assert len(extra)==1
    import shutil
    ext=d/'terminal';ext.mkdir()
    for f in ['search.inc','slices.inc','build.py']:
        shutil.copy(H/'enumerator'/f,ext/f)
    shutil.copy(native/'strong.cpp',ext/'kernel.cpp')
    subprocess.run([sys.executable,ext/'build.py'],check=True)
    move_file=H/'enumerator'/f'marks{s}.txt'
    movement_verdict=verify_movements(move_file,pts,u,workers)
    joint=[]
    for a,c,b,r in extra:
        joint.append(replay_final(d,d/f'i{b}',d/f'profiles{b}-{r}',move_file,a,c,ext/'enumerate',workers))
    assert len(joint[0]['assignments'])==1
    assert joint[0]['assignments'][0]['ownership_levels']==[[1,0,4],[4,3,4],[4,4,0]]
    assert sum(sum(x['closed_by_reason'].values()) for v in joint for x in v['assignments'])==7""")
rep("'joint_symmetry_representatives':sum(pairs.values()),","'joint_symmetry_representatives':sum(pairs.values())+len(extra),'regular_joint_cases':sum(pairs.values()),'additional_coverings':movement_verdict,'special_case':joint,")
rep("H/'certificate.json'","H/'certificate497.json'")
(h/'verify497.py').write_text(s)
