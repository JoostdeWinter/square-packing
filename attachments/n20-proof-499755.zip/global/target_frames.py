"""Try independent rational frame resolutions on the currently critical leaves."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from tempfile import TemporaryDirectory
import json,sys,os,subprocess,time,argparse
from match_evidence import summarize
from branches import h,stamp,atomic
from shared_angle_cases import outstanding
from verify_stronger import shifts
def one(d,k,m,o,sp,dest):
 mode,f,sub,pas,nr,ns,depth,limit=sp
 name=stamp(k,m)+'_'+','.join(map(str,o))+'.json';fout=dest/name
 if fout.is_file() and json.loads(fout.read_text())['closed']:return True
 tested=d/'target_attempts';tested.mkdir(exist_ok=True);key=tested/(name[:-5]+'_'+','.join(map(str,sp))+'.json')
 if key.is_file():return json.loads(key.read_text())['closed']
 U=int(d.name[4:]);shifts(d,U);a,b=k.split('_');env=dict(os.environ,N20_DEPTH_TABLE=str(d/'depth.txt'),N20_EXTRA_RACKS=str(d/f'racks{nr}.txt'),N20_SHIFT_FILE=str(d/f'shift{ns}.txt'),N20_FINE=str(f),N20_FRAME_SUB=str(sub),N20_UNION_PASSES=str(pas),N20_SEP_DEPTH=str(depth),N20_SEP_BUDGET=str(limit),N20_SEP_SPLIT='1');env.pop('N20_BAND',None)
 if not ns:env.pop('N20_SHIFT_FILE',None)
 exe='frame' if mode=='frame' else 'separators';words=subprocess.check_output([d/'advanced'/exe,mode,d/'i64',d/'p64',d/'moves.txt',a,b,'30','3',','.join(map(str,o))],text=True,input=' '.join(map(str,m))+'\n',env=env).split()
 assert words and words[0] in ('OPEN_FRAME','CLOSED_FRAME','OPEN_SEP','CLOSED_SEP','CLOSED')
 ok=words[0].startswith('CLOSED');r={'key':k,'matching':m,'owners':o,'closed':ok,'history':[[sp,words]]};atomic(key,r)
 if ok:atomic(fout,r)
 return ok
def main(v):
 d=h/f'cold{v.U}';dest=d/'direct_replays';dest.mkdir(exist_ok=True,parents=True);opt=v.spec.split(',');sp=[opt[0],*map(int,opt[1:])];assert len(sp)==8;tic=time.monotonic()
 for iteration in range(v.passes):
  while not (d/'prepared.json').is_file():time.sleep(10)
  rows=[]
  for k,m in summarize([v.U])[v.U]['pending']:
   rows.extend((k,m,o) for o in outstanding(d,k,m) if -2 not in o)
  if v.reverse:rows.reverse()
  print('round',iteration,len(rows),'at',v.U,flush=True)
  with ThreadPoolExecutor(v.jobs) as pool:
   jobs={pool.submit(one,d,k,m,o,sp,dest):(k,o) for k,m,o in rows[:v.limit]}
   for f in as_completed(jobs):
    try:val=f.result()
    except subprocess.CalledProcessError as err:print('retryable',jobs[f],err.returncode,flush=True);continue
    print(jobs[f],val,int(time.monotonic()-tic),flush=True)
  if iteration<v.passes-1:time.sleep(50)
if __name__=='__main__':
 q=argparse.ArgumentParser();q.add_argument('U',type=int);q.add_argument('spec');q.add_argument('--jobs',type=int,default=1);q.add_argument('--limit',type=int,default=100);q.add_argument('--passes',type=int,default=1);q.add_argument('--reverse',action='store_true');main(q.parse_args())
