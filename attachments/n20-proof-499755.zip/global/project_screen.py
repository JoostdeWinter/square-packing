"""Transfer only unsettled labelled matchings to a smaller quantitative cap."""
from pathlib import Path
from collections import defaultdict
import argparse,json,time
from branches import atomic
def main():
 p=argparse.ArgumentParser();p.add_argument('verified_case',type=Path);p.add_argument('out',type=Path);p.add_argument('--refined',action='store_true');v=p.parse_args();d=v.verified_case.resolve();out=v.out.resolve();out.mkdir(exist_ok=True,parents=True)
 file=d/('combined_status.json' if v.refined else 'status.json')
 while not file.is_file():time.sleep(12)
 data=json.loads(file.read_text());parent=data['base'] if v.refined else data
 source=parent['source_screen'];assert source['ordered_masks']==53361 and source['symmetry_classes']==6787
 rows=json.loads((d/('combined_open.json' if v.refined else 'open.json')).read_text());groups=defaultdict(set)
 for z in rows:groups[z.get('key',z.get('mask_pair'))].add(tuple(z['matching']))
 choices={k:[list(m) for m in sorted(v)] for k,v in sorted(groups.items())};n=sum(map(len,choices.values()))
 result={'side_micro':parent['side_micro'],'ordered_masks':source['ordered_masks'],'symmetry_classes':source['symmetry_classes'],'counts':{'surviving':n},'open_mask_pairs':len(choices),'screened_at_previous_side':parent['screened_matchings'],'cold_source':data,'kind':'projected_exhaustive_marked_assignment_screen'}
 atomic(out/'open_matchings.json',choices);atomic(out/'screen_verified.json',result);print(n,'matching(s) pending at',parent['side_micro'],flush=True)
if __name__=='__main__':main()
