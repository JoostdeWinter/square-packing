"""Test all endpoint matchings under one independent per-tile angular range."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
from fractions import Fraction as F
import argparse,os,json,time,sys,shutil,subprocess
from branches import h,paths,work,atomic
def main():
 p=argparse.ArgumentParser();p.add_argument('spec');p.add_argument('--jobs',type=int,default=2);p.add_argument('--label',required=True);p.add_argument('--screen',type=Path);p.add_argument('--cold',type=Path);p.add_argument('--mirror',action='store_true');v=p.parse_args()
 a,b=map(F,v.spec.split(','));assert 0<=a<=b<=1;os.environ['N20_BAND']=' '.join(map(str,[a.numerator,a.denominator,b.numerator,b.denominator]))
 if v.cold:
  d=v.cold.resolve();assert json.loads((d/'prepared.json').read_text())['U']==5000000
  ad=d/'advanced'
  if not (ad/'separators.cpp').is_file():
   from verify_refinements import build
   build(d)
  script='build_mirror_band.py' if v.mirror else 'build_bands.py';exe='mirror_band' if v.mirror else 'bands'
  shutil.copy(h/'advanced'/script,ad/script)
  if not (ad/exe).is_file():subprocess.run([sys.executable,ad/script],check=True)
  ps=dict(tab=d/'i64',profiles=d/'p64',moves=d/'moves.txt',dep=d/'depth.txt',racks=lambda n:d/f'racks{n}.txt',exe=ad/exe,extra_counts=(6,14))
 else:
  assert not v.mirror
  while not (h/'advanced/bands').is_file():time.sleep(2)
  ps=paths(5000000,64);ps['exe']=h/'advanced/bands'
 out=h/'trials'/('bands_'+v.label);out.mkdir(exist_ok=True,parents=True)
 if v.screen:
  inp=json.loads((v.screen/'open_matchings.json').read_text());items=[(k,m) for k,arr in inp.items() for m in arr]
 else:
  items=[(f.stem,m['matching']) for f in sorted((h/'trials/fixed500_e32root').glob('*.json')) for m in json.loads(f.read_text())['live']];assert len(items)==1142
 count=Counter();pending=[];start=time.monotonic()
 with ThreadPoolExecutor(v.jobs) as pool:
  for i,f in enumerate(as_completed([pool.submit(work,5000000,64,k,m,'fast',ps,out) for k,m in items]),1):
   z=f.result();count.update(z['counts'])
   if z['open_leaves']:pending.append({k:z[k] for k in ['mask_pair','matching','open_leaves']})
   if i%100==0:print(i,'of',len(items),'open',len(pending),'elapsed',int(time.monotonic()-start),flush=True)
 result={'half_tangent_range':[str(a),str(b)],'strict_endpoint':True,'every_tile_constrained':True,'cold_geometry':bool(v.cold),'also_allow_reflected_interval':v.mirror,'screened_matchings':len(items),'counts':count,'unresolved':pending}
 atomic(h/'trials'/('bands_'+v.label+'_receipt.json'),result);print('finished',len(items),len(pending),count,flush=True)
if __name__=='__main__':main()
