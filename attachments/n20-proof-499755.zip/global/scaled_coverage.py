"""Strict coverage on a smaller board from a closed covering on side five."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import hashlib,tempfile,json,sys
from scale_inputs import build
from branches import h
sys.path.insert(0,str(h/'advanced'))
from endpoint_cover import prove
def endpoint_chart(points):
 r=prove(points);assert r and r['interval_count']>0;return r['interval_count']
def check(inp,U,primary,job_count):
 assert U<5000000 and U%50==0 and 5000000-U>10
 end=h/'proofs/cap5000000';spec=json.loads((inp/'scaled_from_5.json').read_text())
 assert spec['source']=='cap5000000' and spec['U']==U
 files=['moves.txt','racks6.txt','racks14.txt','racks50.txt']
 with tempfile.TemporaryDirectory() as td:
  d=Path(td);build(end,d,U)
  for n in files:assert (d/n).read_bytes()==(inp/n).read_bytes(),n
 coords=[];mods=[]
 for line in (end/'moves.txt').read_text().splitlines()[1:]:
  x,y,n,*vv=map(int,line.split());assert len(vv)==2*n;coords.append((x,y));mods.append(list(zip(vv[::2],vv[1::2])))
 assert len(coords)==22 and all((x*U==a*5000000 and y*U==b*5000000) for (x,y),(a,b) in zip(coords,primary))
 def canon(z):return min(tuple(sorted((5000000-x if a else x,5000000-y if b else y) for x,y in z)) for a,b in product((0,1),repeat=2))
 original={canon(coords)}
 for j,r in enumerate(mods):
  for p in r:
   t=coords.copy();t[j]=p;original.add(canon(t))
 for n in (6,14,50):
  lines=(end/f'racks{n}.txt').read_text().splitlines();assert lines[0]==f'5000000 {n}' and len(lines)==n+1
  for ln in lines[1:]:
   k,*v=map(int,ln.split());assert len(v)==2*k;original.add(canon(list(zip(v[::2],v[1::2]))))
 with ProcessPoolExecutor(job_count) as ex:counts=list(ex.map(endpoint_chart,sorted(original)))
 # Distances in a tile's infinity norm scale exactly. A coordinate rounded
 # to the nearest microunit changes that norm by at most one microunit.
 nearest_margin=F(5000000-U,10000000);aux_margin=nearest_margin-F(1,1000000);assert aux_margin>0
 proof={'method':'exact_closed_stabbing_scaled_from_side_5','source_files_sha256':{n:hashlib.sha256((end/n).read_bytes()).hexdigest() for n in files},'endpoint_patterns':len(original),'source_angle_intervals':[min(counts),max(counts)],'primary_inward_distance':str(nearest_margin),'rounded_auxiliary_inward_distance':str(aux_margin)}
 return proof,counts
