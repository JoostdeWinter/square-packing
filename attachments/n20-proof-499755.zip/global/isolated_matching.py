"""Test whether any other candidate matching differs in just one occupied edge."""
import json,sys
from label_symmetry import image
from match_evidence import summarize
from branches import h
def edges(key,m):
 red=[i for i in range(22) if int(key.split('_')[0])>>i&1]
 return frozenset(zip(red,m))
def inspect(U,ref):
 q=summarize([U])[U];target=edges(*ref)
 physical={edges(*image(k,m,g)) for k,m in q['pending'] for g in range(8)}
 assert target in physical
 dist=sorted(20-len(a&target) for a in physical if a!=target)
 return {'cap':U,'representatives':q['remaining'],'physical_matchings':len(physical),'min_changed_edges':dist[0] if dist else 20,'neighbor_counts':{str(a):dist.count(a) for a in set(dist)}}
if __name__=='__main__':
 z=json.loads((h/'trials/last4998_rankcells.json').read_text())
 for u in map(int,sys.argv[1:]):print(inspect(u,(z['key'],z['matching'])),flush=True)
