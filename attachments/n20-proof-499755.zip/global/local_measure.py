"""Search for and independently round local occupancy and slice inequalities."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from math import floor,ceil
from collections import Counter
import os,sys,json,argparse,time
from branches import h,atomic,stamp
from scale_coupled import calc,cut,facets,mix
def direction(t):return (1-t*t)/(1+t*t),2*t/(1+t*t)
def charts(k,B):
 g=2*B;i=2*k+1;c,s,d=g*g-i*i,2*i*g,g*g+i*i
 ends=[direction(F(j,B)) for j in (k,k+1)];M=max((c*a+s*b+abs(c*b-s*a))/d for a,b in ends)
 H=floor(500000/M)-1;u=max(sum(z) for z in ends);cl,sl=ends[0];ch,sh=ends[1];cross=cl>=sl and ch<=sh
 W=707107 if cross else ceil(500000*u);ht=min(floor(500000*sum(z)) for z in ends)
 plateau=min(floor(1000000/max(z)) for z in ends);prodhi=500000 if cross else max(ceil(1000000*a*b) for a,b in ends)
 return c,s,d,H,W,ht,plateau,prodhi
def resources(U,dens):
 pts={(round(i*U/dens),round(j*U/dens)) for i,j in product(range(1,dens),repeat=2)}
 raw=(h/f'cold{U}/moves.txt').read_text().splitlines()
 for ln in raw[1:]:
  x,y,n,*v=map(int,ln.split())
  for a,b in [(x,y),*zip(v[::2],v[1::2])]:pts.update([(a,b),(U-b,a)])
 cc=lambda num:[round(j*U/(3*dens)) for j in range(1,3*dens)]
 vals=sorted(set(cc(dens)))
 # A local board a microunit shorter than the known optimum supports the stated capacity.
 # This uses s(6)=3 and s(13)=4; the global line and point tests stand independently.
 boxes=[]
 for side,cap in ((2999999,5),(3999999,12)):
  ends=sorted({0,U-side,*[round(j*(U-side)/(dens//2)) for j in range(dens//2+1)]})
  boxes.extend((a,b,side,cap) for a,b in product(ends,repeat=2))
 return sorted(pts),vals,boxes
def matrices(U,k,m,owners,dens,div,settings):
 import numpy as np
 from scipy.sparse import csr_matrix,vstack
 from tempfile import TemporaryDirectory
 from verify_stronger import shifts
 d=h/f'cold{U}';shifts(d,U)
 with TemporaryDirectory() as td:
  st=calc(U,k,m,owners,d/'p64',Path(td)/'state',settings,False)
 if st is None:return None
 pp,ls,boxes=resources(U,dens);pts=np.array(pp,dtype=np.int64);lines=np.array(ls,dtype=np.int64);bx=np.array(boxes,dtype=np.int64)
 capacities=np.array([1]*len(pts)+[U/1000000]*len(lines)*2+[b[3] for b in boxes])
 cs=[charts(j,64) for j in range(64)];proj=[(c*pts[:,0]+s*pts[:,1],-s*pts[:,0]+c*pts[:,1]) for c,s,*v in cs]
 blocks=[];metadata=[]
 for tile,(seed,dom) in enumerate(st):
  fixed=np.ones(len(pts),dtype=bool)
  if len(seed)>=3:
   for a,b,K in facets(seed):fixed&=(a*pts[:,0]+b*pts[:,1]<K)
  else:fixed[:]=False
  opts={};globalN=0
  for j,p in enumerate(dom):
   if not p:continue
   c,s,e,H,W,height,plateau,prod=cs[j];px,py=proj[j];xl=min(v[0] for v in p);xh=max(v[0] for v in p);yl=min(v[1] for v in p);yh=max(v[1] for v in p)
   xs=[xl+(xh-xl)*u//div for u in range(div+1)];ys=[yl+(yh-yl)*u//div for u in range(div+1)]
   for xa,xb in zip(xs,xs[1:]):
    q=cut(cut(p,-1,0,-xa),1,0,xb)
    if not q:continue
    for ya,yb in zip(ys,ys[1:]):
     v=cut(cut(q,0,-1,-ya),0,1,yb)
     if not v:continue
     lx=min(t[0] for t in v);hx=max(t[0] for t in v);ly=min(t[1] for t in v);hy=max(t[1] for t in v)
     X=[c*a+s*b for a,b in v];Y=[-s*a+c*b for a,b in v]
     hits=fixed|((px>=max(X)-e*H)&(px<=min(X)+e*H)&(py>=max(Y)-e*H)&(py<=min(Y)+e*H))
     def chord(l,h):
      dist=np.maximum(np.abs(lines-l),np.abs(lines-h));return np.maximum(0,np.minimum(plateau,(height-dist)*1000000//prod))
     box=(bx[:,0]<=lx-W)&(bx[:,0]+bx[:,2]>=hx+W)&(bx[:,1]<=ly-W)&(bx[:,1]+bx[:,2]>=hy+W)
     vals=np.concatenate((hits.astype(np.int64)*1000000,chord(lx,hx),chord(ly,hy),box.astype(np.int64)*1000000))
     idx=np.flatnonzero(vals);row=(tuple(map(int,idx)),tuple(map(int,vals[idx])));opts.setdefault(row,0);globalN+=1
  assert opts;indices=[];values=[];indptr=[0]
  for idx,v in opts:indices.extend(idx);values.extend(v);indptr.append(len(indices))
  blocks.append(csr_matrix((np.array(values,dtype=np.int64),indices,indptr),shape=(len(opts),len(capacities))));metadata.append([len(opts),globalN])
 return blocks,capacities,metadata
def run_case(U,k,m,o,dens,div,sp,prior=None):
 from scipy.sparse import vstack,csr_matrix,hstack
 from scipy.optimize import linprog
 import numpy as np
 a=matrices(U,k,m,o,dens,div,sp)
 if a is None:return {'closed':True,'method':'native'}
 blocks,cap,md=a;P=len(cap);n=sum(len(z.indptr)-1 for z in blocks);pointsum=vstack(blocks,format='csr')
 if prior is None:
  tile=csr_matrix((np.ones(n),np.arange(n),np.r_[0,np.cumsum([q.shape[0] for q in blocks])]),shape=(20,n)).transpose()
  X=hstack((-pointsum.astype(float)/1e6,tile),format='csr')
  # A feasible nonnegative resource weighting can be scaled to unit capacity.
  res=linprog(np.r_[np.zeros(P),-np.ones(20)],A_ub=X,b_ub=np.zeros(n),A_eq=csr_matrix(np.r_[cap,np.zeros(20)][None,:]),b_eq=[1],bounds=(0,None),method='highs',options={'time_limit':70,'threads':1})
  if not res.success:return {'closed':False,'method':'LP','solver_status':res.message,'dimensions':[n,P]}
  w=np.maximum(res.x[:P],0);ind=np.flatnonzero(w>1e-13);weights={int(i):round(float(w[i])*10**12) for i in ind}
 else:weights={int(i):int(w) for i,w in prior.items()};assert all(0<=i<P and w>=0 for i,w in weights.items())
 # No floating-point numbers enter the accepted inequality.
 iw=np.array([weights.get(i,0) for i in range(P)],dtype=np.int64)
 assert max((int(z.data.max()) for z in blocks if z.nnz),default=0)<=1414214
 assert sum(map(int,iw))*1414214<2**63
 exactcap=round(0)
 _,ls,boxes=resources(U,dens);pts=P-2*len(ls)-len(boxes)
 for i,wg in weights.items():
  cf=1000000 if i<pts else U if i<pts+2*len(ls) else boxes[i-pts-2*len(ls)][3]*1000000
  exactcap+=wg*cf
 demands=[int(min(z@iw)) for z in blocks];total=sum(demands);ok=total>exactcap
 return {'closed':ok,'method':'rational_weights','mass_required':str(total),'mass_available':str(exactcap),'ratio':total/exactcap if exactcap else 0,'weights':weights if ok else None,'dimensions':[n,P],'options_per_tile':md}
if __name__=='__main__':
 from match_evidence import summarize
 from shared_angle_cases import outstanding
 from concurrent.futures import ThreadPoolExecutor,as_completed
 q=argparse.ArgumentParser();q.add_argument('U',type=int);q.add_argument('--grid',type=int,default=18);q.add_argument('--div',type=int,default=2);q.add_argument('--limit',type=int,default=12);q.add_argument('--root',action='store_true');q.add_argument('--reverse',action='store_true');v=q.parse_args();d=h/f'cold{v.U}';out=d/'measure_trials';out.mkdir(exist_ok=True);src=summarize([v.U])[v.U];jobs=[]
 for k,m in src['pending']:
  for o in ([[-2]*4] if v.root else outstanding(d,k,m)):
   if -2 in o and not v.root:continue
   jobs.append((k,m,o))
 if v.reverse:jobs.reverse()
 for k,m,o in jobs[:v.limit]:
  tag=stamp(k,m)+'_'+','.join(map(str,o))+f'_{v.grid}_{v.div}.json';dest=out/tag
  if dest.exists():continue
  start=time.monotonic();sp=[1,2,5,14,16];z=run_case(v.U,k,m,o,v.grid,v.div,sp);z.update(key=k,matching=m,owners=o,grid=v.grid,div=v.div,settings=sp,side_micro=v.U);atomic(dest,z);print(k,o,z['closed'],z.get('ratio'),z.get('dimensions'),int(time.monotonic()-start),flush=True)
