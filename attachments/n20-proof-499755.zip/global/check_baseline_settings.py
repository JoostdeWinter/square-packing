from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import os,subprocess,tempfile,itertools
h=Path(__file__).resolve().parents[1];tbl=h/'trials/b500/i32';geom=h/'enumerator/marks500.txt';racks=h/'advanced/racks500.txt'
def run(setting):
 r,cy=setting;env=dict(os.environ,N20_EXTRA_RACKS=str(racks))
 with tempfile.TemporaryDirectory() as input:
  d=Path(input)
  for m in [3932151,2064383,2097119]:
   output=subprocess.check_output([h/'advanced/advanced','profile',tbl,d,geom,str(m),str(m),str(r),str(cy)],text=True,env=env)
   if (d/str(m)).read_bytes()!=(h/'trials/profiles500_endpoint32'/str(m)).read_bytes():return
  print('match',r,cy,flush=True)
if __name__=='__main__':
 with ThreadPoolExecutor(3) as ex:list(ex.map(run,itertools.product([4,5,6,7,8,9,10,12,14,15,16,18,20,24,28,32,40],[1,2,3])))
