"""Run breadth-first exact center tests before allocating expensive branch trees."""
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
from pathlib import Path
from branches import h,stamp,atomic
from match_evidence import summarize
from verify_stronger import shifts
import subprocess,json,os,time,argparse
def main(v):
 U=v.side;d=h/f'cold{U}';out=d/'quick_frames';out.mkdir(exist_ok=True)
 while not (d/'prepared.json').exists() or not (d/'advanced/refinement_built.json').exists():time.sleep(12)
 shifts(d,U);cfg=json.loads((d/'prepared.json').read_text());bins=cfg['grid'];start=time.monotonic();counts=Counter()
 def one(k,m,lev):
  f=out/(stamp(k,m)+'.json')
  last=json.loads(f.read_text()) if f.is_file() else None
  if last and (last['closed'] or last['last_level']>=lev):return None
  a,b=k.split('_')
  sp=[('check',1,1,1,6,8),('frame',2,4,4,6,8),('frame',3,6,7,14,16),('frame',5,8,12,50,24)][lev]
  mode,fine,sub,pas,nr,ns=sp;kw=dict(os.environ,N20_EXTRA_RACKS=str(d/f'racks{nr}.txt'),N20_SHIFT_FILE=str(d/f'shift{ns}.txt'),N20_DEPTH_TABLE=str(d/'depth.txt'),N20_FINE=str(fine),N20_FRAME_SUB=str(sub),N20_UNION_PASSES=str(pas))
  kw.pop('N20_BAND',None)
  r=subprocess.check_output([d/'advanced'/('deeper' if mode=='check' else 'frame'),mode,d/f'i{bins}',d/f'p{bins}',d/'moves.txt',a,b,'27','2','-2,-2,-2,-2'],input=' '.join(map(str,m))+'\n',text=True,env=kw).split()
  assert r[0] in ('CLOSED','OPEN','CLOSED_FRAME','OPEN_FRAME')
  z={'key':k,'matching':m,'side_micro':U,'last_level':lev,'closed':r[0].startswith('CLOSED'),'nodes':[{'owners':[-2]*4,'calls':[['check' if mode=='check' else list(sp[1:]),r]]}],'attempts':[['breadth_first_root',1]]}
  atomic(f,z);return z['closed']
 for level in range(v.start,v.levels):
  pending=summarize([U])[U]['pending'];jobs=[]
  for k,m in pending:
   f=out/(stamp(k,m)+'.json');rec=json.loads(f.read_text()) if f.is_file() else None
   if not rec or not rec['closed'] and rec['last_level']<level:jobs.append((k,list(m),level))
  jobs.sort(key=lambda z:stamp(z[0],z[1]).split('_')[-1])
  ct=Counter()
  with ThreadPoolExecutor(v.jobs) as pool:
   for i,w in enumerate(as_completed([pool.submit(one,*x) for x in jobs]),1):
    val=w.result();ct[str(val)]+=1
    if i%30==0:print(level,i,'/',len(jobs),dict(ct),int(time.monotonic()-start),flush=True)
  counts.update(ct);print('stage',level,dict(ct),'total',dict(counts),flush=True)
if __name__=='__main__':
 q=argparse.ArgumentParser();q.add_argument('side',type=int);q.add_argument('--levels',type=int,default=3);q.add_argument('--start',type=int,default=0);q.add_argument('--jobs',type=int,default=2);main(q.parse_args())
