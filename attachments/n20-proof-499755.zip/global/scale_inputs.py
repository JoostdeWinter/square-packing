"""Make a smaller-board starting pattern, then let verify_cap check it fresh."""
from pathlib import Path
from fractions import Fraction as F
import argparse
def rounded(x,L,U):
 f=F(x*L,U);return (2*f.numerator+f.denominator)//(2*f.denominator)
def build(src,d,L):
 d.mkdir(exist_ok=True,parents=True)
 lines=(src/'moves.txt').read_text().splitlines();size,U=map(int,lines[0].split());assert size==22 and U>L and L%50==0
 out=[f'{size} {L}']
 for s in lines[1:]:
  x,y,n,*p=map(int,s.split());assert len(p)==n*2
  scale=lambda z:rounded(z,L,U)
  a,b=map(scale,(x,y));shift=sorted(set(zip(map(scale,p[::2]),map(scale,p[1::2])))-{(a,b)})
  out.append(' '.join(map(str,[a,b,len(shift),*(w for z in shift for w in z)])))
 (d/'moves.txt').write_text('\n'.join(out)+'\n')
 for n in (6,14,50):
  p=src/f'racks{n}.txt';s=p.read_text().splitlines();assert list(map(int,s[0].split()))==[U,n];out=[f'{L} {n}']
  for row in s[1:]:
   v,*coords=map(int,row.split());assert len(coords)==2*v
   out.append(' '.join(map(str,[v,*(rounded(x,L,U) for x in coords)])))
  (d/f'racks{n}.txt').write_text('\n'.join(out)+'\n')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('output',type=Path);p.add_argument('U',type=int);v=p.parse_args();build(v.source,v.output,v.U)
