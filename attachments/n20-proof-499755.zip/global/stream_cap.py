"""Start cold lower-cap matches as each verified upper-cap class finishes."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
import argparse,json,time
from branches import work,stamp
def main():
 p=argparse.ArgumentParser();p.add_argument('dest',type=Path);p.add_argument('source',type=Path);p.add_argument('--jobs',type=int,default=2);v=p.parse_args();d=v.dest.resolve();src=v.source.resolve()
 while not (d/'prepared.json').is_file():time.sleep(20)
 cfg=json.loads((d/'prepared.json').read_text());U=cfg['U'];gb=cfg['grid'];out=d/'matchings';out.mkdir(exist_ok=True)
 ps=dict(tab=d/f'i{gb}',moves=d/'moves.txt',profiles=d/f'p{gb}',dep=d/'depth.txt',exe=d/'advanced/deeper',racks=lambda n:d/f'racks{n}.txt',extra_counts=(6,14))
 seen=set();total=0;pending=0
 while True:
  jobs=[]
  for f in sorted((src/'case_replays').glob('*.json')):
   if f.name in seen:continue
   z=json.loads(f.read_text());seen.add(f.name)
   for m in z['survivors']:
    if not (out/(stamp(f.stem,m)+'.json')).is_file():jobs.append((f.stem,m))
  with ThreadPoolExecutor(v.jobs) as ex:
   for fu in as_completed([ex.submit(work,U,gb,k,m,'fast',ps,out) for k,m in jobs]):
    a=fu.result();total+=1;pending+=len(a['open_leaves'])
    if total%50==0:print(total,len(seen),pending,flush=True)
  if (src/'screen_verified.json').is_file():break
  time.sleep(12)
 print('stream ended',total,len(seen),pending,flush=True)
if __name__=='__main__':main()
