"""Use the unrestricted small-tilt bound and the stabilizer of a single labelled matching."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import sys,json,os,subprocess,time,argparse
from branches import h,atomic,stamp
from label_symmetry import image,actions
from split_tile_angle import compilation
from verify_stronger import shifts
from match_evidence import summarize
from shared_angle_cases import outstanding
def orbit(k,m,owners):
 # The all-unowned alternative is invariant under any isometry preserving the labelled matching.
 assert owners==[-1]*4
 a=int(k.split('_')[0]);red=[i for i in range(22) if a>>i&1];group=[]
 for j,tr in enumerate(actions()):
  if image(k,m,j)!=(k,tuple(m)):continue
  swap,R,B=tr;group.append(tuple(red.index(B[y] if swap else R[x]) for x,y in zip(red,m)))
 assert group and all(sorted(p)==list(range(20)) for p in group)
 return [i for i in range(20) if i==min(p[i] for p in group)]
def replay(d,k,m,o,settings):
 e=F(settings[0]);fine,sub,pas,nr,ns=settings[1];U=json.loads((d/'prepared.json').read_text())['U']
 assert 0<e<=F(1,10) and (F(99,5)+15*e)*e**2<5-F(U,1000000)
 # If every absolute tilt were <=e, the checked rank-and-chain theorem would contradict this strict gap.
 a=e/2;b=(1-a)/(1+a);ids=orbit(k,m,o);compilation(d);shifts(d,U);aa,bb=k.split('_')
 for i in ids:
  vals=[a.numerator,a.denominator,b.numerator,b.denominator,((1<<20)-1)^(1<<i),0];env=dict(os.environ,N20_EXTRA_RACKS=str(d/f'racks{nr}.txt'),N20_SHIFT_FILE=str(d/f'shift{ns}.txt'),N20_DEPTH_TABLE=str(d/'depth.txt'),N20_FINE=str(fine),N20_FRAME_SUB=str(sub),N20_UNION_PASSES=str(pas),N20_EXCEPTION_BAND=' '.join(map(str,vals)));env.pop('N20_BAND',None)
  r=subprocess.check_output([d/'advanced/exception_band','frame',d/'i64',d/'p64',d/'moves.txt',aa,bb,'27','2',','.join(map(str,o))],input=' '.join(map(str,m))+'\n',text=True,env=env).split()
  if not r[0].startswith('CLOSED'):assert r[0]=='OPEN_FRAME';return ['OPEN_FRAME',str(i)]
 return ['CLOSED_FRAME','tilt_orbits',str(len(ids))]
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('u',type=int);p.add_argument('key');p.add_argument('--e',default='1/101');p.add_argument('--settings',default='5,6,15,50,24');v=p.parse_args();d=h/f'cold{v.u}'
 for k,m in summarize([v.u])[v.u]['pending']:
  if v.key not in stamp(k,m):continue
  o=[-1]*4
  if o not in outstanding(d,k,m):continue
  st=[v.e,list(map(int,v.settings.split(',')))];print('representatives',orbit(k,m,o),flush=True);r=replay(d,k,m,o,st);print(r,flush=True)
  if r[0]=='CLOSED_FRAME':atomic(d/'direct_replays'/(stamp(k,m)+'_-1,-1,-1,-1.json'),{'key':k,'matching':m,'owners':o,'closed':True,'history':[[['maximum_tilt_case',st],r]]})
