"""Replay a full-root angular contraction for selected hard matchings."""
from pathlib import Path
from branches import h,stamp,atomic
from match_evidence import summarize
from verify_stronger import shifts
import json,sys,os,subprocess,time,argparse
def main(v):
 U=v.U;d=h/f'cold{U}';dest=d/'priority_roots';dest.mkdir(exist_ok=True,parents=True);sp=list(map(int,v.spec.split(',')));assert len(sp)==5
 while not (d/'prepared.json').exists():time.sleep(8)
 shifts(d,U);f,sub,pas,nr,ns=sp;env=dict(os.environ,N20_DEPTH_TABLE=str(d/'depth.txt'),N20_EXTRA_RACKS=str(d/f'racks{nr}.txt'),N20_SHIFT_FILE=str(d/f'shift{ns}.txt'),N20_FINE=str(f),N20_FRAME_SUB=str(sub),N20_UNION_PASSES=str(pas));env.pop('N20_BAND',None)
 opts=summarize([U])[U]['pending'];opts.sort(key=lambda x:(x[0] not in ('2096127_3145725','2097150_2097150'),x[0]))
 if v.nongrid:
  sys.path.insert(0,str(h/'geometry'));from permutation_limits import limits
  opts=[(k,m) for k,m in opts if not limits(k,m,None)]
 if v.reverse:opts.reverse()
 if v.key:opts=[(k,m) for k,m in opts if v.key in stamp(k,m)]
 t=time.monotonic()
 for k,m in opts[:v.limit]:
  out=dest/(stamp(k,m)+'.json')
  if out.exists() and json.loads(out.read_text())['closed']:continue
  a,b=k.split('_');r=subprocess.check_output([d/'advanced/frame','frame',d/'i64',d/'p64',d/'moves.txt',a,b,'27','2','-2,-2,-2,-2'],input=' '.join(map(str,m))+'\n',text=True,env=env).split()
  assert r[0] in ('CLOSED','OPEN_FRAME','CLOSED_FRAME');closed=r[0].startswith('CLOSED')
  z={'key':k,'matching':m,'closed':closed,'side_micro':U,'nodes':[{'owners':[-2]*4,'calls':[[sp,r]]}],'attempts':[['root_frame',1]]}
  if closed:atomic(out,z)
  print(k,stamp(k,m),r,int(time.monotonic()-t),flush=True)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('U',type=int);a.add_argument('spec');a.add_argument('--key');a.add_argument('--nongrid',action='store_true');a.add_argument('--reverse',action='store_true');a.add_argument('--limit',type=int,default=8);main(a.parse_args())
