"""Independent fresh-data replay of a quantitative cap using a verified larger-cap screen."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations,product
from concurrent.futures import ProcessPoolExecutor,ThreadPoolExecutor,as_completed
from collections import Counter
import argparse,os,sys,subprocess,shutil,json,time
h=Path(__file__).resolve().parents[1];sys.path.insert(0,str(h/'base496'))
from branches import work,atomic as write_atomic
from verify_screen import build
from prereqs import SPEC,marks
from coverage import sweep
def check_coverage(t):
 pts,U=t
 if U==5000000:
  from endpoint_cover import prove
  z=prove(pts);assert z;return z['interval_count']
 n=sweep(pts,U,18);assert n>0,(U,pts);return n
def native_build(d,jobs,donor=None):
 if donor is not None:
  from prereqs import checked_sources
  import hashlib
  donor=donor.resolve();assert (donor/'prepared.json').is_file()
  d.mkdir(exist_ok=True,parents=True);up=d/'upstream';up.mkdir(exist_ok=True);checked_sources(up,h/'base496/upstream')
  a=d/'advanced';a.mkdir(exist_ok=True);src=donor/'advanced'
  required=['deeper','cover_depth','direct.cpp'];manifest={}
  if (src/'refinement_built.json').exists():required+=['frame','separators','separators.cpp','refinement_built.json']
  for name in required:
   shutil.copy2(src/name,a/name)
   digest=hashlib.sha256((src/name).read_bytes()).hexdigest();assert digest==hashlib.sha256((a/name).read_bytes()).hexdigest();manifest[name]=digest
  write_atomic(d/'native_copy.json',{'from_verified_build':donor.name,'sha256':manifest})
  return
 build(d,jobs);a=d/'advanced';up=d/'upstream';sys.path.insert(0,str(up));os.chdir(up)
 for f in ['tree.inc','cluster.inc','build_tree.py','lp.inc','build_lp.py','depth.inc','build_depth.py','cover_depth.cpp','smt.inc','build_smt.py','shifted.inc','build_shift.py','smt_chords.inc','build_chord_smt.py','direct.inc','build_direct.py']:
  shutil.copy(h/'advanced'/f,a/f)
 for script in ['build_tree.py','build_lp.py','build_depth.py','build_smt.py','build_shift.py','build_chord_smt.py','build_direct.py']:subprocess.run([sys.executable,a/script],check=True)
 subprocess.run(['g++','-std=c++17','-O3',a/'cover_depth.cpp','-o',a/'cover_depth'],check=True)
def prepare(U,gb,inp,d,jobs,donor=None):
 native_build(d,jobs,donor);a=d/'advanced';up=d/'upstream';sys.path.insert(0,str(up));os.chdir(up)
 cap=F(U,10**6);spec=dict(SPEC,cap=str(cap));pts=[tuple(int(v*10**6) for v in p) for p in marks(spec)]
 m=d/'moves.txt';shutil.copy(inp/'moves.txt',m)
 lines=m.read_text().splitlines();assert list(map(int,lines[0].split()))==[22,U] and len(lines)==23
 rep=set();all_moves=0
 def canonical(arr):
  return min(tuple(sorted((U-x if i else x,U-y if j else y) for x,y in arr)) for i,j in product((0,1),repeat=2))
 rep.add(canonical(pts))
 for i,ln in enumerate(lines[1:]):
  x,y,n,*z=map(int,ln.split());assert (x,y)==pts[i] and len(z)==2*n
  for X,Y in zip(z[::2],z[1::2]):
   new=pts.copy();new[i]=(X,Y);rep.add(canonical(new));all_moves+=1
 rack_shapes=set()
 for nr in (6,14,50):
  f=inp/f'racks{nr}.txt';g=d/f'racks{nr}.txt';shutil.copy(f,g);rows=g.read_text().splitlines();u,mr=map(int,rows[0].split());assert u==U and len(rows)-1==nr==mr
  for l in rows[1:]:
   n,*v=map(int,l.split());assert len(v)==2*n and 20<=n<=60
   rack_shapes.add(canonical(list(zip(v[::2],v[1::2]))))
 all_racks=sorted(rep|rack_shapes)
 scaled=None
 if (inp/'scaled_from_5.json').is_file():
  from scaled_coverage import check
  scaled,coverage=check(inp,U,pts,jobs)
  spec['erosion']=str(min(F(spec['erosion']),F(scaled['primary_inward_distance'])/2))
 else:
  with ProcessPoolExecutor(jobs) as ex:coverage=list(ex.map(check_coverage,[(z,U) for z in all_racks]))
 import check_stabs,nearest_rack,rack_lattice_input
 from verify_rack_angle import check_rack
 from verify_nearest_lower import certified_init
 for mod in [check_stabs,nearest_rack,rack_lattice_input]:mod.marks=marks
 tab=d/f'i{gb}'
 if U==5000000:
  from endpoint_cover import prove
  from endpoint import closed_init
  cert=prove(pts);assert cert;primary={'mode':'closed_coverage_for_strict_normalized_packing','intervals':cert['interval_count'],'event_polynomials':cert['event_polynomials']}
  closed_init(marks(spec),gb,cap,tab)
 else:
  if scaled:
   primary=dict(scaled,status='STRICT_STABBING',erosion=spec['erosion'])
  else:
   primary=check_rack(spec);assert primary['status']=='STRICT_STABBING'
  certified_init(spec,gb,tab)
 with (d/'depth.txt').open('w') as out:subprocess.run([a/'cover_depth',m,'128','2'],stdout=out,check=True)
 pd=d/f'p{gb}';pd.mkdir(exist_ok=True);env=dict(os.environ,N20_EXTRA_RACKS=str(d/'racks6.txt'),N20_DEPTH_TABLE=str(d/'depth.txt'))
 def profile(mask):
  v=subprocess.check_output([a/'deeper','profile',tab,pd,m,str(mask),str(mask),'14','2'],text=True,env=env).split();assert int(v[0])==mask and len(v)==2;return int(v[1])
 masks=sorted((1<<22)-1-(1<<i)-(1<<j) for i,j in combinations(range(22),2))
 preferred=os.getenv('N20_PROFILE_PRIORITY')
 if preferred:
  preference=list(map(int,Path(preferred).read_text().split()));assert set(preference)<=set(masks)
  order={m:i for i,m in enumerate(preference)};masks.sort(key=lambda m:order.get(m,len(order)))
 with ThreadPoolExecutor(jobs) as ex:statuses=list(ex.map(profile,masks))
 result={'U':U,'grid':gb,'coverage_reps_with_auxiliary':len(all_racks),'primary_and_single_move_reps':len(rep),'number_of_moved_points':all_moves,'rigorous_coverage_min_max_intervals':[min(coverage),max(coverage)],'primary':primary,'fresh_profiles':len(masks),'profiles_excluded':sum(v!=0 for v in statuses)}
 write_atomic(d/'prepared.json',result);print('prepared',result,flush=True)
def verify(U,gb,d,base,jobs):
 source=json.loads((base/'screen_verified.json').read_text());assert source['side_micro']>=U and source['ordered_masks']==53361 and source['symmetry_classes']==6787
 choices=json.loads((base/'open_matchings.json').read_text());check=d/'matchings';check.mkdir(exist_ok=True)
 ps=dict(tab=d/f'i{gb}',moves=d/'moves.txt',profiles=d/f'p{gb}',dep=d/'depth.txt',exe=d/'advanced/deeper',racks=lambda n:d/f'racks{n}.txt',extra_counts=(6,14))
 jobspec=[(k,m) for k,rs in choices.items() for m in rs];assert len(jobspec)==source['counts']['surviving']
 status=Counter();pending=[];hist=Counter();t=time.monotonic()
 with ThreadPoolExecutor(jobs) as pool:
  for i,fu in enumerate(as_completed([pool.submit(work,U,gb,k,m,'fast',ps,check) for k,m in jobspec]),1):
   z=fu.result();status.update(z['counts']);hist.update(z['reasons'])
   if z['open_leaves']:pending.append({k:z[k] for k in ['mask_pair','matching','open_leaves']})
   if i%50==0:print(i,len(jobspec),'unresolved',len(pending),'elapsed',int(time.monotonic()-t),flush=True)
 result={'side_micro':U,'source_screen':source,'initialization':json.loads((d/'prepared.json').read_text()),'screened_matchings':len(jobspec),'counts':dict(status),'reasons':hist,'open_matchings':len(pending),'open_ownership_leaves':sum(len(z['open_leaves']) for z in pending)}
 write_atomic(d/'open.json',pending);write_atomic(d/'status.json',result)
 if not pending:write_atomic(d/'verified.json',result)
 print('finished',json.dumps(result),flush=True)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('U',type=int);a.add_argument('inputs',type=Path);a.add_argument('work',type=Path);a.add_argument('screen',type=Path);a.add_argument('--bins',type=int,default=64);a.add_argument('--jobs',type=int,default=3);a.add_argument('--prepare-only',action='store_true');a.add_argument('--reuse-build',type=Path);v=a.parse_args();d=v.work.resolve();src=v.screen.resolve();inp=v.inputs.resolve()
 if not (d/'prepared.json').exists():prepare(v.U,v.bins,inp,d,v.jobs,v.reuse_build)
 if not v.prepare_only:
  while not (src/'screen_verified.json').is_file():time.sleep(25)
  verify(v.U,v.bins,d,src,v.jobs)
