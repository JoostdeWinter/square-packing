from pathlib import Path
import random,json,subprocess,os
h=Path(__file__).resolve().parents[1]
for side,b in [(500,32),(499,48)]:
 src=h/('trials/side500_endpoint' if side==500 else 'trials/side499_g48')
 p=h/('trials/profiles500_endpoint32' if side==500 else 'trials/profiles499_g48')
 table=h/'trials/b500/i32' if side==500 else h.parent/'important_20261120/b499/i48'
 b0=h/'advanced'/('racks500.txt' if side==500 else 'racks499_3.txt');env=dict(os.environ,N20_EXTRA_RACKS=str(b0))
 sample=random.Random(2306).sample(sorted(src.glob('*.json')),12)+[src/'3932151_3932151.json']
 for exe in (h/'enumerator/enumerate',h/'advanced/advanced'):
  counts=[0]*3
  for f in sample:
   a,bb=f.stem.split('_');v=json.loads(f.read_text());old=set(tuple(x) for x in v['assignments'])
   r=subprocess.run([exe,'match',table,p,h/f'enumerator/marks{side}.txt',a,bb,str(v['rounds']),str(v['cycles'])],text=True,env=env,capture_output=True,check=True)
   new=set(tuple(map(int,l.split())) for l in r.stdout.splitlines());counts[0]+=old==new;counts[1]+=len(new-old);counts[2]+=len(old-new)
  print(side,exe.name,counts,flush=True)
