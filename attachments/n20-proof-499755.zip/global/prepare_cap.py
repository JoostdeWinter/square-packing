"""Prepare geometry for a rational quantitative target by exact coverage."""
from pathlib import Path
from itertools import product,combinations
from concurrent.futures import ProcessPoolExecutor,ThreadPoolExecutor
from fractions import Fraction as F
import os,sys,subprocess,json,argparse
here=Path(__file__).resolve().parent;h=here.parent;up=h/'base496/upstream';sys.path[:0]=[str(h/'base496'),str(up)]
from prereqs import marks,SPEC
from coverage import sweep
def signed_near(x,n,d):return (2*x*n+d)//(2*d)
def atomic(p,data):
 f=p.with_suffix('.part');f.write_text(data);f.replace(p)
def fresh_move(task):
 points,U,i,x,y=task
 for factor in (1,2,4,8,16,32,64,128):
  at=points[i];v=(at[0]+(x-at[0])//factor,at[1]+(y-at[1])//factor)
  if at==v:return
  changed=points.copy();changed[i]=v
  n=sweep(changed,U,maxdepth=17)
  if n:return (i,*v,n)
def make_marks(U,d,workers):
 p=[(int(x*10**6),int(y*10**6)) for x,y in marks(dict(SPEC,cap=str(F(U,10**6))))]
 assert len(p)==22 and U%50==0 and U<5000000
 cert=d/'geometry.json'
 if cert.exists():return json.loads(cert.read_text())
 oldpath=h/'enumerator/marks499.txt';lines=oldpath.read_text().splitlines()
 moves=set()
 for i,line in enumerate(lines[1:]):
  xx,yy,n,*values=map(int,line.split())
  for x,y in zip(values[::2],values[1::2]):
   i0,x0,y0=min((p.index((U-p[i][0] if a else p[i][0],U-p[i][1] if b else p[i][1])),4990000-x if a else x,4990000-y if b else y) for a,b in product(range(2),repeat=2))
   moves.add((i0,signed_near(x0,U,4990000),signed_near(y0,U,4990000)))
 with ProcessPoolExecutor(workers) as pool:
  results=[x for x in pool.map(fresh_move,[(p,U,*m) for m in sorted(moves)]) if x]
 mods=[set() for z in p]
 def insert(i,x,y):
  for a,b in product(range(2),repeat=2):
   transform=lambda x,y:(U-x if a else x,U-y if b else y)
   mods[p.index(transform(*p[i]))].add(transform(x,y))
 for i,x,y,v in results:insert(i,x,y)
 # Every endpoint variant is a separate rigorous closed covering. At U<5e6,
 # homothety makes every selected site strictly interior, even after rounding
 # by at most half a micro-unit per board coordinate.
 assert U+10<5000000
 for i,line in enumerate((h/'advanced/endpoint_moves.txt').read_text().splitlines()[1:]):
  x,y,n,*v=map(int,line.split())
  for a,b in zip(v[::2],v[1::2]):insert(i,signed_near(a,U,5000000),signed_near(b,U,5000000))
 lines=[f'22 {U}']+[' '.join(map(str,[*z,len(s),*(v for w in sorted(s) for v in w)])) for z,s in zip(p,mods)]
 atomic(d/'moves.txt','\n'.join(lines)+'\n')
 for n in (2,6,14,50):
  src=h/'advanced'/f'endpoint_racks_{n}.txt'
  out=[f'{U} {n}']
  for row in src.read_text().splitlines()[1:]:
   m,*v=map(int,row.split());out.append(' '.join(map(str,[m,*(signed_near(x,U,5000000) for x in v)])))
  atomic(d/f'racks{n}.txt','\n'.join(out)+'\n')
 count=sweep(p,U,18)
 assert count>0
 res={'U':U,'angle_charts':count,'fresh_single_moves':results,'total_reflected_and_transferred':sum(map(len,mods)),'endpoint_movement_source':'advanced/endpoint_moves.txt'}
 atomic(cert,json.dumps(res,indent=2));print('quantitative geometry',U,count,len(results),sum(map(len,mods)),flush=True);return res
def table(U,gb,d):
 fp=d/f'i{gb}';cap=F(U,10**6)
 if fp.exists():return fp
 os.chdir(up)
 import check_stabs,nearest_rack,rack_lattice_input
 from verify_nearest_lower import certified_init
 for mod in (check_stabs,nearest_rack,rack_lattice_input):mod.marks=marks
 tmp=fp.with_suffix('.part');certified_init(dict(SPEC,cap=str(cap)),gb,tmp);tmp.replace(fp);return fp
def profiles(U,gb,d,workers):
 tab=table(U,gb,d);folder=d/f'p{gb}';folder.mkdir(exist_ok=True)
 env=dict(os.environ,N20_EXTRA_RACKS=str(d/'racks6.txt'),N20_DEPTH_TABLE=str(d/'depth.txt'))
 if not (d/'depth.txt').exists():
  with (d/'depth.tmp').open('w') as f:subprocess.run([h/'advanced/cover_depth',d/'moves.txt','128','2'],stdout=f,check=True)
  (d/'depth.tmp').replace(d/'depth.txt')
 def one(m):
  f=folder/str(m)
  if f.exists():return list(map(int,f.open().readline().split()))[-1]
  tmp=folder/f'partial_{m}';tmp.mkdir(exist_ok=True)
  a=subprocess.check_output([h/'advanced/deeper','profile',tab,tmp,d/'moves.txt',str(m),str(m),'14','2'],text=True,env=env).split()
  assert len(a)==2 and int(a[0])==m
  (tmp/str(m)).replace(f);tmp.rmdir();return int(a[1])
 masks=sorted((1<<22)-1-(1<<i)-(1<<j) for i,j in combinations(range(22),2))
 with ThreadPoolExecutor(workers) as ex:vals=list(ex.map(one,masks))
 result={'grid':gb,'profiles':len(vals),'closed':sum(v!=0 for v in vals)}
 atomic(d/'prepared.json',json.dumps(result));print(result,flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('U',type=int);ap.add_argument('--bins',type=int,default=64);ap.add_argument('--workers',type=int,default=2);v=ap.parse_args();d=h/'trials'/f'cap{v.U}';d.mkdir(exist_ok=True)
 make_marks(v.U,d,v.workers);profiles(v.U,v.bins,d,v.workers)
