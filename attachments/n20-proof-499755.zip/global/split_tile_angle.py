"""Use an exhaustive partition of one physical tile's tangent-half-angle to close an ownership leaf."""
from pathlib import Path
from fractions import Fraction as F
from tempfile import TemporaryDirectory
from concurrent.futures import ThreadPoolExecutor,as_completed
import shutil,subprocess,sys,os,json,time,argparse,fcntl
from branches import h,stamp,atomic
from verify_stronger import shifts
from shared_angle_cases import outstanding,export
from match_evidence import summarize
def compilation(d):
 a=d/'advanced';lk=(a/'exception_band.lock').open('a');fcntl.flock(lk,fcntl.LOCK_EX)
 if (a/'exception_band').is_file():return
 donor=h/'cold5000000/advanced'
 if (donor/'exception_band').is_file() and (donor/'separators.cpp').read_bytes()==(a/'separators.cpp').read_bytes() and (donor/'build_exception_band.py').read_bytes()==(h/'advanced/build_exception_band.py').read_bytes():
  shutil.copy2(donor/'exception_band',a/'exception_band');return
 shutil.copy2(h/'advanced/build_exception_band.py',a/'build_exception_band.py');subprocess.run([sys.executable,a/'build_exception_band.py'],check=True)
def replay(d,k,m,o,settings):
 tile,edges_raw,sp=settings;edges=list(map(F,edges_raw));assert 0<=tile<20 and edges[0]==0 and edges[-1]==1 and all(a<b for a,b in zip(edges,edges[1:]))
 fine,sub,passes,nr,ns=sp;assert 64*fine<1000000;compilation(d);shifts(d,int(d.name[4:]) if d.name.startswith('cold') else json.loads((d/'prepared.json').read_text())['U'])
 for low,high in zip(edges,edges[1:]):
  # At both applications of the interval filter the first closed angle bin reaches at least 1/(64*fine).
  # Using a tiny positive lower cutoff therefore retains the entire first bin, including zero exactly.
  low=low if low else F(1,1000000)
  spec=[low.numerator,low.denominator,high.numerator,high.denominator,((1<<20)-1)^(1<<tile),0]
  env=dict(os.environ,N20_EXTRA_RACKS=str(d/f'racks{nr}.txt'),N20_DEPTH_TABLE=str(d/'depth.txt'),N20_FINE=str(fine),N20_FRAME_SUB=str(sub),N20_UNION_PASSES=str(passes),N20_SHIFT_FILE=str(d/f'shift{ns}.txt'),N20_EXCEPTION_BAND=' '.join(map(str,spec)));env.pop('N20_BAND',None)
  a,b=k.split('_');r=subprocess.check_output([d/'advanced/exception_band','frame',d/'i64',d/'p64',d/'moves.txt',a,b,'18','2',','.join(map(str,o))],input=' '.join(map(str,m))+'\n',text=True,env=env).split()
  assert r[0] in ('CLOSED','CLOSED_FRAME','OPEN_FRAME')
  if r[0]=='OPEN_FRAME':return ['OPEN_FRAME',str(tile),str(low),str(high)]
 return ['CLOSED_FRAME','angle_partition',str(tile)]
def ranked(d,k,m,o):
 with TemporaryDirectory() as td:
  path=Path(td)/'domains';r=export(d,k,m,o,[0,1,5,14,16,64,1],path)
  if r[0]!='EXPORTED_SHARED':return list(range(20))
  lines=iter(path.read_text().splitlines());next(lines);scores=[]
  for i in range(20):
   next(lines);stats=[]
   for q in range(int(next(lines))):
    a,b,g,n,*v=map(int,next(lines).split());stats.append((a,b,sum(v[::2])/n,sum(v[1::2])/n))
   lat=max((abs(x-X)+abs(y-Y) for a,b,x,y in stats for A,B,X,Y in stats),default=0)/1000000
   cross=any(a<24 for a,b,x,y in stats) and any(b>32 for a,b,x,y in stats)
   scores.append((i,lat+2*int(cross)+len(stats)/64))
 return [i for i,v in sorted(scores,key=lambda t:-t[1])]
def main(v):
 d=h/f'cold{v.u}';compilation(d);dest=d/'angle_partitions';dest.mkdir(exist_ok=True);direct=d/'direct_replays';direct.mkdir(exist_ok=True);ordered=[]
 for k,m in summarize([v.u])[v.u]['pending']:
  if v.key and v.key not in stamp(k,m):continue
  for o in outstanding(d,k,m):
   if -2 not in o:ordered.append((k,m,o))
 ordered=ordered[:v.limit];start=time.monotonic()
 for k,m,o in ordered:
  ids=ranked(d,k,m,o);print('priority',k,o,ids,flush=True)
  sp=list(map(int,v.settings.split(',')));edges=v.edges.split(',');mask=stamp(k,m)+'_'+','.join(map(str,o));out=direct/(mask+'.json')
  def once(tile):
   state=dest/(mask+'_'+str(tile)+'_'+str(len(edges))+'_'+','.join(map(str,sp))+'.json')
   if out.exists() and json.loads(out.read_text())['closed']:return 'prior'
   if state.exists():return 'tested'
   conf=[tile,edges,sp];r=replay(d,k,m,o,conf);ok=r[0]=='CLOSED_FRAME';z={'key':k,'matching':m,'owners':o,'closed':ok,'history':[[['anglebranches',conf],r]]};atomic(state,z)
   if ok:atomic(out,z)
   return r
  with ThreadPoolExecutor(v.jobs) as ex:
   fs={ex.submit(once,i):i for i in ids[:v.tiles]}
   for f in as_completed(fs):
    try:r=f.result()
    except subprocess.CalledProcessError as err:print('retryable',err.returncode,flush=True);continue
    print(fs[f],r,int(time.monotonic()-start),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('u',type=int);p.add_argument('--settings',default='3,5,6,14,16');p.add_argument('--edges',default='0,1/16,1/4,1/2,3/4,15/16,1');p.add_argument('--key');p.add_argument('--jobs',type=int,default=1);p.add_argument('--limit',type=int,default=20);p.add_argument('--tiles',type=int,default=4);main(p.parse_args())
