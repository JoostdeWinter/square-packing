"""Exclude root assignments with every tile either exactly aligned or in a closed tilt band."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
from fractions import Fraction as F
from branches import h,stamp,atomic
import argparse,json,time,subprocess,shutil,sys,os,tempfile,hashlib
sys.path.insert(0,str(h/'advanced'))
from z3_lra import run
def build(d):
 from verify_refinements import build as build_base
 a=d/'advanced'
 if not (a/'separators.cpp').is_file():build_base(d)
 shutil.copy2(h/'advanced/build_angle_menu.py',a/'build_angle_menu.py')
 subprocess.run([sys.executable,a/'build_angle_menu.py'],check=True)
def test(d,band,k,m,own,sp):
 factor,sub,passes,rack,shift,lanes,seconds=sp;a,b=k.split('_')
 env=dict(os.environ,N20_DEPTH_TABLE=str(d/'depth.txt'),N20_EXTRA_RACKS=str(d/f'racks{rack}.txt'),N20_FINE=str(factor),N20_FRAME_SUB=str(sub),N20_UNION_PASSES=str(passes),N20_MENU=f'{band.numerator} {band.denominator} {lanes}')
 env.pop('N20_BAND',None);env.pop('N20_SHIFT_FILE',None);env.pop('N20_SMT_CHORDS',None)
 if shift:env['N20_SHIFT_FILE']=str(d/f'shift{shift}.txt')
 with tempfile.TemporaryDirectory() as td:
  f=Path(td)/'test.smt2';r=subprocess.check_output([d/'advanced/angle_menu','anglemenu',d/'i64',d/'p64',d/'moves.txt',a,b,'22','2',','.join(map(str,own)),'-',str(f)],env=env,text=True,input=' '.join(map(str,m))+'\n').split()
  if r[0] in ('CLOSED','CLOSED_MENU'):return {'closed':True,'method':'geometry','response':r}
  assert r==['EXPORTED_MENU'];src=f.read_text();status,_=run(src,seconds*1000);assert status in ('sat','unsat','unknown')
  return {'closed':status=='unsat','method':'exact_LRA','status':status,'sha256':hashlib.sha256(src.encode()).hexdigest(),'bytes':len(src)}
def main(v):
 d=v.work.resolve();screen=v.screen.resolve();dest=v.out.resolve();dest.mkdir(exist_ok=True,parents=True);band=F(v.band);assert 0<band and (1+band)**2<2
 if not (d/'advanced/angle_menu').is_file():build(d)
 from verify_stronger import shifts;shifts(d,5000000)
 data=json.loads((screen/'open_matchings.json').read_text());meta=json.loads((screen/'screen_verified.json').read_text());assert meta['ordered_masks']==53361 and meta['side_micro']==5000000
 items=[(k,m) for k,vs in data.items() for m in vs];assert len(items)==1142
 sp=list(map(int,v.settings.split(',')));assert len(sp)==7
 clock=time.monotonic();ct=Counter();pending=[]
 def once(job):
  k,m=job;f=dest/(stamp(k,m)+'.json')
  if f.is_file():
   prior=json.loads(f.read_text());assert prior['band']==str(band)
   if prior['closed'] or not v.retry:return prior
  r=test(d,band,k,m,[-2]*4,sp);z=dict(r,key=k,matching=m,band=str(band),settings=sp)
  atomic(f,z);return z
 with ThreadPoolExecutor(v.jobs) as ex:
  for i,f in enumerate(as_completed([ex.submit(once,it) for it in items]),1):
   z=f.result();outcome='closed_'+z['method'] if z['closed'] else z['status'];ct[outcome]+=1
   if not z['closed']:pending.append([z['key'],z['matching']])
   if i%50==0:print(i,dict(ct),int(time.monotonic()-clock),flush=True)
 rec={'strict_endpoint':True,'allowed':'board-axis or normalized half-angle t in [a,(1-a)/(1+a)]','a':str(band),'matchings':len(items),'counts':ct,'open':len(pending)};atomic(dest/'summary',rec);atomic(dest/'pending',pending)
 if not pending:atomic(dest/'verified',rec)
 print('complete',rec,flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('band');p.add_argument('work',type=Path);p.add_argument('screen',type=Path);p.add_argument('out',type=Path);p.add_argument('--settings',default='2,3,2,6,8,8,9');p.add_argument('--jobs',type=int,default=3);p.add_argument('--retry',action='store_true');main(p.parse_args())
