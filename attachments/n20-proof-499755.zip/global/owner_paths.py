"""Intersect the possible histories of the four unused primary marks under dilation."""
from pathlib import Path
from collections import Counter
from itertools import product
from match_evidence import summarize,read
from branches import h,stamp
import argparse,json
refinements=('frame_replays','strong_replays','lattice_first','new_replays','multi_first','multi_strong','shared_replays')
def live(d,tag):
 f=d/'matchings'/(tag+'.json')
 if not f.exists():return None
 out=set();z=read(f)
 for o in z['open_leaves']:
  key=tag+'_'+','.join(map(str,o))+'.json'
  if any((p:=d/di/key).exists() and read(p)['closed'] for di in refinements):continue
  out.add(tuple(o))
 return out
def compatible(a,b):return all(v==-1 or u==v for u,v in zip(a,b))
def chain(U,k,m):
 caps=sorted([int(d.name[4:]) for d in h.glob('cold*') if len(d.name)==11 and d.name[4:].isdigit() and int(d.name[4:])>=U]);tag=stamp(k,m);before=None;levels=[]
 for H in caps:
  owners=live(h/f'cold{H}',tag)
  if owners is None:continue
  if before is None:after=owners
  else:after={high for high in owners if any(compatible(low,high) for low in before)}
  levels.append([H,len(owners),len(after)]);before=after
  if not after:return True,levels
 return False,levels
def main(v):
 z=summarize(v.sides);result={}
 for U,R in z.items():
  cnt=Counter();details=[]
  for k,m in R['pending']:
   closed,lv=chain(U,k,m);cnt['impossible' if closed else 'remaining']+=1
   if closed:details.append([k,m,lv])
  print(U,cnt,flush=True);result[U]={'counts':cnt,'newly_excluded':details}
 if v.out:v.out.write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('sides',nargs='+',type=int);a.add_argument('--out',type=Path);main(a.parse_args())
