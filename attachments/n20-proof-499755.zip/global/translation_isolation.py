"""Use the freedom to translate a smaller packing inside an upper board with an isolated label."""
from pathlib import Path
from itertools import product
from tempfile import TemporaryDirectory
import argparse,json
from branches import h,atomic,stamp
from label_symmetry import image
from scale_coupled import facets,cut,write_profiles,calc,hull
from isolated_matching import edges
from verify_stronger import shifts
from verify_choice import load

def isolated(bank,H,k,m):
    ref=edges(k,m);isolated_set=set()
    for row in bank['choices']:
        if row['side_micro']>=H:continue
        for g in range(8):
            isolated_set.add(edges(*image(row['key'],row['matching'],g)))
    assert ref in isolated_set
    least=min((20-len(q&ref) for q in isolated_set if q!=ref),default=20)
    return least,len(isolated_set)

def transfer(lo,hi,gap):
    ts=list(product((0,gap),repeat=2))
    out=[]
    for (ps,base),(qs,upper) in zip(lo,hi):
        seed=hull(ps+[(x-a,y-b) for x,y in qs for a,b in ts])
        rows=[]
        for poly,up in zip(base,upper):
            if not poly or not up:rows.append([]);continue
            for a,b,c in facets(up):
                v=c-max(a*x+b*y for x,y in ts)
                poly=cut(poly,a,b,v)
                if not poly:break
            rows.append(poly)
        if not any(rows):return None
        out.append((seed,rows))
    return out

def test(d,e,k,m,o,sp,rotations=False):
    U,H=(int((q/'moves.txt').read_text().split()[1]) for q in (d,e))
    assert U<H<5000000
    r=load(h/'proofs/isolation_parent4997500.json.gz')
    deg,n=isolated(r,H,k,m)
    if deg<2:return ['OPEN_FRAME','unproved_isolation',str(deg),str(n)]
    shifts(d,U);shifts(e,H)
    with TemporaryDirectory() as td:
        t=Path(td);out=t/'state'
        lo=calc(U,k,m,o,d/'p64',out,sp,False,d)
        if lo is None:return ['CLOSED_FRAME','lower_root']
        hi=calc(H,k,m,[-2]*4,e/'p64',out,sp,False,e)
        if hi is None:return ['CLOSED_FRAME','upper_root']
        info=transfer(lo,hi,H-U)
        if info is None:return ['CLOSED_FRAME','erosion']
        if rotations:
            from rotation_close import subgroup,contract
            assert o in ([-1]*4,[-2]*4)
            _,group=subgroup(d,k,m)
            info=contract(info,U,group)
            if info is None:return ['CLOSED_FRAME','rotation_and_translation']
        write_profiles(t/'profiles',U,k,m,info,d)
        ok=calc(U,k,m,o,t/'profiles',out,sp,True,d) is None
        return ['CLOSED_FRAME' if ok else 'OPEN_FRAME','translation',str(deg),str(n)]

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('lower',type=int);p.add_argument('upper',type=int);p.add_argument('--root',action='store_true');p.add_argument('--rotations',action='store_true');p.add_argument('--settings',default='2,8,9,14,16');v=p.parse_args()
    z=json.loads((h/'trials/last4998_rankcells.json').read_text());d=h/f'cold{v.lower}';e=h/f'cold{v.upper}';k=z['key'];m=z['matching'];o=[-2 if v.root else -1]*4;sp=list(map(int,v.settings.split(',')))
    print('frozen label distance',isolated(load(h/'proofs/isolation_parent4997500.json.gz'),v.upper,k,m),flush=True)
    result=test(d,e,k,m,o,sp,v.rotations);print(result,flush=True)
    dest=d/('isolation_rotation_results' if v.rotations else 'isolation_results');dest.mkdir(exist_ok=True)
    atomic(dest/(stamp(k,m)+'_'+','.join(map(str,o))+'.json'),{'side_micro':v.lower,'upper':v.upper,'matching':m,'key':k,'owners':o,'closed':result[0]=='CLOSED_FRAME','history':[[['translation_isolation',v.upper,sp,v.rotations],result]]})
