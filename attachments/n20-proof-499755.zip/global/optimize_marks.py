"""Search and check extreme positions of each independently replaceable mark."""
from pathlib import Path
from itertools import product
from concurrent.futures import ProcessPoolExecutor,as_completed
from functools import lru_cache
from math import gcd
import json,time,sys,argparse,os
from scale_inputs import rounded
from branches import h,atomic
sys.path.insert(0,str(h/'base496'))
from coverage import sweep
def hull(pts):
 v=sorted(set(pts))
 if len(v)<3:return v
 def half(ls):
  ans=[]
  for p in ls:
   while len(ans)>=2:
    a,b=ans[-2:];cross=(b[0]-a[0])*(p[1]-a[1])-(b[1]-a[1])*(p[0]-a[0])
    if cross>0:break
    ans.pop()
   ans.append(p)
  return ans
 return half(v)[:-1]+half(reversed(v))[:-1]
def ray(arg):
 pts,i,U,a,b,path=arg
 if path.exists():return json.loads(path.read_text())
 base=pts[i];t=time.monotonic();lo=0;hi=650000//max(abs(a),abs(b));n=0
 def test(q):
  p=pts.copy();p[i]=(base[0]+q*a,base[1]+q*b)
  return sweep(p,U,16)
 for _ in range(13):
  if hi-lo<=10:break
  q=(lo+hi+1)//2;k=test(q)
  if k:lo=q;n=k
  else:hi=q-1
 r=lo*98//100
 v=(base[0]+a*r,base[1]+b*r);z={'anchor':i,'direction':[a,b],'point':v,'scale':r,'certified_steps':n,'elapsed':time.monotonic()-t};atomic(path,z);return z
def main(v):
 U=v.side;folder=h/f'trials/extreme_marks_{U}';folder.mkdir(exist_ok=True);d=h/f'proofs/cap{U}';d.mkdir(exist_ok=True)
 ds=[q for q in v.donors if q>U];assert ds
 A=[tuple(map(int,l.split()[:2])) for l in (h/'proofs/cap5000000/moves.txt').read_text().splitlines()[1:]]
 pts=[(rounded(x,U,5000000),rounded(y,U,5000000)) for x,y in A];assert U%50==0
 rs=[i for i,(x,y) in enumerate(pts) if 2*x<=U and 2*y<=U]
 seen=[set() for _ in pts];base=[set() for _ in pts]
 def insert(i,p):
  x,y=pts[i]
  for X,Y in product((0,1),repeat=2):
   f=lambda a,b:(U-a if X else a,U-b if Y else b)
   j=pts.index(f(x,y));seen[j].add(f(*p))
 for ih,up in enumerate(ds):
  src=h/f'proofs/cap{up}';raw=(src/'moves.txt').read_text().splitlines()
  for i,l in enumerate(raw[1:]):
   x,y,n,*z=map(int,l.split())
   for a,b in zip(z[::2],z[1::2]):
    p=rounded(a,U,up),rounded(b,U,up);insert(i,p)
    if ih==0:base[i].add(p)
 directions=[(a,b) for a,b in product(range(-2,3),repeat=2) if gcd(abs(a),abs(b))==1]
 tasks=[(pts,i,U,a,b,folder/f'{i}_{a}_{b}.json') for i in rs for a,b in directions];start=time.monotonic()
 with ProcessPoolExecutor(v.jobs) as ex:
  for N,f in enumerate(as_completed(ex.submit(ray,j) for j in tasks),1):
   z=f.result();insert(z['anchor'],z['point'])
   if N%15==0:print('rays',N,len(tasks),int(time.monotonic()-start),flush=True)
 raw=[f'22 {U}']
 for i,p in enumerate(pts):
  keep=sorted((set(hull(seen[i]|{p}))|base[i])-{p});raw.append(' '.join(map(str,[*p,len(keep),*(z for q in keep for z in q)])))
 (d/'moves.txt').write_text('\n'.join(raw)+'\n')
 up=ds[0]
 for n in (6,14,50):
  raw=(h/f'proofs/cap{up}/racks{n}.txt').read_text().splitlines();rows=[f'{U} {n}']
  for l in raw[1:]:
   k,*z=map(int,l.split());rows.append(' '.join(map(str,[k,*(rounded(x,U,up) for x in z)])))
  (d/f'racks{n}.txt').write_text('\n'.join(rows)+'\n')
 print('proposal',U,len(tasks),sum(int(l.split()[2]) for l in (d/'moves.txt').read_text().splitlines()[1:]),int(time.monotonic()-start),flush=True)
if __name__=='__main__':
 q=argparse.ArgumentParser();q.add_argument('side',type=int);q.add_argument('donors',type=int,nargs='+');q.add_argument('--jobs',type=int,default=2);main(q.parse_args())
