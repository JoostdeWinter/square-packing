"""Test strengthened inscribed polygons of freely rotated tiles at the outstanding owners."""
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
from itertools import islice
import fcntl,os,shutil,subprocess,sys,time,argparse,json
from branches import h,stamp,atomic
from match_evidence import summarize
from shared_angle_cases import outstanding
from verify_stronger import shifts
def build(d):
 a=d/'advanced';lk=(a/'octframe_build.lock').open('a');fcntl.flock(lk,fcntl.LOCK_EX)
 if (a/'octframe').exists():return
 for donor in (h/'cold4998500/advanced',h/'cold4998000/advanced'):
  if donor!=a and (donor/'octframe').is_file() and (donor/'separators.cpp').read_bytes()==(a/'separators.cpp').read_bytes() and (donor/'build_octframe.py').read_bytes()==(h/'advanced/build_octframe.py').read_bytes():
   shutil.copy2(donor/'octframe',a/'octframe');return
 shutil.copy2(h/'advanced/build_octframe.py',a/'build_octframe.py')
 subprocess.run([sys.executable,a/'build_octframe.py'],check=True)
def call(d,k,m,o,sp):
 f,sub,pas,nr,ns,dep,limit=sp;assert dep==0 and limit==0
 a,b=k.split('_');env=dict(os.environ,N20_EXTRA_RACKS=str(d/f'racks{nr}.txt'),N20_DEPTH_TABLE=str(d/'depth.txt'),N20_FINE=str(f),N20_FRAME_SUB=str(sub),N20_UNION_PASSES=str(pas),N20_SHIFT_FILE=str(d/f'shift{ns}.txt'))
 env.pop('N20_BAND',None);words=subprocess.check_output([d/'advanced/octframe','frame',d/'i64',d/'p64',d/'moves.txt',a,b,'30','3',','.join(map(str,o))],text=True,input=' '.join(map(str,m))+'\n',env=env).split()
 assert words[0] in ('CLOSED','OPEN_FRAME','CLOSED_FRAME');return words
def main(v):
 d=h/f'cold{v.u}';build(d);shifts(d,v.u);d0=d/'direct_replays';d0.mkdir(exist_ok=True);out=d/'octagon';out.mkdir(exist_ok=True);sp=tuple(map(int,v.settings.split(',')));assert len(sp)==7
 rows=[]
 for k,m in summarize([v.u])[v.u]['pending']:
  os=outstanding(d,k,m)
  for o in os:
   if -2 not in o:rows.append((len(os),k,m,o))
 rows.sort(key=lambda a:(a[0],a[1],a[3]))
 def one(row):
  _,k,m,o=row;nm=stamp(k,m)+'_'+','.join(map(str,o))+'.json';f=out/(nm[:-5]+'_'+','.join(map(str,sp))+'.json')
  if (d0/nm).is_file() and json.loads((d0/nm).read_text())['closed']:return 'previous'
  if f.exists():return 'cached'
  q=call(d,k,m,o,sp);closed=q[0].startswith('CLOSED')
  z={'key':k,'matching':m,'owners':o,'closed':closed,'history':[[['octframe',*sp],q]]}
  atomic(f,z)
  if closed:atomic(d0/nm,z)
  return str(closed)
 print('candidates',len(rows),flush=True);start=time.monotonic()
 with ThreadPoolExecutor(v.jobs) as e:
  fs={e.submit(one,x):x for x in rows[:v.limit]}
  for future in as_completed(fs):
   try:result=future.result()
   except subprocess.CalledProcessError as err:print('retryable',err.returncode,flush=True);continue
   print(fs[future][1],fs[future][3],result,int(time.monotonic()-start),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('u',type=int);p.add_argument('--settings',default='3,5,5,14,16,0,0');p.add_argument('--jobs',type=int,default=1);p.add_argument('--limit',type=int,default=150);main(p.parse_args())
