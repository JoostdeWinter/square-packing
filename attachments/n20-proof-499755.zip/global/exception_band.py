"""Verify that at least two tiles must have small absolute tilt in any strict sub-five packing."""
from pathlib import Path
from fractions import Fraction
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
import os,time,json,sys,shutil,subprocess,argparse
from branches import h,stamp,atomic
from verify_stronger import shifts
def main(args):
 d=args.cold.resolve();sc=args.screen.resolve();out=args.output.resolve();out.mkdir(exist_ok=True,parents=True)
 band=Fraction(args.threshold);b=(1-band)/(1+band);assert 0<band<b and (d/'status.json').exists()
 status=json.loads((d/'status.json').read_text());meta=json.loads((sc/'screen_verified.json').read_text());masks=json.loads((sc/'open_matchings.json').read_text())
 assert meta['side_micro']==status['side_micro']==5000000 and meta['ordered_masks']==53361
 cases=[(k,m) for k,rows in masks.items() for m in rows];assert len(cases)==status['screened_matchings']==1142
 shutil.copy2(h/'advanced/build_exception_band.py',d/'advanced/build_exception_band.py')
 if not (d/'advanced/exception_band').exists():subprocess.run([sys.executable,d/'advanced/build_exception_band.py'],check=True)
 exe=d/'advanced/exception_band'
 if args.sharp:
  assert args.aligned
  shutil.copy2(h/'advanced/build_exact_axis_exception.py',d/'advanced/build_exact_axis_exception.py')
  exe=d/'advanced/exact_axis_exception'
  if not exe.exists():subprocess.run([sys.executable,d/'advanced/build_exact_axis_exception.py'],check=True)
 shifts(d,5000000);allbits=(1<<20)-1
 def call(k,m,owners,group,spec):
  fine,sub,passes,nr,ns=spec
  env=dict(os.environ,N20_DEPTH_TABLE=str(d/'depth.txt'),N20_EXTRA_RACKS=str(d/f'racks{nr}.txt'),N20_SHIFT_FILE=str(d/f'shift{ns}.txt'),N20_FINE=str(fine),N20_FRAME_SUB=str(sub),N20_UNION_PASSES=str(passes),N20_EXCEPTION_BAND=' '.join(map(str,[band.numerator,band.denominator,b.numerator,b.denominator,group,(2 if args.sharp and group.bit_count()==1 else int(args.aligned))])))
  env.pop('N20_BAND',None)
  a,c=k.split('_');ret=subprocess.check_output([exe,'frame',d/'i64',d/'p64',d/'moves.txt',a,c,'18','2',','.join(map(str,owners))],input=' '.join(map(str,m))+'\n',text=True,env=env).split()
  assert ret[0] in ('CLOSED','CLOSED_FRAME','OPEN_FRAME');return ret
 def task(row):
  k,m=row;key=stamp(k,m);sr=json.loads((d/'matchings'/(key+'.json')).read_text());assert sr['matching']==m and sr['mask_pair']==k and sr['target_micro']==5000000
  if not sr['open_leaves']:return 'cold_ownership',True
  f=out/(key+'.json')
  if f.is_file():
   prev=json.loads(f.read_text());assert prev['band']==str(band) and prev['aligned']==args.aligned
   if prev['closed'] or not args.retry:return prev['method'],prev['closed']
  steps=[]
  def check(owners,group):
   spec=([2,4,4,14,16] if group.bit_count()>=5 else [3,5,5,14,16])
   ret=call(k,m,owners,group,spec);steps.append([owners,group,spec,ret])
   if ret[0].startswith('CLOSED'):return True
   ids=[i for i in range(20) if group>>i&1]
   if len(ids)>1:
    left=sum(1<<i for i in ids[::2]);return check(owners,left) and check(owners,group^left)
   for sp in ([4,6,9,50,24],[5,8,12,50,24]):
    ret=call(k,m,owners,group,sp);steps.append([owners,group,sp,ret])
    if ret[0].startswith('CLOSED'):return True
   return False
  closed=True
  owners=sr['open_leaves']
  if args.sharp and len(owners)>3 and check([-2]*4,allbits):owners=[]
  for o in owners:
   if not check(o,allbits):closed=False;break
  r={'band':str(band),'aligned':args.aligned,'key':k,'matching':m,'ownership_leaves':len(sr['open_leaves']),'closed':closed,'method':'exception_groups','literal_axis_frame':args.sharp,'steps':steps};atomic(f,r);return r['method'],closed
 if args.residue:
  import gzip
  with gzip.open(args.residue,'rt') as f:prior=json.load(f)
  saved={(r['key'],tuple(r['matching'])) for r in prior['choices'] if r['side_micro']==5000000}
  cases=[row for row in cases if (row[0],tuple(row[1])) not in saved]
 if args.reverse:cases.reverse()
 ct=Counter();missing=[];start=time.monotonic()
 with ThreadPoolExecutor(args.jobs) as ex:
  futures={ex.submit(task,row):row for row in cases}
  for fut in as_completed(futures):
   kind,ok=fut.result();ct[kind if ok else 'open']+=1
   if not ok:missing.append(futures[fut])
   n=sum(ct.values())
   if n%100==0 or n>1067:print(n,dict(ct),int(time.monotonic()-start),flush=True)
 assert sum(ct.values())==len(cases)
 if len(cases)!=1142:print('completed restricted subset',len(cases),ct,flush=True);return
 record={'target':5000000,'ordered_masks':53361,'verified_matchings':len(cases),'threshold':str(band),'exception_aligned':args.aligned,'counts':ct,'open':missing};atomic(out/'summary',record)
 if not missing and len(cases)==1142:atomic(out/'verified.json',record)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('threshold');p.add_argument('cold',type=Path);p.add_argument('screen',type=Path);p.add_argument('output',type=Path);p.add_argument('--jobs',type=int,default=2);p.add_argument('--aligned',action='store_true');p.add_argument('--retry',action='store_true');p.add_argument('--sharp',action='store_true');p.add_argument('--reverse',action='store_true');p.add_argument('--residue',type=Path);main(p.parse_args())
