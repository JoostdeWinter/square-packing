"""Run the coupled angle/position relaxation on outstanding geometric assignments."""
from pathlib import Path
from collections import Counter
from concurrent.futures import ThreadPoolExecutor,as_completed
import os,sys,json,subprocess,tempfile,hashlib,argparse,time,fcntl,shutil
from branches import h,atomic,stamp
from match_evidence import summarize
from verify_stronger import shifts
sys.path.insert(0,str(h/'advanced'))
def build(d):
 a=d/'advanced';lock=(a/'shared_build.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX)
 if (a/'shared_angles').is_file():return
 from verify_refinements import build as prep
 if not (a/'frame.cpp').exists():prep(d)
 shutil.copy2(h/'advanced/build_shared_angles.py',a/'build_shared_angles.py');subprocess.run([sys.executable,a/'build_shared_angles.py'],check=True)
def adapt_state(src,dest,lanes):
 from shared_angle_lp import read
 from fractions import Fraction
 raw=iter(src.read_text().splitlines());B,Z,U=map(int,next(raw).split());assert B>=32 and Z==22
 def pointlist(line):
  n,*v=map(int,line.split());assert len(v)==2*n;return list(zip(v[::2],v[1::2]))
 def hull(pts):
  v=sorted(set(pts))
  if len(v)<3:return v
  def half(order):
   H=[]
   for x,y in order:
    while len(H)>1 and (H[-1][0]-H[-2][0])*(y-H[-2][1])<=(H[-1][1]-H[-2][1])*(x-H[-2][0]):H.pop()
    H.append((x,y))
   return H
  return half(v)[:-1]+half(reversed(v))[:-1]
 def line(pts):return ' '.join(map(str,[len(pts),*(w for t in pts for w in t)]))
 R=[f'{U} 1000000 {lanes} 20']
 for i in range(20):
  R.append(next(raw));parts={}
  for k in range(B):
   P=pointlist(next(raw))
   if P:parts.setdefault(k*lanes//B,[]).append((k,P))
  R.append(str(len(parts)))
  for group,p in sorted(parts.items()):
   poly=hull(z for j,q in p for z in q);R.append(f'{p[0][0]} {p[-1][0]+1} {B} '+line(poly))
 assert next(raw,None) is None;dest.write_text('\n'.join(R)+'\n')
 return True
def export(d,k,m,o,spec,path):
 f,sub,passes,nr,ns,lanes,sec=spec
 U=int((d/'moves.txt').open().readline().split()[1]);shifts(d,U)
 env=dict(os.environ,N20_FINE=str(f),N20_FRAME_SUB=str(sub),N20_UNION_PASSES=str(passes),N20_EXTRA_RACKS=str(d/f'racks{nr}.txt'),N20_SHIFT_FILE=str(d/f'shift{ns}.txt'),N20_DEPTH_TABLE=str(d/'depth.txt'),N20_SMT_GROUPS=str(lanes))
 env.pop('N20_BAND',None);a,b=k.split('_');bin_count=json.loads((d/'prepared.json').read_text())['grid']
 if f==0:
  raw=path.with_suffix('.state');z=subprocess.check_output([d/'advanced/frame','check',d/f'i{bin_count}',d/f'p{bin_count}',d/'moves.txt',a,b,str(25+passes),str(sub),','.join(map(str,o)),'-',raw],input=' '.join(map(str,m))+'\n',text=True,env=env).split()
  if z[0]=='CLOSED':return z
  assert z[0]=='OPEN';adapt_state(raw,path,lanes);return ['EXPORTED_SHARED']
 build(d)
 z=subprocess.check_output([d/'advanced/shared_angles','shared',d/f'i{bin_count}',d/f'p{bin_count}',d/'moves.txt',a,b,'30','3',','.join(map(str,o)),'-',path],input=' '.join(map(str,m))+'\n',text=True,env=env).split()
 assert z[0] in ('CLOSED','CLOSED_SHARED','EXPORTED_SHARED');return z
def test(d,k,m,o,sp,save=None):
 from shared_angle_lp import generate
 from z3_lra import run
 with tempfile.TemporaryDirectory() as td:
  path=Path(td)/'domains.txt';z=export(d,k,m,o,sp,path)
  if z[0]!='EXPORTED_SHARED':return {'closed':True,'native':z}
  src,stats=generate(path);status,_=run(src,sp[-1]*1000);assert status in ('sat','unsat','unknown'),status
  if save:
   save.mkdir(exist_ok=True,parents=True);shutil.copyfile(path,save/'domains.txt');(save/'instance.smt2').write_text(src)
  return {'closed':status=='unsat','solver':status,'sha256':hashlib.sha256(src.encode()).hexdigest(),'geometry_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'stats':stats}
def outstanding(d,k,m):
 file=stamp(k,m)+'.json';b=d/'matchings'/file
 if not b.is_file():return [[-2]*4]
 return [o for o in json.loads(b.read_text())['open_leaves'] if not any((p:=d/di/(file[:-5]+'_'+','.join(map(str,o))+'.json')).exists() and json.loads(p.read_text())['closed'] for di in ('frame_replays','strong_replays','direct_replays','lattice_first','new_replays','multi_first','multi_strong','shared_replays'))]
def main(v):
 d=h/f'cold{v.u}';out=d/'shared_replays';out.mkdir(exist_ok=True);sp=tuple(map(int,v.settings.split(',')));sc=summarize([v.u])[v.u];todo=[]
 for k,m in sc['pending']:
  for o in ([[-2]*4] if v.root else outstanding(d,k,m)):
   name=stamp(k,m)+'_'+','.join(map(str,o))+'.json';q=out/name
   if q.is_file() and (json.loads(q.read_text())['closed'] or json.loads(q.read_text())['settings']==list(sp)):continue
   todo.append((k,m,o,q))
 if v.reverse:todo.reverse()
 if v.limit:todo=todo[:v.limit]
 print('started',v.u,len(todo),'settings',sp,flush=True)
 def one(job):
  k,m,o,target=job;rec=test(d,k,m,o,sp,v.keep);rec.update(key=k,matching=m,owners=o,side_micro=v.u,settings=sp)
  if not target.is_file() or not json.loads(target.read_text())['closed']:atomic(target,rec)
  return rec
 t=time.monotonic();ct=Counter()
 with ThreadPoolExecutor(v.jobs) as pool:
  for fu in as_completed([pool.submit(one,row) for row in todo]):
   r=fu.result();ct[r.get('solver','geometry')]+=1;print(dict(ct),r['key'],r['owners'],r.get('stats',{}),int(time.monotonic()-t),flush=True)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('u',type=int);a.add_argument('--settings',default='3,6,5,14,16,16,30');a.add_argument('--jobs',type=int,default=2);a.add_argument('--limit',type=int);a.add_argument('--keep',type=Path);a.add_argument('--root',action='store_true');a.add_argument('--reverse',action='store_true');main(a.parse_args())
