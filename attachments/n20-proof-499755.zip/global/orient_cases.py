"""Search remaining leaves using one shared direction vector per tile."""
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
from collections import Counter
import argparse,json,os,subprocess,sys,time
from branches import h,atomic,paths
sys.path.insert(0,str(h/'advanced'))
from orient_model import Model
def main(v):
 p=paths(v.U,v.bins)
 src=h/f'trials/cap{v.U}_{v.source}';dst=h/f'trials/orient{v.U}_{v.tag}';dst.mkdir(exist_ok=True)
 def run(job):
  z,owners,key=job;receipt=dst/(key+'.json')
  if receipt.exists():return json.loads(receipt.read_text())
  model=dst/(key+'.model');a,b=z['mask_pair'].split('_')
  env=dict(os.environ,N20_EXTRA_RACKS=str(p['racks'](v.racks)),N20_DEPTH_TABLE=str(p['dep']),N20_FINE=str(v.fine),N20_FRAME_SUB=str(v.sub),N20_UNION_PASSES=str(v.pre),N20_FAMILY_ANGLES=str(v.angles))
  if v.shifts:env['N20_SHIFT_FILE']=str(h/f'trials/shifts{v.U}/s{v.shifts}.txt')
  res=subprocess.run([h/'advanced/orient','orient',p['tab'],p['profiles'],p['moves'],a,b,'30','3',','.join(map(str,owners)),'-',model],env=env,input=' '.join(map(str,z['matching']))+'\n',text=True,capture_output=True,check=True)
  words=res.stdout.split();out=dict(mask_pair=z['mask_pair'],matching=z['matching'],owners=owners,side_micro=v.U,settings=[v.fine,v.sub,v.pre,v.angles,v.racks,v.shifts],search_only=True)
  if words[0]=='CLOSED':out.update(result='geometry',exclusion=words)
  else:
   assert words==['ORIENT'];q=Model(model).optimize(v.seconds,v.iterations)
   out.update(result='relaxation_candidate' if q['relaxation_candidate'] else 'relaxation',model=q)
   if not v.keep:model.unlink()
  atomic(receipt,out);return out
 rows=[]
 for f in sorted(src.glob('*.json')):
  z=json.loads(f.read_text())
  for o in z['open_leaves']:
   key=f.stem+'_'+','.join(map(str,o))
   if v.frame:
    q=h/f'trials/frame{v.U}_{v.frame}'/(key+'.json')
    if not q.exists() or json.loads(q.read_text())['result'][0]!='OPEN_FRAME':continue
   rows.append((z,o,key))
 if v.limit:rows=rows[:v.limit]
 start=time.monotonic()
 with ThreadPoolExecutor(v.workers) as pool:
  for f in as_completed([pool.submit(run,j) for j in rows]):
   z=f.result();m=z.get('model',{});print(z['mask_pair'],z['owners'],z['result'],m.get('variables'),m.get('trace',[None])[-1],int(time.monotonic()-start),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('U',type=int);p.add_argument('--bins',type=int,default=64);p.add_argument('--source',default='ep1');p.add_argument('--tag',default='joint');p.add_argument('--angles',type=int,default=6);p.add_argument('--fine',type=int,default=3);p.add_argument('--sub',type=int,default=4);p.add_argument('--pre',type=int,default=2);p.add_argument('--racks',type=int,default=14);p.add_argument('--shifts',type=int,default=0);p.add_argument('--seconds',type=int,default=15);p.add_argument('--iterations',type=int,default=6);p.add_argument('--limit',type=int,default=25);p.add_argument('--workers',type=int,default=1);p.add_argument('--frame',default='plain');p.add_argument('--keep',action='store_true');main(p.parse_args())
