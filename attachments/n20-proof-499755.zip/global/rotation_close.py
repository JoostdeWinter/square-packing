"""Intersect pose domains from rotations preserving a complete labelled matching."""
from pathlib import Path
from tempfile import TemporaryDirectory
import argparse
import json
from branches import h, stamp, atomic
from scale_coupled import calc, facets, cut, write_profiles
from check_union import hull
from verify_stronger import shifts

def subgroup(d, key, matched):
    U = int((d/'moves.txt').read_text().split()[1])
    red = [tuple(map(int,line.split()[:2])) for line in (d/'moves.txt').read_text().splitlines()[1:]]
    rotate = lambda p: (U-p[1],p[0])
    blue = list(map(rotate,red))
    ids = [i for i in range(22) if (int(key.split('_')[0]) >> i)&1]
    assert len(ids)==len(matched)==20
    lab = {(red[i],blue[j]):k for k,(i,j) in enumerate(zip(ids,matched))}
    moves=[]
    for power in range(4):
        loc=[]
        for i,j in zip(ids,matched):
            a,b=red[i],blue[j]
            for _ in range(power):a,b=rotate(a),rotate(b)
            loc.append(lab.get((b,a) if power%2 else (a,b)))
        if None not in loc:
            assert sorted(loc)==list(range(20))
            moves.append((power,loc))
    assert moves[0]==(0,list(range(20)))
    return U,moves

def contract(data,U,group):
    sets=[([], [[] for _ in range(64)]) for _ in range(20)]
    for power,perm in group:
        def turn(point):
            x,y=point
            for _ in range(power):x,y=U-y,x
            return x,y
        for i,(seed,charts) in enumerate(data):
            cores,domains=sets[perm[i]]
            cores.extend(map(turn,seed))
            for k,p in enumerate(charts):
                domains[k].append(list(map(turn,p)))
    out=[]
    for cores,domains in sets:
        poses=[]
        for outer in domains:
            if not all(outer):
                poses.append([]);continue
            poly=outer[0]
            for other in outer[1:]:
                for a,b,c in facets(other):
                    poly=cut(poly,a,b,c)
                    if not poly:break
                if not poly:break
            poses.append(poly)
        if not any(poses):return None
        out.append((hull(cores),poses))
    return out

def replay(d,k,m,o,settings):
    assert o in ([-1]*4,[-2]*4)
    loops,*sp=settings
    assert type(loops) is int and 1<=loops<=10 and len(sp)==5
    U,g=subgroup(d,k,m);shifts(d,U)
    if len(g)==1:return ['OPEN_FRAME','trivial']
    with TemporaryDirectory() as td:
        t=Path(td);inp=d/'p64';out=t/'state'
        for step in range(loops):
            data=calc(U,k,m,o,inp,out,sp,False,d)
            if data is None:return ['CLOSED_FRAME','geometric_check',str(step)]
            data=contract(data,U,g)
            if data is None:return ['CLOSED_FRAME','empty_orbit',str(step)]
            inp=t/'tables';write_profiles(inp,U,k,m,data,d)
        closed=calc(U,k,m,o,inp,out,sp,True,d) is None
    return ['CLOSED_FRAME' if closed else 'OPEN_FRAME','rotation_domains',str(len(g))]

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('cap',type=int);p.add_argument('--root',action='store_true');p.add_argument('--settings',default='2,2,8,10,14,16');v=p.parse_args()
    z=json.loads((h/'trials/last4998_rankcells.json').read_text());d=h/f'cold{v.cap}';k=z['key'];m=z['matching'];o=[-2 if v.root else -1]*4;sp=list(map(int,v.settings.split(',')))
    U,g=subgroup(d,k,m);print('rotations',[(a,b[0]) for a,b in g],flush=True);r=replay(d,k,m,o,sp);print(r,flush=True)
    loc=d/'rotation_results';loc.mkdir(exist_ok=True)
    val={'key':k,'owners':o,'matching':m,'closed':r[0]=='CLOSED_FRAME','history':[[['rotation_group',sp],r]]}
    nm=stamp(k,m)+'_'+','.join(map(str,o))+'.json';atomic(loc/nm,val)
    if val['closed'] and not v.root:
        dr=d/'direct_replays';dr.mkdir(exist_ok=True);atomic(dr/nm,val)
