"""Revisit conditional angle-menu matchings after exhaustive ownership splitting."""
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
from pathlib import Path
from fractions import Fraction as F
from branches import h,stamp,atomic
from angle_menu import test
import json,time,argparse
def main(v):
 d=v.cold.resolve();src=v.root.resolve();dest=v.out.resolve();dest.mkdir(exist_ok=True,parents=True);band=F(v.band);clock=time.monotonic()
 def read(f):return json.loads(f.read_text())
 def work(row):
  k,m,mode,os=row;f=dest/(stamp(k,m)+'.json')
  if f.exists() and read(f)['closed']:return read(f)
  seq=[];closed=True
  if mode in ('from_ownership','from_caps'):return {'closed':True,'method':mode,'key':k,'matching':m,'leaves':[]}
  for o in os:
   name=stamp(k,m)+'_'+','.join(map(str,o))+'.json'
   if o!=[-2]*4 and any((d/q/name).exists() and read(d/q/name)['closed'] for q in ('frame_replays','strong_replays','lattice_first','new_replays','multi_first','multi_strong')):
    seq.append([o,'unrestricted',True]);continue
   hist=[]
   for sp in ((3,5,4,14,16,8,26),(4,7,6,50,24,12,75)):
    r=test(d,band,k,m,o,sp);hist.append([sp,r])
    if r['closed']:break
   seq.append([o,hist,r['closed']])
   if not r['closed']:closed=False;break
  z={'closed':closed,'method':mode,'key':k,'matching':m,'leaves':seq};atomic(f,z);return z
 seen=set();counts=Counter()
 while True:
  decisions={};items=[]
  for f in src.glob('*.json'):
   z=read(f);k,m=z['key'],z['matching'];key=stamp(k,m)
   if z['closed']:decisions[key]='root';continue
   other=dest/(key+'.json')
   if other.exists() and read(other)['closed']:decisions[key]=read(other)['method'];continue
   if any((d/q/(key+'.json')).exists() and read(d/q/(key+'.json'))['closed'] for q in ('root_frames','quick_frames')):
    decisions[key]='from_caps';continue
   base=d/'matchings'/(key+'.json')
   if base.exists():
    leaves=read(base)['open_leaves']
    if not leaves:decisions[key]='from_ownership';continue
    mode='owned_angles'
   elif v.fallback:leaves=[[-2]*4];mode='strong_root_angle'
   else:continue
   ident=(key,mode)
   if ident in seen:continue
   seen.add(ident);items.append((k,m,mode,leaves))
  with ThreadPoolExecutor(v.jobs) as ex:
   for fu in as_completed([ex.submit(work,j) for j in items]):
    z=fu.result();counts['closed' if z['closed'] else 'open']+=1;print(dict(counts),z['key'],z['method'],int(time.monotonic()-clock),flush=True)
  base_ready=(d/'status.json').exists();root_ready=(src/'summary').exists()
  if root_ready:
   assert read(src/'summary')['matchings']==1142
   if len(decisions)==1142 or base_ready and not items:
    c=Counter(decisions.values());res={'half_tangent_cut':str(band),'closed_matchings':len(decisions),'remaining':1142-len(decisions),'methods':c,'root_summary':read(src/'summary')};atomic(dest/'summary',res)
    if len(decisions)==1142:atomic(dest/'verified',res)
    print('end',res,flush=True);return
  time.sleep(15)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('band');p.add_argument('cold',type=Path);p.add_argument('root',type=Path);p.add_argument('out',type=Path);p.add_argument('--jobs',type=int,default=2);p.add_argument('--fallback',action='store_true');main(p.parse_args())
