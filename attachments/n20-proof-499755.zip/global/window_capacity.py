"""Contract center domains using known capacities of two-, three-, and four-unit squares."""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
from tempfile import TemporaryDirectory
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
import json,sys,time,argparse
from branches import h,stamp,atomic
from scale_coupled import calc,write_profiles,cut,hull
def widths():
 from math import ceil
 out=[]
 for k in range(64):
  z=[]
  for j in (k,k+1):z.append((F(64**2-j*j,64**2+j*j),F(128*j,64**2+j*j)))
  if z[0][0]>=z[0][1] and z[1][0]<=z[1][1]:assert 2*707107**2>10**12;out.append(707107)
  else:out.append(ceil(500000*max(sum(x) for x in z)))
 return out
def box(p):return min(x for x,y in p),max(x for x,y in p),min(y for x,y in p),max(y for x,y in p)
def outside(p,X,Y,L,W,U):
 if not p:return p
 l,r,b,t=X+W,X+L-W,Y+W,Y+L-W
 # The tile already fits in the outer board. A coincident wall needs no additional test.
 if X<=0:l=-2*U
 if X+L>=U:r=2*U
 if Y<=0:b=-2*U
 if Y+L>=U:t=2*U
 x,X_,y,Y_=box(p)
 if X_<=l or x>=r or Y_<=b or y>=t:return p
 if l<x and X_<r and b<y and Y_<t:return []
 return hull(q for a,c,d in ((1,0,l),(-1,0,-r),(0,1,b),(0,-1,-t)) for q in cut(p,a,c,d))
def filter_window(st,U,limit=200):
 w=widths();bounds=[]
 for seed,poses in st:
  pos=[(box(p),z) for z,p in zip(w,poses) if p];assert pos
  bounds.append((max(0,min(x-g for (x,X,y,Y),g in pos)),min(U,max(X+g for (x,X,y,Y),g in pos)),max(0,min(y-g for (x,X,y,Y),g in pos)),min(U,max(Y+g for (x,X,y,Y),g in pos))))
 trials=[]
 for target,capacity in ((2000000,1),(3000000,5),(4000000,12)):
  L=target-(U<5000000)
  def axis_mappings(j):
   # Every tested origin defines a legitimate subboard. Endpoints cover all
   # possible sets of tiles guaranteed to lie inside a window in this direction.
   positions=sorted({0,U-L,*[min(U-L,max(0,q)) for b in bounds for q in (b[j+1]-L,b[j])]})
   return [(q,sum(1<<i for i,b in enumerate(bounds) if q<=b[j] and b[j+1]<=q+L)) for q in positions]
  for (x,xm),(y,ym) in product(axis_mappings(0),axis_mappings(2)):
   cover=xm&ym;n=cover.bit_count()
   if n>capacity:return None,(target,'overflow',n)
   if n==capacity:trials.append((target,x,y,L,cover))
 # Check corner windows and the larger capacities first, with spatial diversity.
 trials.sort(key=lambda v:(-(int(v[1] in (0,U-v[3]))+int(v[2] in (0,U-v[3]))),-v[0],v[1],v[2]))
 done=changed=0
 for target,x,y,L,bits in trials[:limit]:
  for i,(seed,poses) in enumerate(st):
   if bits>>i&1:continue
   for k,p in enumerate(poses):
    if p:
     v=outside(p,x,y,L,w[k],U)
     if v!=p:poses[k]=v;changed+=1
   if not any(poses):return None,(target,'tile_deleted',i)
  done+=1
 return st,(done,changed)
def test(U,k,m,o,sp,base=None):
 from verify_stronger import shifts
 rounds,limit,fine,sub,pas,nr,ns=sp;settings=(fine,sub,pas,nr,ns);d=(h/f'cold{U}') if base is None else base;shifts(d,U)
 with TemporaryDirectory() as td:
  td=Path(td);state=td/'state';profiles=td/'profiles';log=[]
  st=calc(U,k,m,o,d/'p64',state,settings,False,d)
  if st is None:return True,['initial']
  for j in range(rounds):
   st,summary=filter_window(st,U,limit);log.append(summary)
   if st is None:return True,log
   write_profiles(profiles,U,k,m,st,d)
   if j==rounds-1 or summary[1]==0:
    if calc(U,k,m,o,profiles,state,settings,True,d) is None:return True,log+['frame']
    if summary[1]==0:break
   st=calc(U,k,m,o,profiles,state,settings,False,d)
   if st is None:return True,log+['check']
 return False,log
def main(v):
 from shared_angle_cases import outstanding
 from match_evidence import summarize
 d=h/f'cold{v.U}';out=d/('window_roots' if v.root else 'window_leaves');out.mkdir(exist_ok=True);report=summarize([v.U])[v.U];rows=[]
 for k,m in report['pending']:
  for o in ([[-2]*4] if v.root else outstanding(d,k,m)):
   if v.root or -2 not in o:rows.append((k,m,o))
 if v.reverse:rows.reverse()
 sp=list(map(int,v.settings.split(',')));assert len(sp)==7
 def one(z):
  k,m,o=z;tag=stamp(k,m)+('' if v.root else '_'+','.join(map(str,o)));f=out/(tag+'.json')
  if f.exists():
   r=json.loads(f.read_text())
   if r['closed'] or r['settings']==sp:return r
  passed,why=test(v.U,k,m,o,sp);r={'key':k,'matching':m,'owners':o,'settings':sp,'side_micro':v.U,'closed':passed,'history':why};atomic(f,r);return r
 print('start',len(rows),flush=True);ct=Counter();t=time.monotonic()
 with ThreadPoolExecutor(v.jobs) as pool:
  for fu in as_completed([pool.submit(one,r) for r in rows[:v.limit] if v.limit] if v.limit else [pool.submit(one,r) for r in rows]):
   r=fu.result();ct[str(r['closed'])]+=1;print(dict(ct),r['key'],r['history'],int(time.monotonic()-t),flush=True)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('U',type=int);a.add_argument('--jobs',type=int,default=1);a.add_argument('--limit',type=int);a.add_argument('--settings',default='3,120,2,4,5,14,16');a.add_argument('--root',action='store_true');a.add_argument('--reverse',action='store_true');main(a.parse_args())
