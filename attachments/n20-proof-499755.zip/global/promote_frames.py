"""Retest an exact successful frame at a larger side on its own geometry."""
from pathlib import Path
from collections import Counter
from concurrent.futures import ThreadPoolExecutor,as_completed
import json,sys,subprocess,time,os,argparse
from branches import stamp,h,atomic
from match_evidence import summarize
from shared_angle_cases import outstanding
from target_frames import one as check_owner
from verify_stronger import shifts
def read(p):return json.loads(p.read_text())
def main(v):
 u=v.side;d=h/f'cold{u}';dest=d/'promotions';dest.mkdir(exist_ok=True,parents=True)
 while not (d/'prepared.json').exists():time.sleep(4)
 shifts(d,u);src=sorted((p for p in h.glob('cold[0-9]*') if p.name[4:].isdigit() and 4995000<=int(p.name[4:])<u),reverse=True)
 def earlier_modes(k,m,o):
  nm=stamp(k,m);out=[]
  for f in src:
   for di in ('priority_roots','quick_frames','root_frames'):
    z=f/di/(nm+'.json')
    if not z.is_file():continue
    j=read(z)
    if not j['closed'] or not j['nodes'] or not j['nodes'][0].get('calls'):continue
    sp,r=j['nodes'][0]['calls'][-1]
    if sp=='check' or not r[0].startswith('CLOSED'):continue
    out.append(('frame',*sp,0,0))
   if -2 in o:continue
   own=nm+'_'+','.join(map(str,o))+'.json'
   for di in ('direct_replays','strong_replays','frame_replays'):
    z=f/di/own
    if not z.is_file():continue
    j=read(z)
    if not j['closed']:continue
    if 'history' in j:out.append(tuple(j['history'][-1][0]))
    elif j.get('attempts'):
     y=j['attempts'][-1];out.append((y['method'],y['fine'],y['subcharts'],y['passes'],y['racks'],0,y['split_depth'],y['budget']))
  return list(dict.fromkeys(out))
 def run(job):
  k,m,o,sp=job;tag=stamp(k,m);rid=tag+'_'+','.join(map(str,o))+'_'+','.join(map(str,sp))+'.json';mark=dest/rid
  if mark.is_file():return
  if -2 not in o:
   out=d/'direct_replays';out.mkdir(exist_ok=True);ok=check_owner(d,k,m,o,list(sp),out);atomic(mark,{'closed':ok});return ok
  folder=d/'priority_roots';folder.mkdir(exist_ok=True);path=folder/(tag+'.json')
  if path.is_file() and read(path)['closed']:return True
  mode,fine,sub,passes,nr,ns,dep,lim=sp
  if mode!='frame':return
  a,b=k.split('_');env=dict(os.environ,N20_DEPTH_TABLE=str(d/'depth.txt'),N20_EXTRA_RACKS=str(d/f'racks{nr}.txt'),N20_FINE=str(fine),N20_FRAME_SUB=str(sub),N20_UNION_PASSES=str(passes))
  env.pop('N20_BAND',None);env.pop('N20_SHIFT_FILE',None)
  if ns:env['N20_SHIFT_FILE']=str(d/f'shift{ns}.txt')
  vals=subprocess.check_output([d/'advanced/frame','frame',d/'i64',d/'p64',d/'moves.txt',a,b,'27','2','-2,-2,-2,-2'],input=' '.join(map(str,m))+'\n',text=True,env=env).split()
  assert vals[0] in ('CLOSED','CLOSED_FRAME','OPEN_FRAME')
  ok=vals[0].startswith('CLOSED');atomic(mark,{'closed':ok,'response':vals})
  if ok:atomic(path,{'key':k,'matching':m,'side_micro':u,'closed':True,'attempts':[['larger_side_frame',1]],'nodes':[{'owners':[-2]*4,'calls':[[[fine,sub,passes,nr,ns],vals]]}]})
  return ok
 t=time.monotonic()
 for turn in range(v.rounds):
  items=[]
  for k,m in summarize([u])[u]['pending']:
   ls=outstanding(d,k,m)
   for owner in ls:
    modes=earlier_modes(k,m,owner)
    for rank,sp in enumerate(modes[:v.settings]):
     nm=stamp(k,m)+'_'+','.join(map(str,owner))+'_'+','.join(map(str,sp))+'.json'
     if not (dest/nm).exists():items.append((rank,len(ls),sp[1],k,m,owner,sp))
  items.sort(key=lambda x:x[:4]);print('round',turn,'jobs',len(items),flush=True)
  with ThreadPoolExecutor(v.jobs) as ex:
   fs={ex.submit(run,a[3:]):a for a in items[:v.limit]}
   for fut in as_completed(fs):
    try:result=fut.result()
    except subprocess.CalledProcessError as e:print('retryable',e.returncode,flush=True);continue
    print(fs[fut][3],fs[fut][5],result,int(time.monotonic()-t),flush=True)
  if not items:break
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('side',type=int);p.add_argument('--jobs',type=int,default=1);p.add_argument('--settings',type=int,default=3);p.add_argument('--rounds',type=int,default=2);p.add_argument('--limit',type=int,default=120);main(p.parse_args())
