"""Explore exact sector-by-sector center and pose marginal constraints."""
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
from collections import Counter
import argparse,gzip,shutil,subprocess,sys,os,time,json
from branches import paths,h,atomic
sys.path.insert(0,str(h/'advanced'));from lifted_lp import Lift
def main(v):
 ps=paths(v.U,v.bins);src=h/f'trials/cap{v.U}_{v.source}';out=h/f'trials/lift{v.U}_{v.tag}';out.mkdir(exist_ok=True)
 while not (h/'advanced/lift').is_file():time.sleep(3)
 def one(job):
  z,o,key=job;file=out/(key+'.json')
  if file.exists():return json.loads(file.read_text())
  a,b=z['mask_pair'].split('_');data=out/(key+'.model')
  env=dict(os.environ,N20_FINE=str(v.fine),N20_DEPTH_TABLE=str(ps['dep']),N20_EXTRA_RACKS=str(ps['racks'](v.racks)),N20_LIFT_PRE=str(v.pre),N20_FAMILY_ANGLES=str(v.angles),N20_FAMILY_DIV=str(v.div),N20_LIFT_SECTORS=str(v.sectors))
  if v.shifts:env['N20_SHIFT_FILE']=str(h/f'trials/shifts{v.U}/s{v.shifts}.txt')
  rr=subprocess.run([h/'advanced/lift','lift',ps['tab'],ps['profiles'],ps['moves'],a,b,'30','3',','.join(map(str,o)),'-',data],text=True,env=env,input=' '.join(map(str,z['matching']))+'\n',capture_output=True,check=True)
  w=rr.stdout.split()
  if w[0]=='CLOSED':s={'status':'geometry','reason':w[1]}
  else:
   assert w==['LIFT'];m=Lift(data);r=m.explore(v.nodes,v.seconds);s={'status':r['tree']['status'],'lp':r}
   if s['status']=='closed' or v.keep:
    with data.open('rb') as fi,gzip.open(data.with_suffix('.model.gz'),'wb',compresslevel=3) as fo:shutil.copyfileobj(fi,fo)
   data.unlink()
  s.update(mask_pair=z['mask_pair'],matching=z['matching'],owners=o,settings=[v.U,v.bins,v.angles,v.div,v.sectors,v.fine,v.racks,v.shifts,v.pre]);atomic(file,s);return s
 seen=set();stats=Counter();t=time.monotonic()
 while True:
  items=[]
  for f in sorted(src.glob('*.json')):
   z=json.loads(f.read_text())
   for o in z['open_leaves']:
    key=f.stem+'_'+','.join(map(str,o))
    if key not in seen:seen.add(key);items.append((z,o,key))
  if v.limit:items=items[:max(0,v.limit-sum(stats.values()))]
  with ThreadPoolExecutor(v.workers) as pool:
   for f in as_completed([pool.submit(one,k) for k in items]):
    z=f.result();stats[z['status']]+=1;l=z.get('lp',{});print(sum(stats.values()),dict(stats),z['mask_pair'],l.get('variables'),l.get('statistics'),int(time.monotonic()-t),flush=True)
  if not v.continuous or v.limit and sum(stats.values())>=v.limit or (h/f'trials/cap{v.U}_{v.source}_receipt.json').is_file() and not items:break
  time.sleep(15)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('U',type=int);a.add_argument('--bins',type=int,default=64);a.add_argument('--source',default='ep1');a.add_argument('--tag',default='four');a.add_argument('--angles',type=int,default=4);a.add_argument('--div',type=int,default=1);a.add_argument('--sectors',type=int,choices=(1,2,4,8),default=4);a.add_argument('--fine',type=int,default=3);a.add_argument('--pre',type=int,default=1);a.add_argument('--racks',type=int,default=6);a.add_argument('--shifts',type=int,default=0);a.add_argument('--nodes',type=int,default=20);a.add_argument('--seconds',type=int,default=90);a.add_argument('--workers',type=int,default=1);a.add_argument('--limit',type=int,default=0);a.add_argument('--keep',action='store_true');a.add_argument('--continuous',action='store_true');main(a.parse_args())
