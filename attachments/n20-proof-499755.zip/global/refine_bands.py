"""Verify a narrower tilt hypothesis on every open leaf of a containing band."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from fractions import Fraction as F
from collections import Counter
import argparse,json,subprocess,os,time
from branches import h,paths,atomic
def main():
 ap=argparse.ArgumentParser();ap.add_argument('parent');ap.add_argument('spec');ap.add_argument('tag');ap.add_argument('--jobs',type=int,default=1);ap.add_argument('--cold',type=Path);ap.add_argument('--mirror',action='store_true');v=ap.parse_args();a,b=map(F,v.spec.split(','));assert 0<=a<=b<=1
 src=h/'trials'/('bands_'+v.parent);dest=h/'trials'/('bandref_'+v.tag);dest.mkdir(exist_ok=True,parents=True);ps=paths(5000000,64)
 exe=h/'advanced/bands'
 if v.cold:
  d=v.cold.resolve();assert json.loads((d/'prepared.json').read_text())['U']==5000000
  ps=dict(tab=d/'i64',profiles=d/'p64',moves=d/'moves.txt',dep=d/'depth.txt',racks=lambda n:d/f'racks{n}.txt');exe=d/'advanced'/('mirror_band' if v.mirror else 'bands')
 envbase=dict(os.environ,N20_BAND=' '.join(map(str,[a.numerator,a.denominator,b.numerator,b.denominator])),N20_DEPTH_TABLE=str(ps['dep']));seen=set();stat=Counter();pending=[];t=time.monotonic();racks=(6,14,50)
 def one(job):
  z,o,f=job;target=dest/(f+'.json')
  if target.is_file():return json.loads(target.read_text())
  k,l=z['mask_pair'].split('_');steps=[]
  for i,(mode,fine,sub,passes) in enumerate([('frame',2,5,5),('frame',4,6,10),('sep',3,4,3)]):
   env=dict(envbase,N20_EXTRA_RACKS=str(ps['racks'](racks[i])),N20_FINE=str(fine),N20_FRAME_SUB=str(sub),N20_UNION_PASSES=str(passes),N20_SEP_DEPTH='5',N20_SEP_BUDGET='65',N20_SEP_SPLIT='1')
   rr=subprocess.check_output([exe,mode,ps['tab'],ps['profiles'],ps['moves'],k,l,'30','3',','.join(map(str,o))],text=True,input=' '.join(map(str,z['matching']))+'\n',env=env).split()
   assert rr[0] in ['CLOSED','CLOSED_FRAME','OPEN_FRAME','CLOSED_SEP','OPEN_SEP'];steps.append(rr)
   if rr[0].startswith('CLOSED'):break
  r={'mask_pair':z['mask_pair'],'matching':z['matching'],'owners':o,'steps':steps,'closed':rr[0].startswith('CLOSED')};atomic(target,r);return r
 while True:
  todo=[]
  for p in sorted(src.glob('*.json')):
   if p.name in seen:continue
   z=json.loads(p.read_text());seen.add(p.name)
   for o in z['open_leaves']:todo.append((z,o,p.stem+'_'+','.join(map(str,o))))
  with ThreadPoolExecutor(v.jobs) as ex:
   for f in as_completed([ex.submit(one,j) for j in todo]):
    r=f.result();stat[r['steps'][-1][0]]+=1
    if not r['closed']:pending.append(r)
    print(sum(stat.values()),len(pending),stat,int(time.monotonic()-t),flush=True)
  prev=h/'trials'/('bands_'+v.parent+'_receipt.json')
  if prev.is_file() and not todo:
   parent=json.loads(prev.read_text());assert not v.mirror or parent.get('also_allow_reflected_interval');low,high=map(F,parent['half_tangent_range']);assert low<=a<=b<=high and parent['screened_matchings']==len(seen)
   assert sum(len(z['open_leaves']) for z in parent['unresolved'])==sum(stat.values())
   res={'parent':v.parent,'cold_geometry':bool(v.cold),'also_allow_reflected_interval':v.mirror,'parent_half_tangent':parent['half_tangent_range'],'half_tangent':[str(a),str(b)],'parent_matchings':len(seen),'refined_owners':sum(stat.values()),'counts':stat,'pending':pending}
   atomic(h/'trials'/('bandref_'+v.tag+'_receipt.json'),res);print('complete',len(pending),'remaining',flush=True);break
  time.sleep(20)
if __name__=='__main__':main()
