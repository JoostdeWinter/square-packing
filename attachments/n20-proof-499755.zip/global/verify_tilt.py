"""Test an explicit angular-count hypothesis on the cold unrestricted screen."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from fractions import Fraction as F
from collections import Counter
import os,sys,subprocess,time,json,shutil,argparse
from branches import h,stamp,atomic
def main(v):
 d=v.work.resolve();a,b=map(F,v.band.split(','));assert 0<=a<=b<=1;dstat=d/'prepared.json'
 while not dstat.is_file() or not (d/'advanced/refinement_built.json').is_file():time.sleep(15)
 cfg=json.loads(dstat.read_text());assert cfg['U']==5000000
 tag=f'tilt_{a.numerator}_{a.denominator}_{b.numerator}_{b.denominator}_exceptions{v.exceptions}'
 out=d/tag;out.mkdir(exist_ok=True);ad=d/'advanced';exe=ad/'tilt_quota'
 if v.build:
  for f in ['tilt_quota.inc','build_tilt_quota.py']:shutil.copy(h/'advanced'/f,ad/f)
  subprocess.run([sys.executable,ad/'build_tilt_quota.py'],check=True)
 else:
  while not exe.is_file():time.sleep(10)
 def run(job):
  k,m,o=job;a0,b0=k.split('_');key=stamp(k,m)+'_'+','.join(map(str,o))+'.json';file=out/key
  if file.is_file():return json.loads(file.read_text())
  prior=d/'frame_replays'/key
  if prior.is_file() and json.loads(prior.read_text())['closed']:return {'closed':True,'by':'unrestricted'}
  hist=[];quota=v.exceptions
  for f,sub,rounds,racks,nodes in [(2,4,3,6,85),(4,6,6,14,160),(6,7,10,50,260)]:
   env=dict(os.environ,N20_DEPTH_TABLE=str(d/'depth.txt'),N20_EXTRA_RACKS=str(d/f'racks{racks}.txt'),N20_FINE=str(f),N20_FRAME_SUB=str(sub),N20_UNION_PASSES=str(rounds),N20_TILT_LIMIT=str(nodes),N20_TILT_SPEC=' '.join(map(str,(a.numerator,a.denominator,b.numerator,b.denominator,quota))))
   env.pop('N20_BAND',None);env.pop('N20_SHIFT_FILE',None)
   rr=subprocess.check_output([exe,'tiltquota',d/f'i{cfg["grid"]}',d/f'p{cfg["grid"]}',d/'moves.txt',a0,b0,'30','3',','.join(map(str,o))],text=True,env=env,input=' '.join(map(str,m))+'\n').split()
   assert rr[0] in ('CLOSED','CLOSED_TILT','OPEN_TILT');hist.append(([f,sub,rounds,racks,nodes],rr))
   if rr[0].startswith('CLOSED'):break
  ans={'key':k,'matching':m,'owners':o,'range':[str(a),str(b)],'exceptions':quota,'history':hist,'closed':rr[0].startswith('CLOSED')};atomic(file,ans);return ans
 seen=set();t=time.monotonic();hist=Counter()
 while True:
  ready=(d/'status.json').is_file();todo=[]
  rows=json.loads((d/'open.json').read_text()) if ready else (json.loads(f.read_text()) for f in (d/'matchings').glob('*.json'))
  for z in rows:
   for o in z['open_leaves']:
    k,m=z['mask_pair'],z['matching'];key=k,tuple(m),tuple(o)
    if key not in seen:seen.add(key);todo.append((k,m,o))
  with ThreadPoolExecutor(v.jobs) as ex:
   for f in as_completed([ex.submit(run,j) for j in todo]):
    z=f.result();hist['closed' if z['closed'] else 'open']+=1
    if sum(hist.values())%10==0:print(sum(hist.values()),dict(hist),int(time.monotonic()-t),flush=True)
  if ready and not todo:break
  time.sleep(12)
 src=json.loads((d/'status.json').read_text());assert len(seen)==src['open_ownership_leaves'];counts=Counter();pending=[]
 for k,m,o in sorted(seen):
  key=stamp(k,m)+'_'+','.join(map(str,o))+'.json';prior=d/'frame_replays'/key
  if prior.is_file() and json.loads(prior.read_text())['closed']:counts['unrestricted']+=1;continue
  z=json.loads((out/key).read_text());assert z['matching']==list(m) and z['owners']==list(o)
  if z['closed']:counts['angular']+=1
  else:counts['open']+=1;pending.append(z)
 res={'side_micro':5000000,'screen':src,'half_tangent_interval':[str(a),str(b)],'allowed_exceptions':v.exceptions,'complete_ownerships':len(seen),'outcomes':counts,'open_ownerships':len(pending)}
 atomic(out/'summary',res);atomic(out/'pending',pending)
 if not pending:atomic(out/'verified',res)
 print('finished',tag,counts,flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('work',type=Path);p.add_argument('band');p.add_argument('--exceptions',default=0,type=int);p.add_argument('--jobs',default=2,type=int);p.add_argument('--build',action='store_true');main(p.parse_args())
