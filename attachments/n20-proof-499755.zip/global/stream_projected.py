"""Begin a smaller-cap replay for matching rows left open at a larger cap."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,time,json
from branches import work,stamp
def run(d,src,jobs):
 while not (d/'prepared.json').is_file():time.sleep(15)
 cfg=json.loads((d/'prepared.json').read_text());U,b=cfg['U'],cfg['grid']
 ps=dict(tab=d/f'i{b}',moves=d/'moves.txt',profiles=d/f'p{b}',dep=d/'depth.txt',exe=d/'advanced/deeper',racks=lambda n:d/f'racks{n}.txt',extra_counts=(6,14))
 out=d/'matchings';out.mkdir(exist_ok=True);seen=set();processed=0
 while True:
  ready=(src/'status.json').is_file();todo=[]
  rows=json.loads((src/'open.json').read_text()) if ready else (json.loads(f.read_text()) for f in (src/'matchings').glob('*.json'))
  for z in rows:
   if not z['open_leaves']:continue
   k,m=z['mask_pair'],z['matching'];sk=stamp(k,m)
   if sk in seen:continue
   seen.add(sk)
   if not (out/(sk+'.json')).is_file():todo.append((k,m))
  with ThreadPoolExecutor(jobs) as ex:
   for f in as_completed([ex.submit(work,U,b,k,m,'fast',ps,out) for k,m in todo]):
    v=f.result();processed+=1
    if processed%10==0:print(processed,len(seen),len(v['open_leaves']),flush=True)
  if ready:break
  time.sleep(15)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('dest',type=Path);p.add_argument('source',type=Path);p.add_argument('--jobs',type=int,default=2);v=p.parse_args();run(v.dest.resolve(),v.source.resolve(),v.jobs)
