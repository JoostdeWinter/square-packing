"""Replay angular frames before branching on the four unselected mark owners.

Each successful receipt gives either a root exclusion or an exhaustive tree.
The finite node budget can only leave a matching pending.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
import os,sys,time,json,argparse,subprocess
from branches import atomic,h,stamp
from verify_stronger import shifts
from match_evidence import summarize
def solve(d,k,m,params,out):
 f=out/(stamp(k,m)+'.json')
 if f.is_file():return json.loads(f.read_text())
 ini=json.loads((d/'prepared.json').read_text());bins=ini['grid'];U=ini['U'];a,b=k.split('_')
 if not (d/'shift16.txt').is_file():shifts(d,U)
 nodes=[];stats=Counter();start=time.monotonic()
 def call(mode,owners,factor,sub,passes,racks,shift):
  env=dict(os.environ,N20_FINE=str(factor),N20_FRAME_SUB=str(sub),N20_UNION_PASSES=str(passes),N20_SHIFT_FILE=str(d/f'shift{shift}.txt'),N20_EXTRA_RACKS=str(d/f'racks{racks}.txt'),N20_DEPTH_TABLE=str(d/'depth.txt'))
  env.pop('N20_BAND',None);which='frame' if mode=='frame' else 'deeper'
  cmd=[d/'advanced'/which,mode,d/f'i{bins}',d/f'p{bins}',d/'moves.txt',a,b,'27','2',','.join(map(str,owners))]
  z=subprocess.check_output(cmd,text=True,input=' '.join(map(str,m))+'\n',env=env).split()
  assert z and z[0] in ('CLOSED','OPEN','OPEN_FRAME','CLOSED_FRAME')
  stats[mode]+=1;return z
 def node(owner,dep):
  if len(nodes)>=params['budget']:return False
  row={'owners':owner,'calls':[]};nodes.append(row)
  # Try a coarse exact check for a cheap stop and the exhaustive owner domains.
  z=call('check',owner,1,1,1,6,8);row['calls'].append(['check',z])
  if z[0]=='CLOSED':return True
  avail=list(map(int,z[1:]));assert len(avail)==4 and all(0<=w<1<<20 for w in avail)
  root=dep==0;last=-2 not in owner
  levels=[(2,4,4,6,8)]
  if root or last:levels.append((3,7,9,14,16))
  if last:levels.append((5,8,15,50,24))
  for g in levels:
   r=call('frame',owner,*g);row['calls'].append([g,r])
   if r[0].startswith('CLOSED'):return True
  if last:return False
  j=min((j for j,v in enumerate(owner) if v==-2),key=lambda j:avail[j].bit_count());row['split']=j
  opts=[-1]+[j0 for j0 in range(20) if avail[j]>>j0&1]
  for q in opts:
   o=list(owner);o[j]=q
   if not node(o,dep+1):return False
  return True
 passed=node([-2]*4,0)
 ans={'key':k,'matching':m,'closed':passed,'attempts':[['root_or_ownership_frames',len(nodes)]],'node_budget':params['budget'],'nodes':nodes,'calls':stats,'seconds':round(time.monotonic()-start,2),'side_micro':U}
 atomic(f,ans);return ans
def main(v):
 U=v.U;d=h/f'cold{U}'
 while not (d/'advanced/refinement_built.json').exists() or not (d/'prepared.json').exists():time.sleep(20)
 out=d/'root_frames';out.mkdir(exist_ok=True);start=time.monotonic();cnt=Counter()
 while True:
  q=summarize([U])[U];candidates=[(k,m) for k,m in q['pending'] if not (out/(stamp(k,m)+'.json')).is_file()]
  if not candidates:break
  candidates.sort(reverse=True);candidates=candidates[:v.batch]
  with ThreadPoolExecutor(v.jobs) as ex:
   for fu in as_completed([ex.submit(solve,d,k,list(m),{'budget':v.nodes},out) for k,m in candidates]):
    r=fu.result();cnt['closed' if r['closed'] else 'open']+=1;print(r['key'],len(r['nodes']),dict(cnt),'of',q['remaining'],'at batch start',int(time.monotonic()-start),flush=True)
 print('finished',U,dict(cnt),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('U',type=int);p.add_argument('--jobs',type=int,default=2);p.add_argument('--nodes',type=int,default=55);p.add_argument('--batch',type=int,default=12);main(p.parse_args())
