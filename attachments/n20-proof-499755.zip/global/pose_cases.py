from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
import argparse,os,sys,subprocess,tempfile,time,gzip,json,hashlib
from branches import paths,atomic,h
sys.path.insert(0,str(h/'advanced'));from family_sat import solve
def main(v):
 ps=paths(v.U,v.bins);src=h/f'trials/cap{v.U}_{v.source}';dest=h/f'trials/poses{v.U}_{v.tag}';dest.mkdir(exist_ok=True);stats=Counter();seen=set();start=time.monotonic()
 while not (h/'advanced/poses').is_file():time.sleep(3)
 def run(job):
  z,o,key=job;file=dest/(key+'.json')
  if file.exists():return json.loads(file.read_text())
  a,b=z['mask_pair'].split('_');env=dict(os.environ,N20_FINE=str(v.factor),N20_EXTRA_RACKS=str(ps['racks'](v.racks)),N20_DEPTH_TABLE=str(ps['dep']),N20_DIRECT_PASSES=str(v.pre),N20_FAMILY_ANGLES=str(v.angles),N20_FAMILY_DIV=str(v.div))
  if v.shift:env['N20_SHIFT_FILE']=str(h/f'trials/shifts{v.U}/s{v.shift}.txt')
  tmp=dest/(key+'.graph')
  c=subprocess.run([h/'advanced/poses','families',ps['tab'],ps['profiles'],ps['moves'],a,b,'30','3',','.join(map(str,o)),'-',tmp],input=' '.join(map(str,z['matching']))+'\n',env=env,text=True,capture_output=True,check=True)
  r=c.stdout.split()
  if r[0]=='CLOSED':res={'status':'geometry','stage':r[1]}
  else:
   assert r==['GRAPH'];res=solve(tmp,v.nodes,v.singleton);res['graph_sha256']=hashlib.sha256(tmp.read_bytes()).hexdigest()
   if res['status']=='unsat':
    with tmp.open('rb') as inp,gzip.open(tmp.with_suffix('.graph.gz'),'wb',compresslevel=3) as out:
     import shutil
     shutil.copyfileobj(inp,out)
   tmp.unlink()
  res.update(mask_pair=z['mask_pair'],matching=z['matching'],owners=o,config=[v.bins,v.factor,v.racks,v.shift,v.pre,v.angles,v.div,v.nodes]);atomic(file,res);return res
 while True:
  todo=[]
  for f in sorted(src.glob('*.json')):
   z=json.loads(f.read_text())
   for o in z['open_leaves']:
    key=f.stem+'_'+','.join(map(str,o))
    if key not in seen:seen.add(key);todo.append((z,o,key))
  with ThreadPoolExecutor(v.workers) as ex:
   for f in as_completed([ex.submit(run,q) for q in todo]):
    r=f.result();stats[r['status']]+=1;print(sum(stats.values()),dict(stats),r['mask_pair'],r.get('families'),r.get('nodes'),int(time.monotonic()-start),flush=True)
  if not v.continuous or ((h/f'trials/cap{v.U}_{v.source}_receipt.json').is_file() and not todo):break
  time.sleep(20)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('U',type=int);ap.add_argument('--source',default='ep1');ap.add_argument('--bins',type=int,default=64);ap.add_argument('--tag',default='p1');ap.add_argument('--factor',type=int,default=4);ap.add_argument('--angles',type=int,default=8);ap.add_argument('--div',type=int,default=2);ap.add_argument('--racks',type=int,default=6);ap.add_argument('--shift',type=int,default=0);ap.add_argument('--pre',type=int,default=2);ap.add_argument('--nodes',type=int,default=12000);ap.add_argument('--workers',type=int,default=2);ap.add_argument('--singleton',action='store_true');ap.add_argument('--continuous',action='store_true');main(ap.parse_args())
