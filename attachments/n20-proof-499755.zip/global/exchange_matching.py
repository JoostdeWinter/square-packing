"""Restrict a 20-square packing by exchanges with certified 19-square packings."""
from pathlib import Path
from itertools import product,combinations
from fractions import Fraction as F
from functools import lru_cache
from tempfile import TemporaryDirectory
from math import ceil,sqrt
from collections import Counter
import sys,argparse,time,json
from branches import h,stamp,atomic
from scale_coupled import calc,write_profiles,cut,hull
from window_capacity import widths
from verify_stronger import shifts

D=1000000
axes=((1,0),(0,1),(1,1),(1,-1))
def radius(diagonal,a,b):
 return 707107*max(abs(a),abs(b)) if diagonal else D*(abs(a)+abs(b))//2
def validate(U,tiles):
 if any(min(x,y,U-x,U-y)<=radius(diag,1,0) for x,y,diag in tiles):return False
 for (x,y,di),(X,Y,dj) in combinations(tiles,2):
  if not any(abs(a*(x-X)+b*(y-Y))>radius(di,a,b)+radius(dj,a,b) for a,b in axes):return False
 return True
@lru_cache(maxsize=None)
def templates(U):
 # Wainwright 1979. Centers transcribed from ofitzharding/sq19, revision
 # 34fb2b7bc39465db368c45cb48d4db58829d3051, Sq19Lean/EndpointPacking.lean.
 # Approximation merely proposes centers. validate() verifies every output exactly.
 v=sqrt(2);e=4*v/3;L=3+e
 xy=[(.5,2.5+e),(1.5,2.5+e),(.5,1.5+e),(2.5+e,.5),(1.5+e,.5),(.5+e,.5),
     (2.5+e,1.5),(1.5+e,1.5),(2.5+e,2.5),(2.5+e,2.5+e),
     (1.5+1.5*v,2.5+2*v/3),(1.5+v,2.5+7*v/6),(2+2*v/3,2+v/2),(2+v/6,2+v),(.5,.5),
     (.5+2*v/3,1.5-v/6),(.5+v/6,1.5+v/3),(1+5*v/6,1+2*v/3),(1+v/3,1+7*v/6)]
 out=set()
 for dilation in (1.003,1.015,1.021):
  gap=U-D*L*dilation
  if gap<4:continue
  for shiftx,shifty in product((.025,.5,.975),repeat=2):
   src=[(round(x*D*dilation+shiftx*gap),round(y*D*dilation+shifty*gap),int(10<=i<=13 or 15<=i)) for i,(x,y) in enumerate(xy)]
   assert len(src)==19 and validate(U,src)
   for sw,fx,fy in product((0,1),repeat=3):
    perm=lambda x,y:(U-x if fx else x,U-y if fy else y)
    data=tuple(sorted((*perm(*((y,x) if sw else (x,y))),i) for x,y,i in src))
    out.add(data)
 result=sorted(out);assert result and 2*707107**2>D**2
 return result
@lru_cache(maxsize=None)
def chart_widths():
 w=widths();out=[]
 for k in range(64):
  def cs(q):return F(64**2-q*q,64**2+q*q),F(128*q,64**2+q*q)
  a,b=cs(k);c,d=cs(k+1)
  # abs diagonal projection has radius max(cos,sin) times one unit.
  diag=ceil(D*max(a,b,c,d));out.append((w[k],w[k],diag,diag))
 return out
@lru_cache(maxsize=64)
def local_axes(k):
 g=128;j=2*k+1;c=g*g-j*j;s=2*g*j;d=g*g+j*j
 vals=[]
 for r in (k,k+1):
  q=64*64+r*r;co=64*64-r*r;si=128*r
  vals.append(F(D*(c*co+s*si+abs(c*si-s*co)),2*q))
 assert max(vals)>=F(D*d,2)
 return ((c,s),(-s,c)),(ceil(max(vals)),ceil(max(vals)))
def cover(adj,ban_tile=-1,ban_probe=-1):
 """Match every unbanned probe to a different unbanned tile."""
 holder=[-1]*20;seen=[-1]*20
 def assign(j,token):
  adjmask=adj[j]&~(1<<ban_tile) if ban_tile>=0 else adj[j]
  while adjmask:
   bit=adjmask&-adjmask;adjmask^=bit;k=bit.bit_length()-1
   if seen[k]==token:continue
   seen[k]=token
   if holder[k]<0 or assign(holder[k],token):holder[k]=j;return True
  return False
 for j in sorted((z for z in range(len(adj)) if z!=ban_probe),key=lambda z:adj[z].bit_count()):
  if not assign(j,j):return False
 return True
def critical(adj):
 if not cover(adj):return None
 out={}
 for i in range(20):
  if cover(adj,ban_tile=i):continue
  candidates=[j for j,mask in enumerate(adj) if mask>>i&1 and cover(adj,ban_tile=i,ban_probe=j)]
  assert candidates;out[i]=candidates
 return out
def bounds(p,aa=axes):
 t=[(min(a*x+b*y for x,y in p),max(a*x+b*y for x,y in p)) for a,b in aa]
 return t
def restrict(p,tiles,C,k=None):
 aa=axes
 if k is not None:
  ax,w=local_axes(k);aa=axes+ax;C=tuple(C)+w
 full=[];bounds_p=bounds(p,aa)
 for x,y,d in tiles:
  region=p
  for z,((a,b),g) in enumerate(zip(aa,C)):
   r=radius(d,a,b)+g;v=a*x+b*y
   if bounds_p[z][1]<v-r or bounds_p[z][0]>v+r:region=[];break
   if bounds_p[z][1]>v+r:region=cut(region,a,b,v+r)
   if bounds_p[z][0]<v-r:region=cut(region,-a,-b,-v+r)
   if not region:break
  if region==p:return p
  full.extend(region)
 return hull(full)
def filter_exchange(st,U,limit,offset):
 import numpy as np
 ws=chart_widths();ids=[];lo=[];hi=[]
 for i,(_,poses) in enumerate(st):
  for k,p in enumerate(poses):
   if not p:continue
   ids.append(i);ext=bounds(p);lo.append([l-g for (l,r),g in zip(ext,ws[k])]);hi.append([r+g for (l,r),g in zip(ext,ws[k])])
 ids=np.array(ids);lo=np.array(lo,dtype=np.int64);hi=np.array(hi,dtype=np.int64)
 trials=templates(U);report=Counter()
 for count in range(min(limit,len(trials))):
  probes=trials[(count*97+offset)%len(trials)];ps=np.array([[a*x+b*y for a,b in axes] for x,y,d in probes],dtype=np.int64)
  rad=np.array([[radius(d,a,b) for a,b in axes] for x,y,d in probes],dtype=np.int64)
  possible=np.all((ps[None,:,:]-rad[None,:,:]<=hi[:,None,:])&(ps[None,:,:]+rad[None,:,:]>=lo[:,None,:]),axis=2)
  rows=np.stack([np.any(possible[ids==i],axis=0) for i in range(20)])
  adj=[int(n) for n in ((1<<np.arange(20,dtype=np.int64))@rows)]
  forced=critical(adj);report['tested']+=1
  if forced is None:return None,dict(report,failed_hall=1)
  for i,links in forced.items():
   report['forced_tiles']+=1;poses=st[i][1];probelist=[probes[j] for j in links]
   for k,p in enumerate(poses):
    if p:
     r=restrict(p,probelist,ws[k],k);report['changed_charts']+=int(r!=p);poses[k]=r
   if not any(poses):return None,dict(report,empty_tile=i)
 return st,report
def test(U,k,m,o,sp,base=None):
 rounds,limit,offset,fine,sub,pas,nr,ns=sp;settings=(fine,sub,pas,nr,ns);d=h/f'cold{U}' if base is None else base;shifts(d,U)
 with TemporaryDirectory() as t:
  td=Path(t);out=td/'state';profile=td/'profiles';st=calc(U,k,m,o,d/'p64',out,settings,False,d)
  if st is None:return True,['initial']
  log=[]
  for j in range(rounds):
   st,c=filter_exchange(st,U,limit,offset+17*j);log.append(dict(c))
   if st is None:return True,log
   if not c.get('changed_charts'):break
   write_profiles(profile,U,k,m,st,d)
   if j==rounds-1 and calc(U,k,m,o,profile,out,settings,True,d) is None:return True,log+['frame']
   st=calc(U,k,m,o,profile,out,settings,False,d)
   if st is None:return True,log+['check']
  return False,log
def main(v):
 from match_evidence import summarize
 from shared_angle_cases import outstanding
 d=h/f'cold{v.U}';out=d/('exchange_roots' if v.root else 'exchange_replays');out.mkdir(exist_ok=True);sp=list(map(int,v.settings.split(',')));assert len(sp)==8;begin=time.monotonic()
 opts=summarize([v.U])[v.U]['pending'];todo=[]
 for k,m in opts:
  for o in ([[-2]*4] if v.root else outstanding(d,k,m)):
   if v.root or -2 not in o:todo.append((k,m,o))
 if v.reverse:todo.reverse()
 for k,m,o in todo[:v.limit]:
  tag=stamp(k,m)+('' if v.root else '_'+','.join(map(str,o)))+'.json';f=out/tag
  if f.exists():
   z=json.loads(f.read_text())
   if z['closed'] or z['settings']==sp:continue
  ok,log=test(v.U,k,m,o,sp,d)
  atomic(f,{'closed':ok,'key':k,'matching':m,'owners':o,'settings':sp,'side_micro':v.U,'history':log})
  print(k,o,ok,log,int(time.monotonic()-begin),flush=True)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('U',type=int);a.add_argument('--settings',default='2,45,0,2,4,5,14,16');a.add_argument('--limit',type=int,default=20);a.add_argument('--root',action='store_true');a.add_argument('--reverse',action='store_true');main(a.parse_args())
