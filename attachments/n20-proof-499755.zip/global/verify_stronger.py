"""Fresh replay with translated unavoidable patterns and fine local frames.

This can run while the quantitative ownership tree is being computed. A
result is complete only after checking against the final list of leaves.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
from fractions import Fraction as F
from itertools import product
import argparse,os,sys,json,subprocess,time,hashlib,tempfile
from branches import h,atomic,stamp
sys.path.insert(0,str(h/'base496'));from prereqs import SPEC,marks
def shifts(d,U):
 assert U<=5000000 and U%50==0
 primary=[(int(10**6*x),int(10**6*y)) for x,y in marks(dict(SPEC,cap=str(F(U,10**6))))]
 assert d.joinpath('moves.txt').read_text().splitlines()[1:][0].split()[:2]==list(map(str,primary[0]))
 forms=[primary,[(U-y,x) for x,y in primary]];rows=[]
 for s,t in [(300000,850000),(150000,760000),(400000,905000),(250000,800000),(50000,730000),(200000,715000)]:
  assert s+500000<=t and (2*t+1000000)**2<=8*10**12 and 0<s<414214
  for pts in forms:
   for dim,sign in product((0,1),(1,-1)):
    rows.append(' '.join(map(str,[dim,sign,s,t,len(pts),*(w for p in pts for w in p)])))
 for n in (8,16,24,48):
  path=d/f'shift{n}.txt';payload=f'{U} {n}\n'+'\n'.join(rows[:n])+'\n'
  if path.is_file() and path.read_text()==payload:continue
  with tempfile.NamedTemporaryFile(mode='w',dir=d,delete=False) as tmp:tmp.write(payload);staged=Path(tmp.name)
  staged.replace(path)
 return {n:hashlib.sha256((d/f'shift{n}.txt').read_bytes()).hexdigest() for n in (8,16,24,48)}
def run(d,jobs):
 while not (d/'advanced/refinement_built.json').is_file():time.sleep(13)
 ini=json.loads((d/'prepared.json').read_text());U=ini['U'];bins=ini['grid'];sha=shifts(d,U)
 out=d/'strong_replays';out.mkdir(exist_ok=True)
 def one(z):
  k,m,o=z;st=stamp(k,m)+'_'+','.join(map(str,o))+'.json';dest=out/st
  if dest.exists():return json.loads(dest.read_text())
  prior=d/'frame_replays'/st
  if prior.is_file() and json.loads(prior.read_text())['closed']:
   return {'closed':True,'prior':True}
  a,b=k.split('_');history=[]
  for mode,fine,sub,pas,racks,sr,depth,lim in [('frame',2,5,5,6,8,0,0),('frame',3,7,10,14,16,0,0),('frame',5,8,15,50,24,0,0),('sep',3,6,4,14,16,7,150),('frame',7,9,22,50,48,0,0)]:
   env=dict(os.environ,N20_DEPTH_TABLE=str(d/'depth.txt'),N20_EXTRA_RACKS=str(d/f'racks{racks}.txt'),N20_FINE=str(fine),N20_FRAME_SUB=str(sub),N20_UNION_PASSES=str(pas),N20_SHIFT_FILE=str(d/f'shift{sr}.txt'),N20_SEP_DEPTH=str(depth),N20_SEP_BUDGET=str(lim),N20_SEP_SPLIT='1')
   env.pop('N20_BAND',None)
   words=subprocess.check_output([d/'advanced'/('frame' if mode=='frame' else 'separators'),mode,d/f'i{bins}',d/f'p{bins}',d/'moves.txt',a,b,'30','3',','.join(map(str,o))],text=True,input=' '.join(map(str,m))+'\n',env=env).split()
   assert words[0] in ('CLOSED','OPEN_FRAME','CLOSED_FRAME','CLOSED_SEP','OPEN_SEP')
   history.append(([mode,fine,sub,pas,racks,sr,depth,lim],words))
   if words[0].startswith('CLOSED'):break
  ans={'key':k,'matching':m,'owners':o,'closed':words[0].startswith('CLOSED'),'history':history};atomic(dest,ans);return ans
 seen=set();total=Counter();start=time.monotonic()
 while True:
  todo=[];ready=(d/'status.json').is_file()
  rows=(json.loads((d/'open.json').read_text()) if ready else (json.loads(f.read_text()) for f in (d/'matchings').glob('*.json')))
  for z in rows:
   for o in z['open_leaves']:
    k,m=z['mask_pair'],z['matching'];t=(k,tuple(m),tuple(o))
    if t not in seen:seen.add(t);todo.append((k,m,o))
  with ThreadPoolExecutor(jobs) as pool:
   for f in as_completed([pool.submit(one,k) for k in todo]):
    z=f.result();total['closed' if z['closed'] else 'pending']+=1
    print('tested',sum(total.values()),dict(total),round(time.monotonic()-start),flush=True)
  if ready and not todo:break
  time.sleep(12)
 base=json.loads((d/'status.json').read_text());expected={(z['mask_pair'],tuple(z['matching']),tuple(o)) for z in json.loads((d/'open.json').read_text()) for o in z['open_leaves']}
 assert seen==expected and len(seen)==base['open_ownership_leaves'];stats=Counter();pending=[]
 for k,m,o in sorted(seen):
  f=stamp(k,m)+'_'+','.join(map(str,o))+'.json';prior=d/'frame_replays'/f
  if prior.is_file() and json.loads(prior.read_text())['closed']:stats['cold_frame']+=1;continue
  q=json.loads((out/f).read_text());assert q['key']==k and q['matching']==list(m) and q['owners']==list(o)
  if q['closed']:stats['translated_frame']+=1
  else:stats['pending']+=1;pending.append(q)
 rec={'base':base,'side_micro':U,'shift_files_sha256':sha,'outcomes':stats,'checked_ownerships':len(seen),'unresolved_ownerships':len(pending)}
 atomic(d/'strong_status.json',rec);atomic(d/'strong_open.json',pending)
 if not pending:atomic(d/'verified_strong.json',rec)
 print('finished',U,dict(stats),flush=True)
if __name__=='__main__':
 q=argparse.ArgumentParser();q.add_argument('directory',type=Path);q.add_argument('--jobs',type=int,default=2);z=q.parse_args();run(z.directory.resolve(),z.jobs)
