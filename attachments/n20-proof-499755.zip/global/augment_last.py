"""Retest a single root after individually certifying moved marks from a nearby stronger run."""
from pathlib import Path
from tempfile import TemporaryDirectory
from itertools import product
import os,sys,json,subprocess,argparse
from branches import h,atomic
from scale_inputs import rounded
from optimize_marks import hull
sys.path.insert(0,str(h/'base496'))
from coverage import sweep
from verify_stronger import shifts

def rows(f):
    lines=f.read_text().splitlines();n,U=map(int,lines[0].split());assert n==22
    values=[list(map(int,l.split())) for l in lines[1:]]
    return U,[tuple(r[:2]) for r in values],[set(zip(r[3::2],r[4::2])) for r in values]

def run(U,donor,settings,directory=None,expected=None):
    d=h/f'cold{U}' if directory is None else directory;work=d/'last_augmented';work.mkdir(exist_ok=True);L,pts,base=rows(d/'moves.txt');D,old,extend=rows(h/f'proofs/cap{donor}/moves.txt');assert U==L and D==donor
    assert [(rounded(x,U,D),rounded(y,U,D)) for x,y in old]==pts
    extra=set()
    for i,(x,y) in enumerate(pts):
        if x>U//2 or y>U//2:continue
        proposed={(rounded(x,U,D),rounded(y,U,D)) for x,y in extend[i]}-base[i]
        for pos in (set(hull(proposed|base[i]|{pts[i]})) & proposed):
            alt=pts.copy();alt[i]=pos
            if not sweep(alt,U,18):continue
            for a,b in product((0,1),repeat=2):
                rot=lambda z:(U-z[0] if a else z[0],U-z[1] if b else z[1])
                j=pts.index(rot(pts[i]));extra.add((j,rot(pos)))
    for j,pos in extra:base[j].add(pos)
    print('new certified moves',len(extra),flush=True)
    if not extra:return ['OPEN_FRAME','no_additional_moves']
    m=work/'moves.txt';q=[f'22 {U}']
    for (x,y),moves in zip(pts,base):q.append(' '.join(map(str,[x,y,len(moves),*(a for z in sorted(moves) for a in z)])))
    m.write_text('\n'.join(q)+'\n')
    with (work/'depth.txt').open('w') as stream:subprocess.run([d/'advanced/cover_depth',m,'128','2'],stdout=stream,check=True)
    z=json.loads((h/'trials/last4998_rankcells.json').read_text())
    if expected is not None:assert (z['key'],z['matching'])==expected
    aa,bb=z['key'].split('_');fine,sub,pas,nr,ns=settings;shifts(d,U)
    env=dict(os.environ,N20_FINE=str(fine),N20_FRAME_SUB=str(sub),N20_UNION_PASSES=str(pas),N20_EXTRA_RACKS=str(d/f'racks{nr}.txt'),N20_SHIFT_FILE=str(d/f'shift{ns}.txt'),N20_DEPTH_TABLE=str(work/'depth.txt'));env.pop('N20_BAND',None)
    result=subprocess.check_output([d/'advanced/frame','frame',d/'i64',d/'p64',m,aa,bb,'27','2','-2,-2,-2,-2'],env=env,text=True,input=' '.join(map(str,z['matching']))+'\n').split()
    assert result[0] in ('CLOSED','CLOSED_FRAME','OPEN_FRAME')
    r={'cap':U,'donor':D,'new_certified_moves':len(extra),'settings':settings,'result':result}
    atomic(work/f'result_{fine}_{sub}.json',r);print(r,flush=True);return result
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('cap',type=int);p.add_argument('donor',type=int);p.add_argument('--settings',default='3,8,12,14,16');a=p.parse_args();run(a.cap,a.donor,list(map(int,a.settings.split(','))))
