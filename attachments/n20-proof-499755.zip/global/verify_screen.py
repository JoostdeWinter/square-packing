"""Cold verification of the nearest-mark assignment screen at 4.99 or 5."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from itertools import combinations
from fractions import Fraction as F
from collections import Counter
import argparse,json,os,subprocess,sys,shutil,time
h=Path(__file__).resolve().parents[1];sys.path[:0]=[str(h/'proof498'),str(h/'base496'),str(h/'enumerator'),str(h/'advanced')]
from verify import orbits
from prereqs import marks,SPEC,checked_sources
from coverage import sweep
from central_replay import verify_movements
from branches import atomic
def build(d,jobs):
 d.mkdir(exist_ok=True,parents=True);u=d/'upstream';u.mkdir(exist_ok=True);checked_sources(u,h/'base496/upstream');sys.path.insert(0,str(u));os.chdir(u)
 from verify_arc_lower import build
 from deepbuild import build as pair
 from strongbuild import build as strong
 n=d/'native';n.mkdir(exist_ok=True);build(n);pair(n/'r.cc',n/'pair');strong(n/'pair.cpp',n/'strong')
 t=d/'enumerator';t.mkdir(exist_ok=True)
 for f in ['build.py','slices.inc','search.inc']:shutil.copy(h/'enumerator'/f,t/f)
 shutil.copy(n/'strong.cpp',t/'kernel.cpp');subprocess.run([sys.executable,t/'build.py'],check=True)
 a=d/'advanced';a.mkdir(exist_ok=True)
 for f in ['build.py','extra.inc','endpoint_chords.inc']:shutil.copy(h/'advanced'/f,a/f)
 subprocess.run([sys.executable,a/'build.py'],check=True)
def prepare(U,d,jobs):
 build(d,jobs);L=F(U,10**6);s=U//10000;spec=dict(SPEC,cap=str(L));pts=marks(spec);coords=[(int(x*10**6),int(y*10**6)) for x,y in pts]
 b=32 if s==500 else 48;tab=d/f'i{b}';moves=h/f'enumerator/marks{s}.txt';extra=h/'advanced'/('racks500.txt' if s==500 else 'racks499_3.txt')
 proofs={}
 if s==500:
  from endpoint import closed_init
  from endpoint_cover import prove
  q=prove(coords);assert q;proofs['primary_closed_charts']=q['interval_count'];proofs['event_polynomials']=q['event_polynomials'];closed_init(pts,b,L,tab)
 else:
  import check_stabs,nearest_rack,rack_lattice_input
  from verify_nearest_lower import certified_init
  from verify_rack_angle import check_rack
  for mod in (check_stabs,nearest_rack,rack_lattice_input):mod.marks=marks
  q=check_rack(spec);assert q['status']=='STRICT_STABBING';proofs['primary']=q;proofs['movements']=verify_movements(moves,coords,U,jobs);certified_init(spec,b,tab)
 lines=extra.read_text().splitlines();side,nr=map(int,lines[0].split());assert side==U and len(lines)==nr+1
 counts=[]
 for ln in lines[1:]:
  n,*v=map(int,ln.split());rack=list(zip(v[::2],v[1::2]));assert len(v)==2*n
  if s==500:
   from endpoint_cover import prove
   count=prove(rack)['interval_count']
  else:count=sweep(rack,U)
  assert count;counts.append(count)
 proofs['auxiliary_charts']=counts;pd=d/'profiles';pd.mkdir(exist_ok=True)
 masks=sorted((1<<22)-1-(1<<i)-(1<<j) for i,j in combinations(range(22),2));env=dict(os.environ,N20_EXTRA_RACKS=str(extra));rnd,cyc=(10,1) if s==500 else (12,2)
 def prof(m):
  rr=subprocess.check_output([d/'advanced/advanced','profile',tab,pd,moves,str(m),str(m),str(rnd),str(cyc)],text=True,env=env).split();assert rr==[str(m),'0']
 with ThreadPoolExecutor(jobs) as ex:list(ex.map(prof,masks))
 proofs.update(side_micro=U,grid=b,profile_rounds=rnd,profile_cycles=cyc,profiles=len(masks));atomic(d/'prepared.json',proofs);print('authenticated, coverage checked and cold profiles rebuilt',proofs,flush=True)
def screen(U,d,jobs,mode,reverse=False):
 s=U//10000;cfg=json.loads((d/'prepared.json').read_text());b=cfg['grid'];tab=d/f'i{b}';pd=d/'profiles';moves=h/f'enumerator/marks{s}.txt';extra=h/'advanced'/('racks500.txt' if s==500 else 'racks499_3.txt')
 enum=d/'advanced/advanced' if mode=='advanced' else d/'enumerator/enumerate';env=dict(os.environ,N20_EXTRA_RACKS=str(extra))
 orbs=orbits(U);assert len(orbs)==6787;folder=d/'case_replays';folder.mkdir(exist_ok=True);before=time.monotonic()
 rd,cy=(18,3) if s==500 else (12,2)
 def pair(case):
  a,bb=case;dest=folder/f'{a}_{bb}.json'
  if dest.exists():return a,bb,json.loads(dest.read_text())
  cmd=[enum,'match',tab,pd,moves,str(a),str(bb),str(5 if s==500 else 8),'1'];q=subprocess.run(cmd,text=True,capture_output=True,env=env,check=True)
  matches=[tuple(map(int,z.split())) for z in q.stdout.splitlines()];assert len(matches)==len(set(matches));survivors=[]
  for m in matches:
   assert len(m)==len(set(m))==20 and sum(1<<k for k in m)==bb
   res=subprocess.check_output([d/'advanced/advanced','check',tab,pd,moves,str(a),str(bb),str(rd),str(cy),'-2,-2,-2,-2'],text=True,input=' '.join(map(str,m))+'\n',env=env).split()
   if res[0]=='OPEN':assert len(res)==5;survivors.append(m)
   else:assert len(res)==2 and res[0]=='CLOSED' and int(res[1]) in (1,2,7,8,9)
  data={'enumerated':len(matches),'survivors':survivors};atomic(dest,data);return a,bb,data
 output={};stats=Counter()
 with ThreadPoolExecutor(jobs) as ex:
  for i,f in enumerate(as_completed([ex.submit(pair,w) for w in sorted(orbs,reverse=reverse)]),1):
   a,bb,z=f.result();stats['enumerated']+=z['enumerated'];stats['no_matching']+=not z['enumerated'];stats['surviving']+=len(z['survivors'])
   if z['survivors']:output[f'{a}_{bb}']=z['survivors']
   if i%400==0:print(i,len(orbs),dict(stats),'elapsed',int(time.monotonic()-before),flush=True)
 rec={'side_micro':U,'ordered_masks':sum(orbs.values()),'symmetry_classes':len(orbs),'matching_kernel':mode,'profile_initialization':cfg,'counts':stats,'open_mask_pairs':len(output)};atomic(d/'open_matchings.json',output);atomic(d/'screen_verified.json',rec);print('completed',rec,flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('U',type=int,choices=[4990000,5000000]);ap.add_argument('work',type=Path);ap.add_argument('--jobs',type=int,default=3);ap.add_argument('--mode',choices=['advanced','basic'],default='advanced');ap.add_argument('--prepare-only',action='store_true');ap.add_argument('--reverse',action='store_true');v=ap.parse_args();d=v.work.resolve()
 if not (d/'prepared.json').exists():prepare(v.U,d,v.jobs)
 if not v.prepare_only:screen(v.U,d,v.jobs,v.mode,v.reverse)
