"""Branch on which of twenty squares prevents insertion of a twenty-first."""
from pathlib import Path
from collections import Counter
from itertools import product
from tempfile import TemporaryDirectory
import json,os,sys,argparse,time
from branches import stamp,h,atomic
from exchange_matching import bounds,radius,axes,chart_widths,restrict,local_axes
from scale_coupled import calc,load_state,write_profiles,mix,hull
from verify_stronger import shifts
D=1000000
def candidates(U):
 # Each probe is an actual aligned unit square strictly inside the board.
 # Ranking and centering may use floating point. Admissibility is checked in integers.
 m=D//2+1;hi=U-m;v=set()
 for i in range(5):
  for step in (0,2500,-2500,10000,-10000,37500,-37500,100000,-100000,200000,-200000):
   v.add(min(hi,max(m,(2*i+1)*U//10+step)))
 return [(x,y,0) for x,y in product(sorted(v),repeat=2)]
def soft_area(p):
 if not p:return 0.
 return 1+abs(sum(x*Y-X*y for (x,y),(X,Y) in zip(p,p[1:]+p[:1])))/2e12
def ranked(st,U,banned=(),limit=15):
 import numpy as np
 P=candidates(U);M=len(P);pr=np.array([[a*x+b*y for a,b in axes] for x,y,d in P],dtype=np.int64)
 rad=np.array([radius(0,a,b) for a,b in axes],dtype=np.int64);lo=pr-rad;hi=pr+rad
 rating=np.zeros(M,dtype=float);degree=np.zeros(M,dtype=int);maximum=np.zeros(M,dtype=float)
 ws=chart_widths()
 for _,poses in st:
  qs=[(k,p,bounds(p)) for k,p in enumerate(poses) if p];tot=np.zeros(M);count=0;hits=np.zeros(M,dtype=bool)
  for k,p,bb in qs:
   exactlo=np.array([l-g for (l,u),g in zip(bb,ws[k])]);exacthi=np.array([u+g for (l,u),g in zip(bb,ws[k])])
   good=np.all((exactlo<=hi)&(exacthi>=lo),axis=1)
   # Estimate retained fraction of the original four projection intervals.
   cl=np.array([l for l,u in bb]);ch=np.array([u for l,u in bb])
   nlo=np.maximum(lo-np.array(ws[k]),cl);nhi=np.minimum(hi+np.array(ws[k]),ch)
   frac=np.maximum(0,np.minimum(1,(nhi-nlo+1)/(ch-cl+1)))
   ax,ww=local_axes(k);a2=np.array(ax,dtype=np.int64);pr2=np.array([(x,y) for x,y,g in P],dtype=np.int64)@a2.T
   rd=np.array([radius(0,a,b) for a,b in ax]);qv=bounds(p,ax);l2=np.array([x for x,y in qv]);h2=np.array([y for x,y in qv]);ll=np.maximum(pr2-rd-np.array(ww),l2);hh=np.minimum(pr2+rd+np.array(ww),h2)
   good&=np.all(hh>=ll,axis=1);ratio=np.maximum(0,np.minimum(1,(hh-ll+1)/(h2-l2+1)))
   cost=np.minimum(np.min(frac,axis=1),np.min(ratio,axis=1))*good;tot+=cost;hits|=good;count+=1
  assert count;tot/=count;rating+=tot;maximum=np.maximum(maximum,tot);degree+=hits
 ban=set(banned);order=sorted((j for j,p in enumerate(P) if p not in ban),key=lambda j:(bool(maximum[j]>.99999),rating[j]+.09*degree[j],maximum[j],j))
 top=[];seen=[]
 for j in order:
  p=P[j]
  if any(abs(x-p[0])+abs(y-p[1])<40000 for x,y,_ in seen):continue
  seen.append(p);top.append((p,float(rating[j]),int(degree[j])))
  if len(top)==limit:break
 return top
def alternatives(st,probe):
 ws=chart_widths();out=[];total=0
 for i,(seed,poses) in enumerate(st):
  rows=[restrict(p,[probe],w,k) if p else [] for k,(p,w) in enumerate(zip(poses,ws))]
  if not any(rows):continue
  if rows==poses:return None
  out.append((i,rows))
 return out
def search(U,k,m,o,sp,d=None):
 d=h/f'cold{U}' if d is None else d;depth,shortlist,fine,sub,pas,nr,ns,budget=sp;settings=(fine,sub,pas,nr,ns);shifts(d,U);stats=Counter();trace=[]
 with TemporaryDirectory() as td:
  td=Path(td);out=td/'state';profiles=td/'profiles'
  st=calc(U,k,m,o,d/'p64',out,settings,False,d)
  if st is None:return True,dict(initial=1),[]
  def visit(st,history,z):
   stats['nodes']+=1
   if stats['nodes']>budget:return False
   ls=ranked(st,U,history,shortlist);options=[]
   for probe,cost,degree in ls:
    assert D//2<min(probe[0],probe[1],U-probe[0],U-probe[1]) and probe[2]==0
    opts=alternatives(st,probe)
    if opts is None:continue
    if not opts:stats['uninsertable_claim_contradicted']+=1;return True
    price=sum(sum(soft_area(p) for p in ps)/sum(soft_area(p) for p in st[i][1]) for i,ps in opts)
    options.append((price+.1*len(opts),probe,opts))
   if not options:return False
   _,probe,branches=min(options,key=lambda option:option[0]);trace.append([z,probe,[a for a,r in branches]])
   # Try the branches with greatest retained area first.
   branches.sort(key=lambda a:-sum(soft_area(p) for p in a[1])/sum(soft_area(p) for p in st[a[0]][1]))
   for i,rows in branches:
    child=st.copy();child[i]=(st[i][0],rows);write_profiles(profiles,U,k,m,child,d)
    updated=calc(U,k,m,o,profiles,out,settings,False,d);stats['native_checks']+=1
    if updated is None:continue
    updated=mix(updated,child,U,U)
    if updated is None:continue
    for (seed,ps),(old,_) in zip(updated,child):seed[:]=hull(seed+old)
    write_profiles(profiles,U,k,m,updated,d)
    if calc(U,k,m,o,profiles,out,settings,True,d) is None:stats['frame_exclusions']+=1;continue
    if z>=depth or not visit(updated,history+[probe],z+1):return False
   return True
  ok=visit(st,[],1)
 return ok,dict(stats),trace
def main(v):
 from match_evidence import summarize
 from shared_angle_cases import outstanding
 d=h/f'cold{v.U}';root=v.root;out=d/('spare_roots' if root else 'spare_replays');out.mkdir(exist_ok=True);sp=list(map(int,v.settings.split(',')));assert len(sp)==8;start=time.monotonic()
 todo=[(k,m,o) for k,m in summarize([v.U])[v.U]['pending'] for o in ([[-2]*4] if root else outstanding(d,k,m)) if root or -2 not in o]
 if v.reverse:todo.reverse()
 for k,m,o in todo[:v.limit]:
  file=out/(stamp(k,m)+('' if root else '_'+','.join(map(str,o)))+'.json')
  if file.exists():
   r=json.loads(file.read_text())
   if r['closed'] or r['settings']==sp:continue
  ok,stats,trace=search(v.U,k,m,o,sp);atomic(file,{'closed':ok,'key':k,'matching':m,'owners':o,'side_micro':v.U,'settings':sp,'stats':stats,'tree':trace});print(k,o,ok,stats,trace[:2],int(time.monotonic()-start),flush=True)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('U',type=int);a.add_argument('--settings',default='2,8,2,3,3,14,16,14');a.add_argument('--root',action='store_true');a.add_argument('--reverse',action='store_true');a.add_argument('--limit',type=int,default=8);main(a.parse_args())
