"""Follow the same twenty centers through two boards, with conservative owner transfer."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
from itertools import product
from tempfile import TemporaryDirectory
import json,os,time,sys,subprocess,argparse,shutil
from branches import h,atomic,stamp
from match_evidence import summarize
from verify_stronger import shifts
sys.path.insert(0,str(h/'advanced'));from check_union import hull,contains,edges
def line(p):return ' '.join(map(str,[len(p),*(u for v in p for u in v)]))
def parse(line):
 n,*v=map(int,line.split());assert len(v)==2*n;return list(zip(v[::2],v[1::2]))
def load_state(path):
 rows=iter(path.read_text().splitlines());B,Z,U=map(int,next(rows).split());assert B==64 and Z==22
 data=[(parse(next(rows)),[parse(next(rows)) for k in range(B)]) for i in range(20)];assert next(rows,None) is None;return data
def facets(p):
 if len(p)<3:
  xs,ys=zip(*p);return [(1,0,max(xs)),(-1,0,-min(xs)),(0,1,max(ys)),(0,-1,-min(ys))]
 return [(v[1]-u[1],u[0]-v[0],(v[1]-u[1])*u[0]+(u[0]-v[0])*u[1]) for u,v in edges(p)]
def cut(p,a,b,c):
 if not p:return []
 z=[a*x+b*y-c for x,y in p]
 if max(z)<=0:return p
 if min(z)>0:return []
 out=[]
 for i,(v,w) in enumerate(edges(p)):
  x,y=z[i],z[(i+1)%len(p)]
  if x<=0:out.append(v)
  if (x<0<y) or (y<0<x):
   den=x-y;aa=w[0]*x-v[0]*y;bb=w[1]*x-v[1]*y;out.extend(product((aa//den,-((-aa)//den)),(bb//den,-((-bb)//den))))
 return hull(out)
def mix(low,other,U,H):
 # Both are written in board coordinates, U for low and H for other.
 def outer(p):return hull(w for x,y in p for w in product((U*x//H,-((-U*x)//H)),(U*y//H,-((-U*y)//H))))
 outputs=[]
 for (seed,base),(remote_seed,remote) in zip(low,other):
  if U<H:
   assert (H-U)*1000000>2*H
   near=lambda z:(2*U*z+H)//(2*H)
   seed=hull(seed+[(near(x),near(y)) for x,y in remote_seed])
  rows=[]
  for p,q in zip(base,remote):
   if not p or not q:rows.append([]);continue
   for a,b,c in facets(outer(q)):
    p=cut(p,a,b,c)
    if not p:break
   rows.append(p)
  if not any(rows):return None
  outputs.append((seed,rows))
 return outputs
def write_profiles(out,U,k,m,state,base=None):
 d=h/f'cold{U}' if base is None else base
 a,b=map(int,k.split('_'));R=[i for i in range(22) if a>>i&1];B=sorted(m);assert len(R)==len(B)==20
 rm=dict(zip(R,state));rot=lambda p:hull((y,U-x) for x,y in p)
 bm={j:(rot(seed),[rot(p) for p in rows]) for j,(seed,rows) in zip(m,state)}
 if a==b:
  mixed={}
  for g in R:
   s,r=rm[g];t,rr=bm[g]
   # A common input for both roles must be valid for either one.
   inner=hull([z for z in s if contains(t,z)]+[z for z in t if contains(s,z)])
   if not inner:
    # Original single-pattern mark belongs to either role in this common frame.
    mark=tuple(map(int,(d/'moves.txt').read_text().splitlines()[1+g].split()[:2]));inner=[mark]
   mixed[g]=inner,[hull(p+q) for p,q in zip(r,rr)]
  lists=[(a,R,mixed)]
 else:lists=[(a,R,rm),(b,B,bm)]
 out.mkdir(exist_ok=True)
 for mask,ids,mp in lists:
  lines=[f'{U} 64 22 {mask} 0',*(line(mp[j][0]) for j in ids),*(line(p) for j in ids for p in mp[j][1])]
  (out/str(mask)).write_text('\n'.join(lines)+'\n')
def calc(U,k,m,owners,folder,output,spec,frame,base=None):
 d=h/f'cold{U}' if base is None else base;fine,sub,passes,nr,ns=spec;a,b=k.split('_')
 env=dict(os.environ,N20_EXTRA_RACKS=str(d/f'racks{nr}.txt'),N20_DEPTH_TABLE=str(d/'depth.txt'),N20_SHIFT_FILE=str(d/f'shift{ns}.txt'),N20_FINE=str(fine),N20_FRAME_SUB=str(sub),N20_UNION_PASSES=str(passes));env.pop('N20_BAND',None)
 cmd=[d/'advanced/frame','frame' if frame else 'check',d/'i64',folder,d/'moves.txt',a,b,'28','3',','.join(map(str,owners)),'-',output]
 z=subprocess.check_output(cmd,input=' '.join(map(str,m))+'\n',text=True,env=env).split()
 if z[0].startswith('CLOSED'):return None
 if frame:assert z[0]=='OPEN_FRAME';return True
 assert z[0]=='OPEN';return load_state(output)
def test(U,H,k,m,o,settings,dirs=None):
 assert 0<U<H<=5000000;count,fine,sub,pas,nr,ns=settings;sp=(fine,sub,pas,nr,ns)
 if dirs is None:dirs={v:h/f'cold{v}' for v in (U,H)}
 for V in (U,H):shifts(dirs[V],V)
 hi_o=[-1 if w==-1 else -2 for w in o]
 with TemporaryDirectory() as td:
  t=Path(td);P=t/'tables';out=t/'state'
  lo=calc(U,k,m,o,dirs[U]/'p64',out,sp,False,dirs[U])
  if lo is None:return True,'initial_lower'
  hi=calc(H,k,m,hi_o,dirs[H]/'p64',out,sp,False,dirs[H])
  if hi is None:return True,'initial_upper'
  for i in range(count):
   hi=mix(hi,lo,H,U)
   if hi is None:return True,'empty_forward'
   write_profiles(P,H,k,m,hi,dirs[H])
   if i==count-1 and calc(H,k,m,hi_o,P,out,sp,True,dirs[H]) is None:return True,'upper_frame'
   hi=calc(H,k,m,hi_o,P,out,sp,False,dirs[H])
   if hi is None:return True,'upper_check'
   lo=mix(lo,hi,U,H)
   if lo is None:return True,'empty_backward'
   write_profiles(P,U,k,m,lo,dirs[U])
   if i==count-1 and calc(U,k,m,o,P,out,sp,True,dirs[U]) is None:return True,'lower_frame'
   lo=calc(U,k,m,o,P,out,sp,False,dirs[U])
   if lo is None:return True,'lower_check'
 return False,'budget'
def main(v):
 from shared_angle_cases import outstanding
 d=h/f'cold{v.U}';dest=d/('coupled_roots' if v.root else 'coupled_replays');dest.mkdir(exist_ok=True)
 settings=list(map(int,v.settings.split(',')));assert len(settings)==6
 R=summarize([v.U])[v.U];items=[]
 for k,m in R['pending']:
  opts=[[-2]*4] if v.root else outstanding(d,k,m)
  for o in opts:
   if not v.root and -2 in o:continue
   k0=stamp(k,m)+('' if v.root else '_'+','.join(map(str,o)));f=dest/(k0+'.json')
   if f.exists():
    z=json.loads(f.read_text())
    if z['closed'] or (z['settings']==settings and z['upper']==v.H):continue
   items.append((k,m,o,f))
 if v.reverse:items.reverse()
 if v.limit:items=items[:v.limit]
 print('begin',v.U,v.H,len(items),flush=True);cnt=Counter();t=time.monotonic()
 def one(arg):
  k,m,o,f=arg;closed,why=test(v.U,v.H,k,m,o,settings)
  z={'closed':closed,'method':'two_scale','upper':v.H,'side_micro':v.U,'settings':settings,'matching':m,'key':k,'owners':o,'outcome':why}
  if not f.exists() or not json.loads(f.read_text())['closed']:atomic(f,z)
  return z
 with ThreadPoolExecutor(v.jobs) as ex:
  for j in as_completed([ex.submit(one,it) for it in items]):
   z=j.result();cnt[z['outcome']]+=1;print(dict(cnt),z['key'],z['owners'],int(time.monotonic()-t),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('U',type=int);p.add_argument('H',type=int);p.add_argument('--jobs',type=int,default=2);p.add_argument('--root',action='store_true');p.add_argument('--reverse',action='store_true');p.add_argument('--limit',type=int);p.add_argument('--settings',default='2,3,5,7,14,16');main(p.parse_args())
