"""Recheck unresolved complete owner leaves by subdividing tile angles and clipping in each rational midpoint frame."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
import argparse,subprocess,sys,json,os,time
from branches import paths,atomic,h
def main(v):
 ps=paths(v.U,v.bins);src=h/f'trials/cap{v.U}_{v.source}';dest=h/f'trials/quota{v.U}_{v.tag}';dest.mkdir(exist_ok=True);t=time.monotonic()
 while not (h/'advanced/quota').exists():time.sleep(2)
 def one(job):
  z,o,key=job;out=dest/(key+'.json')
  if out.is_file():return json.loads(out.read_text())
  a,b=z['mask_pair'].split('_');env=dict(os.environ,N20_EXTRA_RACKS=str(ps['racks'](v.racks)),N20_DEPTH_TABLE=str(ps['dep']),N20_FINE=str(v.factor),N20_UNION_PASSES=str(v.passes),N20_QUOTA_DEPTH=str(v.depth),N20_QUOTA_BUDGET=str(v.budget))
  if v.shifts:env['N20_SHIFT_FILE']=str(h/f'trials/shifts{v.U}/s{v.shifts}.txt')
  rr=subprocess.run([h/'advanced/quota','quota',ps['tab'],ps['profiles'],ps['moves'],a,b,'30','3',','.join(map(str,o))],input=' '.join(map(str,z['matching']))+'\n',text=True,env=env,capture_output=True,check=True)
  rs=rr.stdout.split();assert rs[0] in ('CLOSED','CLOSED_QUOTA','OPEN_QUOTA')
  ans={'mask_pair':z['mask_pair'],'matching':z['matching'],'owners':o,'result':rs,'settings':[v.bins,v.racks,v.shifts,v.factor,v.depth,v.budget,v.passes]};atomic(out,ans);return ans
 seen=set();stats=Counter()
 while True:
  todo=[]
  for f in sorted(src.glob('*.json')):
   z=json.loads(f.read_text())
   for o in z['open_leaves']:
    key=f.stem+'_'+','.join(map(str,o))
    if v.retry:
     previous=h/f'trials/frame{v.U}_{v.retry}'/(key+'.json')
     if not previous.exists() or json.loads(previous.read_text())['result'][0]!='OPEN_FRAME':continue
    if key not in seen:todo.append((z,o,key));seen.add(key)
  with ThreadPoolExecutor(v.workers) as ex:
   for f in as_completed([ex.submit(one,k) for k in todo]):
    z=f.result();stats[z['result'][0]]+=1
    print(sum(stats.values()),dict(stats),z['mask_pair'],z['owners'],z['result'],int(time.monotonic()-t),flush=True)
  if not v.continuous or ((h/f'trials/cap{v.U}_{v.source}_receipt.json').exists() and not todo and not v.retry):break
  time.sleep(20)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('U',type=int);a.add_argument('--bins',default=64,type=int);a.add_argument('--source',default='ep1');a.add_argument('--tag',default='plain');a.add_argument('--sub',type=int,default=6);a.add_argument('--passes',type=int,default=5);a.add_argument('--racks',type=int,default=6);a.add_argument('--shifts',type=int,default=8);a.add_argument('--factor',type=int,default=4);a.add_argument('--workers',type=int,default=2);a.add_argument('--retry');a.add_argument('--depth',type=int,default=3);a.add_argument('--budget',type=int,default=30);a.add_argument('--continuous',action='store_true');main(a.parse_args())
