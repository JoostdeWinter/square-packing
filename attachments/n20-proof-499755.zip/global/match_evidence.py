"""Inventory cold exclusions at equal or larger sides, preserving full owners."""
from pathlib import Path
from collections import Counter
from functools import lru_cache
import json,sys,argparse
from branches import stamp,h
def read(p):return json.loads(p.read_text())
def source(folder):
 p=h/folder
 if not (p/'screen_verified.json').is_file():return None
 q=read(p/'screen_verified.json');vals=read(p/'open_matchings.json')
 data={(k,tuple(m)) for k,rows in vals.items() for m in rows};assert len(data)==q['counts']['surviving']
 return data
def available(U):
 folder=h/f'cold{U}';ans={};open_=Counter()
 for f in (folder/'matchings').glob('*.json'):
  z=read(f);k=z['mask_pair'],tuple(z['matching']);assert f.stem==stamp(*k)
  if not z['open_leaves']:ans[k]=('ownership',0);continue
  ok=True;used=[]
  for owner in z['open_leaves']:
   key=f.stem+'_'+','.join(map(str,owner))+'.json';proof=None
   for d in ('frame_replays','strong_replays','direct_replays','lattice_first','new_replays','multi_first','multi_strong'):
    b=folder/d/key
    if b.is_file() and read(b)['closed']:proof=d;break
   if not proof:ok=False;break
   used.append(proof)
  if ok:ans[k]=('full_refinements',len(used))
  else:open_[k]+=len(z['open_leaves'])
 for f in [*(folder/'root_frames').glob('*.json'),*(folder/'quick_frames').glob('*.json'),*(folder/'priority_roots').glob('*.json')]:
  z=read(f)
  if z['closed']:ans[z['key'],tuple(z['matching'])]=('root_frame',z['attempts'][-1][0])
 return ans,open_
def summarize(targets,highest=False):
 scr5=source('cold500_screen');scr49=source('cold499_screen');assert scr5 and scr49
 caps=sorted([int(p.name[4:]) for p in h.glob('cold[0-9]*') if p.name[4:].isdigit() and len(p.name[4:])==7],reverse=True)
 bank={u:available(u) for u in caps};out={}
 for U in targets:
  screen=scr49 if U<=4990000 else scr5;pending=[];proofs=[];counts=Counter()
  for k,m in sorted(screen):
   option=None
   if (k,m) not in scr5:option=(5000000,'assignment_screen',0)
   for u in sorted((v for v in caps if v>=U),key=(lambda v:-v) if highest else (lambda v:(v!=U,v))):
    hit=bank[u][0].get((k,m))
    if hit:option=(u,*hit);break
   if option:
    counts[option[1],option[0]]+=1;proofs.append({'key':k,'matching':m,'at':option[0],'method':option[1]})
   else:pending.append((k,m))
  if pending:
   from label_symmetry import image
   roots={(r['key'],tuple(r['matching'])):r for r in proofs};open_rows=[]
   for k,m in pending:
    options=[(g,roots[a]) for g in range(1,8) if (a:=image(k,m,g)) in roots]
    if not options:open_rows.append((k,m));continue
    g,w=max(options,key=lambda v:v[1]['at']);proofs.append({'key':k,'matching':m,'at':w['at'],'method':'symmetry','transform':g,'source':w});counts['symmetry',w['at']]+=1
   pending=open_rows
  out[U]={'target_micro':U,'source_screen':4990000 if U<=4990000 else 5000000,'total':len(screen),'covered':len(proofs),'remaining':len(pending),'per_method':[[k,v,n] for (k,v),n in sorted(counts.items())],'pending':pending,'proof_choices':proofs}
 return out
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('sides',nargs='*',type=int,default=[4990000,4995000,4997000,4997500,4998000,4998500,4999000,5000000]);p.add_argument('--save',type=Path);v=p.parse_args();s=summarize(v.sides)
 for n,z in s.items():print(n,z['covered'],z['remaining'],z['per_method'])
 if v.save:v.save.write_text(json.dumps(s))
