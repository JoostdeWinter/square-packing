from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
import argparse,subprocess,sys,json,os,gzip,hashlib,time
from branches import paths,stamp,atomic,h
def main():
 a=argparse.ArgumentParser();a.add_argument('U',type=int);a.add_argument('--source',default='ep1');a.add_argument('--bins',type=int,default=64);a.add_argument('--groups',type=int,default=4);a.add_argument('--factor',type=int,default=3);a.add_argument('--racks',type=int,default=14);a.add_argument('--time',type=int,default=8);a.add_argument('--workers',type=int,default=2);a.add_argument('--tag',default='d1');a.add_argument('--binary',default='smt');a.add_argument('--shifts',type=int,default=0);a.add_argument('--continuous',action='store_true');a.add_argument('--limit',type=int,default=0);v=a.parse_args()
 p=paths(v.U,v.bins);src=h/f'trials/cap{v.U}_{v.source}';dest=h/f'trials/smt{v.U}_{v.tag}';dest.mkdir(exist_ok=True);started=time.monotonic()
 while not (h/'advanced'/v.binary).exists():time.sleep(2)
 def one(job):
  z,o,key=job;out=dest/(key+'.json')
  if out.exists():return json.loads(out.read_text())
  name=dest/(key+'.smt2');a,b=z['mask_pair'].split('_');m=z['matching'];env=dict(os.environ,N20_FINE=str(v.factor),N20_EXTRA_RACKS=str(p['racks'](v.racks)),N20_DEPTH_TABLE=str(p['dep']),N20_SMT_GROUPS=str(v.groups))
  if v.shifts:env['N20_SHIFT_FILE']=str(h/f'trials/shifts{v.U}/s{v.shifts}.txt')
  cmd=[h/'advanced'/v.binary,'smt',p['tab'],p['profiles'],p['moves'],a,b,'32','3',','.join(map(str,o)),'-',name]
  r=subprocess.run(cmd,text=True,capture_output=True,input=' '.join(map(str,m))+'\n',check=True,env=env);ans=r.stdout.split()
  rec={'U':v.U,'mask_pair':z['mask_pair'],'matching':m,'owners':o,'settings':[v.bins,v.factor,v.groups,v.racks,v.time,v.shifts]}
  if ans[0]=='CLOSED':rec.update(status='geometry',reason=ans[1])
  else:
   assert ans==['EXPORTED'];data=name.read_bytes();result=subprocess.check_output([sys.executable,h/'advanced/z3_lra.py',name,str(v.time*1000)],text=True).strip();assert result in ('sat','unsat','unknown'),result
   rec.update(status=result,sha256=hashlib.sha256(data).hexdigest(),size=len(data),model_summary=data.decode().splitlines()[-2])
   if result=='unsat' or v.limit:
    with gzip.open(name.with_suffix('.smt2.gz'),'wb',compresslevel=4) as f:f.write(data)
   name.unlink()
  atomic(out,rec);return rec
 seen=set();cnt=Counter()
 while True:
  todo=[]
  for f in sorted(src.glob('*.json')):
   z=json.loads(f.read_text())
   for o in z['open_leaves']:
    key=f.stem+'_'+','.join(map(str,o))
    if key not in seen:todo.append((z,o,key));seen.add(key)
  if v.limit:todo=todo[:max(0,v.limit-sum(cnt.values()))]
  with ThreadPoolExecutor(v.workers) as ex:
   for f in as_completed([ex.submit(one,q) for q in todo]):
    r=f.result();cnt[r['status']]+=1
    print(sum(cnt.values()),dict(cnt),r['mask_pair'],r['owners'],int(time.monotonic()-started),flush=True)
  if not v.continuous or (v.limit and sum(cnt.values())>=v.limit):break
  if (h/f'trials/cap{v.U}_{v.source}_receipt.json').exists() and not todo:break
  time.sleep(18)
if __name__=='__main__':main()
