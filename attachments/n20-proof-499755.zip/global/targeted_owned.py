"""Prioritize all unresolved labels at a finite side for the standard ownership replay."""
from branches import h,stamp,work
from match_evidence import summarize
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
import argparse,json,time
def main(v):
 d=h/f'cold{v.u}'
 while not (d/'prepared.json').exists():time.sleep(10)
 n=json.loads((d/'prepared.json').read_text())['grid'];ps=dict(tab=d/f'i{n}',profiles=d/f'p{n}',moves=d/'moves.txt',dep=d/'depth.txt',exe=d/'advanced/deeper',racks=lambda j:d/f'racks{j}.txt',extra_counts=(6,14))
 out=d/'matchings';out.mkdir(exist_ok=True);t0=time.monotonic();stats=Counter()
 while True:
  q=summarize([v.u])[v.u];jobs=[(k,list(m)) for k,m in q['pending'] if not (out/(stamp(k,m)+'.json')).exists()]
  if not jobs:break
  jobs.sort(key=lambda t:stamp(*t).split('_')[-1]);jobs=jobs[:v.batch]
  with ThreadPoolExecutor(v.jobs) as pool:
   for fu in as_completed([pool.submit(work,v.u,n,k,m,'fast',ps,out) for k,m in jobs]):
    z=fu.result();stats['closed' if not z['open_leaves'] else 'needs_refinement']+=1;print(q['remaining'],dict(stats),int(time.monotonic()-t0),flush=True)
 print('complete',v.u,dict(stats),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('u',type=int);p.add_argument('--jobs',type=int,default=3);p.add_argument('--batch',type=int,default=15);main(p.parse_args())
