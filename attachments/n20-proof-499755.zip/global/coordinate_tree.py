"""Exhaustive center-coordinate and elementary-angle bisections for hard geometric leaves."""
from pathlib import Path
from tempfile import TemporaryDirectory
from collections import Counter
import os,sys,time,subprocess,json,argparse
from branches import h,stamp,atomic
from match_evidence import summarize
from shared_angle_cases import outstanding
from scale_coupled import load_state
from verify_stronger import shifts
def native(d,k,m,o,cuts,spec,return_state=False):
 mode,f,sub,pas,nr,ns=spec;a,b=k.split('_');env=dict(os.environ,N20_DEPTH_TABLE=str(d/'depth.txt'),N20_EXTRA_RACKS=str(d/f'racks{nr}.txt'),N20_SHIFT_FILE=str(d/f'shift{ns}.txt'),N20_FINE=str(f),N20_FRAME_SUB=str(sub),N20_UNION_PASSES=str(pas));env.pop('N20_BAND',None)
 assert mode in ('check','frame');codes='/'.join(','.join(map(str,t)) for t in cuts) or '-'
 with TemporaryDirectory() as td:
  output=Path(td)/'state';cmd=[d/'advanced/frame',mode,d/'i64',d/'p64',d/'moves.txt',a,b,'28','3',','.join(map(str,o)),codes]
  if return_state:cmd.append(output)
  q=subprocess.check_output(cmd,text=True,input=' '.join(map(str,m))+'\n',env=env).split();assert q[0] in ('CLOSED','CLOSED_FRAME','OPEN_FRAME','OPEN')
  return q,(load_state(output) if return_state and q[0]=='OPEN' else None)
def replay(d,k,m,o,tree):
 def rec(cuts,z):
  if z[0]=='check' or z[0]=='frame':
   return native(d,k,m,o,cuts,z)[0][0].startswith('CLOSED')
  assert len(z)==4 and z[0]=='split' and len(z[1])==3
  i,axis,t=z[1];assert type(i)==type(axis)==type(t)==int and 0<=i<20 and 0<=axis<=2
  if axis==2:assert 1<=t<64
  return all(rec(cuts+[[i,axis,sign,t]],child) for sign,child in zip([1,-1],z[2:]))
 return ['CLOSED_FRAME'] if rec([],tree) else ['OPEN_FRAME']
def options(state,U,style):
 out=[]
 for i,(_,poses) in enumerate(state):
  ks=[k for k,r in enumerate(poses) if r];assert len(ks)>0
  if 2<=len(ks):
   groups=[k for k in ks if k<32];other=[k for k in ks if k>=32]
   if groups and other:
    score=(abs(ks[-1]-ks[0])/64)*min(len(groups),len(other))/(len(ks)/2)
    out.append((score*(1.5 if style==1 else .25),[i,2,32]))
  points=[q for k in ks for q in poses[k]]
  for axis in (0,1):
   lo,hi=min(q[axis] for q in points),max(q[axis] for q in points)
   if hi-lo<3:continue
   mid=(lo+hi)//2;pos=(2*round((mid*10/U-1)/2)+1)*U//10
   t=pos if lo+(hi-lo)//3<=pos<=hi-(hi-lo)//3 and style!=2 else mid
   score=(hi-lo)/1000000
   out.append((score,[i,axis,t]))
 return sorted(out,key=lambda z:(-z[0],z[1]))
def discover(d,k,m,o,style,depth,budget):
 U=json.loads((d/'prepared.json').read_text())['U'];ct=Counter()
 quick=['check',1,1,1,14,16];mid=['frame',2,4,5,14,16];heavy=['frame',4,7,14,50,24]
 def rec(cuts,level):
  if ct['calls']>=budget:return None
  ct['calls']+=1;q,st=native(d,k,m,o,cuts,quick,True)
  if q[0].startswith('CLOSED'):ct['easy']+=1;return quick
  if level==0 or level>=2:
   q,_=native(d,k,m,o,cuts,mid)
   if q[0].startswith('CLOSED'):ct['frame']+=1;return mid
  if level==depth:
   q,_=native(d,k,m,o,cuts,heavy)
   if q[0].startswith('CLOSED'):ct['fine']+=1;return heavy
   ct['open']+=1;return None
  used={tuple((i,a,t)) for i,a,sg,t in cuts};opts=[v for rate,v in options(st,U,style) if tuple(v) not in used]
  if not opts:return None
  i,ax,t=opts[0];tree=['split',[i,ax,t]]
  for sig in [1,-1]:
   child=rec(cuts+[[i,ax,sig,t]],level+1)
   if child is None:return None
   tree.append(child)
  return tree
 return rec([],0),ct
def main(v):
 d=h/f'cold{v.u}';shifts(d,v.u);direct=d/'direct_replays';direct.mkdir(exist_ok=True);records=d/'coordinate_trees';records.mkdir(exist_ok=True)
 start=time.monotonic()
 for k,m in summarize([v.u])[v.u]['pending']:
  if v.key not in stamp(k,m):continue
  for o in outstanding(d,k,m):
   if -2 in o:continue
   name=stamp(k,m)+'_'+','.join(map(str,o));f=direct/(name+'.json')
   if f.is_file() and json.loads(f.read_text())['closed']:continue
   tr,ct=discover(d,k,m,o,v.style,v.depth,v.budget)
   print(k,o,dict(ct),'closed',tr is not None,int(time.monotonic()-start),flush=True)
   if tr is not None:atomic(f,{'key':k,'matching':m,'owners':o,'closed':True,'history':[[['coordinate_tree',tr],['CLOSED_FRAME','exhaustive_bisections']]]})
   atomic(records/(name+'_s'+str(v.style)+'.json'),{'tree':tr,'counts':ct})
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('u',type=int);p.add_argument('key');p.add_argument('--style',type=int,choices=[0,1,2],default=0);p.add_argument('--depth',type=int,default=5);p.add_argument('--budget',type=int,default=80);main(p.parse_args())
