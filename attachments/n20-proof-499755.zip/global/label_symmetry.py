"""Identify labelled matchings equivalent by genuine board isometries."""
from itertools import product
from functools import lru_cache
from collections import Counter
from branches import h,stamp
from match_evidence import summarize
import argparse,json
@lru_cache(maxsize=1)
def actions():
 D=5000000;red=tuple(tuple(map(int,l.split()[:2])) for l in (h/'proofs/cap5000000/moves.txt').read_text().splitlines()[1:]);blue=tuple((D-y,x) for x,y in red)
 assert len(red)==len(set(red))==22 and set(red)!=set(blue)
 result=[]
 for sw,rx,ry in product((0,1),repeat=3):
  def f(p):
   x,y=p
   if sw:x,y=y,x
   return (D-x if rx else x,D-y if ry else y)
  r=tuple(map(f,red));b=tuple(map(f,blue));swap=set(r)==set(blue)
  R,B=(blue,red) if swap else (red,blue)
  assert set(r)==set(R) and set(b)==set(B);result.append((swap,tuple(R.index(z) for z in r),tuple(B.index(z) for z in b)))
 return result
def image(k,m,g):
 a,b=map(int,k.split('_'));rs=[i for i in range(22) if a>>i&1];assert b==sum(1<<j for j in m);sw,R,B=actions()[g]
 edges=sorted((B[j],R[i]) if sw else (R[i],B[j]) for i,j in zip(rs,m));k2=f"{sum(1<<i for i,j in edges)}_{sum(1<<j for i,j in edges)}";return k2,tuple(j for i,j in edges)
def inspect(targets):
 for u,s in summarize(targets).items():
  ok={(r['key'],tuple(r['matching'])):r for r in s['proof_choices']};todo={};unaccounted=set();domains=set(ok)|set((k,tuple(m)) for k,m in s['pending'])
  for k,m in s['pending']:
   reaches=[(g,image(k,m,g)) for g in range(8)];choices=[(g,*ok[st].values()) for g,st in reaches if st in ok]
   if choices:todo[k,tuple(m)]=choices[0]
   else:unaccounted.add(min(st for g,st in reaches if st in domains))
  print(u,'pending',s['remaining'],'closes_by_symmetry',len(todo),'inequivalent_remaining',len(unaccounted),flush=True)
if __name__=='__main__':
 import sys
 inspect(list(map(int,sys.argv[1:])))
