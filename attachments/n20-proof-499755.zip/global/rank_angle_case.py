"""Independently rotating tiles with a small maximum tilt occupy twenty distinct rank cells."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from tempfile import TemporaryDirectory
import os,subprocess,sys,json,argparse,time,shutil
from branches import h,stamp,atomic
from maximum_tilt_case import orbit
from shared_angle_cases import outstanding
from verify_stronger import shifts
from coordinate_tree import native
from match_evidence import summarize
from split_tile_angle import compilation
D=1000000
def floor(q):return q.numerator//q.denominator
def ceil(q):return -floor(-q)
def ranks(U,t):
 assert 0<t and 2*t<=F(1,10)
 u=(1-t*t+2*t)/(1+t*t);d=u*(u-1)
 return [(ceil(D*(F(1,2)+j-j*d)),floor(U-D*(F(1,2)+(4-j)*(1-d)))) for j in range(5)]
def ceilout(q):return -floor(-q)
def strips(U,t):
 # Physical center coordinates are real, and the native profiles are in integer microunits.
 u=(1-t*t+2*t)/(1+t*t);d=u*(u-1);assert 2*t<=F(1,10)
 return [(floor(D*(F(1,2)+j-j*d)),ceilout(U-D*(F(1,2)+(4-j)*(1-d)))) for j in range(5)]
def assignments(st,U,t,cap=2000):
 hi=(1-t)/(1+t);bs=strips(U,t);domains=[]
 for seed,poses in st:
  cells=set()
  for k,poly in enumerate(poses):
   if not poly or not (F(k,64)<=t or F(k+1,64)>=hi):continue
   xl=min(x for x,y in poly);xh=max(x for x,y in poly);yl=min(y for x,y in poly);yh=max(y for x,y in poly)
   for x,y in product(range(5),repeat=2):
    if xl<=bs[x][1] and xh>=bs[x][0] and yl<=bs[y][1] and yh>=bs[y][0]:cells.add((x,y))
  domains.append(sorted(cells))
 order=sorted(range(20),key=lambda i:len(domains[i]));out=[];a=[None]*20
 def rec(j,used,rows,cols):
  if len(out)>cap:raise ValueError('too many rank assignments')
  if j==20:out.append(tuple(a));return
  i=order[j]
  for x,y in domains[i]:
   if (x,y) in used or rows[x]>=4 or cols[y]>=4:continue
   a[i]=(x,y);rows[x]+=1;cols[y]+=1;used.add((x,y));rec(j+1,used,rows,cols);used.remove((x,y));rows[x]-=1;cols[y]-=1
 rec(0,set(),[0]*5,[0]*5);return domains,out
def board_test(d,k,m,o,cuts,band,spec,single=None):
 U=json.loads((d/'prepared.json').read_text())['U'];shifts(d,U);a,b=k.split('_');fine,sub,passes,nr,ns=spec;env=dict(os.environ,N20_DEPTH_TABLE=str(d/'depth.txt'),N20_EXTRA_RACKS=str(d/f'racks{nr}.txt'),N20_SHIFT_FILE=str(d/f'shift{ns}.txt'),N20_FINE=str(fine),N20_FRAME_SUB=str(sub),N20_UNION_PASSES=str(passes));env.pop('N20_BAND',None)
 if single is not None:
  compilation(d);exe=d/'advanced/exception_band';hi=(1-band)/(1+band);vals=[band.numerator,band.denominator,hi.numerator,hi.denominator,((1<<20)-1)^(1<<single),0];env['N20_EXCEPTION_BAND']=' '.join(map(str,vals))
 else:
  folder=d/'advanced';exe=folder/'mirror_band'
  if not exe.is_file():
   donor=h/'cold5000000/advanced';builder=h/'advanced/build_mirror_band.py'
   if (donor/'mirror_band').is_file() and (donor/'separators.cpp').read_bytes()==(folder/'separators.cpp').read_bytes() and (donor/'build_mirror_band.py').read_bytes()==builder.read_bytes():
    shutil.copy2(donor/'mirror_band',exe)
   else:
    shutil.copy2(builder,folder/builder.name);subprocess.run([sys.executable,folder/builder.name],check=True)
  env['N20_BAND']=f'0 1 {band.numerator} {band.denominator}'
 cs='/'.join(','.join(map(str,c)) for c in cuts) or '-';res=subprocess.check_output([exe,'frame',d/'i64',d/'p64',d/'moves.txt',a,b,'28','3',','.join(map(str,o)),cs],text=True,input=' '.join(map(str,m))+'\n',env=env).split();assert res[0] in ('CLOSED','CLOSED_FRAME','OPEN_FRAME');return res
def replay(d,k,m,o,settings,verbose=False):
 t=F(settings[0]);sp=settings[1];U=json.loads((d/'prepared.json').read_text())['U'];q,st=native(d,k,m,o,[],['check',1,1,1,14,16],True)
 if q[0]=='CLOSED':return q
 domains,trees=assignments(st,U,t);bounds=strips(U,t)
 if verbose:print('rank options',len(trees),[len(x) for x in domains],flush=True)
 for n,cells in enumerate(trees):
  cuts=[]
  for i,p in enumerate(cells):
   for dim,j in enumerate(p):cuts.extend([[i,dim,-1,bounds[j][0]],[i,dim,1,bounds[j][1]]])
  result=board_test(d,k,m,o,cuts,t,sp)
  if verbose:print('small',n,result,flush=True)
  if result[0]=='OPEN_FRAME':return ['OPEN_FRAME','small',str(n)]
 reps=orbit(k,m,o) if o==[-1]*4 else range(20)
 for i in reps:
  result=board_test(d,k,m,o,[],t,sp,single=i)
  if verbose:print('large',i,result,flush=True)
  if result[0]=='OPEN_FRAME':return ['OPEN_FRAME','large',str(i)]
 return ['CLOSED_FRAME','small_rank_and_large_tilt',str(len(trees)),str(len(reps))]
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('u',type=int);p.add_argument('key');p.add_argument('t');p.add_argument('--settings',default='4,6,10,50,24');p.add_argument('--inspect',action='store_true');v=p.parse_args();d=h/f'cold{v.u}'
 for k,m in summarize([v.u])[v.u]['pending']:
  if v.key not in stamp(k,m):continue
  o=[-1]*4
  if o not in outstanding(d,k,m):continue
  if v.inspect:
   q,st=native(d,k,m,o,[],['check',1,1,1,14,16],True)
   for t0 in ['1/120','1/100','1/80','1/64','1/50','1/40','1/32','1/24','1/20']:
    t=F(t0);dom,cells=assignments(st,v.u,t);print(t,len(cells),[len(z) for z in dom],flush=True)
   continue
  conf=[v.t,list(map(int,v.settings.split(',')))];r=replay(d,k,m,o,conf,True);print(r,flush=True)
  if r[0]=='CLOSED_FRAME':atomic(d/'direct_replays'/(stamp(k,m)+'_-1,-1,-1,-1.json'),{'key':k,'matching':m,'owners':o,'closed':True,'history':[[['rank_angle_case',conf],r]]})
