"""Run geometry and ownership on labelled matchings from an equal or larger cap."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,wait,FIRST_COMPLETED
from collections import Counter
from dataclasses import dataclass
import argparse,hashlib,json,os,subprocess,time,tempfile
h=Path(__file__).resolve().parents[1];D=10**6
def atomic(p,obj):
 with tempfile.NamedTemporaryFile(mode='w',dir=p.parent,prefix='pending_',delete=False) as f:
  json.dump(obj,f,separators=(',',':'));f.write('\n');n=Path(f.name)
 n.replace(p)
def stamp(k,m):return k+'_'+hashlib.sha256(bytes(m)).hexdigest()[:16]
def paths(U,b):
 if U==5000000:return dict(tab=h/f'trials/b500/i{b}',profiles=h/f'trials/profiles500_endpointB{b}',moves=h/'advanced/endpoint_moves.txt',dep=h/'advanced/endpoint_depth128.txt',racks=lambda n:h/f'advanced/endpoint_racks_{n}.txt')
 if U==4990000:return dict(tab=h.parent/f'important_20261120/b499/i{b}',profiles=h/'trials/profiles499_g48',moves=h/'enumerator/marks499.txt',dep=h/'advanced/depth499.txt',racks=lambda n:h/f'advanced/racks499_{n}.txt')
 d=h/f'trials/cap{U}';return dict(tab=d/f'i{b}',profiles=d/f'p{b}',moves=d/'moves.txt',dep=d/'depth.txt',racks=lambda n:d/f'racks{n}.txt')
def work(U,b,k,m,setting,paths_,out):
 dest=out/(stamp(k,m)+'.json')
 if dest.exists():
  r=json.loads(dest.read_text());assert r['matching']==m;return r
 t=time.monotonic();a,bb=k.split('_');ps=paths_;exe=ps.get('exe',h/'advanced/deeper')
 vals=[int((ps['profiles']/i).open().readline().split()[-1]) for i in (a,bb)]
 counts=Counter();leaves=[];reasons=Counter()
 def calc(mode,owners,rounds,iterations,extra,fine=1,depth=0,budget=2,checks=2):
  env=dict(os.environ,N20_DEPTH_TABLE=str(ps['dep']),N20_EXTRA_RACKS=str(ps['racks'](extra)),N20_FINE=str(fine),N20_TREE_DEPTH=str(depth),N20_TREE_LIMIT=str(budget),N20_TREE_CHECKS=str(checks))
  rr=subprocess.run([exe,mode,ps['tab'],ps['profiles'],ps['moves'],a,bb,str(rounds),str(iterations),','.join(map(str,owners))],text=True,input=' '.join(map(str,m))+'\n',capture_output=True,env=env,check=True)
  z=rr.stdout.split();assert z and z[0] in ['CLOSED','OPEN','CLOSED_TREE','OPEN_TREE']
  counts[mode+'_calls']+=1
  if z[0].endswith('TREE'):counts['tree_nodes']+=int(z[1])
  if z[0]=='CLOSED':reasons[f'{mode}_{z[1]}']+=1
  return z
 def isclosed(z):return z[0].startswith('CLOSED')
 n1,n2=paths_.get('extra_counts',(3,5) if U==4990000 else (6,14))
 fast,deep=(4,6) if b==64 else (5,7)
 def solve():
  if any(vals):counts['single']=1;return
  root=(-2,)*4
  rr=calc('check',root,20,2,n1)
  if isclosed(rr):counts['root_simple']=1;return
  rr=calc('tree',root,24,2,n1,fast)
  if isclosed(rr):counts['root_refined']=1;return
  pending=[root]
  while pending:
   owner=pending.pop();counts['ownership_nodes']+=1
   r=calc('check',owner,24,3,n1)
   if isclosed(r):continue
   if -2 not in owner:
    rr=calc('tree',owner,28,3,n2,deep,0,2,2)
    if not isclosed(rr) and setting=='thorough':rr=calc('tree',owner,32,4,n2,deep,8,100,4)
    if not isclosed(rr):leaves.append(list(owner))
    continue
   domains=list(map(int,r[1:]));assert len(domains)==4 and all(0<=v<1<<20 for v in domains)
   pos=min((i for i in range(4) if owner[i]==-2),key=lambda v:(domains[v].bit_count(),v))
   for who in [-1]+[j for j in range(20) if domains[pos]>>j&1]:
    nxt=list(owner);nxt[pos]=who;pending.append(tuple(nxt))
 solve();res={'target_micro':U,'mask_pair':k,'matching':m,'profile_grid':b,'settings':setting,'counts':dict(counts),'reasons':dict(reasons),'open_leaves':leaves,'seconds':round(time.monotonic()-t,2)}
 atomic(dest,res);return res
def main():
 ap=argparse.ArgumentParser();ap.add_argument('U',type=int);ap.add_argument('--bins',type=int,default=64);ap.add_argument('--workers',type=int,default=2);ap.add_argument('--source',default='fixed500_e32root');ap.add_argument('--source-classes',type=int,default=4888);ap.add_argument('--tag',default='new');ap.add_argument('--settings',choices=['fast','thorough'],default='fast');ap.add_argument('--source-kind',choices=['fixed','enhanced'],default='fixed');ap.add_argument('--completion');v=ap.parse_args()
 ps=paths(v.U,v.bins);w=h/'trials';src=w/v.source;dst=w/f'cap{v.U}_{v.tag}';dst.mkdir(exist_ok=True)
 ready=ps['profiles']/('summary.json' if v.U==5000000 or v.U==4990000 else 'unused')
 if v.U not in (5000000,4990000):ready=ps['profiles'].parent/'prepared.json'
 while not ready.exists():time.sleep(20)
 seen=set();queues=[];jobs={};stats=Counter();last=0;done=set();matches=0;start=time.monotonic()
 with ThreadPoolExecutor(v.workers) as pool:
  while True:
   if not queues and (not jobs or time.monotonic()-last>10):
    day=[]
    for p in sorted(src.glob('*.json'),key=lambda p:(not p.stem.startswith('3932151_3932151'),p.stem)):
     if p.name in seen:continue
     z=json.loads(p.read_text());seen.add(p.name)
     if v.source_kind=='fixed':items=[(p.stem,t['matching']) for t in z['live']]
     else:items=[(z['mask_pair'],z['matching'])] if z['open_leaves'] else []
     for k,m in items:
      key=stamp(k,m);assert key not in done;done.add(key);day.append((k,m))
    matches+=len(day);queues.extend(reversed(day))
    last=time.monotonic()
   while queues and len(jobs)<v.workers:
    k,m=queues.pop();jobs[pool.submit(work,v.U,v.bins,k,m,v.settings,ps,dst)]=(k,m)
   if not jobs:
    complete=len(seen)>=v.source_classes if not v.completion else (w/v.completion).is_file()
    if complete and not queues:break
    time.sleep(10);continue
   completed,_=wait(jobs,timeout=8,return_when=FIRST_COMPLETED)
   for f in completed:
    k,m=jobs.pop(f);j=f.result();stats['checked']+=1;stats['unresolved_matchings']+=bool(j['open_leaves']);stats['unresolved_ownerships']+=len(j['open_leaves'])
    for key,c in j['counts'].items():stats[key]+=c
    if stats['checked']%25==0:print(k,stats['checked'],'of',matches,'from',len(seen),'cases','open',stats['unresolved_matchings'],stats['unresolved_ownerships'],'elapsed',int(time.monotonic()-start),flush=True)
 assert len(seen)==v.source_classes or v.completion
 print('complete',len(seen),dict(stats),flush=True);atomic(w/f'cap{v.U}_{v.tag}_receipt.json',{'source':v.source,'processed_source_files':len(seen),'received_matchings':matches,'stats':stats,'target_micro':v.U,'settings':v.settings})
if __name__=='__main__':main()
