"""Check a complete coverage ledger against the exact native results retained by the search."""
from pathlib import Path
from collections import Counter
from itertools import combinations
import argparse,sys,json,hashlib,gzip
from branches import h,stamp,atomic
from verify_choice import load,save
from label_symmetry import image
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def snap(path):return json.loads(path.read_text())
def gather(packet,dest):
 z=load(packet);screen=h/('cold500_screen' if z['base_screen']==5000000 else 'cold499_screen')
 stored={'base_screen':snap(screen/'screen_verified.json'),'base_labels':snap(screen/'open_matchings.json'),'geometry':{},'actions':{}}
 for r in z['choices']:
  row=r.get('transformed_proof',r);k,m,n=row['key'],row['matching'],row['side_micro'];folder=h/f'cold{n}';identity=stamp(k,m);key=f'{n}:{identity}:{row["method"]}'
  if key in stored['actions']:continue
  if str(n) not in stored['geometry']:
   cfg=snap(folder/'prepared.json');assert cfg['U']==n and cfg['fresh_profiles']==231
   for fn in ['moves.txt','racks6.txt','racks14.txt','racks50.txt']:assert digest(folder/fn)==digest(h/f'proofs/cap{n}'/fn)
   profiles=[]
   for i,j in combinations(range(22),2):
    ma=(1<<22)-1-(1<<i)-(1<<j);p=folder/'p64'/str(ma);first=list(map(int,p.open().readline().split()));assert first[:4]==[n,64,22,ma];profiles.append(first[-1])
   assert sum(bool(x) for x in profiles)==cfg['profiles_excluded']
   stored['geometry'][str(n)]={'initialization':cfg,'inputs_sha256':{fn:digest(folder/fn) for fn in ['moves.txt','racks6.txt','racks14.txt','racks50.txt']},'native_sha256':{fn:digest(folder/'advanced'/fn) for fn in ['deeper','frame','separators']}}
  action={};method=row['method'];fn=identity+'.json'
  if method in ('ownership','full_refinements'):action['ownership']=snap(folder/'matchings'/fn)
  if method=='root_frame':
   options=[]
   for sub in ('root_frames','quick_frames','priority_roots'):
    f=folder/sub/fn
    if f.exists() and snap(f)['closed']:options.append(snap(f))
   action['roots']=options
  if method=='full_refinements':
   action['terminals']={}
   for o,sp in row['terminals']:
    ls=[];s=','.join(map(str,o));filename=identity+'_'+s+'.json'
    for sub in ('frame_replays','direct_replays','strong_replays','lattice_first','new_replays','multi_first','multi_strong'):
     f=folder/sub/filename
     if f.exists() and snap(f)['closed']:ls.append(snap(f))
    assert ls;action['terminals'][s]=ls
  stored['actions'][key]=action
 save(dest,stored)
def check(packet,ledger):
 z=load(packet);bank=load(ledger);base=z['base_screen'];target=z['target_micro'];meta=bank['base_screen'];assert target<=base==meta['side_micro']==5000000 and meta['ordered_masks']==53361 and meta['symmetry_classes']==6787
 expected={(k,tuple(m)) for k,v in bank['base_labels'].items() for m in v}
 assert len(expected)==1142==z['covered_matchings']==len(z['choices']) and expected=={(r['key'],tuple(r['matching'])) for r in z['choices']}
 assert meta['counts']['enumerated']==15017 and meta['counts']['surviving']==1142
 ct=Counter();calls=Counter();active=set()
 for number,cfg in bank['geometry'].items():
  g=cfg['initialization'];assert int(number)==g['U'] and g['grid']==64 and g['fresh_profiles']==231
  for fn,sha in cfg['inputs_sha256'].items():assert digest(h/f'proofs/cap{number}'/fn)==sha
 def ok(w):return bool(w) and w[0] in ('CLOSED','CLOSED_TREE','CLOSED_FRAME','CLOSED_SEP','CLOSED_LATTICE','CLOSED_MULTILATTICE')
 def root_matches(row,r):
  if r['matching']!=row['matching'] or r['key']!=row['key'] or not r['closed']:return False
  if 'side_micro' in r and r['side_micro']!=row['side_micro']:return False
  nodes={tuple(q['owners']):q for q in r['nodes']};recipe={tuple(o):(m,p) for o,m,p in row['tree']}
  if set(nodes)!=set(recipe):return False
  visited=set()
  def visit(o):
   if o in visited or o not in nodes:return False
   visited.add(o);nd=nodes[o];spec,words=nd['calls'][-1];mode,param=recipe[o]
   if 'split' not in nd:return ok(words) and ((mode=='frame' and spec==param) or (mode=='check' and spec=='check'))
   part=nd['split'];q=nd['calls'][0]
   if mode!='branch' or part!=param or not 0<=part<4 or o[part]!=-2 or q[0]!='check' or q[1][0]!='OPEN' or len(q[1])!=5:return False
   bits=int(q[1][part+1]);assert 0<=bits<(1<<20)
   return all(visit(o[:part]+(i,)+o[part+1:]) for i in [-1]+[j for j in range(20) if bits>>j&1])
  return visit((-2,)*4) and visited==set(nodes)
 def terminal_matches(sp,rec,k,m,o):
  if not rec['closed'] or rec.get('matching',m)!=m or rec.get('owners',o)!=o or rec.get('key',rec.get('mask_pair',k))!=k:return False
  if 'history' in rec:
   conf,w=rec['history'][-1]
   return ok(w) and (sp==conf or sp==[rec.get('mode'),*conf])
  for y in rec['attempts']:
   st=[y['method'],y['fine'],y['subcharts'],y['passes'],y['racks'],0,y['split_depth'],y['budget']]
   if sp==st and ok(y.get('result',y.get('response',[]))):return True
  return False
 for outer in z['choices']:
  r=outer.get('transformed_proof',outer);k,m,n,method=r['key'],r['matching'],r['side_micro'],r['method'];assert target<=n<=base and str(n) in bank['geometry']
  if outer['method']=='symmetry':assert image(outer['key'],outer['matching'],outer['transform'])==(k,tuple(m)) and outer['side_micro']==n
  key=f'{n}:{stamp(k,m)}:{method}';active.add(key);ac=bank['actions'][key];ct[outer['method']]+=1
  if method=='root_frame':
   assert any(root_matches(r,h) for h in ac['roots']),(n,k);calls['geometric_tree_nodes']+=len(r['tree']);continue
  assert method in ('full_refinements','ownership')
  sr=ac['ownership'];assert sr['mask_pair']==k and sr['matching']==m and sr['target_micro']==n and sr['settings']=='fast' and sr['profile_grid']==64
  # This is the retained output of the ordinary cold ownership verifier.
  assert sum(sr['counts'].values())>0 and ('single' in sr['counts'] or sr['counts'].get('check_calls',0)>0)
  calls['ordinary_ownership_results']+=1;calls['ordinary_ownership_nodes']+=sr['counts'].get('ownership_nodes',0)
  if method=='ownership':assert not sr['open_leaves'];continue
  leaves={tuple(o) for o in sr['open_leaves']};assert len(leaves)==len(sr['open_leaves']) and leaves=={tuple(o) for o,sp in r['terminals']} and len(leaves)==len(r['terminals'])
  for o,sp in r['terminals']:
   xs=ac['terminals'][','.join(map(str,o))]
   assert any(terminal_matches(sp,x,k,m,o) for x in xs),(n,k,o,sp,xs[:1])
   calls['terminal_geometric_exclusions']+=1
 assert active==set(bank['actions'])
 return {'target_micro':target,'base_screen':base,'input_recipe_sha256':digest(packet),'execution_ledger_sha256':digest(ledger),'verified_matchings':len(expected),'ordered_masks':meta['ordered_masks'],'symmetry_classes':meta['symmetry_classes'],'method_counts':ct,'checks':calls,'pending':0,'verification':'crosscheck_of_recorded_exact_executions'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('recipe',type=Path);p.add_argument('ledger',type=Path);p.add_argument('--gather',action='store_true');p.add_argument('--out',type=Path);v=p.parse_args()
 if v.gather:gather(v.recipe,v.ledger)
 r=check(v.recipe,v.ledger);print(r,flush=True)
 if v.out:atomic(v.out,r)
