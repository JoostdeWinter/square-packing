"""Cold repro of angular-frame and separation refinements on all open leaves."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
import argparse,json,os,time,subprocess,sys,shutil,hashlib
from branches import h,atomic,stamp
def build(d):
 a=d/'advanced';assert (a/'direct.cpp').is_file()
 for tag in ['poses','union','frame','separators']:
  inc={'frame':'localframe'}.get(tag,tag)+'.inc';script='build_'+tag+'.py'
  for name in [inc,script]:shutil.copy(h/'advanced'/name,a/name)
  subprocess.run([sys.executable,a/script],check=True)
 atomic(a/'refinement_built.json',{'sha256':{f:hashlib.sha256((a/f).read_bytes()).hexdigest() for f in ['poses.cpp','union.cpp','frame.cpp','separators.cpp']}})
def run(d,workers):
 while not (d/'prepared.json').is_file():time.sleep(20)
 a=d/'advanced'
 if not (a/'refinement_built.json').is_file():build(d)
 while not (d/'status.json').is_file():time.sleep(15)
 base=json.loads((d/'status.json').read_text());U=base['side_micro'];b=base['initialization']['grid'];cache=d/'frame_replays';cache.mkdir(exist_ok=True)
 data=json.loads((d/'open.json').read_text());allcases=[(z['mask_pair'],z['matching'],o) for z in data for o in z['open_leaves']]
 assert len(allcases)==base['open_ownership_leaves'];pending=[];hist=Counter();start=time.monotonic()
 def each(job):
  key,m,o=job;dest=cache/(stamp(key,m)+'_'+','.join(map(str,o))+'.json')
  if dest.is_file():return json.loads(dest.read_text())
  A,B=key.split('_');steps=[]
  settings=[('frame',2,5,4,6,0,0),('frame',3,7,9,14,0,0),('frame',4,8,14,50,0,0),('sep',3,5,3,14,6,70),('sep',4,6,4,50,8,140)]
  for mode,f,sub,passes,nr,dep,limit in settings:
   env=dict(os.environ,N20_DEPTH_TABLE=str(d/'depth.txt'),N20_EXTRA_RACKS=str(d/f'racks{nr}.txt'),N20_FINE=str(f),N20_FRAME_SUB=str(sub),N20_UNION_PASSES=str(passes),N20_SEP_DEPTH=str(dep),N20_SEP_BUDGET=str(limit),N20_SEP_SPLIT='1')
   env.pop('N20_SHIFT_FILE',None);env.pop('N20_BAND',None)
   rr=subprocess.check_output([a/('frame' if mode=='frame' else 'separators'),mode,d/f'i{b}',d/f'p{b}',d/'moves.txt',A,B,'30','3',','.join(map(str,o))],text=True,env=env,input=' '.join(map(str,m))+'\n').split()
   assert rr and rr[0] in ('CLOSED','CLOSED_FRAME','OPEN_FRAME','CLOSED_SEP','OPEN_SEP')
   steps.append({'method':mode,'fine':f,'subcharts':sub,'passes':passes,'racks':nr,'split_depth':dep,'budget':limit,'result':rr})
   if rr[0].startswith('CLOSED'):break
  ans={'key':key,'matching':m,'owners':o,'attempts':steps,'closed':rr[0].startswith('CLOSED')};atomic(dest,ans);return ans
 with ThreadPoolExecutor(workers) as ex:
  for i,fut in enumerate(as_completed([ex.submit(each,z) for z in allcases]),1):
   ans=fut.result();hist[(ans['attempts'][-1]['result'][0],len(ans['attempts']))]+=1
   if not ans['closed']:pending.append(ans)
   print('replayed',i,'of',len(allcases),'open',len(pending),'elapsed',int(time.monotonic()-start),flush=True)
 result={'side_micro':U,'base':base,'refined_complete_ownerships':len(allcases),'unresolved_ownerships':len(pending),'outcome_counts':[[k[0],k[1],v] for k,v in sorted(hist.items())],'native_sources':json.loads((a/'refinement_built.json').read_text())}
 atomic(d/'combined_status.json',result);atomic(d/'combined_open.json',pending)
 if not pending:atomic(d/'verified_combined.json',result)
 print('finished',U,'with',len(pending),'unresolved of',len(allcases),flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('work',type=Path);ap.add_argument('--jobs',default=2,type=int);v=ap.parse_args();run(v.work.resolve(),v.jobs)
