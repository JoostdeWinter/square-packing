"""Generate or independently replay a per-matching, cross-side proof.

Every winning side is at least the target. Only nearest marks transfer.
Terminal ownerships are checked on the same board on which they were split.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
import os,sys,argparse,json,subprocess,time,gzip,fcntl,hashlib,tempfile
from branches import h,stamp,work,atomic
from match_evidence import summarize,read
from verify_cap import prepare
from verify_refinements import build as build_frames
from verify_stronger import shifts
def load(p):
 with (gzip.open(p,'rt') if p.suffix=='.gz' else p.open()) as f:return json.load(f)
def save(p,obj):
 if p.suffix=='.gz':
  with tempfile.NamedTemporaryFile(dir=p.parent,delete=False) as tmp:name=tmp.name
  try:
   with gzip.open(name,'wt',compresslevel=9) as f:json.dump(obj,f,separators=(',',':'))
   os.replace(name,p)
  finally:
   if os.path.exists(name):os.unlink(name)
 else:atomic(p,obj)
def pack(U,dest,prefer_owned=False,highest=False):
 s=summarize([U],highest=highest)[U]
 if s['remaining']:raise ValueError(str(s['remaining'])+' unmatched cases remain')
 if prefer_owned:
  # Each matching below has already passed the full pinned cold ownership tree.
  # Using its own choice avoids rerunning a second geometric method at the same leaf.
  proven={};cost=Counter()
  for folder in sorted(h.glob('cold[0-9]*')):
   if not folder.name[4:].isdigit() or len(folder.name)!=11:continue
   cap=int(folder.name[4:])
   if cap<U or cap>5000000 or not (folder/'prepared.json').is_file():continue
   for file in (folder/'matchings').glob('*.json'):
    r=read(file)
    if not r['open_leaves']:
     assert r['target_micro']==cap and file.stem==stamp(r['mask_pair'],r['matching'])
     proven[r['mask_pair'],tuple(r['matching'])]=cap
  for item in s['proof_choices']:
   cap=proven.get((item['key'],tuple(item['matching'])))
   if cap is not None and (not highest or cap>=item['at']):item['at']=cap;item['method']='ownership'
   cost[item['method'],item['at']]+=1
  s['per_method']=[[m,u,n] for (m,u),n in sorted(cost.items())]
 rows=[]
 for outer in s['proof_choices']:
  row=outer['source'] if outer['method']=='symmetry' else outer
  n=row['at'];d=h/f'cold{n}';k=row['key'];m=row['matching'];f=stamp(k,m)+'.json';method=row['method'];item={'key':k,'matching':m,'side_micro':n,'method':method}
  if method=='root_frame':
   paths=[d/fold/f for fold in ('root_frames','quick_frames','priority_roots')];z=next(read(path) for path in paths if path.is_file() and read(path)['closed']);tree=[]
   for r in z['nodes']:
    if 'split' in r:tree.append([r['owners'],'branch',r['split']])
    else:
     spec,zr=r['calls'][-1];assert zr[0].startswith('CLOSED');tree.append([r['owners'],'check' if spec=='check' else 'frame',spec])
   item['tree']=tree
  elif method=='full_refinements':
   raw=read(d/'matchings'/f);steps=[]
   for o in raw['open_leaves']:
    name=f[:-5]+'_'+','.join(map(str,o))+'.json';p=d/'frame_replays'/name;q=d/'strong_replays'/name
    if not q.exists() or not read(q)['closed']:
     alternate=d/'direct_replays'/name
     if alternate.is_file() and read(alternate)['closed']:q=alternate
    if p.is_file() and read(p)['closed']:
     a=read(p)['attempts'][-1];spec=[a['method'],a['fine'],a['subcharts'],a['passes'],a['racks'],0,a['split_depth'],a['budget']]
    elif q.is_file() and read(q)['closed']:
     z=read(q);spec,r=z['history'][-1];assert r[0].startswith('CLOSED')
    else:
     paths=[d/site/name for site in ('lattice_first','new_replays','multi_first','multi_strong')];f2=next(path for path in paths if path.is_file() and read(path)['closed'])
     z=read(f2);assert z['mode'] in ('lattice','multilattice');sp,r=z['history'][-1];assert r[0].startswith('CLOSED');spec=[z['mode'],*sp]
    steps.append([o,spec])
   item['terminals']=steps
  else:assert method in ('ownership','assignment_screen')
  if outer['method']=='symmetry':
   item={'method':'symmetry','side_micro':n,'key':outer['key'],'matching':outer['matching'],'transform':outer['transform'],'transformed_proof':item}
  rows.append(item)
 packet={'target_micro':U,'base_screen':s['source_screen'],'ordered_masks':53361,'symmetry_classes':6787,'covered_matchings':len(rows),'counts':s['per_method'],'choices':rows}
 save(dest,packet);print('saved',len(rows),s['per_method'],flush=True)
def verify(recipe,dest,jobs,existing,rerun=False,ancestor=None,rowcache=None):
 z=load(recipe);target=z['target_micro'];base=z['base_screen'];assert target<=base and base in (4990000,5000000);dest.mkdir(exist_ok=True,parents=True)
 lock=(dest/'recipe_replay.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX);sha=hashlib.sha256(recipe.read_bytes()).hexdigest()
 receipt=dest/'verified.json'
 if receipt.is_file():
  prior=read(receipt)
  if prior.get('recipe_sha256')==sha and (not rerun or prior.get('repeat_ownership_search')) and (existing or not prior.get('existing_cold_data')):
   print('already verified',target,flush=True);return
 rows=z['choices'];active=rows;ancsha=None;inherited=0
 if ancestor is not None:
  parent=load(ancestor);ancsha=hashlib.sha256(ancestor.read_bytes()).hexdigest()
  assert parent['base_screen']==base and parent['target_micro']<=target and all(r['side_micro']>=target for r in rows)
  lookup={(r['key'],tuple(r['matching'])):r for r in parent['choices']};assert len(lookup)==len(parent['choices'])
  active=[r for r in rows if lookup.get((r['key'],tuple(r['matching'])))!=r];inherited=len(rows)-len(active)
 sides=sorted({r['side_micro'] for r in active if r['method']!='assignment_screen'})
 screens={base}|{r['side_micro'] for r in active if r['method']=='assignment_screen'}
 screened={}
 for s in sorted(screens):
  if existing:d=h/('cold499_screen' if s==4990000 else 'cold500_screen')
  else:
   d=dest/f'screen{s}'
   if not (d/'screen_verified.json').is_file():subprocess.run([sys.executable,h/'global/verify_screen.py',str(s),d,'--jobs',str(jobs)],check=True)
  meta=read(d/'screen_verified.json');assert meta['side_micro']==s and meta['ordered_masks']==53361 and meta['symmetry_classes']==6787
  opts={(k,tuple(m)) for k,ms in read(d/'open_matchings.json').items() for m in ms};assert len(opts)==meta['counts']['surviving'];screened[s]=opts
 assert len(rows)==z['covered_matchings'] and len(rows)==len(screened[base]) and {(r['key'],tuple(r['matching'])) for r in rows}==screened[base]
 dirs={}
 geometry_rows=[r.get('transformed_proof',r) for r in active]
 for u in sides:
  assert target<=u<=5000000;d=h/f'cold{u}' if existing else dest/f'geometry{u}';dirs[u]=d
  if not (d/'prepared.json').exists():prepare(u,64,h/f'proofs/cap{u}',d,jobs)
  assert read(d/'prepared.json')['U']==u
  if not (d/'advanced/refinement_built.json').exists():build_frames(d)
  shifts(d,u)
  if any(r['side_micro']==u and any(s[0]=='octframe' for _,s in r.get('terminals',[])) for r in geometry_rows):
   from octagon_cases import build as build_oct
   build_oct(d)
  has_lattice=any(r['side_micro']==u and any(s[0]=='lattice' for _,s in r.get('terminals',[])) for r in geometry_rows)
  if has_lattice and not (d/'advanced/lattice_domains').is_file():
   from lattice_cases import build as build_lattice
   build_lattice(d)
  has_multi=any(r['side_micro']==u and any(s[0]=='multilattice' for _,s in r.get('terminals',[])) for r in geometry_rows)
  if has_multi and not (d/'advanced/multilattice').is_file():
   from lattice_cases import build as build_lattice
   build_lattice(d,True)
 def item(row):
  k,m,u,method=row['key'],row['matching'],row['side_micro'],row['method'];assert u>=target
  if method=='symmetry':
   from label_symmetry import image
   g=row['transform'];q=row['transformed_proof'];assert type(g) is int and 0<=g<8 and q['method']!='symmetry' and q['side_micro']==u
   assert image(k,m,g)==(q['key'],tuple(q['matching'])) and (q['key'],tuple(q['matching'])) in screened[base]
   _,nodes=item(q);return method,nodes
  if method=='assignment_screen':assert (k,tuple(m)) not in screened[u];return method,0
  d=dirs[u];b=read(d/'prepared.json')['grid'];aa,bb=k.split('_');cid=stamp(k,m)
  def call(mode,o,spec,rnds=('30','3')):
   f,sub,pas,nr,ns,depth,lim=spec
   env=dict(os.environ,N20_EXTRA_RACKS=str(d/f'racks{nr}.txt'),N20_DEPTH_TABLE=str(d/'depth.txt'),N20_FINE=str(f),N20_FRAME_SUB=str(sub),N20_UNION_PASSES=str(pas),N20_SEP_DEPTH=str(depth),N20_SEP_BUDGET=str(lim),N20_SEP_SPLIT='1')
   env.pop('N20_BAND',None);env.pop('N20_SHIFT_FILE',None)
   if ns:env['N20_SHIFT_FILE']=str(d/f'shift{ns}.txt')
   exe={'frame':'frame','sep':'separators','check':'deeper'}[mode]
   w=subprocess.check_output([d/'advanced'/exe,mode,d/f'i{b}',d/f'p{b}',d/'moves.txt',aa,bb,*rnds,','.join(map(str,o))],text=True,input=' '.join(map(str,m))+'\n',env=env).split()
   assert w and w[0] in ('CLOSED','OPEN','OPEN_FRAME','CLOSED_FRAME','CLOSED_SEP','OPEN_SEP');return w
  if method=='root_frame':
   tree={tuple(o):(m,s) for o,m,s in row['tree']};assert len(tree)==len(row['tree']);count=0
   def visit(o):
    nonlocal count
    count+=1;which,spec=tree[tuple(o)]
    if which in ('check','branch'):
     w=call('check',o,(1,1,1,6,8,0,0),('27','2'))
     if w[0]=='CLOSED':return
     assert which=='branch' and w[0]=='OPEN' and len(w)==5 and 0<=spec<4 and o[spec]==-2
     bits=int(w[spec+1]);assert 0<=bits<1<<20
     for child in [-1]+[i for i in range(20) if bits>>i&1]:
      a=list(o);a[spec]=child;visit(a)
    else:
     assert which=='frame'
     if spec[0]=='augmented_moves':
      from augment_last import run as run_augmented
      assert tuple(o)==(-2,)*4 and len(spec)==3
      w=run_augmented(u,spec[1],spec[2],d,(k,m))
     else:
      assert len(spec)==5;w=call('frame',o,(*spec,0,0),('27','2'))
     assert w[0].startswith('CLOSED'),(u,k,o)
   visit([-2]*4);return method,count
  assert method in ('ownership','full_refinements')
  cache=dest/f'matching_replay_{u}';cache.mkdir(exist_ok=True)
  ps=dict(tab=d/f'i{b}',moves=d/'moves.txt',profiles=d/f'p{b}',dep=d/'depth.txt',exe=d/'advanced/deeper',racks=lambda nr:d/f'racks{nr}.txt',extra_counts=(6,14))
  if existing and not rerun:rec=read(d/'matchings'/(cid+'.json'))
  else:rec=work(u,b,k,m,'fast',ps,cache)
  assert rec['target_micro']==u and rec['matching']==m and rec['mask_pair']==k
  if method=='ownership':assert not rec['open_leaves'];return method,0
  known={tuple(o):spec for o,spec in row['terminals']}
  for o in rec['open_leaves']:
   mode,*spec=known[tuple(o)]
   if mode=='rank_angle_case':
    from rank_angle_case import replay as check_rank_angles
    assert len(spec)==1;words=check_rank_angles(d,k,m,o,spec[0])
   elif mode=='maximum_tilt_case':
    from maximum_tilt_case import replay as check_maximum_tilt
    assert len(spec)==1;words=check_maximum_tilt(d,k,m,o,spec[0])
   elif mode=='coordinate_tree':
    from coordinate_tree import replay as replay_coordinates
    assert len(spec)==1;words=replay_coordinates(d,k,m,o,spec[0])
   elif mode=='anglebranches':
    from split_tile_angle import replay as replay_partitions
    assert len(spec)==1;words=replay_partitions(d,k,m,o,spec[0])
   elif mode=='rotation_group':
    from rotation_close import replay as rotate_replay
    assert len(spec)==1;words=rotate_replay(d,k,m,o,spec[0])
   elif mode=='octframe':
    from octagon_cases import call as oct_call
    words=oct_call(d,k,m,o,spec)
   elif mode in ('lattice','multilattice'):
    from lattice_cases import call as lattice_call
    words=lattice_call(d,k,m,o,spec,mode=='multilattice')
   else:words=call(mode,o,spec)
   assert words[0].startswith('CLOSED'),(u,k,o)
  return method,len(rec['open_leaves'])
 cached_count=0
 def checked(row):
  if rowcache is None:return (*item(row),False)
  content=json.dumps(row,sort_keys=True,separators=(',',':')).encode()
  physical=row.get('transformed_proof',row);u=physical['side_micro'];material=cap_sigs.get(u,b'')
  if physical['method'] in ('ownership','full_refinements'):
   rr=dirs[u]/'matchings'/(stamp(physical['key'],physical['matching'])+'.json');material+=hashlib.sha256(rr.read_bytes()).digest()
  key=hashlib.sha256(cache_sig+material+content).hexdigest();entry=rowcache/(key+'.json')
  if entry.exists():
   receipt=read(entry);assert receipt['key']==key and receipt['method']==row['method']
   return receipt['method'],receipt['nodes'],True
  for attempt in range(4):
   try:method,nodes=item(row);break
   except subprocess.CalledProcessError as exc:
    if exc.returncode!=-9 or attempt==3:raise
    time.sleep(3*(attempt+1))
  atomic(entry,{'key':key,'method':method,'nodes':nodes});return method,nodes,False
 if rowcache is not None:
  assert existing and not rerun
  rowcache.mkdir(exist_ok=True,parents=True)
  code=sorted([*h.joinpath('global').glob('*.py'),*h.joinpath('advanced').glob('*.inc'),*h.joinpath('advanced').glob('*.py'),*h.joinpath('base496').glob('*.py'),*h.joinpath('base496/upstream').glob('*.*')])
  seed=hashlib.sha256()
  for file in code:
   if file.is_file():seed.update(str(file.relative_to(h)).encode()+b'\0'+hashlib.sha256(file.read_bytes()).digest())
  seed.update(str(base).encode());cache_sig=seed.digest();cap_sigs={}
  for u,directory in dirs.items():
   ds=hashlib.sha256();files=[directory/name for name in ('prepared.json','moves.txt','racks6.txt','racks14.txt','racks50.txt','depth.txt','i64','advanced/deeper','advanced/frame','advanced/separators')]+sorted((directory/'p64').glob('[0-9]*'))
   for file in files:ds.update(hashlib.sha256(file.read_bytes()).digest())
   cap_sigs[u]=ds.digest()
 tally=Counter();nn=0;t=time.monotonic()
 with ThreadPoolExecutor(jobs) as ex:
  for j,fu in enumerate(as_completed([ex.submit(checked,r) for r in active]),1):
   a,b,was_cached=fu.result();cached_count+=int(was_cached);tally[a]+=1;nn+=b
   if j%100==0:print('passed',j,'of',len(rows),int(time.monotonic()-t),flush=True)
 if ancestor is not None:
  rec={'target_micro':target,'recipe_sha256':sha,'parent_sha256':ancsha,'base_screen':base,'covered_matchings':len(rows),'inherited':inherited,'newly_replayed':sum(tally.values()),'new_method_counts':tally,'replayed_frame_nodes_in_delta':nn,'verified_rows_read_from_shared_cache':cached_count}
  assert inherited+sum(tally.values())==len(rows);atomic(dest/'delta.json',rec);print('complete delta',rec,flush=True);return
 rec={'target_micro':target,'recipe_sha256':sha,'base_screen':base,'verified_matchings':len(rows),'method_counts':tally,'replayed_frame_terminals_or_tree_nodes':nn,'existing_cold_data':existing,'repeat_ownership_search':bool(rerun or not existing),'pending':0,'verified_rows_read_from_shared_cache':cached_count};atomic(dest/'verified.json',rec);print('complete',rec,flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();sub=p.add_subparsers(required=True,dest='op');a=sub.add_parser('assemble');a.add_argument('side',type=int);a.add_argument('output',type=Path);a.add_argument('--prefer-owned',action='store_true');a.add_argument('--highest',action='store_true');a=sub.add_parser('replay');a.add_argument('packet',type=Path);a.add_argument('work',type=Path);a.add_argument('--jobs',type=int,default=4);a.add_argument('--existing-cold-data',action='store_true');a.add_argument('--repeat-owned',action='store_true');a.add_argument('--row-cache',type=Path);v=p.parse_args()
 if v.op=='assemble':pack(v.side,v.output.resolve(),v.prefer_owned,v.highest)
 else:verify(v.packet.resolve(),v.work.resolve(),v.jobs,v.existing_cold_data,v.repeat_owned,rowcache=v.row_cache)
