"""Test unresolved ownerships using the normalized integer and half-integer sites."""
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
from branches import h,stamp,atomic
from pathlib import Path
import os,argparse,json,time,subprocess,shutil,sys
def build(d,multi=False):
 from verify_refinements import build as build_base
 ad=d/'advanced'
 if not (ad/'separators.cpp').is_file():build_base(d)
 script='build_multilattice.py' if multi else 'build_lattice_domains.py'
 for name in ([script,'lattice_domains.inc','multilattice.inc'] if multi else [script,'lattice_domains.inc']):shutil.copy2(h/'advanced'/name,ad/name)
 subprocess.run([sys.executable,ad/script],check=True)
def call(d,k,m,o,spec,multi=False):
 fine,sub,rounds,racks,shift,depth,budget=spec[:7];U=json.loads((d/'prepared.json').read_text())['U'];n=json.loads((d/'prepared.json').read_text())['grid'];a,b=k.split('_')
 env=dict(os.environ,N20_FINE=str(fine),N20_FRAME_SUB=str(sub),N20_UNION_PASSES=str(rounds),N20_EXTRA_RACKS=str(d/f'racks{racks}.txt'),N20_DEPTH_TABLE=str(d/'depth.txt'),N20_LATTICE_DEPTH=str(depth),N20_LATTICE_BUDGET=str(budget))
 env.pop('N20_BAND',None);env.pop('N20_SHIFT_FILE',None)
 if shift:env['N20_SHIFT_FILE']=str(d/f'shift{shift}.txt')
 mode='multilattice' if multi else 'lattice';exe='multilattice' if multi else 'lattice_domains'
 if multi:env['N20_LATTICES']=str(spec[7])
 rr=subprocess.check_output([d/'advanced'/exe,mode,d/f'i{n}',d/f'p{n}',d/'moves.txt',a,b,'30','3',','.join(map(str,o))],env=env,input=' '.join(map(str,m))+'\n',text=True).split()
 assert rr and rr[0] in ('CLOSED','CLOSED_LATTICE','OPEN_LATTICE','CLOSED_MULTILATTICE','OPEN_MULTILATTICE');return rr
def main(v):
 d=v.cold.resolve();from verify_stronger import shifts
 cfg=json.loads((d/'prepared.json').read_text());shifts(d,cfg['U'])
 exe='multilattice' if v.multi else 'lattice_domains'
 if not (d/'advanced'/exe).is_file():build(d,v.multi)
 out=d/(('multi_strong' if v.strong else 'multi_first') if v.multi else ('new_replays' if v.strong else 'lattice_first'));out.mkdir(exist_ok=True);seen=set();t=time.monotonic();tot=Counter()
 def one(job):
  k,m,o,key=job;f=out/(key+'.json')
  if f.is_file():return json.loads(f.read_text())
  steps=[]
  specs=[(2,4,3,6,8,2,12),(4,6,5,14,16,4,40)]
  if v.strong:specs=[(3,5,4,14,16,2,14),(5,8,6,50,24,6,100)]
  if v.multi:specs=[(2,4,3,6,8,1,8,3),(3,6,4,14,16,3,16,7)] if not v.strong else [(4,7,5,50,24,3,50,10),(6,8,8,50,24,6,100,15)]
  for sp in specs:
   ans=call(d,k,m,o,sp,v.multi);steps.append([sp,ans])
   if ans[0].startswith('CLOSED'):break
  z={'key':k,'matching':m,'owners':o,'closed':ans[0].startswith('CLOSED'),'mode':'multilattice' if v.multi else 'lattice','history':steps};atomic(f,z);return z
 while True:
  sealed=(d/'status.json').exists();todo=[]
  for f in sorted((d/'matchings').glob('*.json')):
   z=json.loads(f.read_text())
   for o in z['open_leaves']:
    key=f.stem+'_'+','.join(map(str,o))
    if key in seen:continue
    sources=['frame_replays','strong_replays']
    if v.strong:sources+=['lattice_first']
    if v.multi:sources+=['new_replays','lattice_first']
    if v.multi and v.strong:sources+=['multi_first']
    if any((d/name/(key+'.json')).is_file() and json.loads((d/name/(key+'.json')).read_text())['closed'] for name in sources):continue
    seen.add(key);todo.append((z['mask_pair'],z['matching'],o,key))
  with ThreadPoolExecutor(v.jobs) as pool:
   for f in as_completed([pool.submit(one,j) for j in todo]):
    z=f.result();tot['closed' if z['closed'] else 'open']+=1;print(dict(tot),z['key'],z['owners'],z['history'][-1],int(time.monotonic()-t),flush=True)
  if sealed and not todo:break
  time.sleep(16)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('cold',type=Path);p.add_argument('--strong',action='store_true');p.add_argument('--multi',action='store_true');p.add_argument('--jobs',type=int,default=2);main(p.parse_args())
