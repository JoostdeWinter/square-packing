"""Advance an audited lower bound by replaying every changed matching."""
from pathlib import Path
from collections import Counter
import hashlib,json,sys,argparse,tempfile
from verify_choice import load,save,pack,verify
from branches import atomic
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def prepare(U,parent,dest):
 z=load(parent);assert z['target_micro']<=U
 with tempfile.TemporaryDirectory() as t:
  proposal=Path(t)/'source.json.gz';pack(U,proposal,True);q=load(proposal)
 assert q['base_screen']==z['base_screen']
 prior={(r['key'],tuple(r['matching'])):r for r in z['choices']};counts=Counter();same=0
 for i,r in enumerate(q['choices']):
  k=r['key'],tuple(r['matching']);p=prior[k]
  if p['side_micro']>=U:q['choices'][i]=p;same+=1
  a=q['choices'][i];counts[a['method'],a['side_micro']]+=1
 q['counts']=[[m,u,n] for (m,u),n in sorted(counts.items())];q['construction']={'inherited_from_sha256':sha(parent),'reusable_matchings':same}
 save(dest,q);print('packed',U,same,'new',len(q['choices'])-same,flush=True)
def certify(packet,dest,parent,parent_receipt):
 q=load(packet);p=load(parent);a=json.loads(parent_receipt.read_text());delta=json.loads((dest/'delta.json').read_text());target=q['target_micro']
 assert a['pending']==0 and a['recipe_sha256']==sha(parent) and a['target_micro']==p['target_micro']
 assert a['verified_matchings']==len(p['choices'])==len(q['choices'])==delta['covered_matchings'] and a['base_screen']==q['base_screen']==p['base_screen']
 assert delta['recipe_sha256']==sha(packet) and delta['parent_sha256']==sha(parent) and delta['target_micro']==target
 old={(r['key'],tuple(r['matching'])):r for r in p['choices']};new={(r['key'],tuple(r['matching'])):r for r in q['choices']}
 assert set(old)==set(new) and all(r['side_micro']>=target for r in new.values())
 n=sum(old[k]==r for k,r in new.items());assert n==delta['inherited'] and n+delta['newly_replayed']==len(new)
 stats=Counter(r['method'] for r in new.values());z={'target_micro':target,'base_screen':q['base_screen'],'recipe_sha256':sha(packet),'verified_matchings':len(new),'method_counts':stats,'parent_recipe_sha256':sha(parent),'parent_target_micro':p['target_micro'],'inherited_previously_verified_matchings':n,'newly_replayed_matchings':delta['newly_replayed'],'newly_replayed_frame_nodes':delta['replayed_frame_nodes_in_delta'],'pending':0}
 atomic(dest/'verified.json',z);print('verified',z,flush=True)
if __name__=='__main__':
 a=argparse.ArgumentParser();ops=a.add_subparsers(required=True,dest='action');p=ops.add_parser('assemble');p.add_argument('side',type=int);p.add_argument('parent',type=Path);p.add_argument('packet',type=Path);p=ops.add_parser('delta');p.add_argument('parent',type=Path);p.add_argument('packet',type=Path);p.add_argument('out',type=Path);p.add_argument('--jobs',type=int,default=3);p.add_argument('--existing-cold-data',action='store_true');p=ops.add_parser('certify');p.add_argument('parent',type=Path);p.add_argument('parent_receipt',type=Path);p.add_argument('packet',type=Path);p.add_argument('out',type=Path);v=a.parse_args()
 if v.action=='assemble':prepare(v.side,v.parent.resolve(),v.packet.resolve())
 elif v.action=='delta':verify(v.packet.resolve(),v.out.resolve(),v.jobs,v.existing_cold_data,ancestor=v.parent.resolve())
 else:certify(v.packet.resolve(),v.out.resolve(),v.parent.resolve(),v.parent_receipt.resolve())
