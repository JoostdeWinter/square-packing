"""Exact continuous coverage by centered squares in the moving angle frame."""
from fractions import Fraction as F
from functools import lru_cache

UNIT=10**6
def direction(t):
    p,q=t.numerator,t.denominator
    return q*q-p*p,2*p*q,q*q+p*p

@lru_cache(maxsize=65536)
def frame(u,a,b):
    C,S,E=direction((a+b)/2)
    ends=[direction(a),direction(b)]
    agreements=[(C*x+S*y,abs(C*y-S*x),E*d) for x,y,d in ends]
    if any(dot<=cross for dot,cross,den in agreements):raise ValueError('Interval too wide')
    inflation=max(F(dot+cross,den) for dot,cross,den in agreements)
    # Certify a 0.99999-side core. Distances in the projection are in units of 1/(UNIT*E).
    half=F(99999*UNIT*E,200000)/inflation
    h=half.numerator//half.denominator
    edge=min(F(UNIT*(x+y),2*d) for x,y,d in ends)
    lo=edge.numerator//edge.denominator
    hi=u-lo
    board=tuple((C*x+S*y,C*y-S*x) for x,y in ((lo,lo),(hi,lo),(hi,hi),(lo,hi)))
    return C,S,h,board

def x_bounds(board,b,t):
    low=[]; high=[]
    for (x,y),(v,w) in zip(board,board[1:]+board[:1]):
        if b<=y<=t:low.append(x);high.append(x)
        if y==w:continue
        if y>w:x,y,v,w=v,w,x,y
        for lim in (b,t):
            if y<lim<w:
                vnum=x*(w-y)+(v-x)*(lim-y);den=w-y
                low.append(vnum//den);high.append(-((-vnum)//den))
    return min(low),max(high)

def covers(marks,u,a,b):
    c,s,h,board=frame(u,a,b)
    sites=sorted((c*x+s*y,c*y-s*x) for x,y in marks)
    ymin=min(y for x,y in board); ymax=max(y for x,y in board)
    ends=sorted({ymin,ymax}|{v for x,y in sites for v in (y-h,y+h) if ymin<v<ymax})
    for bottom,top in zip(ends,ends[1:]):
        left,right=x_bounds(board,bottom,top)
        for x,y in sites:
            if y-h<=bottom and top<=y+h:
                if x-h>left:break
                left=max(left,x+h)
                if left>=right:break
        if left<right:return False
    return True

def sweep(marks,side,maxdepth=15):
    """Return a binary proof tree's terminal count, or zero upon failure."""
    def recur(a,b,depth):
        if covers(marks,side,a,b):return 1
        if depth==maxdepth:return 0
        mid=(a+b)/2
        l=recur(a,mid,depth+1)
        if not l:return 0
        r=recur(mid,b,depth+1)
        return l+r if r else 0
    n=0
    for i in range(4):
        k=recur(F(i,4),F(i+1,4),0)
        if not k:return 0
        n+=k
    return n
