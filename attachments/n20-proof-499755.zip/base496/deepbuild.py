from pathlib import Path
import subprocess,sys
H=Path(__file__).resolve().parent
def build(src,out):
    base=Path(src).read_text().split('int main(int ac,char**av)');assert len(base)==2
    a=(H/'pairs.cpp.inc').read_text()
    def rep(x,y):
        nonlocal a
        assert a.count(x)==1,x
        a=a.replace(x,y)
    rep('const vector<int>& B){\n const int n=A.size();','const vector<int>& B,const vector<Mask>* allowed=nullptr,vector<Mask>* output=nullptr){\n const int n=A.size();')
    rep('bool exists=false;for(int k=0;', 'if(allowed && !((*allowed)[i]>>j&1))continue;bool exists=false;for(int k=0;')
    rep('a.init=move(ca);b.init=move(cb);return 0;','if(output)*output=gi;a.init=move(ca);b.init=move(cb);return 0;')
    rep('int main(int ac,char**av)',(H/'branchpair.inc').read_text()+'\nint main(int ac,char**av)')
    rep('if(mode!="pairs"||ac!=6)', 'if((mode!="pairs"||ac!=6)&&(mode!="deep"||ac!=11))')
    rep('if(!result&&cycles>0){','''if(!result&&mode=="deep"){
       Budget cfg{0,stoi(av[7]),stoi(av[6]),rounds,cycles,stoi(av[8]),stoi(av[9]),stoi(av[10])};
       if(cfg.depth<0||cfg.depth>40||cfg.limit<1||cfg.limit>100000||cfg.factor<1||cfg.factor>32||cfg.angle_cap>1024)throw runtime_error("depth settings");
       Engine x=base,y=base;x.init=A.c;x.seed=A.h;y.init=B.c;y.seed=B.h;
       vector<Mask> allowed(A.O.size(),(Mask(1)<<A.O.size())-1);
       result=search_pair(x,y,A.O,B.O,move(allowed),cfg,0);iter=cfg.nodes;
   } else if(!result&&cycles>0){''')
    cc=Path(out).with_suffix('.cpp');cc.write_text(base[0]+a)
    subprocess.run(['g++','-O3','-std=c++17',str(cc),'-o',str(out)],check=True)
if __name__=='__main__':build(sys.argv[1],sys.argv[2])
