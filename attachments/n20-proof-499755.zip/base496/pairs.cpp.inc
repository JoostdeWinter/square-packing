// Two descriptions of the same packing. A quarter-turn preserves a square's
// orientation modulo pi/2, so the exact same half-angle bin can be used.
using Mask=uint64_t;
vector<int> ids(Mask m,int z){vector<int> t;for(int i=0;i<z;i++)if(m>>i&1)t.push_back(i);return t;}
P rotate90(const P& p,I u){P q;for(auto z:p)q.push_back({u-z.y,z.x});return hull(move(q));}
void write_poly(ostream& o,const P& p){o<<p.size();for(auto z:p)o<<' '<<z.x<<' '<<z.y;o<<'\n';}
P read_poly(istream& s){int n;s>>n;if(!s||n<0||n>5000)throw runtime_error("profile polygon");P p(n);for(auto& z:p)s>>z.x>>z.y;return p;}
struct Profile {Mask m;vector<int> O;vector<P>h;vector<vector<P>> c;vector<Bound>bb;int B,Z;I U;bool shut=false;
 Profile(string file,bool rotate){ifstream f(file);int rc;f>>U>>B>>Z>>m>>rc;
 if(!f||B<4||B>256||Z>63)throw runtime_error("profile header "+file);O=ids(m,Z);shut=rc!=0;if(shut)return;
 h.resize(Z);bb.resize(Z);c.assign(B,vector<P>(Z));
 for(int i:O){h[i]=read_poly(f);if(rotate)h[i]=rotate90(h[i],U);}
 for(int i:O){P all;for(int k=0;k<B;k++){auto p=read_poly(f);if(rotate)p=rotate90(p,U);all.insert(all.end(),p.begin(),p.end());c[k][i]=move(p);}
 if(all.empty())throw runtime_error("empty live tile");bb[i]=bbox(all);}
 string tail;if(!f||f>>tail)throw runtime_error("profile tail");}
};
bool bmatch(Bound a,Bound b){return a.l<=b.r&&b.l<=a.r&&a.b<=b.t&&b.b<=a.t;}
bool aug(int i,const vector<Mask>& G,vector<int>& own,Mask& seen){Mask t=G[i]&~seen;while(t){int j=__builtin_ctzll(t);t&=t-1;if(seen>>j&1)continue;seen|=Mask(1)<<j;if(own[j]<0||aug(own[j],G,own,seen)){own[j]=i;return true;}}return false;}
bool perfect(const vector<Mask>& G,int skip=-1,int fixed=-1){int n=G.size();vector<int>own(n,-1);for(int i=0;i<n;i++)if(i!=skip){Mask seen=fixed<0?0:Mask(1)<<fixed;if(!aug(i,G,own,seen))return false;}return true;}
P intersect_outer(P p,const P&q){
 if(p.empty()||q.empty())return {};
 auto box=bbox(q);if(!bmatch(bbox(p),box))return {};
 vector<HP> fs=q.size()>=3?facets(q):vector<HP>{{1,0,box.r},{-1,0,-box.l},{0,1,box.t},{0,-1,-box.b}};
 for(auto h:fs){if(mx(p,h)<=h.k)continue;if(mn(p,h)>h.k)return {};p=cut(p,h);if(p.empty())return {};}return p;
}
void merge_vertices(P& dest,const P& q){dest.insert(dest.end(),q.begin(),q.end());}
int pair_filter(Engine& a,Engine& b,const vector<int>& A,const vector<int>& B){
 const int n=A.size();if(B.size()!=n||a.B!=b.B)throw runtime_error("matching shape");
 vector<Mask> graph(n);vector<vector<vector<P>>> pieces(n,vector<vector<P>>(n));
 vector<vector<Bound>> ba(a.B,vector<Bound>(n)),bb(a.B,vector<Bound>(n));
 for(int k=0;k<a.B;k++)for(int i=0;i<n;i++){if(!a.init[k][A[i]].empty())ba[k][i]=bbox(a.init[k][A[i]]);if(!b.init[k][B[i]].empty())bb[k][i]=bbox(b.init[k][B[i]]);}
 for(int i=0;i<n;i++)for(int j=0;j<n;j++){
   bool exists=false;for(int k=0;k<a.B;k++){
     auto& u=a.init[k][A[i]];auto& v=b.init[k][B[j]];
     if(u.empty()||v.empty()||!bmatch(ba[k][i],bb[k][j]))continue;
     auto p=intersect_outer(u,v);if(p.empty())continue;
     for(int other=0;other<2&&!p.empty();other++){const P& inner=other?a.seed[A[i]]:b.seed[B[j]];
       for(auto ax:a.rows[k].axes){if(inner.empty())continue;ax.k+=mn(inner,ax);if(mx(p,ax)>ax.k)p=cut(p,ax);if(p.empty())break;}}
     if(p.empty())continue;
     if(!exists){pieces[i][j].resize(a.B);exists=true;}pieces[i][j][k]=move(p);
   }
   if(exists)graph[i]|=Mask(1)<<j;
 }
 if(!perfect(graph))return 1;
 vector<vector<P>> ca(a.B,vector<P>(a.Z)),cb(a.B,vector<P>(b.Z));
 vector<Mask> gi(n),gj(n);
 for(int i=0;i<n;i++){Mask t=graph[i];while(t){int j=__builtin_ctzll(t);t&=t-1;if(!perfect(graph,i,j))continue;
     gi[i]|=Mask(1)<<j;gj[j]|=Mask(1)<<i;
     for(int k=0;k<a.B;k++){merge_vertices(ca[k][A[i]],pieces[i][j][k]);merge_vertices(cb[k][B[j]],pieces[i][j][k]);}
 }}
 for(int i=0;i<n;i++){
   if(__builtin_popcountll(gi[i])==1){int j=__builtin_ctzll(gi[i]);merge_vertices(a.seed[A[i]],b.seed[B[j]]);a.seed[A[i]]=hull(move(a.seed[A[i]]));}
   if(__builtin_popcountll(gj[i])==1){int j=__builtin_ctzll(gj[i]);merge_vertices(b.seed[B[i]],a.seed[A[j]]);b.seed[B[i]]=hull(move(b.seed[B[i]]));}
   for(int k=0;k<a.B;k++){ca[k][A[i]]=hull(move(ca[k][A[i]]));cb[k][B[i]]=hull(move(cb[k][B[i]]));}
 }
 a.init=move(ca);b.init=move(cb);return 0;
}
int main(int ac,char**av){try{
 if(ac<3)throw runtime_error("args");string mode=av[1];Engine base(av[2]);restr.clear();
 if(mode=="profile"){
   if(ac!=5)throw runtime_error("profile arguments");int rounds=stoi(av[3]);if(rounds<1||rounds>1000)throw runtime_error("rounds");string dir=av[4];Mask m;
   while(cin>>m){auto O=ids(m,base.Z);if(O.empty())throw runtime_error("empty mask");Engine e=base;int where,it;int rc=e.run(O,rounds,where,it);
      string fn=dir+"/"+to_string(m);ofstream f(fn);f<<e.U<<" "<<e.B<<" "<<e.Z<<" "<<m<<" "<<rc<<"\n";
      if(!rc){for(int i:O)write_poly(f,e.seed[i]);for(int i:O)for(int k=0;k<e.B;k++)write_poly(f,e.init[k][i]);}
      cout<<m<<" "<<rc<<endl;
   } return 0;
 }
 if(mode!="pairs"||ac!=6)throw runtime_error("pairs arguments");
 string dir=av[3];int cycles=stoi(av[4]),rounds=stoi(av[5]);
 if(cycles<0||cycles>50||rounds<1||rounds>1000)throw runtime_error("iterations");
 map<Mask,Profile> pa,pb;
 auto get=[&](auto& memo,Mask m,bool rot)->Profile&{auto it=memo.find(m);if(it==memo.end())it=memo.emplace(m,Profile(dir+"/"+to_string(m),rot)).first;return it->second;};
 string line;
 while(getline(cin,line)){if(line.empty())continue;istringstream ins(line);Mask ma,mb;ins>>ma>>mb;if(!ins)throw runtime_error("pair masks");
   auto&A=get(pa,ma,false);auto&B=get(pb,mb,true);int result=0,iter=0;
   if(A.U!=base.U||B.U!=base.U||A.B!=base.B||B.B!=base.B||A.m!=ma||B.m!=mb)throw runtime_error("profile mismatch");
   if(A.shut||B.shut)result=1;
   if(!result){vector<Mask> g(A.O.size());for(int i=0;i<(int)A.O.size();i++)for(int j=0;j<(int)B.O.size();j++)if(bmatch(A.bb[A.O[i]],B.bb[B.O[j]]))g[i]|=Mask(1)<<j;
      if(!perfect(g))result=2;}
   if(!result&&cycles>0){Engine x=base,y=base;x.init=A.c;x.seed=A.h;y.init=B.c;y.seed=B.h;int w,t;
      for(iter=1;iter<=cycles;iter++){
         if(pair_filter(x,y,A.O,B.O)){result=3;break;}
         if(x.run(A.O,rounds,w,t)||y.run(B.O,rounds,w,t)){result=4;break;}
      }}
   cout<<ma<<" "<<mb<<" "<<result<<" "<<iter<<endl;
 }
 }catch(exception&e){cerr<<e.what()<<endl;return 2;}}
