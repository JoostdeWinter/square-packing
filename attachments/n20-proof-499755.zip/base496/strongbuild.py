from pathlib import Path
import subprocess,sys
H=Path(__file__).resolve().parent
def build(deep_source,out):
    a=Path(deep_source).read_text()
    def rep(k,v):
        nonlocal a
        assert a.count(k)==1,k
        a=a.replace(k,v)
    k='int pair_filter(Engine& a';rep(k,(H/'conflicts.inc').read_text()+'\n'+k)
    k='if(!perfect(graph))return 1;';rep(k,k+'\n vector<vector<P>> edge_shapes;conflict_filter(a,b,A,B,pieces,graph,edge_shapes);if(!perfect(graph))return 1;')
    k='for(int i=0;i<n;i++){\n   if(__builtin_popcountll(gi[i])'
    rep(k,'''for(int v=0;v<n;v++){vector<const P*> lhs,rhs;
       for(int w=0;w<n;w++){if(gi[v]>>w&1)lhs.push_back(&edge_shapes[v][w]);if(gj[v]>>w&1)rhs.push_back(&edge_shapes[w][v]);}
       if(lhs.empty()||rhs.empty())throw runtime_error("empty alternatives");
       guaranteed_intersection(a.seed[A[v]],lhs,a.U);guaranteed_intersection(b.seed[B[v]],rhs,b.U);
    }
 '''+k)
    cc=Path(out).with_suffix('.cpp');cc.write_text(a)
    subprocess.run(['g++','-O3','-std=c++17',str(cc),'-o',str(out)],check=True)
if __name__=='__main__':build(sys.argv[1],sys.argv[2])
