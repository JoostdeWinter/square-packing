struct Budget{int nodes,limit,depth,rounds,cycles,level_fine,factor,angle_cap;};
int search_pair(Engine &x,Engine &y,const vector<int>&A,const vector<int>&B,vector<Mask> allowed,Budget& cfg,int depth) {
    if(++cfg.nodes>cfg.limit)return 0;
    int w,t;vector<Mask> live;bool first=true;
    for(int it=0;it<cfg.cycles;it++) {
        if(pair_filter(x,y,A,B,&allowed,&live))return 3;
        allowed=live;
        if(it==0 && depth==cfg.level_fine && cfg.factor>=2){
            bool fx=fine(x,A,cfg.factor,cfg.angle_cap),fy=fine(y,B,cfg.factor,cfg.angle_cap);
            if(fx!=fy || x.B!=y.B)throw runtime_error("joint angle refinement mismatch");
            for(int k=0;k<x.B;k++)if(x.rows[k].ki!=y.rows[k].ki||x.rows[k].gi!=y.rows[k].gi)throw runtime_error("joint angle index");
        }
        if(x.run(A,cfg.rounds,w,t)||y.run(B,cfg.rounds,w,t))return 4;
    }
    if(depth>=cfg.depth||cfg.nodes>=cfg.limit)return 0;
    if(pair_filter(x,y,A,B,&allowed,&live))return 3;
    int row=-1;double best=0.;int n=A.size();
    for(int i=0;i<n;i++) {
        int k=__builtin_popcountll(live[i]);if(k<2)continue;
        double rank=1./(k-.8);
        if(rank>best){best=rank;row=i;}
    }
    if(row>=0){
        Mask opts=live[row];
        while(opts){
           int j=__builtin_ctzll(opts);opts&=opts-1;
           auto subset=live;subset[row]=Mask(1)<<j;
           auto a=x,b=y;
           if(!search_pair(a,b,A,B,move(subset),cfg,depth+1))return 0;
        }
        return 5;
    }
    I width=-1,mid=0;int axis=-1,who=-1;
    for(int i:A){P pts;for(int k=0;k<x.B;k++)merge_vertices(pts,x.init[k][i]);if(pts.empty())return 3;
        auto z=bbox(pts);
        if(z.r-z.l>width){width=z.r-z.l;mid=(z.r+z.l)/2;axis=0;who=i;}
        if(z.t-z.b>width){width=z.t-z.b;mid=(z.t+z.b)/2;axis=1;who=i;}
    }
    if(width<16)return 0;
    for(int s:{-1,1}){
       auto a=x,b=y;HP h{axis==0?s:0,axis==1?s:0,s*mid};
       for(int k=0;k<a.B;k++)if(!a.init[k][who].empty()&&mx(a.init[k][who],h)>h.k)a.init[k][who]=cut(a.init[k][who],h);
       if(!search_pair(a,b,A,B,live,cfg,depth+1))return 0;
    }
    return 6;
}
