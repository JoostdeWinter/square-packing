// Every tile is convex. Its two matched interior marks and every point
// certified from their common centre domain lie strictly inside that tile.
using EdgeDomains=vector<vector<vector<P>>>;
void conflict_filter(Engine& a,Engine& b,const vector<int>& A,const vector<int>& B,
                     const EdgeDomains& pieces,vector<Mask>& graph,vector<vector<P>>& inner) {
    int n=A.size();inner.assign(n,vector<P>(n));vector<vector<Bound>> boxes(n,vector<Bound>(n));
    for(int i=0;i<n;i++){
        Mask available=graph[i];
        while(available){int j=__builtin_ctzll(available);available&=available-1;
            auto &area=inner[i][j];area=a.seed[A[i]];merge_vertices(area,b.seed[B[j]]);
            vector<HP> common;
            for(int k=0;k<a.B;k++)if(!pieces[i][j][k].empty()){
                for(auto h:a.rows[k].fac){h.k+=mn(pieces[i][j][k],h);common.push_back(h);}
            }
            if(common.empty())throw runtime_error("empty matching edge");
            merge_vertices(area,safe(common,a.U));area=hull(move(area));if(area.empty())throw runtime_error("no primary seed");
            boxes[i][j]=bbox(area);
            for(int v=0;v<n;v++){
                if((v!=i && meets(area,a.seed[A[v]])) || (v!=j && meets(area,b.seed[B[v]]))){graph[i]&=~(Mask(1)<<j);break;}
            }
        }
    }
    if(!perfect(graph))return;
    // For each fixed matching edge, every other tile must retain a distinct
    // feasible partner whose certified interior polygon avoids the fixed one.
    for(int i=0;i<n;i++){
        Mask available=graph[i];
        while(available){int j=__builtin_ctzll(available);available&=available-1;
            auto compatible=graph;
            for(int v=0;v<n;v++)if(v!=i){
                Mask w=compatible[v]&~(Mask(1)<<j);
                while(w){int l=__builtin_ctzll(w);w&=w-1;
                    if(bmatch(boxes[i][j],boxes[v][l]) && meets(inner[i][j],inner[v][l]))
                        compatible[v]&=~(Mask(1)<<l);
                }
            }
            if(!perfect(compatible,i,j))graph[i]&=~(Mask(1)<<j);
        }
    }
}
void guaranteed_intersection(P& h,const vector<const P*>& options,I cap) {
    if(options.size()==1){merge_vertices(h,*options.front());h=hull(move(h));return;}
    vector<HP> all;
    for(const P* p:options){if(p->size()<3)return;auto f=facets(*p);all.insert(all.end(),f.begin(),f.end());}
    if(!all.empty()){merge_vertices(h,safe(all,cap));h=hull(move(h));}
}
