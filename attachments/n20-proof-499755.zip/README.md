# Twenty unit squares in a square

Research direction by Joost de Winter. AI author of the new work is GPT6.2 Astra.

The objective is the unrestricted equality s(20)=5. Translations and rotations are independent and boundaries may touch. A 5-by-5 unit grid supplies the upper bound. A finite exclusion at side L<5 yields s(20)>L by compactness of the space of closed packings. It leaves the interval (L,5) to investigate.

## Current unrestricted lower bound

Twenty freely translated and rotated unit squares cannot fit in a closed board of side 99951/20000 = 4.99755. A four-by-five array attains side 5. The unrestricted minimum therefore lies in (4.99755, 5], with a gap of 49/20000 = 0.00245. The existing public submission at side 4.95 is [issue 1055](https://github.com/jlevy/squares/issues/1055).

The complete screen covers 53,361 ordered occupancy-mask pairs in 6,787 symmetry classes. It enumerates 15,017 matchings and retains 1,142. At 4.99755, the audit of exact executions checks 1,068 complete ownership exclusions, 47 root geometric proofs and 27 matchings requiring further geometric exclusions. The latter use 89 terminal exclusions. All 1,142 matchings are covered.

    python3 global/check_execution.py proofs/release4997550.json.gz proofs/ledger4997550.json.gz
    python3 global/verify_choice.py replay proofs/release4997550.json.gz fresh_global --jobs 3

The first command checks the saved native outputs, input identities and recorded geometric branches. The second rebuilds the computation from the pinned sources and recomputes individual exclusions. A separate proof recipe at 4.9975 passed all 1,142 matchings and reran 492 geometric terminals or tree nodes using previously rebuilt data and stored ownership results. Its receipt is runs/replay4997500_full.json. The exact original lower-bound claims from earlier checkpoints are retained below.

The final recipe carries forward 1,141 label exclusions from the earlier complete proof. Their recorded exclusion sides already reach the new target. It replaces the remaining 1 with a stronger geometric exclusion. Its exact target-specific receipt is runs/replay4997550_saved.json. A second native run of the one changed matching again excluded it with all four ownership choices unrestricted. Its receipt is runs/replay4997550_last_root.json.

The full side-five equality remains open. The last screen retains 1 candidate matching(s) at 4.998 and 44 in the strict side-five test. These counts describe candidates for further examination. No feasible packing below five was produced. geometry/isolated_translation.md describes a restriction on how the remaining marked-point assignments can change as the packing moves.

## Reproduce the unrestricted exclusions

Run these commands from the root of the extracted archive, using Python 3 with assertions enabled and a C++17 compiler.

    python3 base496/verify.py --offline base496/upstream --certificate base496/certificate.json --receipt replay496.json --jobs 4
    python3 verify497.py --offline base496/upstream --receipt replay497.json --jobs 4

The 4.96 clean replay passed all 53,361 ordered hole-pattern pairs. Its receipt is included. The separate 4.97 clean replay passed every case. Its receipt records 34,592 ordered pairs excluded by single patterns and 18,769 by 2,407 joint classes. The movement verifier certified 176 moved sites in 47 reflection classes. It also checked an explicit feasible 16-square control. The 4.97 reduction tests two Bentz 22-mark patterns related by a quarter turn. At the difficult pair of occupancy masks, it enumerates all consistent pairings and uses extra independently certified single-mark displacements. Each of four unselected marks can belong to an individual tile or be in no tile interior. Seven terminal exclusions in a nine-node tree exhaust the one pairing retained by the line and convexity tests. Each point required of a given tile is in its interior. See enumerator/central_replay.py for the exhaustive rules.

The earlier exact integer geometry and half-angle initialization use Mira Cult's work at revision 78bec6aacebf304d942a9225e16c2f18165778ff. Twenty upstream files are included with their Git blob identifiers authenticated by base496/prereqs.py. The primary unavoidable patterns come from Bentz. The profile checkers test a feasible 16-square control internally. The global sources used for comparison are the official [20-square record](https://squaremath.org/cases/20.html), [the 4.95 registration](https://github.com/jlevy/squares/issues/1055) and [the 21-square proof](https://evand.github.io/square-packing/s21/).


At side 5 the archive includes an independently reconstructed common-tilt obstruction with 41 polynomial certificates, a quadratic near-grid stability theorem for freely varying tilts, and a structural condition on every hypothetical sub-5 packing. Run python3 geometry/verify_parallel.py and python3 geometry/near_grid.py. Their scope is described in geometry/parallel.md, geometry/near_grid.md and geometry/integer_grid.md.

The complementary endpoint lane adds a fully unrestricted aggregate-tilt theorem.  If `u_i=cos(phi_i)+sin(phi_i)` for the twenty reduced tile angles, every strict side `S<5` packing must satisfy `sum u_i(u_i-1) >= 4(5-S)`, and therefore `sum phi_i >= 2(5-S)` radians.  This includes independent rotations, non-lattice centers and all contact degeneracies.  Run `python3 complementary_endpoint_0024/chord_capacity.py --output complementary_endpoint_0024/chord_capacity_receipt.json` and `python3 complementary_endpoint_0024/verify_chord_capacity.py complementary_endpoint_0024/chord_capacity_receipt.json`; the proof and directional extension are in `complementary_endpoint_0024/README.md`.

## Unrestricted result at 4.98

A clean replay at side 249/50 verified all 53,361 ordered choices, represented by 6,787 symmetry classes. The simple geometry closed 3,786 classes. Of the other 3,001 classes, 1,325 admitted no joint assignment. There were 5,255 assignments in the remaining classes. At initial propagation 5,184 closed. The 71 left required 851 ownership nodes. All 138 fully specified remaining alternatives were excluded. Twenty extra point patterns and 176 individually moved marks were checked over the full continuous angle range. This establishes s(20)>4.98 for independent translations and rotations, with the usual allowance for boundaries to touch. See proof498/README.md and runs/replay498.json. The direct side-5 search is separate.

## Result covering every common orientation

The exact minimum for twenty parallel unit squares is 5. Any nonzero common tilt relative to the board excludes even a closed board of side 5. This follows from 41 polynomial certificates near zero, 7,360 finite geometric exclusions over 31 middle-angle intervals, and 27 weighted covers up to 45°. The separate standard-library verifier replays the entire restricted theorem. See geometry/all_parallel.md, geometry/check_common.py and runs/common_verified.json.

The boundary-strip result in geometry/boundary_sweep.md applies without any restriction on relative angles. In a board of side below 5, at most four tiles can come within √2−1 of any specified wall. At least four whole tiles must therefore lie in the square obtained by removing strips of that thickness at all four walls.


## Higher side lengths and the endpoint search

A clean replay established the unrestricted inequality s(20)>997/200=4.985. The 4.99 assignment screen checked 53,361 ordered primary mask pairs in 6,787 symmetry classes. It returned 5,391 matchings before root filtering and 250 after it. At 4.985, 163 of those 250 closed at the first test, 60 closed after angular refinement and the remaining 27 closed in a total of 555 ownership nodes. There were zero open cases. The receipts are runs/screen499.json and runs/replay4985.json. A separate discovery calculation at 4.99 also exhausted those 250 assignments. Its coarse tests left 25 fully specified alternatives. A new exact angular-frame test excluded 21, and its finer settings excluded the last four. See runs/discovery499.json. An independent cold rebuild now certifies s(20)>499/100 = 4.99. It regenerated 231 geometric profiles and all 250 surviving matchings. The root checks eliminated 210 matchings. The ownership search visited 1,418 nodes and left 25 terminal alternatives. Higher-resolution geometric tests excluded all 25. A second replay using the compressed proof recipe also covered every one of the 250 matchings. Its exact counts are in runs/replay4990.json.

The transfer argument including ties and contact degeneracies is in geometry/transfer.md. The upper-side screen can be regenerated from the pinned upstream sources. The lower-side replay verifies every moved mark and auxiliary pattern, rebuilds all 231 profiles and rechecks each surviving labelled assignment. A packing at a smaller side would retain its two nearest-mark labels when its centers and its marks are scaled together to the larger board. The quantitative replay reopens all four ownership choices at the new side. The terminal refinement contracts the possible center polygon in a rational midpoint frame, excludes the union of the forbidden open regions, and propagates the resulting shapes. An independent exact-rational implementation audits selected terminal charts.

    python3 global/verify_screen.py 4990000 fresh499screen --jobs 4
    python3 global/verify_cap.py 4985000 proofs/cap4985000 fresh4985 fresh499screen --jobs 4
    python3 global/verify_cap.py 4990000 proofs/cap4990000 fresh4990 fresh499screen --jobs 4
    python3 global/verify_refinements.py fresh4990 --jobs 2
    python3 global/verify_stronger.py fresh4990 --jobs 2

To reproduce the compressed proof from the pinned sources in one command, run

    python3 global/verify_choice.py replay proofs/choice4990000.json.gz fresh499choice --jobs 4

The geometry in geometry/lattice_kernel.md identifies a fixed region inside each of at least four different tiles in every hypothetical sub-5 packing. Its exact shape is the intersection of the four unit disks centered at the corners of an assigned unit lattice cell. The five-band classification in geometry/small_tilt_cells.md allows independent rotations up to 10.8831° and gives 120 vacancy permutations when all twenty angles fall in that range. The screen at side 5 admits a limiting grid with a vacancy permutation in just 25 of its 1,142 surviving labelled assignments. The remaining possibilities include nongrid configurations.


## Stability for small independent angles

The note geometry/global_small_tilt.md proves a global estimate using only the maximum absolute tile tilt e, in radians. For e at most 1/10 it gives 5−S ≤ (99/5+15e)e² in any hypothetical packing of side S below five. Sorting the centers by their long chords forces them into four-per-row and four-per-column rank groups. Consequently any sequence of sub-5 packings with all angles tending to zero must converge along a subsequence to one of the 120 permutation vacancy patterns. At maximum tilt one degree the rigorous lower side bound exceeds 4.99388387. This estimate alone allows positive improvements of quadratic order.

The five representative angular-frame exclusions in runs/frame_traces are replayed in exact fractions, using a separate half-plane subtraction algorithm, by running python3 advanced/check_frame.py runs/frame_traces/*.txt.gz. The independent reference also checked 1,206 polygon-union controls, including complements reduced to a segment or a single point. The native positive controls preserved all twenty centers and orientations in ten test configurations and resolutions.


## Unrestricted result at 4.995

The cold verifier excludes side 999/200 = 4.995 for twenty freely rotated unit squares. It starts from the side-five screen over all 53,361 ordered mask pairs. That screen enumerated 15,017 matchings and retained 1,142. At 4.995, 983 matchings closed at the first root check and 61 more after angular refinement. The ownership search visited 2,927 nodes. It left 112 fully specified alternatives in 42 matchings. All 112 closed in the independent geometric refinements. The alternative compressed recipe also passed for every matching. It used 975 ownership exclusions, 135 root-frame exclusions and 32 refined ownership trees. Its replay rechecked 266 frame terminals or tree nodes. See runs/replay4995.json.

    python3 global/verify_choice.py replay proofs/choice4995000.json.gz fresh4995choice --jobs 4

The fixed-angle result in geometry/axis_diagonal.md permits an independent choice of 0 or 45 degrees for each of the twenty squares. Its minimum is exactly 5. In addition, any hypothetical packing beating 5 must contain a tile whose tilt from the nearest board axis is strictly less than twice arctan(1/24), about 4.772 degrees. The cold replay for this statement examined all 1,142 assignments and closed all nine remaining ownership alternatives under the angular restriction. These theorems address different classes of packings.

    python3 global/band_cases.py 1/24,23/25 --jobs 3 --screen fresh500screen --cold fresh500geometry --label reproduced_far24
    python3 global/refine_bands.py reproduced_far24 1/24,23/25 reproduced_far24 --jobs 2 --cold fresh500geometry

The last two commands use the endpoint geometry produced by the commands in geometry/axis_diagonal.md. See runs/tilt_24_verified.json for the exact counts. The signed-angle estimate in geometry/turning_orders.md gives additional constraints on small independent tilts.

## An exact endpoint for independently reflected tilts

The minimum side is exactly 5 if the twenty tiles have the same absolute tilt and each may independently choose its sign. This includes every common magnitude from 0 to 45 degrees. The proof in geometry/equal_magnitude.md combines an unrestricted large-angle exclusion with 117 exact polynomial certificates for 26,611 candidate small-angle separation graphs. An independent Boolean formulation passed all 550 coverage checks. The unrestricted lower bound and this restricted endpoint answer different questions.

    python3 geometry/verify_equal_magnitude.py proofs/equal_tilt_through_24.json.gz --Q 24 --exact-paths
    python3 geometry/check_equal_boolean.py proofs/equal_tilt_through_24.json.gz --Q 24 --jobs 4

## Angular diversity with twenty independent rotations

For an unrestricted packing of side below 5, let α and β be the smallest and largest absolute tilts relative to the board axes. The proof gives β−α > (9/10)tan²(β/2), with angles in radians. See geometry/angle_diversity.md for the geometric reduction and both verification commands. All 31,465 candidate small-angle graphs were excluded. Across the full angle range any strictly improving packing needs both a sufficiently oblique tile relative to its least tilted tile and a tile within 4.772 degrees of the axes.

## Independent tilt magnitudes and one aligned tile

For any twenty freely rotating squares beating side 5, the spread between the smallest and largest absolute tilts in radians satisfies β−α>2 tan²(β/2). The geometric reduction, exact counts and three replay commands are in geometry/angle_diversity.md. The independent graph encoding excluded all 583 sign or separation instances.

If one square is board-aligned and each of the other nineteen independently chooses +θ or −θ with 0≤tan(θ/2)≤1/24, a side below five is impossible. A standalone exact replay verifies 273,584 separation graphs using the 576-certificate bank. The independent Boolean and difference-logic formulation returned UNSAT on 6,071 cases. See geometry/one_axis_equal.md for both replay commands, and runs/one_axis24_standalone_verified.json and runs/one_axis24_boolean_verified.json for the counts.


The sharpened continuous-angle argument proves β−α>(1051/500)tan²(β/2). At least one tile is within 2 arctan(5/123), approximately 4.65563 degrees, of a board axis. Geometry and exact arithmetic for both conclusions appear in geometry/angle_diversity.md. A separate center-counting argument in geometry/diagonal_tilt_count.md proves that at least two tiles have absolute tilts below 2 arctan(19/48), approximately 43.19 degrees.
