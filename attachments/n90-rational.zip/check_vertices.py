"""Independent convex-polygon check of rational wall containment and pair separation."""
import gzip,json,sys
from fractions import Fraction as Q
from pathlib import Path
def replay(path):
    d=json.loads(gzip.decompress(path.read_bytes()));L=Q(d['side'])
    assert L>0 and len(d['squares'])==d['n']
    squares=[]
    for X,Y,T in d['squares']:
        x,y,t=map(Q,(X,Y,T));u=(1-t*t)/(1+t*t);v=2*t/(1+t*t)
        verts=[(x+(a*u-b*v)/2,y+(a*v+b*u)/2) for a,b in [(-1,-1),(1,-1),(1,1),(-1,1)]]
        assert all(0<=p<=L and 0<=q<=L for p,q in verts)
        proj=list(zip(*verts));bounds=[(min(v),max(v)) for v in proj];squares.append((verts,bounds))
    def outside(a,b):
        for (x,y),(X,Y) in zip(a,a[1:]+a[:1]):
            if all((X-x)*(q-y)<=(Y-y)*(p-x) for p,q in b):return True
        return False
    for i,(p,box) in enumerate(squares):
        for q,B in squares[:i]:
            if any(a>=D or c>=b for (a,b),(c,D) in zip(box,B)):continue
            assert outside(p,q) or outside(q,p),(d['n'],i)
    print('PASS',d['n'],d['n']*(d['n']-1)//2,flush=True)
if __name__=='__main__':
    assert __debug__
    for name in sys.argv[1:]:replay(Path(name))
