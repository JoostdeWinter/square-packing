"""Certify the smallest common scale of fixed rational centers and rebox the layout."""
from fractions import Fraction as Q
from pathlib import Path
from hashlib import sha256
import argparse,gzip,json
def read(p):return json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())
def parse(p):
    out=[]
    for row in p['squares']:
        x,y,t=map(Q,row) if isinstance(row,list) else (Q(row[k]) for k in ('cx','cy','t'))
        c=(1-t*t)/(1+t*t);s=2*t/(1+t*t)
        out.append((x,y,t,c,s,(abs(c)+abs(s))/2))
    assert len(out)==p['n']
    return out
def threshold(p):
    scale=Q(9,10)
    for i,(x,y,t,c,s,h) in enumerate(p):
        for X,Y,T,C,S,H in p[:i]:
            dx,dy=x-X,y-Y
            if max(abs(dx),abs(dy))*scale>=h+H:continue
            available=2*max(abs(dx*c+dy*s),abs(dx*s-dy*c),abs(dx*C+dy*S),abs(dx*S-dy*C))
            need=1+abs(c*C+s*S)+abs(c*S-s*C)
            scale=max(scale,need/available)
    return scale
def box(p,k):
    xl=min(k*x-h for x,y,t,c,s,h in p);yl=min(k*y-h for x,y,t,c,s,h in p)
    side=max(max(k*x+h-xl,k*y+h-yl) for x,y,t,c,s,h in p)
    return side,[[str(k*x-xl),str(k*y-yl),str(t)] for x,y,t,c,s,h in p]
def verify(record):
    p=parse(record);L=Q(record['side'])
    assert all(h<=x<=L-h and h<=y<=L-h for x,y,t,c,s,h in p)
    assert threshold(p)<=1
def main():
    parser=argparse.ArgumentParser();parser.add_argument('input',type=Path);parser.add_argument('--out',type=Path);a=parser.parse_args()
    if not __debug__:raise RuntimeError('Enable assertions')
    data=read(a.input)
    if not a.out:verify(data);print('verified',data['n']);return
    p=parse(data);scale=threshold(p);L,rows=box(p,scale);old=Q(data['side'])
    if L>=old:print('no gain',data['n'],flush=True);return
    rec=dict(n=len(rows),side=str(L),squares=rows,center_scale=str(scale),original_side=str(old),gain=str(old-L),input_sha256=sha256(a.input.read_bytes()).hexdigest(),reboxing_only=scale==1)
    verify(rec)
    a.out.write_bytes(gzip.compress(json.dumps(rec).encode(),mtime=0));print('PASS',len(rows),'improvement',float(old-L),'scale change',float(1-scale),flush=True)
if __name__=='__main__':main()
